/* brw_verdict.h: `brownian_bench verdict` (Lane D5). Turns the scored records of one experiment into per-item
 * acceptance results and one experiment verdict, exactly as the frozen spec sections 13, 14, 15, 19 and 21 define.
 * Private, sealed. C only. Every numeric band is read at run time from the thresholds sidecar (brw.thr.v1, digest
 * checked against the qprofile) or is a value literally written in the spec text (cited at the use). An item the
 * spec requires but for which neither source gives a number, program bytes or a stored quantity is NOT_COMPUTABLE
 * with a reason; nothing is guessed. */
#ifndef BRW_VERDICT_H
#define BRW_VERDICT_H
#include <stddef.h>
#include <stdint.h>
#include "brw_protocol.h"
#include "brw_tps.h"

typedef enum { BRW_VD_PASS = 0, BRW_VD_FAIL = 1, BRW_VD_NC = 2, BRW_VD_DESC = 3 } brw_vd_res;
typedef enum { BRW_VD_V_PASS = 0, BRW_VD_V_FAIL = 1, BRW_VD_V_STOPPED = 2, BRW_VD_V_INCOMPLETE = 3 } brw_vd_verdict;

typedef struct {
    char id[24];          /* s13.1, s14.B1-3.4, s15.I-far ... (ladder ids of R3-35 G8) */
    char cell[24];
    char text[96];        /* what the item says */
    brw_vd_res res;
    int required;         /* 0 = descriptive row, never changes the verdict */
    int stop_no;          /* stop condition of spec section 19 this item tripped (0 = none) */
    char measured[512];
    char band[512];
    char why[512];        /* NOT_COMPUTABLE reason, or a note */
    char gains[200];      /* first 8 hex digits of the qgain digests used */
} brw_vd_item;

typedef struct { int no; int state; char text[160]; char why[8192]; } brw_vd_stop;   /* state 0 clear, 1 hit, 2 not evaluated */

#define BRW_VD_MAXITEMS 96
#define BRW_VD_MAXSTOPS 24
typedef struct {
    char experiment[16];
    brw_vd_item it[BRW_VD_MAXITEMS]; size_t n;
    brw_vd_stop st[BRW_VD_MAXSTOPS]; size_t nst;
    brw_vd_verdict verdict;
    char rule[900];
    /* the INT phase is a separate rung and never changes the observational verdict (spec section 15 last paragraph) */
    brw_vd_verdict int_verdict; int has_int;
} brw_vd_report;

/* per-cell counts recomputed from the stored worlds: reference intervals (spec 8, brw_stats.h) against the hidden true parameters */
typedef struct {
    int have; uint32_t n;
    uint32_t cov_d, cov_mu, excl0, below0;
    char why[160];         /* when !have */
} brw_vd_wstats;
typedef struct { char cell[24]; brw_vd_wstats s; } brw_vd_cellstats;

typedef struct {
    const tyqr_gain *g; const ty_digest *gd; size_t ng;
    const tyqr_freeze *fr; const ty_digest *fd;
    const tyqr_profile *pr;
    const brw_vd_cellstats *cs; size_t ncs;
    const char *thr; size_t thrlen;                 /* thresholds sidecar bytes (already digest-checked) */
    const brw_tps_gain_res *tps; size_t ntps;       /* stop 27: TPS1 sidecar result per qgain record (tps[k] belongs to g[k], k < ntps); NULL = not evaluated */
} brw_vd_in;

/* value of `<item> <field> <value>` in a brw.thr.v1 buffer; 0 found, -1 absent */
int brw_vd_thr_get(const char *buf, size_t len, const char *item, const char *field, char *val, size_t cap);
/* the counts for W worlds given their hidden parameters (one per world). D interval: brw_d_interval (Y = X); mu interval: brw_mu_interval */
int brw_vd_stats_from(const brw_cellinfo *ci, const brw_traj *tr, const brw_params *par, size_t W, brw_vd_wstats *out);
/* regenerates the hidden parameters exactly as brw_leak_check does (label "seal", block 0, parent from the qfreeze digest), then brw_vd_stats_from */
int brw_vd_world_stats(const brw_cellinfo *ci, const brw_traj *tr, size_t W, const ty_digest *qfreeze, brw_vd_wstats *out, char *why, size_t cap);
/* item 9 (spec 13): qgain of the h = 1 DIFFUSION variant (candidate opcode BRW_OP_VARIANT_H1) against DIFFUSION on the given B0-irregular worlds; 0, or the brw_gain_compute code (FAIL_LEAK, FAIL_FLOOR give a STOPPED record) */
int brw_vd_variant_gain(const brw_cellinfo *ci, const brw_traj *tr, size_t W, const tyqr_profile *pr, const ty_digest *pd, const tyqr_freeze *fr, const ty_digest *fd,
                        const tyqr_world *wo, const ty_digest *wd, tyqr_gain *g, char *why, size_t cap);
/* evaluate one experiment ("EXP-002A", "EXP-002B" or "EXP-002C"); 0 or TYQ_E_ARG */
int brw_vd_evaluate(const brw_vd_in *in, const char *experiment, brw_vd_report *rep);
/* deterministic text rendering (brw.verdict.v1); the record is this text, named verdict.<sha256 hex>.txt */
int brw_vd_render(const brw_vd_report *rep, const tyqr_profile *pr, const ty_digest *pd, const ty_digest *fd, char *out, size_t cap, size_t *len);
const char *brw_vd_res_name(brw_vd_res r);
const char *brw_vd_verdict_name(brw_vd_verdict v);

typedef struct {
    const char *experiment, *thresholds, *outdir;
    const char *dirs[8]; size_t ndirs;               /* run directories: qgain, qworld + trajectories, qfreeze, qprofile */
} brw_vd_args;
/* the CLI body: loads and digest-checks every record, refuses (FAIL_PROFILE) on a thresholds digest mismatch,
 * evaluates, prints the lines to stdout, writes the verdict record O_EXCL 0444. Returns 0 when a verdict was produced
 * (whatever it is: a FAIL is a valid result, spec 21), else a TYQ_* refusal with `why`. */
int brw_verdict_run(const brw_vd_args *a, brw_vd_verdict *v, char *record_path, size_t pcap, char *why, size_t cap);
#endif

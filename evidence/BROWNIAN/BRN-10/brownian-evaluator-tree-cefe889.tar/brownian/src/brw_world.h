/* brw_world.h: exact-transition world generator (plan §7, §8, §12-§14, §18, §28.2). */
#ifndef BRW_WORLD_H
#define BRW_WORLD_H
#include <stddef.h>
#include <stdint.h>
#include "brw_rng.h"

typedef enum { BRW_FAM_D0 = 0, BRW_FAM_D1 = 1, BRW_FAM_D2 = 2 } brw_family;
typedef enum { BRW_GRID_REGULAR = 0, BRW_GRID_IRREGULAR = 1 } brw_grid;
typedef enum {
    BRW_OBS_EXACT = 0, BRW_OBS_MEAS_NOISE, BRW_OBS_T4_INNOV, BRW_OBS_OUTLIER,
    BRW_OBS_MISSING, BRW_OBS_AFFINE
} brw_obs_mode;                      /* hostile modes: parameters per Appendix OI-9 */

typedef struct { double D, mu, theta, sigma; double aff_c, aff_b; } brw_params;   /* evaluator-only; aff_c/aff_b: H-affine y = aff_c*x + aff_b (1, 0 elsewhere) */

typedef struct {
    const char *name;                /* e.g. "B0-regular" */
    brw_family family; brw_grid grid; brw_obs_mode obs;
    uint32_t n_points, split;
    double snr_s;                    /* B1 only: mu = s*sqrt(2D/255) */
    double theta, sigma;             /* D2 only */
    int x0_fixed; double x0;         /* B2 D2 cells: x0 = 0 */
    int d_fixed; double d_value;     /* H-boundary-D: D = 0.05 */
    double obs_p;                    /* H-outlier 0.01, H-missing 0.1, else 0 */
    /* EXP-002C-INT set-state construction (R3-36): 0 for every other cell. set_state = 1: x[split - 1] is SET to set_x (the point is observed but
     * never scored), x_0 = x0_sd * N(0,1) when x0_sd > 0 and x0_fixed = 0; `split` is then the first SCORED index, the fit prefix is split - 1 points. */
    int set_state; double set_x; double x0_sd;
} brw_cell_spec;

typedef struct { uint64_t count; double *t; int64_t *k; } brw_traj;

typedef int (*brw_transition_fn)(brw_family f, const brw_params *p, double x, double h,
                                 double *mean, double *var);

int  brw_cell_lookup(const char *name, brw_cell_spec *out);
int  brw_transition(brw_family f, const brw_params *p, double x, double h,
                    double *mean, double *var);       /* exact law; refuses theta <= 0 for D2, h <= 0 */
int  brw_check_transition_kats(brw_transition_fn fn); /* D2 mean + small-step KATs; used by BI tests */
int  brw_quantize(double x, int64_t *k);              /* floor(x * 2^20); BRW_E_RANGE if |x| >= 2^31 */
double brw_symbol_value(int64_t k);                   /* (k + 0.5) * 2^-20 */
int  brw_world_generate(const brw_cell_spec *cell, const uint8_t world_seed[32],
                        brw_traj *out, brw_params *hidden_out);
void brw_traj_free(brw_traj *t);
/* number of rows of tr in the prefix: cs->split, or on the missing-rows cell the kept rows with original index < cs->split */
uint32_t brw_world_split(const brw_cell_spec *cs, const brw_traj *tr);
/* number of prefix rows the candidate is fitted on: brw_world_split, minus the set-state point on an INT/CTL cell (fit prefix 128, first scored 129) */
uint32_t brw_world_fit_split(const brw_cell_spec *cs, const brw_traj *tr);
#endif

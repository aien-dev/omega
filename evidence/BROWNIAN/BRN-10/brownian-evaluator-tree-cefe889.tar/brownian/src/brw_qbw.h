#ifndef BRW_QBW_H
#define BRW_QBW_H
#include <stddef.h>
#include <stdint.h>
#include "brw_world.h"
int brw_qbw_encode(const brw_traj *t, uint8_t **buf, size_t *len);
int brw_qbw_decode(const uint8_t *buf, size_t len, brw_traj *out);  /* §8 refusals */
int brw_qbw_write_excl(const char *path, const brw_traj *t);         /* O_CREAT|O_EXCL, 0444 */
int brw_qbw_read(const char *path, brw_traj *out);
#endif

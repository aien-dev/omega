/* brw_dl.c -- BRW-DL v0: assembler, checker, interpreter (private, sealed). C99 + libm only.
 * Build: cc -O2 -std=gnu11 -ffp-contract=off -o brw_dl brw_dl.c -lm
 * Use:   brw_dl asm  prog.brwdl [out.bin]   text -> canonical bytes; prints bytes, k, sha256
 *        brw_dl info prog.brwdl
 *        brw_dl run  prog.brwdl world.txt S text -> loc/scale per held-out step (world.txt: "t y" lines)
 *        brw_dl memo pairs.txt              pairs "t y" -> program text (stored-pairs memorizer)
 * Spec: BRW_DL_SPEC.md (byte-exact). Rounding: no fused multiply-add (-ffp-contract=off). */
#define _POSIX_C_SOURCE 200809L
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "brw_dl.h"

/* ---------------- opcode table ---------------- */
typedef struct { const char *name; uint8_t op; } OpName;
static const OpName OPS[] = {
    {"add",0x30},{"sub",0x31},{"mul",0x32},{"div",0x33},{"neg",0x34},{"exp",0x35},{"log",0x36},
    {"sqrt",0x37},{"expm1",0x38},{"abs",0x39},{"min",0x3A},{"max",0x3B},{"lt",0x3C},{"le",0x3D},
    {"sel",0x3E},{"dup",0x40},{"swap",0x41},{"drop",0x42},{"over",0x43},
    {"now",0x50},{"gap",0x51},{"prevt",0x52},{"idx",0x53},{"obs",0x54},{"prevobs",0x55},
    {"count",0x56},{"countinc",0x57},{"first_t",0x58},{"last_t",0x59},{"first_y",0x5A},{"last_y",0x5B},
    {"emit_normal",0xE0},
};
#define NOPS ((int)(sizeof OPS / sizeof OPS[0]))
static const char *opname(uint8_t op) { for (int i = 0; i < NOPS; i++) if (OPS[i].op == op) return OPS[i].name; return NULL; }
static int isknown(uint8_t op) {
    return op <= 0x23 || opname(op) || op == 0x60 || op == 0x61 || (op >= 0x64 && op <= 0x67) ||
           (op >= 0x80 && op <= 0xA3);
}

/* ---------------- byte buffer + LEB128 ---------------- */
typedef struct { uint8_t b[BRW_MAXBYTES + 16]; int n; int over; } Buf;
static void put(Buf *B, uint8_t x) { if (B->n >= BRW_MAXBYTES) { B->over = 1; return; } B->b[B->n++] = x; }
static void putleb(Buf *B, unsigned v) { do { uint8_t x = v & 0x7f; v >>= 7; if (v) x |= 0x80; put(B, x); } while (v); }
static int getleb(const uint8_t *c, int n, int *pos, unsigned *out) {
    unsigned v = 0; int sh = 0, st = *pos;
    for (;;) {
        if (*pos >= n || sh > 21) return -1;
        uint8_t x = c[(*pos)++]; v |= (unsigned)(x & 0x7f) << sh; sh += 7;
        if (!(x & 0x80)) { if (x == 0 && *pos - st > 1) return -1; break; } /* non-shortest */
    }
    *out = v; return 0;
}

/* canonical literal encoding: shortest exact form */
static void put_literal(Buf *B, double d) {
    if (!signbit(d) && d >= 0 && d <= 31 && d == floor(d)) { put(B, (uint8_t)d); return; }
    if (!signbit(d) && d >= 32 && d <= 255 && d == floor(d)) { put(B, 0x20); put(B, (uint8_t)d); return; }
    if (d <= -1 && d >= -255 && d == floor(d)) { put(B, 0x21); put(B, (uint8_t)(-d)); return; }
    float f = (float)d;
    if ((double)f == d) { put(B, 0x22); uint8_t x[4]; memcpy(x, &f, 4); for (int i = 0; i < 4; i++) put(B, x[i]); return; }
    put(B, 0x23); uint8_t x[8]; memcpy(x, &d, 8); for (int i = 0; i < 8; i++) put(B, x[i]);
}

/* ---------------- assembler ---------------- */
typedef struct { const char *s; int pos; char err[160]; } Asm;
static int nexttok(Asm *A, char *tok, int cap) {
    for (;;) {
        while (A->s[A->pos] == ' ' || A->s[A->pos] == '\t' || A->s[A->pos] == '\n' || A->s[A->pos] == '\r') A->pos++;
        if (A->s[A->pos] == ';') { while (A->s[A->pos] && A->s[A->pos] != '\n') A->pos++; continue; }
        break;
    }
    char ch = A->s[A->pos];
    if (!ch) return 0;
    if (ch == '{' || ch == '}') { tok[0] = ch; tok[1] = 0; A->pos++; return 1; }
    int n = 0;
    while (A->s[A->pos] && !strchr(" \t\r\n{};", A->s[A->pos])) { if (n < cap - 1) tok[n++] = A->s[A->pos]; A->pos++; }
    tok[n] = 0; return 1;
}
static int asm_err(Asm *A, const char *m, const char *t) { snprintf(A->err, sizeof A->err, "%s '%s'", m, t); return -1; }
static int parse_reg(const char *t, char pre, int max) {
    if (t[0] != pre || !t[1]) return -1;
    char *e; long v = strtol(t + 1, &e, 10);
    return (*e || v < 0 || v > max) ? -1 : (int)v;
}
static int asm_block(Asm *A, Buf *B, int top);
static int asm_open(Asm *A, Buf *out, int wrapped) { /* expects '{', assembles block, emits [len] body */
    char tok[64];
    if (!nexttok(A, tok, 64) || strcmp(tok, "{")) return asm_err(A, "expected {, got", tok);
    Buf *tmp = calloc(1, sizeof(Buf));
    int r = asm_block(A, tmp, 0);
    if (r == 0) {
        if (tmp->over) r = asm_err(A, "block too large", "");
        else { if (wrapped) putleb(out, (unsigned)tmp->n); for (int i = 0; i < tmp->n; i++) put(out, tmp->b[i]); }
    }
    free(tmp); return r;
}
static int asm_block(Asm *A, Buf *B, int top) {
    char tok[64]; (void)top;
    while (nexttok(A, tok, 64)) {
        if (!strcmp(tok, "}")) return 0;
        if (!strcmp(tok, "{")) return asm_err(A, "unexpected", tok);
        if (!strcmp(tok, "sum_pts") || !strcmp(tok, "sum_inc")) {
            put(B, tok[4] == 'p' ? 0x60 : 0x61);
            if (asm_open(A, B, 1)) return -1;
            continue;
        }
        if (!strcmp(tok, "load") || !strcmp(tok, "store")) {
            char t2[64]; if (!nexttok(A, t2, 64)) return asm_err(A, "missing register after", tok);
            int r = parse_reg(t2, 'r', 15); if (r < 0) return asm_err(A, "bad register", t2);
            put(B, (uint8_t)((tok[0] == 'l' ? 0x80 : 0x90) + r)); continue;
        }
        if (!strcmp(tok, "call")) {
            char t2[64]; if (!nexttok(A, t2, 64)) return asm_err(A, "missing function after", tok);
            int f = parse_reg(t2, 'f', 3); if (f < 0) return asm_err(A, "bad function", t2);
            put(B, (uint8_t)(0xA0 + f)); continue;
        }
        if (!strcmp(tok, "lsq")) {
            char t2[64]; if (!nexttok(A, t2, 64)) return asm_err(A, "lsq needs p", "");
            int p = atoi(t2); if (p < 1 || p > 4) return asm_err(A, "lsq p out of range", t2);
            if (!nexttok(A, t2, 64)) return asm_err(A, "lsq needs dst", "");
            int dst = parse_reg(t2, 'r', 15); if (dst < 0) return asm_err(A, "bad register", t2);
            put(B, (uint8_t)(0x63 + p)); put(B, (uint8_t)dst);
            for (int i = 0; i < p; i++) {
                if (!nexttok(A, t2, 64)) return asm_err(A, "lsq needs function", "");
                int f = parse_reg(t2, 'f', 3); if (f < 0) return asm_err(A, "bad function", t2);
                put(B, (uint8_t)f);
            }
            continue;
        }
        int found = 0;
        for (int i = 0; i < NOPS; i++) if (!strcmp(tok, OPS[i].name)) { put(B, OPS[i].op); found = 1; break; }
        if (found) continue;
        char *e; double d = strtod(tok, &e);
        if (*e || !isfinite(d)) return asm_err(A, "unknown token", tok);
        put_literal(B, d);
    }
    return 0;
}
int brwdl_assemble(const char *text, uint8_t *out, int *n, char *err, int errcap) {
    Asm A = {text, 0, {0}}; char tok[64]; Buf *B = calloc(1, sizeof(Buf)); int r = 0;
    Buf *funcs = calloc(1, sizeof(Buf)); int nf = 0;
    int seen_fit = 0, seen_pred = 0;
    Buf *fit = calloc(1, sizeof(Buf)), *prd = calloc(1, sizeof(Buf));
    while (!r && nexttok(&A, tok, 64)) {
        if (!strcmp(tok, "func")) { if (seen_fit || seen_pred || nf >= 4) r = asm_err(&A, "misplaced", tok); else { r = asm_open(&A, funcs, 1); nf++; } }
        else if (!strcmp(tok, "fit")) { if (seen_fit || seen_pred) r = asm_err(&A, "misplaced", tok); else { r = asm_open(&A, fit, 0); seen_fit = 1; } }
        else if (!strcmp(tok, "predict")) { if (!seen_fit || seen_pred) r = asm_err(&A, "misplaced", tok); else { r = asm_open(&A, prd, 0); seen_pred = 1; } }
        else r = asm_err(&A, "unexpected top-level", tok);
    }
    if (!r && !(seen_fit && seen_pred)) r = asm_err(&A, "need fit and predict blocks", "");
    if (!r) {
        putleb(B, (unsigned)nf); for (int i = 0; i < funcs->n; i++) put(B, funcs->b[i]);
        putleb(B, (unsigned)fit->n); for (int i = 0; i < fit->n; i++) put(B, fit->b[i]);
        putleb(B, (unsigned)prd->n); for (int i = 0; i < prd->n; i++) put(B, prd->b[i]);
        if (B->over || funcs->over || fit->over || prd->over) r = asm_err(&A, "program exceeds 4096 bytes", "");
    }
    if (r) { snprintf(err, errcap, "%s", A.err); }
    else { memcpy(out, B->b, B->n); *n = B->n; }
    free(B); free(funcs); free(fit); free(prd); return r;
}

/* ---------------- static checker (canonical form, contexts, stack, taint, k) ---------------- */
enum { X_FIT = 1, X_PTS = 2, X_INC = 4, X_COL = 8, X_PRED = 16 };
typedef struct {
    const uint8_t *c; int n;
    struct { int off, len; } fn[4]; int nf; int fitoff, fitlen, predoff, predlen;
    uint8_t rw[16], rtaint[16], predread[16], called[4];
    int sumdepth; char err[160];
} V;
static int verr(V *v, const char *m, int pos) { snprintf(v->err, sizeof v->err, "%s at byte %d", m, pos); return -1; }
static int vwalk(V *v, int off, int len, int ctx, int callok, uint8_t *outtaint);

static int vbody_expr(V *v, int off, int len, int ctx, int callok, uint8_t *taint) {
    /* an expression body: fresh stack, must leave exactly 1 value */
    return vwalk(v, off, len, ctx, callok, taint);
}
/* stack ops table: pops, pushes for simple ops */
static int simple_effect(uint8_t op, int *pops) {
    if (op <= 0x23) { *pops = 0; return 1; }
    switch (op) {
    case 0x30: case 0x31: case 0x32: case 0x33: case 0x3A: case 0x3B: case 0x3C: case 0x3D: *pops = 2; return 1;
    case 0x34: case 0x35: case 0x36: case 0x37: case 0x38: case 0x39: *pops = 1; return 1;
    case 0x3E: *pops = 3; return 1;
    case 0x40: *pops = 1; return 2; case 0x41: *pops = 2; return 2; case 0x42: *pops = 1; return 0; case 0x43: *pops = 2; return 3;
    default: *pops = 0; return 1; /* context reads */
    }
}
/* walk a body. Top-level fit/predict blocks are walked with the same routine; a 'top' block may end with
 * depth 0 (fit: everything stored; predict: after emit). Bodies (functions, loop bodies) must end at depth 1.
 * For the top blocks ctx is X_FIT / X_PRED and outtaint == NULL. */
static int vwalk(V *v, int off, int len, int ctx, int callok, uint8_t *outtaint) {
    const uint8_t *c = v->c; int pos = off, end = off + len, d = 0;
    uint8_t st[BRW_MAXSTACK + 8]; int top = (ctx == X_FIT || ctx == X_PRED) && outtaint == NULL;
    int emitted = 0;
    while (pos < end) {
        int at = pos; uint8_t op = c[pos++];
        if (!isknown(op)) return verr(v, "unknown opcode", at);
        if (emitted) return verr(v, "bytes after emit", at);
        int pops, pushes; uint8_t tin = 0;
        if (op <= 0x23) {
            if (op == 0x20) { if (pos >= end) return verr(v, "truncated", at); if (c[pos++] < 32) return verr(v, "non-canonical literal", at); }
            else if (op == 0x21) { if (pos >= end) return verr(v, "truncated", at); if (c[pos++] < 1) return verr(v, "non-canonical literal", at); }
            else if (op == 0x22) {
                if (pos + 4 > end) return verr(v, "truncated", at);
                float f; memcpy(&f, c + pos, 4); pos += 4; double dd = f;
                if (!isfinite(dd)) return verr(v, "non-finite literal", at);
                if (!signbit(dd) && dd <= 255 && dd == floor(dd)) return verr(v, "non-canonical literal", at);
                if (dd <= -1 && dd >= -255 && dd == floor(dd)) return verr(v, "non-canonical literal", at);
            } else if (op == 0x23) {
                if (pos + 8 > end) return verr(v, "truncated", at);
                double dd; memcpy(&dd, c + pos, 8); pos += 8;
                if (!isfinite(dd)) return verr(v, "non-finite literal", at);
                if ((double)(float)dd == dd) return verr(v, "non-canonical literal", at);
            }
            pops = 0; pushes = 1; st[d] = 0; /* fallthrough push handled below via tin */
            if (d + 1 > BRW_MAXSTACK) return verr(v, "stack overflow", at);
            st[d++] = 0; continue;
        }
        if (op >= 0x50 && op <= 0x5B) {
            int ok = 0;
            switch (op) {
            case 0x50: case 0x53: ok = ctx & (X_PTS | X_INC | X_COL | X_PRED); break;
            case 0x51: case 0x52: ok = ctx & (X_INC | X_PRED); break;
            case 0x54: ok = ctx & (X_PTS | X_INC); break;
            case 0x55: ok = ctx & (X_INC | X_PRED); break;
            default: ok = ctx & (X_FIT | X_PTS | X_INC | X_COL); break; /* prefix aggregates: fit time only */
            }
            if (!ok) return verr(v, "opcode not allowed in this context", at);
            uint8_t tn = 0;
            if (op == 0x54 || (op == 0x55 && (ctx & X_INC)) || op == 0x5A || op == 0x5B) tn = 1;
            if (d + 1 > BRW_MAXSTACK) return verr(v, "stack overflow", at);
            st[d++] = tn; continue;
        }
        if (op == 0x60 || op == 0x61) {
            if (ctx != X_FIT || !top) return verr(v, "loop only at top level of fit", at);
            unsigned bl; if (getleb(c, end, &pos, &bl) || bl == 0 || pos + (int)bl > end) return verr(v, "bad loop length", at);
            uint8_t tt = 0;
            if (vbody_expr(v, pos, (int)bl, op == 0x60 ? X_PTS : X_INC, 4, &tt)) return -1;
            pos += bl; if (d + 1 > BRW_MAXSTACK) return verr(v, "stack overflow", at);
            st[d++] = tt; continue;
        }
        if (op >= 0x64 && op <= 0x67) {
            int p = op - 0x63;
            if (ctx != X_FIT || !top) return verr(v, "lsq only at top level of fit", at);
            if (pos + 1 + p > end) return verr(v, "truncated", at);
            int dst = c[pos++];
            if (dst + p > 15) return verr(v, "lsq registers out of range", at);
            for (int i = 0; i < p; i++) {
                int f = c[pos++];
                if (f >= v->nf) return verr(v, "bad function id", at);
                v->called[f] = 1; uint8_t tt;
                if (vbody_expr(v, v->fn[f].off, v->fn[f].len, X_COL, f, &tt)) return -1;
            }
            for (int i = 0; i <= p; i++) { v->rw[dst + i] = 1; v->rtaint[dst + i] = 1; }
            continue;
        }
        if (op >= 0x80 && op <= 0x8F) {
            int r = op & 15;
            if (!v->rw[r]) return verr(v, "load of unwritten register", at);
            if (ctx & X_PRED) v->predread[r] = 1;
            if (d + 1 > BRW_MAXSTACK) return verr(v, "stack overflow", at);
            st[d++] = v->rtaint[r]; continue;
        }
        if (op >= 0x90 && op <= 0x9F) {
            if (ctx != X_FIT || !top) return verr(v, "store only at top level of fit", at);
            if (d < 1) return verr(v, "stack underflow", at);
            int r = op & 15; v->rw[r] = 1; v->rtaint[r] = st[--d]; continue;
        }
        if (op >= 0xA0 && op <= 0xA3) {
            int f = op & 3;
            if (f >= callok) return verr(v, "call must target a lower-numbered function", at);
            if (f >= v->nf) return verr(v, "bad function id", at);
            v->called[f] = 1; uint8_t tt;
            if (vbody_expr(v, v->fn[f].off, v->fn[f].len, ctx, f, &tt)) return -1;
            if (d + 1 > BRW_MAXSTACK) return verr(v, "stack overflow", at);
            st[d++] = tt; continue;
        }
        if (op == 0xE0) {
            if (ctx != X_PRED || !top) return verr(v, "emit only in predict", at);
            if (d != 2) return verr(v, "emit needs exactly two values on the stack", at);
            d = 0; emitted = 1; continue;
        }
        pops = 0; pushes = simple_effect(op, &pops);
        if (d < pops) return verr(v, "stack underflow", at);
        for (int i = 0; i < pops; i++) tin |= st[d - 1 - i];
        if (op == 0x40 || op == 0x41 || op == 0x43) { /* structural ops: keep per-slot taint */
            uint8_t a = st[d - 1], b = d >= 2 ? st[d - 2] : 0;
            if (op == 0x40) { st[d] = a; d++; }
            else if (op == 0x41) { st[d - 1] = b; st[d - 2] = a; }
            else { st[d] = b; d++; }
            if (d > BRW_MAXSTACK) return verr(v, "stack overflow", at);
            continue;
        }
        d -= pops;
        if (d + pushes > BRW_MAXSTACK) return verr(v, "stack overflow", at);
        for (int i = 0; i < pushes; i++) st[d++] = tin;
    }
    if (top) {
        if (ctx == X_PRED && !emitted) return verr(v, "predict must end with emit_normal", end);
        if (d != 0) return verr(v, "fit must leave an empty stack", end);
    } else {
        if (d != 1) return verr(v, "body must leave exactly one value", end);
        *outtaint = st[0];
    }
    return 0;
}
int brwdl_check(const uint8_t *code, int n, BrwInfo *info, char *err, int errcap) {
    V v; memset(&v, 0, sizeof v); v.c = code; v.n = n;
    memset(info, 0, sizeof *info);
    if (n < 3 || n > BRW_MAXBYTES) { snprintf(err, errcap, "size out of range"); return -1; }
    int pos = 0; unsigned u;
    if (getleb(code, n, &pos, &u) || u > 4) { snprintf(err, errcap, "bad function count"); return -1; }
    v.nf = (int)u;
    for (int i = 0; i < v.nf; i++) {
        if (getleb(code, n, &pos, &u) || u == 0 || pos + (int)u > n) { snprintf(err, errcap, "bad function length"); return -1; }
        v.fn[i].off = pos; v.fn[i].len = (int)u; pos += u;
    }
    if (getleb(code, n, &pos, &u) || pos + (int)u > n) { snprintf(err, errcap, "bad fit length"); return -1; }
    v.fitoff = pos; v.fitlen = (int)u; pos += u;
    if (getleb(code, n, &pos, &u) || u == 0 || pos + (int)u > n) { snprintf(err, errcap, "bad predict length"); return -1; }
    v.predoff = pos; v.predlen = (int)u; pos += u;
    if (pos != n) { snprintf(err, errcap, "trailing bytes"); return -1; }
    if (vwalk(&v, v.fitoff, v.fitlen, X_FIT, 4, NULL)) { snprintf(err, errcap, "%s", v.err); return -1; }
    if (vwalk(&v, v.predoff, v.predlen, X_PRED, 4, NULL)) { snprintf(err, errcap, "%s", v.err); return -1; }
    for (int i = 0; i < v.nf; i++) if (!v.called[i]) { snprintf(err, errcap, "function %d never called", i); return -1; }
    int k = 0; for (int r = 0; r < 16; r++) if (v.rtaint[r] && v.predread[r]) k++;
    info->bytes = n; info->k = k; info->nfuncs = v.nf;
    info->fitoff = v.fitoff; info->fitlen = v.fitlen; info->predoff = v.predoff; info->predlen = v.predlen;
    for (int i = 0; i < v.nf; i++) { info->fnoff[i] = v.fn[i].off; info->fnlen[i] = v.fn[i].len; }
    return 0;
}

/* ---------------- interpreter ---------------- */
typedef struct {
    const uint8_t *c; const BrwInfo *in;
    const double *t, *y; int S;
    double reg[16];
    double tcur, tprev, ycur, yprev; int idxcur;
    long steps, budget; int fail; const char *why;
} R;
static int rfail(R *r, const char *w) { r->fail = 1; r->why = w; return -1; }
static int rexec(R *r, int off, int len, int ctx, double *res, double *out2);
static int chk(R *r, double x) { if (!isfinite(x)) return rfail(r, "non-finite value"); return 0; }

static int lsq_run(R *r, int p, int dst, const int *fid) {
    int S = r->S; if (S < p) return rfail(r, "lsq: fewer points than columns");
    double *col = malloc(sizeof(double) * S * (p + 1) * 2); if (!col) return rfail(r, "oom");
    double *orig = col + (size_t)S * (p + 1); /* copy of the columns */
    int rc = 0;
    for (int k = 0; k < p && !rc; k++)
        for (int j = 0; j < S && !rc; j++) {
            r->tcur = r->t[j]; r->idxcur = j; double val;
            if (rexec(r, r->in->fnoff[fid[k]], r->in->fnlen[fid[k]], X_COL, &val, NULL)) rc = -1;
            else col[(size_t)k * S + j] = val;
        }
    if (rc) { free(col); return -1; }
    for (int j = 0; j < S; j++) col[(size_t)p * S + j] = r->y[j];
    memcpy(orig, col, sizeof(double) * S * p);
    double Rm[4][4]; memset(Rm, 0, sizeof Rm), (void)0;
    double rhs[4] = {0, 0, 0, 0};
    double *vv = malloc(sizeof(double) * S);
    for (int cc = 0; cc < p; cc++) {
        double *x = col + (size_t)cc * S; double nn = 0;
        for (int q = cc; q < S; q++) nn += x[q] * x[q];
        double norm = sqrt(nn);
        if (!(norm > 0) || !isfinite(norm)) { free(col); free(vv); return rfail(r, "lsq: rank deficient"); }
        double alpha = -copysign(norm, x[cc]);
        for (int q = cc; q < S; q++) vv[q] = x[q];
        vv[cc] = x[cc] - alpha;
        double vtv = 0; for (int q = cc; q < S; q++) vtv += vv[q] * vv[q];
        if (!(vtv > 0) || !isfinite(vtv)) { free(col); free(vv); return rfail(r, "lsq: degenerate reflector"); }
        for (int k = cc + 1; k <= p; k++) {
            double *z = col + (size_t)k * S, s = 0;
            for (int q = cc; q < S; q++) s += vv[q] * z[q];
            double f = 2 * s / vtv;
            for (int q = cc; q < S; q++) z[q] -= f * vv[q];
        }
        Rm[cc][cc] = alpha;
        for (int k = cc + 1; k < p; k++) Rm[cc][k] = col[(size_t)k * S + cc];
        rhs[cc] = col[(size_t)p * S + cc];
    }
    double beta[4];
    for (int q = p - 1; q >= 0; q--) {
        double s = rhs[q];
        for (int k = q + 1; k < p; k++) s -= Rm[q][k] * beta[k];
        if (Rm[q][q] == 0) { free(col); free(vv); return rfail(r, "lsq: singular"); }
        beta[q] = s / Rm[q][q];
        if (chk(r, beta[q])) { free(col); free(vv); return -1; }
    }
    double rss = 0;
    for (int j = 0; j < S; j++) {
        double fit = orig[j] * beta[0];
        for (int k = 1; k < p; k++) fit += orig[(size_t)k * S + j] * beta[k];
        double e = r->y[j] - fit; rss += e * e;
    }
    for (int k = 0; k < p; k++) r->reg[dst + k] = beta[k];
    r->reg[dst + p] = rss / S;
    r->steps += (long)S * p;
    free(col); free(vv);
    return chk(r, r->reg[dst + p]);
}

static int rexec(R *r, int off, int len, int ctx, double *res, double *out2) {
    const uint8_t *c = r->c; int pos = off, end = off + len, d = 0;
    double st[BRW_MAXSTACK + 4];
    while (pos < end) {
        if (++r->steps > r->budget) return rfail(r, "step budget exceeded");
        uint8_t op = c[pos++];
        if (op <= 0x1F) { st[d++] = op; continue; }
        if (op == 0x20) { st[d++] = c[pos++]; continue; }
        if (op == 0x21) { st[d++] = -(double)c[pos++]; continue; }
        if (op == 0x22) { float f; memcpy(&f, c + pos, 4); pos += 4; st[d++] = f; continue; }
        if (op == 0x23) { double x; memcpy(&x, c + pos, 8); pos += 8; st[d++] = x; continue; }
        double a, b;
        switch (op) {
        case 0x30: b = st[--d]; a = st[--d]; st[d++] = a + b; break;
        case 0x31: b = st[--d]; a = st[--d]; st[d++] = a - b; break;
        case 0x32: b = st[--d]; a = st[--d]; st[d++] = a * b; break;
        case 0x33: b = st[--d]; a = st[--d]; st[d++] = a / b; break;
        case 0x34: st[d - 1] = -st[d - 1]; break;
        case 0x35: st[d - 1] = exp(st[d - 1]); break;
        case 0x36: st[d - 1] = log(st[d - 1]); break;
        case 0x37: st[d - 1] = sqrt(st[d - 1]); break;
        case 0x38: st[d - 1] = expm1(st[d - 1]); break;
        case 0x39: st[d - 1] = fabs(st[d - 1]); break;
        case 0x3A: b = st[--d]; a = st[--d]; st[d++] = a < b ? a : b; break;
        case 0x3B: b = st[--d]; a = st[--d]; st[d++] = a > b ? a : b; break;
        case 0x3C: b = st[--d]; a = st[--d]; st[d++] = a < b ? 1 : 0; break;
        case 0x3D: b = st[--d]; a = st[--d]; st[d++] = a <= b ? 1 : 0; break;
        case 0x3E: { double cc = st[--d]; b = st[--d]; a = st[--d]; st[d++] = cc != 0 ? a : b; break; }
        case 0x40: st[d] = st[d - 1]; d++; break;
        case 0x41: a = st[d - 1]; st[d - 1] = st[d - 2]; st[d - 2] = a; break;
        case 0x42: d--; break;
        case 0x43: st[d] = st[d - 2]; d++; break;
        case 0x50: st[d++] = r->tcur; break;
        case 0x51: st[d++] = r->tcur - r->tprev; break;
        case 0x52: st[d++] = r->tprev; break;
        case 0x53: st[d++] = r->idxcur; break;
        case 0x54: st[d++] = r->ycur; break;
        case 0x55: st[d++] = r->yprev; break;
        case 0x56: st[d++] = r->S; break;
        case 0x57: st[d++] = r->S - 1; break;
        case 0x58: st[d++] = r->t[0]; break;
        case 0x59: st[d++] = r->t[r->S - 1]; break;
        case 0x5A: st[d++] = r->y[0]; break;
        case 0x5B: st[d++] = r->y[r->S - 1]; break;
        case 0x60: case 0x61: {
            unsigned bl = 0; getleb(c, end, &pos, &bl);
            int j0 = op == 0x60 ? 0 : 1;
            if (r->S < j0 + 1) return rfail(r, "loop over too few points");
            double sum = 0;
            for (int j = j0; j < r->S; j++) {
                r->tcur = r->t[j]; r->ycur = r->y[j]; r->idxcur = j;
                if (j > 0) { r->tprev = r->t[j - 1]; r->yprev = r->y[j - 1]; }
                double val; if (rexec(r, pos, (int)bl, op == 0x60 ? X_PTS : X_INC, &val, NULL)) return -1;
                sum += val;
            }
            pos += bl; st[d++] = sum; break;
        }
        case 0x64: case 0x65: case 0x66: case 0x67: {
            int p = op - 0x63, dst = c[pos++], fid[4];
            for (int i = 0; i < p; i++) fid[i] = c[pos++];
            if (lsq_run(r, p, dst, fid)) return -1;
            break;
        }
        case 0xE0: { if (out2) *out2 = st[d - 1]; *res = st[d - 2]; return 0; }
        default:
            if (op >= 0x80 && op <= 0x8F) { st[d++] = r->reg[op & 15]; break; }
            if (op >= 0x90 && op <= 0x9F) { r->reg[op & 15] = st[--d]; break; }
            if (op >= 0xA0 && op <= 0xA3) {
                int f = op & 3; double val;
                if (rexec(r, r->in->fnoff[f], r->in->fnlen[f], ctx, &val, NULL)) return -1;
                st[d++] = val; break;
            }
            return rfail(r, "bad opcode");
        }
        if (d > 0 && !isfinite(st[d - 1])) return rfail(r, "non-finite value");
    }
    if (d > 0) *res = st[d - 1];
    (void)ctx; (void)out2; return 0;
}
int brwdl_run(const uint8_t *code, const BrwInfo *info, const double *t, const double *y, int N, int S,
              double *loc, double *scale, const char **why) {
    R r; memset(&r, 0, sizeof r);
    r.c = code; r.in = info; r.t = t; r.y = y; r.S = S; r.budget = BRW_FITSTEPS;
    if (S < 1 || S > BRW_MAXPOINTS || N > BRW_MAXPOINTS) { *why = "size limits"; return -1; }
    double dummy;
    if (rexec(&r, info->fitoff, info->fitlen, X_FIT, &dummy, NULL) && r.fail) { *why = r.why; return -1; }
    for (int i = S; i < N; i++) {
        r.steps = 0; r.budget = BRW_PREDSTEPS;
        r.tcur = t[i]; r.tprev = t[i - 1]; r.yprev = y[i - 1]; r.idxcur = i; r.ycur = 0;
        double l = 0, s = 0;
        /* predict block: emit_normal returns location (under) and scale (top) */
        if (rexec(&r, info->predoff, info->predlen, X_PRED, &l, &s)) { *why = r.why; return -1; }
        if (!isfinite(l) || !isfinite(s) || !(s > 0)) { *why = "FAIL_PROTOCOL: non-finite location or scale not > 0"; return -1; }
        loc[i - S] = l; scale[i - S] = s;
    }
    return 0;
}

/* ---------------- SHA-256 ---------------- */
static const uint32_t K256[64] = {
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
#define ROR(x,n) (((x) >> (n)) | ((x) << (32 - (n))))
void brwdl_sha256(const uint8_t *m, size_t n, char hex[65]) {
    uint32_t h[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    size_t tot = ((n + 9 + 63) / 64) * 64; uint8_t *p = calloc(1, tot); memcpy(p, m, n); p[n] = 0x80;
    uint64_t bits = (uint64_t)n * 8; for (int i = 0; i < 8; i++) p[tot - 1 - i] = (uint8_t)(bits >> (8 * i));
    for (size_t o = 0; o < tot; o += 64) {
        uint32_t w[64];
        for (int i = 0; i < 16; i++) w[i] = (uint32_t)p[o+4*i] << 24 | p[o+4*i+1] << 16 | p[o+4*i+2] << 8 | p[o+4*i+3];
        for (int i = 16; i < 64; i++) {
            uint32_t s0 = ROR(w[i-15],7) ^ ROR(w[i-15],18) ^ (w[i-15] >> 3), s1 = ROR(w[i-2],17) ^ ROR(w[i-2],19) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }
        uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
        for (int i = 0; i < 64; i++) {
            uint32_t S1 = ROR(e,6)^ROR(e,11)^ROR(e,25), ch = (e&f)^(~e&g), t1 = hh+S1+ch+K256[i]+w[i];
            uint32_t S0 = ROR(a,2)^ROR(a,13)^ROR(a,22), mj = (a&b)^(a&c)^(b&c), t2 = S0+mj;
            hh=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=hh;
    }
    for (int i = 0; i < 8; i++) sprintf(hex + 8 * i, "%08x", h[i]);
    free(p);
}

/* ---------------- CLI ---------------- */
#ifdef BRW_DL_CLI  /* CLI: the design tool (asm/info/run/memo) and, with --line, the evaluator interpreter (R3-30a) */
#include <errno.h>
static char *slurp(const char *fn, long *n) {
    FILE *f = fopen(fn, "rb"); if (!f) return NULL;
    fseek(f, 0, SEEK_END); long z = ftell(f); fseek(f, 0, SEEK_SET);
    char *b = malloc(z + 1); if (fread(b, 1, z, f) != (size_t)z) { fclose(f); return NULL; } b[z] = 0; fclose(f); if (n) *n = z; return b;
}
static int load_prog(const char *fn, uint8_t *code, int *n, BrwInfo *in) {
    char *txt = slurp(fn, NULL); char err[200];
    if (!txt) { fprintf(stderr, "cannot read %s\n", fn); return -1; }
    if (brwdl_assemble(txt, code, n, err, sizeof err)) { fprintf(stderr, "assemble error: %s\n", err); return -1; }
    if (brwdl_check(code, *n, in, err, sizeof err)) { fprintf(stderr, "check error: %s\n", err); return -1; }
    free(txt); return 0;
}
static void gen_memo(const char *fn) {
    long z; char *txt = slurp(fn, &z); if (!txt) { fprintf(stderr, "cannot read %s\n", fn); exit(1); }
    double T[512], Y[512]; int n = 0; char *p = txt;
    while (n < 512) { char *e; double a = strtod(p, &e); if (e == p) break; p = e; double b = strtod(p, &e); if (e == p) break; p = e; T[n] = a; Y[n] = b; n++; }
    printf("; stored-pairs memorizer: exact stored value at a stored time, else previous value with scale 1\n");
    printf("fit { }\npredict {\n  prevobs\n");
    for (int i = 0; i < n; i++) printf("  %.17g swap now %.17g sub abs 0 le sel\n", Y[i], T[i]);
    printf("  0.0009765625 1 0\n");
    for (int i = 0; i < n; i++) printf("  now %.17g sub abs 0 le add\n", T[i]);
    printf("  sel\n  emit_normal\n}\n");
}
/* ---- evaluator discovery interpreter (R3-30a; was brw_interp.c), run as: brw_interp --line <program>
 * Line protocol brw.line.v1 on stdin/stdout, ASCII, reals %.17g:
 *   parent: B 1                -> reply R 1 (handshake; an extension that separates BLOCKED from FAIL_PROTOCOL)
 *   parent: W n s              -> a new world of n points, first s revealed
 *   parent: O i t y            -> observed point i (in order 0..n-1)
 *   parent: Q i t              -> reply N i loc scale  (i >= s, all of 0..i-1 already observed)
 *   parent: X                  -> exit 0
 * The program (argv[2]) is canonical BRW-DL bytes. Prediction for index i re-runs the interpreter on points
 * 0..i-1 fit once on the first s points, the same computation as brw_predict_fit_once, taking the last output.
 */
#include "brw_dl.h"

static int rd_int(const char *s, long *v) {
    char *e; errno = 0;
    if (!*s) return -1;
    long x = strtol(s, &e, 10);
    if (*e || errno) return -1;
    *v = x; return 0;
}
static int rd_real(const char *s, double *v) {
    char *e; errno = 0;
    if (!*s) return -1;
    double x = strtod(s, &e);
    if (*e || errno == ERANGE || !isfinite(x)) return -1;
    *v = x; return 0;
}
static int split(char *line, char **tok, int max) {
    int n = 0; char *p = line;
    for (;;) { if (n == max) return max + 1; tok[n++] = p; char *sp = strchr(p, ' '); if (!sp) break; *sp = 0; p = sp + 1; }
    return n;
}
static int idie(const char *m) { fprintf(stderr, "brw_interp: %s\n", m); return 2; }

static int interp_main(int argc, char **argv) {
    static uint8_t code[BRW_MAXBYTES + 16];
    static double t[BRW_MAXPOINTS + 1], y[BRW_MAXPOINTS + 1];
    static char line[4200];
    if (argc != 3 || strcmp(argv[1], "--line") != 0) return idie("usage: brw_interp --line <program>");
    FILE *pf = fopen(argv[2], "rb");
    if (!pf) return idie("cannot open the program");
    size_t n = fread(code, 1, sizeof code, pf);
    fclose(pf);
    if (n < 3 || n > BRW_MAXBYTES) return idie("program size out of range");
    BrwInfo info; char err[128];
    if (brwdl_check(code, (int)n, &info, err, sizeof err) != 0) { fprintf(stderr, "brw_interp: program refused: %s\n", err); return 2; }
    long N = -1, S = -1, seen = 0; int handshaken = 0;
    while (fgets(line, sizeof line, stdin)) {
        size_t l = strlen(line);
        if (l == 0 || line[l - 1] != '\n') return idie("line too long or unterminated");
        line[l - 1] = 0;
        char *tok[6]; int k = split(line, tok, 4);
        if (k > 4) return idie("too many fields");
        if (strcmp(tok[0], "B") == 0) {
            long v; if (k != 2 || rd_int(tok[1], &v) || v != 1) return idie("bad handshake");
            printf("R 1\n"); fflush(stdout); handshaken = 1;
        } else if (!handshaken) return idie("no handshake");
        else if (strcmp(tok[0], "W") == 0) {
            if (k != 3 || rd_int(tok[1], &N) || rd_int(tok[2], &S) || N < 2 || N > BRW_MAXPOINTS || S < 1 || S >= N) return idie("bad W");
            seen = 0;
        } else if (strcmp(tok[0], "O") == 0) {
            long i; double tv, yv;
            if (N < 0 || k != 4 || rd_int(tok[1], &i) || rd_real(tok[2], &tv) || rd_real(tok[3], &yv) || i != seen || i >= N) return idie("bad O");
            t[i] = tv; y[i] = yv; seen = i + 1;
        } else if (strcmp(tok[0], "Q") == 0) {
            long i; double tv; static double lo[BRW_MAXPOINTS], sa[BRW_MAXPOINTS]; const char *why = "";
            if (N < 0 || k != 3 || rd_int(tok[1], &i) || rd_real(tok[2], &tv) || i < S || i >= N || i != seen) return idie("bad Q");
            t[i] = tv; y[i] = 0;
            if (brwdl_run(code, &info, t, y, (int)(i + 1), (int)S, lo, sa, &why) != 0) { fprintf(stderr, "brw_interp: program error: %s\n", why); return 3; }
            /* the raw output of the last held-out index, exactly as brw_predict_fit_once reads it */
            printf("N %ld %.17g %.17g\n", i, lo[i - S], sa[i - S]); fflush(stdout);
        } else if (strcmp(tok[0], "X") == 0) {
            if (k != 1) return idie("bad X");
            return 0;
        } else return idie("unknown command");
    }
    return idie("input ended without X");
}
int main(int argc, char **argv) {
    if (argc >= 2 && !strcmp(argv[1], "--line")) return interp_main(argc, argv);
    if (argc >= 3 && !strcmp(argv[1], "memo")) { gen_memo(argv[2]); return 0; }
    if (argc < 3) { fprintf(stderr, "usage: brw_dl asm|info|run|memo ...\n"); return 2; }
    uint8_t code[BRW_MAXBYTES + 16]; int n; BrwInfo in;
    if (load_prog(argv[2], code, &n, &in)) return 1;
    char hex[65]; brwdl_sha256(code, n, hex);
    if (!strcmp(argv[1], "asm") || !strcmp(argv[1], "info")) {
        printf("bytes=%d k=%d functions=%d sha256=%s\n", n, in.k, in.nfuncs, hex);
        if (argc > 3) { FILE *f = fopen(argv[3], "wb"); fwrite(code, 1, n, f); fclose(f); }
        else { for (int i = 0; i < n; i++) printf("%02x", code[i]); printf("\n"); }
        return 0;
    }
    if (!strcmp(argv[1], "run") && argc >= 5) {
        long z; char *txt = slurp(argv[3], &z); double *t = malloc(sizeof(double) * BRW_MAXPOINTS), *y = malloc(sizeof(double) * BRW_MAXPOINTS);
        int N = 0; char *p = txt;
        while (N < BRW_MAXPOINTS) { char *e; double a = strtod(p, &e); if (e == p) break; p = e; double b = strtod(p, &e); if (e == p) break; p = e; t[N] = a; y[N] = b; N++; }
        int S = atoi(argv[4]); double *loc = malloc(sizeof(double) * N), *sc = malloc(sizeof(double) * N); const char *why = "";
        if (brwdl_run(code, &in, t, y, N, S, loc, sc, &why)) { fprintf(stderr, "run failed: %s\n", why); return 1; }
        for (int i = 0; i < N - S; i++) printf("%d %.17g %.17g\n", S + i, loc[i], sc[i]);
        return 0;
    }
    return 2;
}
#endif

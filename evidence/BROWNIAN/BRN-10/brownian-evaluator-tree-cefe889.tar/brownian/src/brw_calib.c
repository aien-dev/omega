/* brw_calib.c: BRN-5 calibration tool library (see brw_calib.h). Private, sealed. C only.
 *
 * Interpretations fixed here (each is reported to the integrator):
 *  - the frozen null interval is over BLOCK MEANS of W worlds (Section 10: "[q0.42%, q99.58%] of block means";
 *    brw_null_calibrate is the quantile definition: index (int)(tail*nb) and min(nb-1,(int)((1-tail)*nb)), tail 0.05/12;
 *    center = mean of block means), not over per-world statistics;
 *  - U11 "the development function with the label brownian.nullcal.v1 in place of brownian.dev.v1": that string is the
 *    PARENT seed argument (brw_world_seed), the world label stays brw_world_label("dev", cell, 0). */
#include "brw_calib.h"
#include "brw_cells.h"
#include "brw_dl.h"
#include "brw_predict.h"
#include "brw_rng.h"
#include <ctype.h>
#include <math.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

const double BRW_CALIB_OCC_S[BRW_CALIB_OCC_NS] = { 0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.25, 3.5, 3.75, 4.0, 4.25, 4.5, 5.0, 5.5, 6.0 };
const uint32_t BRW_CALIB_OCC_H[BRW_CALIB_OCC_NH] = { 128, 256, 512, 1024 };
const char *const BRW_CALIB_STAT_NAMES[6] = { "mean_z", "mean_z2", "ac1", "spearman_z2_t", "slope_z_yprev", "exkurt" };
const char *const BRW_CALIB_PRIMARY[11] = { "B0-irregular", "B0-regular", "B1-0", "B1-1", "B1-3", "B1-4n",
                                            "B2-clear", "B2-emerging", "B2-fast", "B2-noise", "B2-weak" };

static void seterr(char *err, size_t cap, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
#include <stdarg.h>
static void seterr(char *err, size_t cap, const char *fmt, ...) {
    va_list ap;
    if (!err || !cap) return;
    va_start(ap, fmt); vsnprintf(err, cap, fmt, ap); va_end(ap);
}

uint32_t brw_calib_cell_w(const char *cell) {
    if (!cell) return 0;
    if (!strcmp(cell, "B2-weak") || !strcmp(cell, "B2-clear") || !strcmp(cell, "B2-fast")) return BRW_W_B2;
    if (!strcmp(cell, "B2-emerging")) return BRW_W_B2_EMERGING;
    brw_cell_spec cs;
    if (brw_cell_lookup(cell, &cs) != BRW_OK) return 0;
    return BRW_W_B0_B1_NOISE;
}

int brw_calib_match_opcode(const brw_cell_spec *cs) {
    switch (cs->family) {
    case BRW_FAM_D0: return BRW_OP_DIFFUSION;
    case BRW_FAM_D1: return BRW_OP_DIFF_DRIFT;
    default: return BRW_OP_MEAN_REVERT;
    }
}

int brw_calib_world_seed(const char *parent, const char *cell, uint64_t block, uint64_t rep, uint8_t out[32]) {
    char label[128];
    int rc = brw_world_label("dev", cell, block, label, sizeof label);
    if (rc != BRW_OK) return rc;
    return brw_world_seed(label, (const uint8_t *)parent, strlen(parent), rep, out);
}

/* ---------------------------------------------------------------- parallel-for */

typedef struct { brw_calib_range_fn fn; void *ctx; uint64_t b, e; int tid; } par_job;
static void *par_thread(void *a) { par_job *j = a; j->fn(j->ctx, j->b, j->e, j->tid); return NULL; }

int brw_calib_par(uint64_t n, int nthreads, brw_calib_range_fn fn, void *ctx) {
    if (nthreads < 1) nthreads = 1;
    if ((uint64_t)nthreads > n) nthreads = n ? (int)n : 1;
    if (nthreads == 1) { fn(ctx, 0, n, 0); return BRW_OK; }
    par_job *jobs = malloc((size_t)nthreads * sizeof *jobs);
    pthread_t *th = malloc((size_t)nthreads * sizeof *th);
    if (!jobs || !th) { free(jobs); free(th); return BRW_E_IO; }
    int started = 0, rc = BRW_OK;
    for (int i = 0; i < nthreads; i++) {
        jobs[i] = (par_job){ fn, ctx, n * (uint64_t)i / (uint64_t)nthreads, n * (uint64_t)(i + 1) / (uint64_t)nthreads, i };
        if (pthread_create(&th[i], NULL, par_thread, &jobs[i]) != 0) { rc = BRW_E_IO; break; }
        started++;
    }
    for (int i = 0; i < started; i++) pthread_join(th[i], NULL);
    free(jobs); free(th);
    return rc;
}

/* ---------------------------------------------------------------- null worlds */

typedef struct {
    const brw_cell_spec *cs; const brw_prog *prog; const char *parent; const char *cell; uint64_t block;
    brw_diag *out; uint64_t *bad; int *bad_rc;   /* per-thread first failure */
    int nthreads;
} null_ctx;

static void null_range(void *vc, uint64_t b, uint64_t e, int tid) {
    null_ctx *c = vc;
    const uint32_t S = c->cs->split, N = c->cs->n_points, H = N - S;
    double y[BRW_MAXPOINTS], z[BRW_MAXPOINTS];
    tyq_pred pr[BRW_MAXPOINTS];
    c->bad[tid] = UINT64_MAX; c->bad_rc[tid] = 0;
    for (uint64_t w = b; w < e; w++) {
        uint8_t ws[32]; brw_traj tr = { 0, NULL, NULL }; const char *why = "";
        int rc = brw_calib_world_seed(c->parent, c->cell, c->block, w, ws);
        if (rc == BRW_OK) rc = brw_world_generate(c->cs, ws, &tr, NULL);
        if (rc == BRW_OK) {
            for (uint32_t i = 0; i < N; i++) y[i] = brw_symbol_value(tr.k[i]);
            rc = brw_predict_fit_once(c->prog, tr.t, y, N, S, pr, &why);
            if (rc == TYQ_OK) {
                for (uint32_t i = 0; i < H; i++) {
                    double sd = pr[i].scale;
                    if (sd < TYQ_SD_MIN) sd = TYQ_SD_MIN;   /* evaluator floor (Section 2), as in the design check */
                    z[i] = (y[S + i] - pr[i].loc) / sd;
                }
                rc = brw_diag_world(z, tr.t + S, y + S - 1, H, &c->out[w]);
            }
        }
        brw_traj_free(&tr);
        if (rc != 0) { c->bad[tid] = w; c->bad_rc[tid] = rc; return; }
    }
}

int brw_calib_null_worlds(const brw_cell_spec *cs, uint64_t n, int nthreads, brw_diag *out, char *err, size_t errcap) {
    return brw_calib_null_worlds_ex(cs, BRW_CALIB_NULL_PARENT, 0, n, nthreads, out, err, errcap);
}

int brw_calib_null_worlds_ex(const brw_cell_spec *cs, const char *parent, uint64_t block, uint64_t n, int nthreads, brw_diag *out, char *err, size_t errcap) {
    brw_prog prog;
    if (!cs || !out || n == 0 || cs->n_points > BRW_MAXPOINTS || cs->n_points <= cs->split + 2) {
        seterr(err, errcap, "bad null-world request"); return BRW_E_ARG;
    }
    int rc = brw_ref_program(brw_calib_match_opcode(cs), &prog);
    if (rc != TYQ_OK) { seterr(err, errcap, "reference program refused (%d)", rc); return rc; }
    if (nthreads < 1) nthreads = 1;
    null_ctx c = { cs, &prog, parent, cs->name, block, out, NULL, NULL, nthreads };
    c.bad = malloc((size_t)nthreads * sizeof *c.bad); c.bad_rc = malloc((size_t)nthreads * sizeof *c.bad_rc);
    if (!c.bad || !c.bad_rc) { free(c.bad); free(c.bad_rc); return BRW_E_IO; }
    for (int i = 0; i < nthreads; i++) { c.bad[i] = UINT64_MAX; c.bad_rc[i] = 0; }
    rc = brw_calib_par(n, nthreads, null_range, &c);
    for (int i = 0; i < nthreads && rc == BRW_OK; i++)   /* lowest failing index, deterministic */
        if (c.bad[i] != UINT64_MAX) { seterr(err, errcap, "world %llu failed (code %d)", (unsigned long long)c.bad[i], c.bad_rc[i]); rc = c.bad_rc[i]; }
    free(c.bad); free(c.bad_rc);
    return rc;
}

int brw_calib_null_from_worlds(const brw_diag *worlds, uint64_t n, uint32_t W, brw_null_cell *nc, char *err, size_t errcap) {
    if (!worlds || !nc || W == 0 || n % W != 0 || n / W < 100) {
        seterr(err, errcap, "need n %% W == 0 and n/W >= 100 blocks (W=%u, n=%llu)", W, (unsigned long long)n);
        return BRW_E_ARG;
    }
    size_t nb = (size_t)(n / W);
    brw_diag *bm = malloc(nb * sizeof *bm);
    if (!bm) return BRW_E_IO;
    int rc = BRW_OK;
    for (size_t b = 0; b < nb && rc == BRW_OK; b++) rc = brw_diag_block_mean(worlds + b * W, W, &bm[b]);
    if (rc == BRW_OK) rc = brw_null_calibrate(bm, nb, BRW_NULL_TAIL, nc);
    free(bm);
    if (rc != BRW_OK) seterr(err, errcap, "null calibration failed (%d)", rc);
    return rc;
}

int brw_calib_nullcal(const char *cell, uint64_t n, int nthreads, brw_null_cell *nc, char *err, size_t errcap) {
    brw_cell_spec cs;
    uint32_t W = brw_calib_cell_w(cell);
    if (!W || brw_cell_lookup(cell, &cs) != BRW_OK) { seterr(err, errcap, "unknown cell %s", cell ? cell : "(null)"); return BRW_E_ARG; }
    if (n % W != 0 || n / W < 100) { seterr(err, errcap, "n_worlds must be a multiple of W=%u with at least 100 blocks", W); return BRW_E_ARG; }
    brw_diag *w = malloc((size_t)n * sizeof *w);
    if (!w) return BRW_E_IO;
    int rc = brw_calib_null_worlds(&cs, n, nthreads, w, err, errcap);
    if (rc == BRW_OK) rc = brw_calib_null_from_worlds(w, n, W, nc, err, errcap);
    free(w);
    return rc;
}

void brw_calib_write_null(FILE *f, const char *cell, const brw_null_cell *nc) {
    for (int i = 0; i < 6; i++)
        fprintf(f, "%s %s %.17g %.17g %.17g\n", cell, BRW_CALIB_STAT_NAMES[i], nc->center[i], nc->lo[i], nc->hi[i]);
}

/* ---------------------------------------------------------------- block scoring (occ, preq) */

typedef struct {
    const brw_cell_spec *cs; const char *cell; uint64_t block;
    int nprog; const brw_prog *const *progs; const brw_mode *modes;
    brw_world_score *out; uint64_t *bad; int *bad_rc;
} score_ctx;

static void score_range(void *vc, uint64_t b, uint64_t e, int tid) {
    score_ctx *c = vc;
    c->bad[tid] = UINT64_MAX; c->bad_rc[tid] = 0;
    for (uint64_t w = b; w < e; w++) {
        uint8_t ws[32]; brw_traj tr = { 0, NULL, NULL };
        int rc = brw_calib_world_seed(BRW_DEV_PARENT, c->cell, c->block, w, ws);
        if (rc == BRW_OK) rc = brw_world_generate(c->cs, ws, &tr, NULL);
        for (int p = 0; p < c->nprog && rc == BRW_OK; p++)
            rc = brw_score_world(c->progs[p], &tr, c->cs->split, c->modes[p], &c->out[w * (uint64_t)c->nprog + (uint64_t)p]);
        brw_traj_free(&tr);
        if (rc != 0) { c->bad[tid] = w; c->bad_rc[tid] = rc; return; }
    }
}

/* Scores W worlds of dev block `block` of the cell for nprog (program, mode) pairs; out is W*nprog, world-major. */
static int score_block(const brw_cell_spec *cs, uint32_t W, uint64_t block, int nprog, const brw_prog *const *progs,
                       const brw_mode *modes, int nthreads, brw_world_score *out, char *err, size_t errcap) {
    if (nthreads < 1) nthreads = 1;
    score_ctx c = { cs, cs->name, block, nprog, progs, modes, out, NULL, NULL };
    c.bad = malloc((size_t)nthreads * sizeof *c.bad); c.bad_rc = malloc((size_t)nthreads * sizeof *c.bad_rc);
    if (!c.bad || !c.bad_rc) { free(c.bad); free(c.bad_rc); return BRW_E_IO; }
    for (int i = 0; i < nthreads; i++) { c.bad[i] = UINT64_MAX; c.bad_rc[i] = 0; }
    int rc = brw_calib_par(W, nthreads, score_range, &c);
    for (int i = 0; i < nthreads && rc == BRW_OK; i++)
        if (c.bad[i] != UINT64_MAX) { seterr(err, errcap, "%s block %llu world %llu failed (code %d)", cs->name, (unsigned long long)block, (unsigned long long)c.bad[i], c.bad_rc[i]); rc = c.bad_rc[i]; }
    free(c.bad); free(c.bad_rc);
    return rc;
}

/* T = DL(B) - DL(M) over the worlds of one block; arms b_i, m_i index the per-world score columns. */
static int block_t(const brw_prog *pb, const brw_prog *pm, const brw_world_score *sc, int nprog, int bi, int mi,
                   uint32_t W, int64_t *t_ub) {
    brw_cell_dl b, m;
    int rc = brw_cell_dl_init(&b, pb);
    if (rc == TYQ_OK) rc = brw_cell_dl_init(&m, pm);
    for (uint32_t w = 0; w < W && rc == TYQ_OK; w++) {
        rc = brw_cell_dl_add(&b, &sc[(uint64_t)w * (uint64_t)nprog + (uint64_t)bi]);
        if (rc == TYQ_OK) rc = brw_cell_dl_add(&m, &sc[(uint64_t)w * (uint64_t)nprog + (uint64_t)mi]);
    }
    if (rc == TYQ_OK) rc = brw_cell_gain(&b, &m, t_ub);
    return rc;
}

/* ---------------------------------------------------------------- Occam crossing */

int brw_calib_occ_spec(double s, uint32_t H, brw_cell_spec *cs, char *name, size_t cap) {
    if (!cs || !name || H == 0 || BRW_SPLIT_PRIMARY + H > BRW_MAXPOINTS) return BRW_E_ARG;
    int n = snprintf(name, cap, "OCC-s%+.2f-H%u", s, H);
    if (n <= 0 || (size_t)n >= cap) return BRW_E_ARG;
    memset(cs, 0, sizeof *cs);
    cs->name = name; cs->family = BRW_FAM_D1; cs->grid = BRW_GRID_REGULAR; cs->obs = BRW_OBS_EXACT;
    cs->n_points = BRW_SPLIT_PRIMARY + H; cs->split = BRW_SPLIT_PRIMARY; cs->snr_s = s;
    return BRW_OK;
}

int brw_calib_occ_mean_t(double s, uint32_t H, uint32_t n_blocks, int nthreads, double *mean_t_ub, char *err, size_t errcap) {
    brw_cell_spec cs; char name[64]; brw_prog pb, pm;
    const uint32_t W = BRW_W_B0_B1_NOISE;
    int rc = brw_calib_occ_spec(s, H, &cs, name, sizeof name);
    if (rc == BRW_OK) rc = brw_ref_program(BRW_OP_DIFFUSION, &pb);
    if (rc == BRW_OK) rc = brw_ref_program(BRW_OP_DIFF_DRIFT, &pm);
    if (rc != BRW_OK && rc != TYQ_OK) { seterr(err, errcap, "occ setup failed (%d)", rc); return rc; }
    brw_world_score *sc = malloc((size_t)W * 2 * sizeof *sc);
    if (!sc) return BRW_E_IO;
    const brw_prog *progs[2] = { &pb, &pm };
    const brw_mode modes[2] = { BRW_MODE_FIT_ONCE, BRW_MODE_FIT_ONCE };
    long double sum = 0;
    for (uint32_t blk = 0; blk < n_blocks; blk++) {
        int64_t t = 0;
        rc = score_block(&cs, W, blk, 2, progs, modes, nthreads, sc, err, errcap);
        if (rc == 0) rc = block_t(&pb, &pm, sc, 2, 0, 1, W, &t);
        if (rc != 0) break;
        sum += (long double)t;
    }
    free(sc);
    if (rc != 0) return rc;
    *mean_t_ub = (double)(sum / (long double)n_blocks);
    return BRW_OK;
}

int brw_calib_cross(const double *s, const double *t, size_t n, double *s_cross) {
    for (size_t k = 0; k + 1 < n; k++)
        if (t[k] < 0.0 && t[k + 1] >= 0.0) {
            *s_cross = s[k] + (0.0 - t[k]) * (s[k + 1] - s[k]) / (t[k + 1] - t[k]);
            return BRW_OK;
        }
    return BRW_E_RANGE;
}

/* ---------------------------------------------------------------- fit-once vs prequential */

/* Comparison per cell: the first declared T item of the cell in Sections 13, 14, 15 (model, baseline):
 * B0-regular item 1 (DIFFUSION vs IID_NORMAL); B0-short item 4 (DIFFUSION_DRIFT vs DIFFUSION; item 1 is not required
 * there); B1-0/B1-1/B1-3 item .1 (DIFFUSION_DRIFT vs DIFFUSION); B2-noise item 1 (MEAN_REVERT vs DIFFUSION);
 * B2-weak/B2-clear item 2/3 (MEAN_REVERT vs DIFFUSION_DRIFT). Section 11 does not name the pair. */
static int preq_pair(const char *cell, int *model, int *base) {
    static const struct { const char *cell; int m, b; } P[8] = {
        { "B0-regular", BRW_OP_DIFFUSION, BRW_OP_IID }, { "B0-short", BRW_OP_DIFF_DRIFT, BRW_OP_DIFFUSION },
        { "B1-0", BRW_OP_DIFF_DRIFT, BRW_OP_DIFFUSION }, { "B1-1", BRW_OP_DIFF_DRIFT, BRW_OP_DIFFUSION },
        { "B1-3", BRW_OP_DIFF_DRIFT, BRW_OP_DIFFUSION }, { "B2-noise", BRW_OP_MEAN_REVERT, BRW_OP_DIFFUSION },
        { "B2-weak", BRW_OP_MEAN_REVERT, BRW_OP_DIFF_DRIFT }, { "B2-clear", BRW_OP_MEAN_REVERT, BRW_OP_DIFF_DRIFT } };
    for (int i = 0; i < 8; i++) if (!strcmp(cell, P[i].cell)) { *model = P[i].m; *base = P[i].b; return BRW_OK; }
    return BRW_E_ARG;
}

int brw_calib_preqcheck(const char *cell, uint64_t block, int nthreads, brw_calib_preq *out, char *err, size_t errcap) {
    brw_cell_spec cs; brw_prog pb, pm;
    int om, ob;
    uint32_t W = brw_calib_cell_w(cell);
    if (!W || brw_cell_lookup(cell, &cs) != BRW_OK || preq_pair(cell, &om, &ob) != BRW_OK) {
        seterr(err, errcap, "cell %s is not one of the 8 preqcheck cells", cell ? cell : "(null)"); return BRW_E_ARG;
    }
    int rc = brw_ref_program(ob, &pb);
    if (rc == TYQ_OK) rc = brw_ref_program(om, &pm);
    if (rc != TYQ_OK) { seterr(err, errcap, "reference program refused (%d)", rc); return rc; }
    /* columns: 0 base fit-once, 1 model fit-once, 2 base prequential, 3 model prequential */
    const brw_prog *progs[4] = { &pb, &pm, &pb, &pm };
    const brw_mode modes[4] = { BRW_MODE_FIT_ONCE, BRW_MODE_FIT_ONCE, BRW_MODE_PREQUENTIAL, BRW_MODE_PREQUENTIAL };
    brw_world_score *sc = malloc((size_t)W * 4 * sizeof *sc);
    if (!sc) return BRW_E_IO;
    int64_t tf = 0, tp = 0;
    rc = score_block(&cs, W, block, 4, progs, modes, nthreads, sc, err, errcap);
    if (rc == 0) rc = block_t(&pb, &pm, sc, 4, 0, 1, W, &tf);
    if (rc == 0) rc = block_t(&pb, &pm, sc, 4, 2, 3, W, &tp);
    if (rc != 0) { free(sc); return rc; }
    long double sf = 0, sp = 0;
    for (uint32_t w = 0; w < W; w++) { sf += (long double)sc[(uint64_t)w * 4 + 1].data_ub; sp += (long double)sc[(uint64_t)w * 4 + 3].data_ub; }
    free(sc);
    memset(out, 0, sizeof *out);
    snprintf(out->cell, sizeof out->cell, "%s", cell);
    out->block = block; out->W = W; out->op_model = om; out->op_base = ob;
    out->t_fit_ub = (double)tf; out->t_preq_ub = (double)tp;
    double mx = fabs(out->t_fit_ub) > fabs(out->t_preq_ub) ? fabs(out->t_fit_ub) : fabs(out->t_preq_ub);
    out->rel_gap = mx > 0 ? fabs(out->t_fit_ub - out->t_preq_ub) / mx : 0.0;
    out->agree = ((tf > 0) - (tf < 0)) == ((tp > 0) - (tp < 0)) && tf != 0 && tp != 0;
    out->data_fit_mean_ub = (double)(sf / (long double)W); out->data_preq_mean_ub = (double)(sp / (long double)W);
    out->kat_pass = fabs(out->data_fit_mean_ub - out->data_preq_mean_ub) > 1.0;
    return BRW_OK;
}

/* ---------------------------------------------------------------- brw.calib.v1 text */

static int cell_index(const char *c, size_t n) {
    for (int i = 0; i < 11; i++) if (strlen(BRW_CALIB_PRIMARY[i]) == n && !strncmp(BRW_CALIB_PRIMARY[i], c, n)) return i;
    return -1;
}
static int num_ok(const char *s, size_t n, double *v) {
    char buf[64]; char *end;
    if (n == 0 || n >= sizeof buf) return 0;
    memcpy(buf, s, n); buf[n] = 0;
    *v = strtod(buf, &end);
    return *end == 0 && isfinite(*v) && !isspace((unsigned char)buf[0]);
}
/* split a line into up to max tokens on single spaces; returns count, or -1 on empty token / too many */
static int split_line(const char *s, size_t len, const char **tok, size_t *tl, int max) {
    int n = 0; size_t i = 0;
    while (i <= len) {
        size_t j = i;
        while (j < len && s[j] != ' ') j++;
        if (j == i || n >= max) return -1;
        tok[n] = s + i; tl[n] = j - i; n++;
        i = j + 1;
        if (j == len) break;
    }
    return n;
}

typedef struct { char line[160]; } lrec;
typedef struct { lrec nl[11][6]; int have[11][6]; lrec occ[BRW_CALIB_OCC_NH]; uint32_t occ_h[BRW_CALIB_OCC_NH]; int nocc; } calib_data;

/* parse one non-header line into data; returns 0 or BRW_E_FORMAT */
static int take_line(calib_data *d, const char *s, size_t len, char *err, size_t errcap) {
    const char *tok[5]; size_t tl[5]; double v;
    int nt = split_line(s, len, tok, tl, 5);
    if (len >= sizeof(lrec)) { seterr(err, errcap, "line too long"); return BRW_E_FORMAT; }
    if (nt == 3 && tl[0] == 9 && !strncmp(tok[0], "occ_cross", 9)) {
        char hb[16]; char *end; if (tl[1] >= sizeof hb) goto bad;
        memcpy(hb, tok[1], tl[1]); hb[tl[1]] = 0;
        for (size_t i = 0; hb[i]; i++) if (!isdigit((unsigned char)hb[i])) goto bad;
        unsigned long h = strtoul(hb, &end, 10);
        if (!num_ok(tok[2], tl[2], &v) || h == 0 || (hb[0] == '0') || d->nocc >= BRW_CALIB_OCC_NH) goto bad;
        for (int i = 0; i < d->nocc; i++) if (d->occ_h[i] == h) { seterr(err, errcap, "duplicate occ_cross H %lu", h); return BRW_E_FORMAT; }
        d->occ_h[d->nocc] = (uint32_t)h; memcpy(d->occ[d->nocc].line, s, len); d->occ[d->nocc].line[len] = 0; d->nocc++;
        return BRW_OK;
    }
    if (nt == 5) {
        int ci = cell_index(tok[0], tl[0]), si = -1;
        for (int i = 0; i < 6; i++) if (strlen(BRW_CALIB_STAT_NAMES[i]) == tl[1] && !strncmp(BRW_CALIB_STAT_NAMES[i], tok[1], tl[1])) si = i;
        if (ci < 0 || si < 0) goto bad;
        for (int i = 2; i < 5; i++) if (!num_ok(tok[i], tl[i], &v)) goto bad;
        if (d->have[ci][si]) { seterr(err, errcap, "duplicate null line %s %s", BRW_CALIB_PRIMARY[ci], BRW_CALIB_STAT_NAMES[si]); return BRW_E_FORMAT; }
        d->have[ci][si] = 1; memcpy(d->nl[ci][si].line, s, len); d->nl[ci][si].line[len] = 0;
        return BRW_OK;
    }
bad:
    seterr(err, errcap, "unrecognised line: %.*s", (int)(len > 80 ? 80 : len), s);
    return BRW_E_FORMAT;
}

static int load_text(calib_data *d, const char *text, int want_header, char *err, size_t errcap) {
    const char *p = text; int first = 1;
    while (*p) {
        const char *nl = strchr(p, '\n');
        if (!nl) { seterr(err, errcap, "last line lacks LF"); return BRW_E_FORMAT; }
        size_t len = (size_t)(nl - p);
        if (first && want_header) {
            if (len != strlen(BRW_CALIB_HEADER) || strncmp(p, BRW_CALIB_HEADER, len)) { seterr(err, errcap, "header line must be %s", BRW_CALIB_HEADER); return BRW_E_FORMAT; }
        } else if (len == strlen(BRW_CALIB_HEADER) && !strncmp(p, BRW_CALIB_HEADER, len)) {
            /* a part file may carry the header; ignore */
        } else {
            int rc = take_line(d, p, len, err, errcap);
            if (rc) return rc;
        }
        first = 0; p = nl + 1;
    }
    if (want_header && first) { seterr(err, errcap, "empty file"); return BRW_E_FORMAT; }
    return BRW_OK;
}

/* after loading: cells with any stat must have all six; occ H ascending needs sorting by caller */
static int complete_check(const calib_data *d, int partial, char *err, size_t errcap) {
    for (int c = 0; c < 11; c++) {
        int n = 0; for (int s = 0; s < 6; s++) n += d->have[c][s];
        if (n != 0 && n != 6) { seterr(err, errcap, "cell %s has %d of 6 statistics", BRW_CALIB_PRIMARY[c], n); return BRW_E_FORMAT; }
        if (n == 0 && !partial) { seterr(err, errcap, "cell %s missing", BRW_CALIB_PRIMARY[c]); return BRW_E_FORMAT; }
    }
    if (!partial) {
        if (d->nocc != BRW_CALIB_OCC_NH) { seterr(err, errcap, "need occ_cross for 4 H values, have %d", d->nocc); return BRW_E_FORMAT; }
        for (int i = 0; i < BRW_CALIB_OCC_NH; i++) {
            int f = 0; for (int j = 0; j < d->nocc; j++) f |= d->occ_h[j] == BRW_CALIB_OCC_H[i];
            if (!f) { seterr(err, errcap, "occ_cross H %u missing", BRW_CALIB_OCC_H[i]); return BRW_E_FORMAT; }
        }
    }
    return BRW_OK;
}

int brw_calib_check_text(const char *text, int partial, char *err, size_t errcap) {
    static calib_data d;   /* large; the tool is single-purpose and not re-entrant here */
    memset(&d, 0, sizeof d);
    int rc = load_text(&d, text, 1, err, errcap);
    if (rc) return rc;
    /* file order: null lines in cell byte order then stat order, then occ lines ascending, nothing else */
    const char *p = strchr(text, '\n') + 1; int lastc = -1, laststat = 5; int in_occ = 0; uint32_t lasth = 0;
    while (*p) {
        const char *nl = strchr(p, '\n'); size_t len = (size_t)(nl - p);
        if (len >= 9 && !strncmp(p, "occ_cross ", 10)) {
            in_occ = 1; uint32_t h = (uint32_t)strtoul(p + 10, NULL, 10);
            if (h <= lasth) { seterr(err, errcap, "occ_cross H not ascending"); return BRW_E_FORMAT; }
            lasth = h;
        } else {
            if (in_occ) { seterr(err, errcap, "null line after occ_cross"); return BRW_E_FORMAT; }
            const char *sp = memchr(p, ' ', len); int ci = cell_index(p, (size_t)(sp - p));
            const char *tk = sp + 1; const char *sp2 = memchr(tk, ' ', (size_t)(nl - tk)); size_t l2 = (size_t)(sp2 - tk); int si = -1;
            for (int i = 0; i < 6; i++) if (strlen(BRW_CALIB_STAT_NAMES[i]) == l2 && !strncmp(BRW_CALIB_STAT_NAMES[i], tk, l2)) si = i;
            if (ci == lastc) { if (si != laststat + 1) { seterr(err, errcap, "statistics out of order"); return BRW_E_FORMAT; } }
            else { if (ci < lastc || si != 0 || laststat != 5) { seterr(err, errcap, "cells out of byte order"); return BRW_E_FORMAT; } }
            lastc = ci; laststat = si;
        }
        p = nl + 1;
    }
    return complete_check(&d, partial, err, errcap);
}

int brw_calib_assemble(const char *const *parts, size_t nparts, int partial, char **out, char *err, size_t errcap) {
    static calib_data d;
    memset(&d, 0, sizeof d);
    for (size_t i = 0; i < nparts; i++) { int rc = load_text(&d, parts[i], 0, err, errcap); if (rc) return rc; }
    int rc = complete_check(&d, partial, err, errcap);
    if (rc) return rc;
    size_t cap = 64 + 11 * 6 * 160 + BRW_CALIB_OCC_NH * 160, n = 0;
    char *buf = malloc(cap);
    if (!buf) return BRW_E_IO;
    n += (size_t)snprintf(buf + n, cap - n, "%s\n", BRW_CALIB_HEADER);
    for (int c = 0; c < 11; c++) for (int s = 0; s < 6; s++) if (d.have[c][s]) n += (size_t)snprintf(buf + n, cap - n, "%s\n", d.nl[c][s].line);
    int used[BRW_CALIB_OCC_NH] = { 0 };
    for (int k = 0; k < d.nocc; k++) {   /* ascending H */
        int best = -1;
        for (int i = 0; i < d.nocc; i++) if (!used[i] && (best < 0 || d.occ_h[i] < d.occ_h[best])) best = i;
        used[best] = 1; n += (size_t)snprintf(buf + n, cap - n, "%s\n", d.occ[best].line);
    }
    *out = buf;
    return BRW_OK;
}

/* ---------------------------------------------------------------- qfreeze keys 11 and 12 */

#include "sha256.h"

#define OPI BRW_OP_IID
#define OPL BRW_OP_LINEAR_TREND
#define OPC BRW_OP_CUBIC_TREND
#define OPD BRW_OP_DIFFUSION
#define OPF BRW_OP_DIFF_DRIFT
#define OPM BRW_OP_MEAN_REVERT
#define OPK BRW_OP_LOOKUP_FLOOR
/* Section 13 items 1-6 (item 9, the h = 1 variant, has no program bytes anywhere in the tree: excluded), Section 14
 * B1-x items that are "T of ... against ..." , Section 15 items 1-4 and 5 (label only). */
const brw_calib_cmp BRW_CALIB_CMPS[] = {
    { "B0-regular",   OPD, OPI, 'L', "13.1" }, { "B0-regular", OPL, OPD, 'U', "13.2" }, { "B0-regular", OPC, OPD, 'U', "13.3" },
    { "B0-regular",   OPF, OPD, 'U', "13.4" }, { "B0-regular", OPM, OPD, 'U', "13.5" }, { "B0-regular", OPK, OPD, 'U', "13.6" },
    { "B0-irregular", OPD, OPI, 'L', "13.1" }, { "B0-irregular", OPM, OPD, 'U', "13.5" },
    { "B0-short",     OPF, OPD, 'U', "13.4" }, { "B0-short", OPM, OPD, 'U', "13.5" },
    { "B1-0",  OPF, OPD, 'U', "B1-0.1" }, { "B1-0", OPM, OPD, 'U', "B1-0.2" },
    { "B1-1",  OPF, OPD, 'U', "B1-1.1" },
    { "B1-3",  OPF, OPD, 'L', "B1-3.1" }, { "B1-3", OPM, OPF, 'U', "B1-3.4" },
    { "B1-4n", OPF, OPD, 'L', "B1-4n.1" }, { "B1-4n", OPM, OPF, 'U', "B1-4n.2" },
    { "B2-noise", OPM, OPD, 'U', "15.1a" }, { "B2-noise", OPD, OPI, 'L', "15.1b" },
    { "B2-weak",  OPM, OPF, 'N', "15.2" },
    { "B2-clear", OPM, OPF, 'L', "15.3a" }, { "B2-clear", OPC, OPM, 'U', "15.3b" },
    { "B2-fast",  OPM, OPF, 'L', "15.3a" }, { "B2-fast", OPC, OPM, 'U', "15.3b" }, { "B2-fast", OPI, OPM, 'N', "15.4" },
    { "B2-emerging", OPM, OPF, '-', "15.5" },
};
const size_t BRW_CALIB_CMPS_N = sizeof BRW_CALIB_CMPS / sizeof BRW_CALIB_CMPS[0];
const char *const BRW_CALIB_KEY_CELLS[12] = { "B0-irregular", "B0-regular", "B0-short", "B1-0", "B1-1", "B1-3", "B1-4n",
                                              "B2-clear", "B2-emerging", "B2-fast", "B2-noise", "B2-weak" };

const char *brw_calib_label_name(int l) {
    static const char *const n[4] = { "POSITIVE", "NEGATIVE", "WEAK", "AMBIGUOUS" };
    return l >= 0 && l < 4 ? n[l] : "?";
}
/* R3-26 G6, same rule as brw_class_label in brw_protocol.c (that file is not part of this build). */
int brw_calib_label4(int64_t t, int64_t lo, int64_t hi) {
    if (lo > 0) return BRW_LAB_POSITIVE;
    if (hi < 0) return BRW_LAB_NEGATIVE;
    return t > 0 ? BRW_LAB_WEAK : BRW_LAB_AMBIGUOUS;
}

/* Bootstrap seed of a development comparison. Section 5 gives analysis_seed = SHA-256("brownian.v1|analysis|<mode>|<cell>|<block>"
 * || 0x00 || parent_seed) with a 32-byte parent. Development has no freeze, so the parent is (unspecified, conservative
 * fixed choice) SHA-256 of the ASCII development parent BRW_DEV_PARENT. The same stream is re-initialised for every
 * comparison, and the lengthened recomputation uses the identical stream. */
static void dev_analysis_seed(const char *cell, uint64_t block, uint8_t out[32]) {
    uint8_t parent[32], z = 0; char s[256]; sha256_ctx c;
    sha256_init(&c); sha256_update(&c, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT)); sha256_final(&c, parent);
    int n = snprintf(s, sizeof s, "brownian.v1|analysis|dev|%s|%llu", cell, (unsigned long long)block);
    sha256_init(&c); sha256_update(&c, (const uint8_t *)s, (size_t)n); sha256_update(&c, &z, 1); sha256_update(&c, parent, 32);
    sha256_final(&c, out);
}

static int interval(const int64_t *diff, uint32_t W, int64_t cell_term, const uint8_t seed[32], int64_t *lo, int64_t *hi) {
    ClRng boot; double mc;
    int rc = brw_boot_init(&boot, seed);
    if (rc == BRW_OK) rc = brw_bootstrap_interval(diff, W, cell_term, BRW_BOOT_B, &boot, lo, hi, &mc);
    return rc;
}

static int crit_check(char crit, int64_t lo, int64_t hi) {
    switch (crit) { case 'L': return lo > 0; case 'U': return hi < 0; case 'N': return !(lo > 0); default: return 1; }
}

int brw_calib_keys_cell(const char *cell, int nthreads, brw_calib_item *items, size_t *n, char *err, size_t errcap) {
    brw_cell_spec cs; brw_prog progs[8]; const brw_prog *pp[8]; brw_mode modes[8]; int ops[8]; int nops = 0;
    uint32_t W = brw_calib_cell_w(cell);
    size_t cnt = 0, first[32];
    if (!W || brw_cell_lookup(cell, &cs) != BRW_OK) { seterr(err, errcap, "unknown cell %s", cell ? cell : "(null)"); return BRW_E_ARG; }
    for (size_t i = 0; i < BRW_CALIB_CMPS_N; i++) if (!strcmp(BRW_CALIB_CMPS[i].cell, cell)) {
        first[cnt] = i; memset(&items[cnt], 0, sizeof items[cnt]); items[cnt].cmp = &BRW_CALIB_CMPS[i]; cnt++;
        int m = BRW_CALIB_CMPS[i].op_model, b = BRW_CALIB_CMPS[i].op_base;
        for (int k = 0; k < 2; k++) {
            int op = k ? b : m, f = 0;
            for (int j = 0; j < nops; j++) if (ops[j] == op) f = 1;
            if (!f) {
                if (nops >= 8) return BRW_E_ARG;
                int rc = brw_ref_program(op, &progs[nops]);
                if (rc != TYQ_OK) { seterr(err, errcap, "reference program 0x%02x refused (%d)", op, rc); return rc; }
                ops[nops] = op; nops++;
            }
        }
    }
    if (!cnt) { seterr(err, errcap, "cell %s has no comparison", cell); return BRW_E_ARG; }
    for (int j = 0; j < nops; j++) { pp[j] = &progs[j]; modes[j] = BRW_MODE_FIT_ONCE; }
    brw_world_score *sc = malloc((size_t)W * (size_t)nops * sizeof *sc);
    int64_t *diff = malloc((size_t)W * sizeof *diff);
    if (!sc || !diff) { free(sc); free(diff); return BRW_E_IO; }
    int rc = BRW_OK;
    for (uint32_t blk = 0; blk < BRW_CALIB_NBLOCKS && rc == BRW_OK; blk++) {
        rc = score_block(&cs, W, blk, nops, pp, modes, nthreads, sc, err, errcap);
        uint8_t seed[32]; dev_analysis_seed(cell, blk, seed);
        for (size_t c = 0; c < cnt && rc == BRW_OK; c++) {
            int im = -1, ib = -1; const brw_calib_cmp *cm = items[c].cmp;
            for (int j = 0; j < nops; j++) { if (ops[j] == cm->op_model) im = j; if (ops[j] == cm->op_base) ib = j; }
            brw_cell_dl b, m, ml; int64_t t = 0, lt = 0, lo = 0, hi = 0, llo = 0, lhi = 0;
            rc = brw_cell_dl_init(&b, &progs[ib]);
            if (rc == TYQ_OK) rc = brw_cell_dl_init(&m, &progs[im]);
            if (rc == TYQ_OK) rc = brw_cell_dl_init_bits(&ml, m.model_bits + 8u, m.k);   /* one byte longer, rider k unchanged */
            for (uint32_t w = 0; w < W && rc == TYQ_OK; w++) {
                const brw_world_score *sb = &sc[(uint64_t)w * (uint64_t)nops + (uint64_t)ib], *sm = &sc[(uint64_t)w * (uint64_t)nops + (uint64_t)im];
                rc = brw_cell_dl_add(&b, sb);
                if (rc == TYQ_OK) rc = brw_cell_dl_add(&m, sm);
                if (rc == TYQ_OK) rc = brw_cell_dl_add(&ml, sm);
                diff[w] = (sb->data_ub + sb->rider_ub) - (sm->data_ub + sm->rider_ub);   /* Section 8, R3-26 G5 */
            }
            if (rc == TYQ_OK) rc = brw_cell_gain(&b, &m, &t);
            if (rc == TYQ_OK) rc = brw_cell_gain(&b, &ml, &lt);
            if (rc == TYQ_OK && (lt != t - 8000000 || ml.bytes_ub != m.bytes_ub + 8000000)) { seterr(err, errcap, "lengthening arithmetic self-check failed"); rc = BRW_E_PROTOCOL; }
            if (rc == TYQ_OK) rc = interval(diff, W, b.bytes_ub - m.bytes_ub, seed, &lo, &hi);
            if (rc == TYQ_OK) rc = interval(diff, W, b.bytes_ub - ml.bytes_ub, seed, &llo, &lhi);
            if (rc != BRW_OK && rc != TYQ_OK) { if (!err || !*err) seterr(err, errcap, "%s %s block %u failed (%d)", cell, cm->item, blk, rc); break; }
            rc = BRW_OK;
            items[c].t[blk] = t; items[c].lo[blk] = lo; items[c].hi[blk] = hi;
            items[c].lt[blk] = lt; items[c].llo[blk] = llo; items[c].lhi[blk] = lhi;
            items[c].label[blk] = brw_calib_label4(t, lo, hi); items[c].llabel[blk] = brw_calib_label4(lt, llo, lhi);
            items[c].crit_ok[blk] = crit_check(cm->crit, lo, hi);
        }
    }
    free(sc); free(diff);
    if (rc != BRW_OK) return rc;
    for (size_t c = 0; c < cnt; c++) {
        brw_calib_item *it = &items[c];
        it->stable = 1; it->unchanged = 1;
        for (int b = 0; b < BRW_CALIB_NBLOCKS; b++) {
            /* sign 0 is not a sign: conservative, it fails stability */
            if (it->t[b] == 0 || (it->t[b] > 0) != (it->t[0] > 0) || it->label[b] != it->label[0]) it->stable = 0;
            if (it->llabel[b] != it->label[b]) it->unchanged = 0;
        }
    }
    (void)first;
    *n = cnt;
    return BRW_OK;
}

int brw_calib_keys_verdict(const brw_calib_item *items, size_t n, int which) {
    if (n == 0) return 0;
    for (size_t i = 0; i < n; i++) if (!(which ? items[i].unchanged : items[i].stable)) return 0;
    return 1;
}

int brw_calib_null_compare(const char *cell, const brw_null_cell *nc, int agree[6][3], double gap[6][3]) {
    const brw_frozen_null *fz = brw_frozen_null_find(cell);
    int bad = 0;
    if (!fz) return BRW_E_ARG;
    for (int i = 0; i < 6; i++) {
        const double a[3] = { nc->center[i], nc->lo[i], nc->hi[i] }, f[3] = { fz->nc.center[i], fz->nc.lo[i], fz->nc.hi[i] };
        int cellbad = 0;
        for (int k = 0; k < 3; k++) { agree[i][k] = a[k] == f[k]; gap[i][k] = fabs(a[k] - f[k]); if (!agree[i][k]) cellbad = 1; }
        bad += cellbad;
    }
    return bad;
}

/* ---------------------------------------------------------------- R3-31 coverage check */

/* DESIGN_CHECK_R2.md lines 397-407, column "nullcal-quantile test rate" (frozen test; R3-26 G16). */
double brw_calib_design_r0(const char *cell, int *found) {
    static const struct { const char *c; double r; } R[11] = {
        { "B0-regular", 0.052 }, { "B0-irregular", 0.048 }, { "B1-0", 0.065 }, { "B1-1", 0.052 }, { "B1-3", 0.052 }, { "B1-4n", 0.040 },
        { "B2-noise", 0.050 }, { "B2-weak", 0.048 }, { "B2-clear", 0.043 }, { "B2-fast", 0.050 }, { "B2-emerging", 0.075 } };
    for (int i = 0; i < 11; i++) if (!strcmp(R[i].c, cell)) { if (found) *found = 1; return R[i].r; }
    if (found) *found = 0;
    return 0.0;
}

static int cmp_dbl(const void *a, const void *b) { double x = *(const double *)a, y = *(const double *)b; return (x > y) - (x < y); }

int brw_calib_cov_from_worlds(const char *cell, const brw_diag *worlds, uint64_t nb, brw_calib_cov *out, char *err, size_t errcap) {
    const brw_frozen_null *fz = brw_frozen_null_find(cell);
    uint32_t W = brw_calib_cell_w(cell); int found = 0;
    if (!fz || !W || nb == 0 || fz->W != W) { seterr(err, errcap, "no frozen null row (or W mismatch) for %s", cell ? cell : "(null)"); return BRW_E_ARG; }
    brw_diag *bm = malloc((size_t)nb * sizeof *bm);
    if (!bm) return BRW_E_IO;
    memset(out, 0, sizeof *out);
    snprintf(out->cell, sizeof out->cell, "%s", cell); out->W = W; out->n_blocks = nb;
    int rc = BRW_OK;
    for (uint64_t b = 0; b < nb && rc == BRW_OK; b++) {
        int fl[6];
        rc = brw_diag_block_mean(worlds + b * W, W, &bm[b]);
        if (rc == BRW_OK && brw_null_reject(&bm[b], &fz->nc, fl)) out->rejected++;
    }
    if (rc != BRW_OK) { free(bm); seterr(err, errcap, "block mean failed (%d)", rc); return rc; }
    out->rate = (double)out->rejected / (double)nb;
    out->r0 = brw_calib_design_r0(cell, &found);
    if (!found) { free(bm); seterr(err, errcap, "no design-check rate r0 for %s", cell); return BRW_E_ARG; }
    out->se = sqrt(out->r0 * (1.0 - out->r0) / (double)nb); out->band = 4.0 * out->se;
    out->worst_bound = 0.065 + 4.0 * sqrt(0.065 * 0.935 / (double)nb);
    out->band_ok = fabs(out->rate - out->r0) <= out->band;
    out->worst_ok = out->rate <= out->worst_bound;
    out->p_stop13 = brw_binom_range(5, 20, 20, out->rate);       /* 1 - BinomCDF(4; 20, r) */
    out->p_stop13_r0 = brw_binom_range(5, 20, 20, out->r0);
    out->pass = out->band_ok;   /* R3-32: worst-rate line is a diagnostic only */
    if (nb >= 100) {   /* diagnostics only */
        out->have_diag = 1;
        double *x = malloc((size_t)nb * sizeof *x);
        if (!x) { free(bm); return BRW_E_IO; }
        for (int s = 0; s < 6; s++) {
            double sum = 0;
            for (uint64_t b = 0; b < nb; b++) { x[b] = (&bm[b].mean_z)[s]; sum += x[b]; }
            qsort(x, (size_t)nb, sizeof *x, cmp_dbl);
            const double f[3] = { fz->nc.center[s], fz->nc.lo[s], fz->nc.hi[s] };
            const double fresh[3] = { sum / (double)nb, x[(size_t)(BRW_NULL_TAIL * (double)nb)],
                                      x[(size_t)((1.0 - BRW_NULL_TAIL) * (double)nb) < nb ? (size_t)((1.0 - BRW_NULL_TAIL) * (double)nb) : nb - 1] };
            for (int k = 0; k < 3; k++) out->gap[s][k] = fabs(fresh[k] - f[k]);
            for (int side = 0; side < 2; side++) {   /* order-statistic 99.9% interval for the population quantile p */
                double p = side ? 1.0 - BRW_NULL_TAIL : BRW_NULL_TAIL;
                uint32_t n32 = (uint32_t)nb; int kl = 0, ku = (int)n32;
                for (int k = 1; k <= (int)n32; k++) { if (brw_binom_range(0, k - 1, n32, p) <= 0.0005) kl = k; else break; }
                for (int k = 0; k <= (int)n32; k++) if (brw_binom_range(0, k, n32, p) >= 0.9995) { ku = k; break; }
                double lo = kl >= 1 ? x[kl - 1] : -INFINITY, hi = ku < (int)n32 ? x[ku] : INFINITY;
                out->contained[s][side] = f[1 + side] >= lo && f[1 + side] <= hi;
            }
        }
        free(x);
    }
    free(bm);
    return BRW_OK;
}

int brw_calib_coverage_null(const char *cell, uint64_t n, int nthreads, brw_calib_cov *out, char *err, size_t errcap) {
    brw_cell_spec cs; uint32_t W = brw_calib_cell_w(cell);
    if (!W || brw_cell_lookup(cell, &cs) != BRW_OK) { seterr(err, errcap, "unknown cell %s", cell ? cell : "(null)"); return BRW_E_ARG; }
    if (n == 0 || n % W != 0) { seterr(err, errcap, "n_worlds must be a positive multiple of W=%u", W); return BRW_E_ARG; }
    brw_diag *w = malloc((size_t)n * sizeof *w);
    if (!w) return BRW_E_IO;
    int rc = brw_calib_null_worlds(&cs, n, nthreads, w, err, errcap);
    if (rc == BRW_OK) rc = brw_calib_cov_from_worlds(cell, w, n / W, out, err, errcap);
    free(w);
    return rc;
}

int brw_calib_coverage_dev(const char *cell, uint32_t n_blocks, int nthreads, brw_calib_cov *out, char *err, size_t errcap) {
    brw_cell_spec cs; uint32_t W = brw_calib_cell_w(cell);
    if (!W || !n_blocks || brw_cell_lookup(cell, &cs) != BRW_OK) { seterr(err, errcap, "unknown cell or zero blocks"); return BRW_E_ARG; }
    brw_diag *w = malloc((size_t)n_blocks * W * sizeof *w);
    if (!w) return BRW_E_IO;
    int rc = BRW_OK;
    for (uint32_t b = 0; b < n_blocks && rc == BRW_OK; b++)
        rc = brw_calib_null_worlds_ex(&cs, BRW_DEV_PARENT, b, W, nthreads, w + (size_t)b * W, err, errcap);
    if (rc == BRW_OK) rc = brw_calib_cov_from_worlds(cell, w, n_blocks, out, err, errcap);
    free(w);
    return rc;
}

void brw_calib_write_cov(FILE *f, const brw_calib_cov *c) {
    fprintf(f, "%s %llu %llu %.17g %.17g %.17g\n", c->cell, (unsigned long long)c->n_blocks, (unsigned long long)c->rejected,
            c->rate, c->r0, c->p_stop13);
}

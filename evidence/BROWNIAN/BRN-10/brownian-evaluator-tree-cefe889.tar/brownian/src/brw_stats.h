/* brw_stats.h: Brownian evaluator statistics (Lane D, plan §12-§17, §28.2; decisions R3-2, R3-3, R3-19, R3-20).
 * Pure statistics: no world generation and no predictor code. Callers hand in per-world arrays.
 * Every function returns BRW_OK or a BRW_E_* code from brw_rng.h unless noted. */
#ifndef BRW_STATS_H
#define BRW_STATS_H
#include <stddef.h>
#include <stdint.h>
#include "brw_rng.h"   /* BRW_E_*, ClRng, brw_stream_init */

#define BRW_BOOT_B          10000u        /* plan §16: B = 10000 paired resamples (the design-check grid used 2000) */
#define BRW_NULL_TAIL       (0.05 / 12.0) /* per-tail probability of the frozen null intervals: q0.42% / q99.58% */
#define BRW_STOP13_LIMIT    5             /* stop #13: reject in >= 5 of 20 development blocks (R3-3) */
#define BRW_STOP13_BLOCKS   20

/* ---------- special functions ---------- */
/* 0.5*erfc(-x/sqrt(2)); copied from omega src/runtime/rx_costmodel.c:232 (norm_cdf), never edited there. */
double brw_norm_cdf(double x);
/* B25: x with P(dof/2, x/2) = p; Newton on the regularised lower incomplete gamma (long double), series for
 * x/2 < dof/2+1, continued fraction otherwise, Wilson-Hilferty start, stop at relative step < 1e-15
 * (a bracketing bisection guards every step). dof >= 1, 0 < p < 1. */
int brw_chi2_quantile(uint32_t dof, double p, double *out);
/* Regularised lower incomplete gamma P(a, x) in long double; exposed for tests. */
long double brw_gamma_p_ld(long double a, long double x);

/* ---------- bootstrap over worlds (B11, B12, B27, OI-12) ---------- */
/* Initialise the paired bootstrap stream: brw_stream_init(boot, analysis_seed, "bootstrap") (OI-4). Re-init for every
 * comparison so all pairs of a cell share resamples. */
int brw_boot_init(ClRng *boot, const uint8_t analysis_seed[32]);
/* Plan §28.2 signature. Resample r = 0..B-1 in order draws n world indices with cl_rng_below(boot, n) in order;
 * statistic_r = cell_term_ub + sum of per_world_diff_ub over the resample. Sorted ascending, lo = element index
 * B*25/1000-1 (249 at B=10000), hi = B*975/1000-1 (9749). mc_err_bits (may be NULL): the B resamples are split in
 * order into 10 batches of B/10 (B multiple of 10, >= 400); each batch's 2.5% bound is its sorted element index
 * (B/10)*25/1000-1 (24 at 10000); mc_err = sample sd (n-1) of the 10 bounds / sqrt(10), divided by 1e6 (bits). */
int brw_bootstrap_interval(const int64_t *per_world_diff_ub, size_t n_worlds, int64_t cell_term_ub,
                           uint32_t B, ClRng *boot, int64_t *lo_ub, int64_t *hi_ub, double *mc_err_bits);
/* Same rule on doubles: statistic = sum (mean=0) or mean (mean=1) of the resample; no cell term. mc_err in the
 * statistic's own unit. */
int brw_bootstrap_interval_d(const double *v, size_t n, int mean, uint32_t B, ClRng *boot,
                             double *lo, double *hi, double *mc_err);

typedef enum { BRW_CLASS_NEG = -1, BRW_CLASS_AMB = 0, BRW_CLASS_POS = 1 } brw_class;
/* hi < 0 -> NEG; lo > 0 -> POS; otherwise AMB (interval covers 0). "lower > 0" item == POS; "upper < 0" item == NEG;
 * "lower not above 0" (B2-weak, R3-2) == (class != POS). */
brw_class brw_classify(double lo, double hi);
brw_class brw_classify_ub(int64_t lo_ub, int64_t hi_ub);

/* ---------- reference intervals (§13, §16, B20, B26) ---------- */
/* D0, Y = X: n = split-1 increments, D_hat = (1/(2n)) sum d_i^2/h_i, interval [n D_hat/c_hi, n D_hat/c_lo], c_lo/c_hi
 * the 0.025/0.975 chi-square quantiles with n dof. Prefix = indices [0, split); split >= 2, h > 0. */
int brw_d_interval(const double *t, const double *y, uint32_t split, double *d_hat, double *lo, double *hi);
/* B1 D interval: D_hat = v_rate_hat/2 from drift-residual increments, n_inc dof (B26); same interval form. */
int brw_d_interval_drift(const double *t, const double *y, uint32_t split, double *d_hat, double *lo, double *hi);
/* mu_hat = (y_last-y_first)/(t_last-t_first); se = sqrt(v_rate_hat/(t_last-t_first)); mu_hat +/- 1.959963984540054 se;
 * v_rate_hat = (1/n_inc) sum (d_j - mu_hat h_j)^2/h_j (ML divisor). */
int brw_mu_interval(const double *t, const double *y, uint32_t split, double *mu_hat, double *lo, double *hi);

/* ---------- exact binomial bands (coverage and exclusion items) ---------- */
double brw_binom_pmf(uint32_t k, uint32_t n, double p);
/* sum_{k=lo}^{hi} pmf (k clamped to [0,n]); long double evaluation */
double brw_binom_range(int lo, int hi, uint32_t n, double p);
/* count bounds for a fraction f of n: lo = ceil(f n - 1e-9), hi = floor(f n + 1e-9) (design-check convention) */
int brw_band_count_lo(double f, uint32_t n);
int brw_band_count_hi(double f, uint32_t n);
/* P(count/n inside [f_lo, f_hi]) for n independent worlds each with per-world probability p (exact binomial). */
double brw_band_pass_prob(uint32_t n, double p, double f_lo, double f_hi);
enum { BRW_BAND_PASS = 0, BRW_BAND_WARN = 1, BRW_BAND_STOP = 2 };
/* PASS if count in [ceil(f_lo n), floor(f_hi n)]; else STOP if outside [ceil(stop_lo n), floor(stop_hi n)]; else WARN.
 * One-sided items ("at least 0.40"): f_hi = stop_hi = 1 and stop_lo = f_lo. */
int brw_band_check(uint32_t count, uint32_t n, double f_lo, double f_hi, double stop_lo, double stop_hi);
uint32_t brw_count_cover(const double *lo, const double *hi, const double *truth, size_t n);  /* lo <= truth <= hi */
uint32_t brw_count_excludes(const double *lo, const double *hi, size_t n, double value);      /* value < lo || value > hi */
uint32_t brw_count_below(const double *hi, size_t n, double value);                            /* hi < value */

/* ---------- residual diagnostics (B19) ---------- */
typedef struct { double mean_z, mean_z2, lag1, spearman_z2_t, slope_prev_y, excess_kurt; } brw_diag;
/* Per world on n held-out points (n >= 3): mean z; mean z^2; lag-1 autocorrelation
 * sum_{i<n-1}(z_i-m)(z_{i+1}-m) / sum(z_i-m)^2; Spearman(z^2, t) (average ranks, Pearson of ranks; 0 when a rank
 * variance is 0); slope of z on y_prev by OLS (0 if y_prev is constant); excess kurtosis m4/m2^2-3 (population
 * moments). E_RANGE when z has zero variance. */
int brw_diag_world(const double *z, const double *t, const double *y_prev, size_t n, brw_diag *out);
/* mean of the per-world statistics over n_worlds worlds (the block mean) */
int brw_diag_block_mean(const brw_diag *worlds, size_t n_worlds, brw_diag *mean);
/* Holm step-down at familywise alpha over six p-values; reject[i] set; returns the number rejected. */
int brw_holm6(const double p[6], double alpha, int reject[6]);
/* Two-sided bootstrap p-value (OI-12) min(1, 2 min(F_le, F_ge)) of the B resampled block means against null_center[i];
 * resamples are paired across the six statistics (one index draw per resample). Then Holm at alpha. Family rejection
 * == *n_reject > 0. */
int brw_diag_boot_holm(const brw_diag *worlds, size_t n_worlds, const double null_center[6], uint32_t B,
                       ClRng *boot, double alpha, double p[6], int reject[6], int *n_reject);

/* ---------- finite-sample null table (R3-3, R3-19b) ---------- */
typedef struct { double center[6], lo[6], hi[6]; } brw_null_cell;   /* order: mean z, mean z^2, lag1, spearman, slope, kurt */
/* From n_blocks null block means: center = mean of the block means; lo/hi = sorted block-mean elements at index
 * (int)(tail*nb) and min(nb-1, (int)((1-tail)*nb)) (design-check convention). n_blocks >= 100. Generation of the null
 * worlds is the caller's. */
int brw_null_calibrate(const brw_diag *block_means, size_t n_blocks, double tail, brw_null_cell *out);
/* Direct family test against the frozen interval: flags[i] = 1 when block-mean statistic i lies outside [lo, hi];
 * returns 1 if any does. The first Holm step at 0.05 over six is per-statistic two-sided 0.05/6 = tails 0.05/12, which
 * is exactly the frozen [q0.42%, q99.58%] interval, and Holm rejects the family iff its first step rejects. */
int brw_null_reject(const brw_diag *block_mean, const brw_null_cell *nc, int flags[6]);
/* Stop #13: *stop = 1 when n_reject >= 5 of exactly 20 development blocks (R3-3). E_ARG if n_blocks != 20. */
int brw_stop13(uint32_t n_reject, uint32_t n_blocks, int *stop);

/* The frozen table of DESIGN_CHECK_R2 (1fd3189, "Frozen values"). B0-short has no row (not run, N = 8). */
typedef struct { const char *cell; uint32_t W, H; const char *matching_ref; brw_null_cell nc; } brw_frozen_null;
extern const brw_frozen_null BRW_FROZEN_NULLS[];
extern const size_t BRW_FROZEN_NULLS_N;   /* 11 */
const brw_frozen_null *brw_frozen_null_find(const char *cell);
#endif

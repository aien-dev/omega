/* brw_calib.h: BRN-5 calibration tool library (null calibration, Occam crossing, fit-once vs prequential,
 * brw.calib.v1 assembly). Private, sealed. C only. Decisions: R3-3, R3-19, R3-24 (U6, U10, U11), R3-26 (G3, G15, G17),
 * R3-28 (d, e). Every function returns BRW_OK or a BRW_E_* / TYQ_* code; err (may be NULL) gets a message. */
#ifndef BRW_CALIB_H
#define BRW_CALIB_H
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include "brw_world.h"
#include "brw_stats.h"

#define BRW_CALIB_HEADER    "brw.calib.v1"
#define BRW_CALIB_NULL_PARENT "brownian.nullcal.v1"   /* U11: replaces brownian.dev.v1 as the parent seed */
#define BRW_CALIB_OCC_NS    16                        /* U10: s >= 0 grid points */
#define BRW_CALIB_OCC_NH    4
extern const double BRW_CALIB_OCC_S[BRW_CALIB_OCC_NS];
extern const uint32_t BRW_CALIB_OCC_H[BRW_CALIB_OCC_NH];
extern const char *const BRW_CALIB_STAT_NAMES[6];     /* mean_z mean_z2 ac1 spearman_z2_t slope_z_yprev exkurt */
extern const char *const BRW_CALIB_PRIMARY[11];       /* the 11 cells with a null row, in byte order */

/* Worlds per block W of a cell (brw_cells.h: 400, 200 for B2-weak/clear/fast, 1600 for B2-emerging). 0 if unknown. */
uint32_t brw_calib_cell_w(const char *cell);
/* Reference opcode of the matching reference (Section 10): D0 -> DIFFUSION 0x04, D1 -> DIFFUSION_DRIFT 0x05, D2 -> MEAN_REVERT 0x06. */
int brw_calib_match_opcode(const brw_cell_spec *cs);
/* world_seed of world `rep` of `block` of `cell` under `parent` (mode "dev"). */
int brw_calib_world_seed(const char *parent, const char *cell, uint64_t block, uint64_t rep, uint8_t out[32]);

/* Generic parallel-for: fn(ctx, begin, end, tid) over contiguous ranges of [0,n). nthreads <= 1 runs inline. */
typedef void (*brw_calib_range_fn)(void *ctx, uint64_t begin, uint64_t end, int tid);
int brw_calib_par(uint64_t n, int nthreads, brw_calib_range_fn fn, void *ctx);

/* Six diagnostics of every one of n null worlds (index 0..n-1) of the cell. Deterministic in nthreads. */
int brw_calib_null_worlds(const brw_cell_spec *cs, uint64_t n, int nthreads, brw_diag *out, char *err, size_t errcap);
/* Block means over blocks of W consecutive worlds, then brw_null_calibrate at tail BRW_NULL_TAIL. Needs n % W == 0
 * and n / W >= 100. */
int brw_calib_null_from_worlds(const brw_diag *worlds, uint64_t n, uint32_t W, brw_null_cell *nc, char *err, size_t errcap);
int brw_calib_nullcal(const char *cell, uint64_t n, int nthreads, brw_null_cell *nc, char *err, size_t errcap);
/* Writes the six `<cell> <stat> <center> <lo> <hi>` lines (%.17g). */
void brw_calib_write_null(FILE *f, const char *cell, const brw_null_cell *nc);

/* Occam OCC cell spec: D1, regular, exact, N = 128 + H, SPLIT 128, snr_s = s; name "OCC-s%+.2f-H%u" (U10). */
int brw_calib_occ_spec(double s, uint32_t H, brw_cell_spec *cs, char *name, size_t cap);
/* Mean certification T (DIFFUSION_DRIFT vs DIFFUSION, micro-bits, byte term -128 bits once per block, riders) over
 * dev blocks 0..n_blocks-1 of W = 400 worlds. */
int brw_calib_occ_mean_t(double s, uint32_t H, uint32_t n_blocks, int nthreads, double *mean_t_ub, char *err, size_t errcap);
/* Linear zero crossing of a mean-T curve over grid s[0..n): first k with t[k] < 0 <= t[k+1]. BRW_E_RANGE if none. */
int brw_calib_cross(const double *s, const double *t, size_t n, double *s_cross);

/* fit-once vs prequential (Section 11, R3-26 G15). Comparison (model M vs baseline B) per cell: see brw_calib.c. */
typedef struct {
    char cell[32]; uint64_t block; uint32_t W;
    int op_model, op_base;
    double t_fit_ub, t_preq_ub;          /* T in micro-bits, byte term included in both arms */
    double rel_gap;                      /* |Tf - Tp| / max(|Tf|, |Tp|) */
    int agree;                           /* sign(Tf) == sign(Tp) */
    double data_fit_mean_ub, data_preq_mean_ub;   /* model program: mean per-world data_ub (structural KAT, R3-28e) */
    int kat_pass;                        /* |difference| > 1 ub (= 1e-6 bit) */
} brw_calib_preq;
int brw_calib_preqcheck(const char *cell, uint64_t block, int nthreads, brw_calib_preq *out, char *err, size_t errcap);

/* brw.calib.v1 text: validate grammar (and, unless partial, completeness: 11 cells x 6 stats and occ H 128 256 512 1024). */
int brw_calib_check_text(const char *text, int partial, char *err, size_t errcap);
/* Merge part texts (null lines and occ_cross lines, any order) into the canonical file text (malloc'd). */
int brw_calib_assemble(const char *const *parts, size_t nparts, int partial, char **out, char *err, size_t errcap);

/* ---- qfreeze keys 11/12 (R3-30i): lengthening_test and stability_test; development blocks only ----
 * Comparison table = every "T of M against B" item of Sections 13 (items 1-6), 14 and 15 (items 1-4, and the B2-emerging
 * label). crit: 'L' lower > 0, 'U' upper < 0, 'N' lower NOT above 0, '-' none (sign/label only). */
typedef struct { const char *cell; int op_model, op_base; char crit; const char *item; } brw_calib_cmp;
extern const brw_calib_cmp BRW_CALIB_CMPS[];
extern const size_t BRW_CALIB_CMPS_N;
extern const char *const BRW_CALIB_KEY_CELLS[12];     /* the 11 primary cells plus B0-short */
#define BRW_CALIB_NBLOCKS 3                           /* development blocks 0, 1, 2 (Section 5 item 6, Section 11) */
typedef enum { BRW_LAB_POSITIVE = 0, BRW_LAB_NEGATIVE, BRW_LAB_WEAK, BRW_LAB_AMBIGUOUS } brw_calib_label;
const char *brw_calib_label_name(int label);
/* Four-way label of Section 8 (R3-26 G6) from T and its interval, all micro-bits. */
int brw_calib_label4(int64_t t, int64_t lo, int64_t hi);
typedef struct {
    const brw_calib_cmp *cmp;
    int64_t t[BRW_CALIB_NBLOCKS], lo[BRW_CALIB_NBLOCKS], hi[BRW_CALIB_NBLOCKS];          /* as scored */
    int64_t lt[BRW_CALIB_NBLOCKS], llo[BRW_CALIB_NBLOCKS], lhi[BRW_CALIB_NBLOCKS];       /* candidate side lengthened by one byte */
    int label[BRW_CALIB_NBLOCKS], llabel[BRW_CALIB_NBLOCKS];
    int crit_ok[BRW_CALIB_NBLOCKS];
    int stable;      /* sign(T) nonzero and identical, four-way label identical, on all blocks */
    int unchanged;   /* lengthened label == as-scored label on every block */
} brw_calib_item;
/* Scores every comparison of `cell` on dev blocks 0..2. `items` needs room for BRW_CALIB_CMPS_N entries; *n gets the count. */
int brw_calib_keys_cell(const char *cell, int nthreads, brw_calib_item *items, size_t *n, char *err, size_t errcap);
/* PASS/FAIL over items: which = 0 stability, 1 lengthening. */
int brw_calib_keys_verdict(const brw_calib_item *items, size_t n, int which);

/* nullcal cross-check (R3-30 addendum): exact double equality against the compiled-in frozen table, per stat and field.
 * Returns the number of disagreeing statistics (0 = all agree); agree[i][f] set (f: 0 center, 1 lo, 2 hi), maxgap[i][f] the
 * absolute gap. BRW_E_ARG if the cell has no frozen row. */
int brw_calib_null_compare(const char *cell, const brw_null_cell *nc, int agree[6][3], double gap[6][3]);

/* ---- R3-31 coverage check of the frozen null table (binding) plus printed diagnostics ---- */
int brw_calib_null_worlds_ex(const brw_cell_spec *cs, const char *parent, uint64_t block, uint64_t n, int nthreads, brw_diag *out, char *err, size_t errcap);
/* r0: the design-check per-cell rate of the frozen nullcal-quantile test (DESIGN_CHECK_R2 Diagnostics, column "nullcal-quantile
 * test rate", rounded to 3 decimals there). 0 with *found = 0 if the cell has none. */
double brw_calib_design_r0(const char *cell, int *found);
typedef struct {
    char cell[32]; uint32_t W; uint64_t n_blocks, rejected;
    double rate, r0, se, band;      /* se = sqrt(r0(1-r0)/n_b); band = 4 se */
    double worst_bound;             /* 0.065 + 4 sqrt(0.065 * 0.935 / n_b) */
    double p_stop13;                /* 1 - BinomCDF(4; 20, rate) (G16) */
    double p_stop13_r0;             /* same at r0 */
    int band_ok, worst_ok, pass;
    /* diagnostics only (R3-31d); have_diag needs >= 100 blocks */
    int have_diag; double gap[6][3]; int contained[6][2];   /* fresh vs frozen: center/lo/hi abs gap; frozen lo/hi inside the 99.9% order-statistic interval */
} brw_calib_cov;
/* worlds: n_blocks * W per-world diagnostics in block order. Rejection = brw_null_reject of the block mean against the
 * FROZEN interval (the Section 10 nullcal-quantile test, exactly what brownian_bench calibrate counts). */
int brw_calib_cov_from_worlds(const char *cell, const brw_diag *worlds, uint64_t n_blocks, brw_calib_cov *out, char *err, size_t errcap);
/* Fresh nullcal sample: n worlds (multiple of W) of parent brownian.nullcal.v1, block 0. */
int brw_calib_coverage_null(const char *cell, uint64_t n, int nthreads, brw_calib_cov *out, char *err, size_t errcap);
/* Development sample: blocks 0..n_blocks-1 of parent brownian.dev.v1 (the same worlds brownian_bench dev writes). */
int brw_calib_coverage_dev(const char *cell, uint32_t n_blocks, int nthreads, brw_calib_cov *out, char *err, size_t errcap);
/* Sidecar line (the frozen spec's U6 grammar permits no extra lines in brw.calib.v1, so these go to brw.calib.cov.v1). */
void brw_calib_write_cov(FILE *f, const brw_calib_cov *c);
#endif

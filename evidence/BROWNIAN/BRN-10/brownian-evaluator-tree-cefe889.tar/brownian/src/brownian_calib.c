/* brownian_calib: BRN-5 calibration CLI (private, sealed). Usage:
 *   brownian_calib [-j N] [-v] nullcal <cell> <n_worlds>
 *   brownian_calib [-j N] [-v] [-n] occcross <H> <n_blocks>
 *   brownian_calib [-j N] preqcheck <cell> <block>
 *   brownian_calib [-j N] stability|lengthening [cell...]   (qfreeze keys 12, 11; dev blocks 0-2)
 *   brownian_calib [-j N] coverage [--dev] [--sidecar F] <cell> <n_worlds|n_blocks>       (R3-31 coverage of the frozen null table)
 *   brownian_calib assemble [--partial] <part-file>...          (writes brw.calib.v1 to stdout)
 * Results go to stdout; timing and diagnostics to stderr. */
#include "brw_calib.h"
#include "brw_cells.h"
#include "brw_rng.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

static double now(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec; }
static int usage(void) {
    fprintf(stderr, "usage: brownian_calib [-j N] [-v] [-n] nullcal <cell> <n_worlds> | occcross <H> <n_blocks> | preqcheck <cell> <block> | stability [cell...] | lengthening [cell...] | coverage [--dev] [--sidecar F] <cell> <n_worlds|n_blocks> | assemble [--partial] <part>...\n");
    return 64;
}
static char *slurp(const char *path) {
    FILE *f = fopen(path, "rb"); char *b = NULL; long z;
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) == 0 && (z = ftell(f)) >= 0 && fseek(f, 0, SEEK_SET) == 0 && (b = malloc((size_t)z + 1))) {
        if (fread(b, 1, (size_t)z, f) != (size_t)z) { free(b); b = NULL; } else b[z] = 0;
    }
    fclose(f);
    return b;
}
static int parse_u64(const char *s, uint64_t *v) { char *e; if (!*s || *s == '-') return 0; *v = strtoull(s, &e, 10); return !*e; }

int main(int argc, char **argv) {
    int nthreads = 1, verbose = 0, neg = 0, a = 1;
    char err[256] = "";
    while (a < argc && argv[a][0] == '-' && strcmp(argv[a], "--partial") != 0) {
        if (!strcmp(argv[a], "-j") && a + 1 < argc) { nthreads = atoi(argv[a + 1]); a += 2; if (nthreads < 1) return usage(); }
        else if (!strcmp(argv[a], "-v")) { verbose = 1; a++; }
        else if (!strcmp(argv[a], "-n")) { neg = 1; a++; }
        else return usage();
    }
    if (a >= argc) return usage();
    const char *cmd = argv[a++];
    double t0 = now();

    if (!strcmp(cmd, "nullcal")) {
        uint64_t n; brw_null_cell nc;
        if (a + 2 != argc || !parse_u64(argv[a + 1], &n)) return usage();
        int rc = brw_calib_nullcal(argv[a], n, nthreads, &nc, err, sizeof err);
        if (rc) { fprintf(stderr, "nullcal: %s\n", err); return 2; }
        brw_calib_write_null(stdout, argv[a], &nc);
        fprintf(stderr, "nullcal %s n=%llu j=%d: %.2f s\n", argv[a], (unsigned long long)n, nthreads, now() - t0);
        return 0;
    }
    if (!strcmp(cmd, "occcross")) {
        uint64_t H, nb;
        if (a + 2 != argc || !parse_u64(argv[a], &H) || !parse_u64(argv[a + 1], &nb) || nb == 0) return usage();
        double s[2 * BRW_CALIB_OCC_NS], t[2 * BRW_CALIB_OCC_NS], sx;
        for (int half = 0; half < (neg ? 2 : 1); half++)
            for (int i = 0; i < BRW_CALIB_OCC_NS; i++) {
                int idx = half * BRW_CALIB_OCC_NS + i;
                s[idx] = (half ? -1.0 : 1.0) * BRW_CALIB_OCC_S[i];
                int rc = brw_calib_occ_mean_t(s[idx], (uint32_t)H, (uint32_t)nb, nthreads, &t[idx], err, sizeof err);
                if (rc) { fprintf(stderr, "occcross: %s\n", err); return 2; }
                if (verbose) fprintf(stderr, "OCC-s%+.2f-H%llu mean T = %.6f bits/block\n", s[idx], (unsigned long long)H, t[idx] / 1e6);
            }
        if (brw_calib_cross(s, t, BRW_CALIB_OCC_NS, &sx)) { fprintf(stderr, "occcross: no sign change on the positive grid\n"); return 3; }
        printf("occ_cross %llu %.17g\n", (unsigned long long)H, sx);
        if (neg) {   /* mirror the negative half so it reads in ascending |s| */
            double ns[BRW_CALIB_OCC_NS], nt[BRW_CALIB_OCC_NS], nx;
            for (int i = 0; i < BRW_CALIB_OCC_NS; i++) { ns[i] = -s[BRW_CALIB_OCC_NS + i]; }
            /* on the negative side T(-s) < 0 is the same drift-earns-credit event; use T itself, not -T */
            for (int i = 0; i < BRW_CALIB_OCC_NS; i++) nt[i] = t[BRW_CALIB_OCC_NS + i];
            if (!brw_calib_cross(ns, nt, BRW_CALIB_OCC_NS, &nx)) fprintf(stderr, "negative-side crossing |s| = %.17g (symmetry check, not written)\n", nx);
            else fprintf(stderr, "negative-side crossing: none\n");
        }
        fprintf(stderr, "occcross H=%llu blocks=%llu j=%d: %.2f s\n", (unsigned long long)H, (unsigned long long)nb, nthreads, now() - t0);
        return 0;
    }
    if (!strcmp(cmd, "preqcheck")) {
        uint64_t blk; brw_calib_preq r;
        if (a + 2 != argc || !parse_u64(argv[a + 1], &blk)) return usage();
        int rc = brw_calib_preqcheck(argv[a], blk, nthreads, &r, err, sizeof err);
        if (rc) { fprintf(stderr, "preqcheck: %s\n", err); return 2; }
        printf("preqcheck %s block %llu W %u model 0x%02x baseline 0x%02x\n", r.cell, (unsigned long long)r.block, r.W, r.op_model, r.op_base);
        printf("T_fit_once_bits_per_block %.9g\nT_prequential_bits_per_block %.9g\nrelative_gap %.9g\n", r.t_fit_ub / 1e6, r.t_preq_ub / 1e6, r.rel_gap);
        printf("mean_data_ub_fit_once %.9g\nmean_data_ub_prequential %.9g\n", r.data_fit_mean_ub, r.data_preq_mean_ub);
        int is_kat = !strcmp(r.cell, "B1-3") && r.block == 0;
        if (is_kat) printf("structural_KAT %s (|data_ub gap| %.9g ub, needs > 1)\n", r.kat_pass ? "PASS" : "FAIL", fabs(r.data_fit_mean_ub - r.data_preq_mean_ub));
        printf("%s\n", r.agree ? "AGREE" : "STOP");
        fprintf(stderr, "preqcheck %s j=%d: %.2f s\n", r.cell, nthreads, now() - t0);
        return (r.agree && (!is_kat || r.kat_pass)) ? 0 : 4;
    }
    if (!strcmp(cmd, "stability") || !strcmp(cmd, "lengthening")) {
        int which = !strcmp(cmd, "lengthening"), all_ok = 1, ncell = 0;
        const char *cells[12]; brw_calib_item *items = calloc(BRW_CALIB_CMPS_N, sizeof *items);
        if (a == argc) for (int i = 0; i < 12; i++) cells[ncell++] = BRW_CALIB_KEY_CELLS[i];
        else while (a < argc && ncell < 12) cells[ncell++] = argv[a++];
        if (!items || a != argc) return usage();
        for (int c = 0; c < ncell; c++) {
            size_t n = 0;
            int rc = brw_calib_keys_cell(cells[c], nthreads, items, &n, err, sizeof err);
            if (rc) { fprintf(stderr, "%s: %s\n", cmd, err); return 2; }
            for (size_t i = 0; i < n; i++) {
                const brw_calib_item *it = &items[i];
                printf("%s %s %s", cmd, it->cmp->cell, it->cmp->item);
                for (int b = 0; b < BRW_CALIB_NBLOCKS; b++) {
                    if (which) printf(" | b%d %s->%s", b, brw_calib_label_name(it->label[b]), brw_calib_label_name(it->llabel[b]));
                    else printf(" | b%d T %.6g [%.6g,%.6g] %s%s", b, (double)it->t[b] / 1e6, (double)it->lo[b] / 1e6, (double)it->hi[b] / 1e6,
                                brw_calib_label_name(it->label[b]), it->crit_ok[b] ? "" : " (item criterion not met)");
                }
                printf(" | %s\n", (which ? it->unchanged : it->stable) ? "ok" : "CHANGED");
            }
            int v = brw_calib_keys_verdict(items, n, which);
            printf("%s %s %s\n", cmd, cells[c], v ? "PASS" : "FAIL");
            if (!v) all_ok = 0;
        }
        free(items);
        printf("%s %s\n", which ? "lengthening_test" : "stability_test", all_ok ? "PASS" : "FAIL");
        fprintf(stderr, "%s j=%d: %.2f s\n", cmd, nthreads, now() - t0);
        return all_ok ? 0 : 4;
    }
    if (!strcmp(cmd, "coverage")) {   /* R3-31 (b): coverage of the FROZEN null intervals on a fresh sample */
        const char *sidecar = NULL; int dev = 0; uint64_t n; brw_calib_cov c;
        while (a < argc && argv[a][0] == '-' && strcmp(argv[a], "--partial") != 0) {
            if (!strcmp(argv[a], "--dev")) { dev = 1; a++; }
            else if (!strcmp(argv[a], "--sidecar") && a + 1 < argc) { sidecar = argv[a + 1]; a += 2; }
            else return usage();
        }
        if (a + 2 != argc || !parse_u64(argv[a + 1], &n) || n > 0xffffffffu * (uint64_t)(dev ? 1 : 4000)) return usage();
        int rc = dev ? brw_calib_coverage_dev(argv[a], (uint32_t)n, nthreads, &c, err, sizeof err)
                     : brw_calib_coverage_null(argv[a], n, nthreads, &c, err, sizeof err);
        if (rc) { fprintf(stderr, "coverage: %s\n", err); return 2; }
        printf("coverage %s blocks %llu rejected %llu rate %.6f r0 %.3f se %.6f band4se %.6f |r-r0| %.6f band %s\n", c.cell,
               (unsigned long long)c.n_blocks, (unsigned long long)c.rejected, c.rate, c.r0, c.se, c.band, fabs(c.rate - c.r0),
               c.band_ok ? "OK" : "OUT");
        printf("diag coverage %s worst_rate_bound %.6f (0.065 + 4 SE) rate %s\n", c.cell, c.worst_bound, c.worst_ok ? "OK" : "OUT");
        printf("coverage %s P_stop13 fresh %.6f at_r0 %.6f frozen_disclosed 0.0079\n", c.cell, c.p_stop13, c.p_stop13_r0);
        if (c.have_diag)
            for (int i = 0; i < 6; i++)
                printf("diag %s %s gap_center %.6g gap_lo %.6g gap_hi %.6g lo_in_99.9%%_order_interval %s hi_in_99.9%%_order_interval %s\n", c.cell,
                       BRW_CALIB_STAT_NAMES[i], c.gap[i][0], c.gap[i][1], c.gap[i][2], c.contained[i][0] ? "yes" : "no", c.contained[i][1] ? "yes" : "no");
        printf("coverage %s %s\n", c.cell, c.pass ? "PASS" : "FAIL (STOP: new profile version, never a table edit)");
        if (sidecar) {
            FILE *f = fopen(sidecar, "a");
            if (!f) { fprintf(stderr, "coverage: cannot open %s\n", sidecar); return 2; }
            if (ftell(f) == 0) fputs("brw.calib.cov.v1\n", f);
            brw_calib_write_cov(f, &c); fclose(f);
        }
        fprintf(stderr, "coverage %s n=%llu j=%d: %.2f s\n", c.cell, (unsigned long long)n, nthreads, now() - t0);
        return c.pass ? 0 : 4;
    }
    if (!strcmp(cmd, "assemble")) {
        int partial = 0;
        if (a < argc && !strcmp(argv[a], "--partial")) { partial = 1; a++; }
        int np = argc - a;
        if (np < 1) return usage();
        const char **parts = calloc((size_t)np, sizeof *parts);
        for (int i = 0; i < np; i++) { parts[i] = slurp(argv[a + i]); if (!parts[i]) { fprintf(stderr, "assemble: cannot read %s\n", argv[a + i]); return 2; } }
        char *text = NULL;
        int rc = brw_calib_assemble(parts, (size_t)np, partial, &text, err, sizeof err);
        if (rc == 0) rc = brw_calib_check_text(text, partial, err, sizeof err);
        if (rc) { fprintf(stderr, "assemble: %s\n", err); return 2; }
        fputs(text, stdout);
        return 0;
    }
    return usage();
}

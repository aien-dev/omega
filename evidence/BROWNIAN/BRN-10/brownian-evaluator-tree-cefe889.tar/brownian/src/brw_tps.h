/* TPS1 adapter hookup (spec Section 8, stop 27 = Section 19 row 27, R3-25/R3-28f). Reads stored PRD1 predictions and the stored
 * held-out bin indices, runs omega's brw_tps_build (hard gate + qint gate per observation, then the EXP-001 range and rANS coders)
 * and reports the coded lengths beside the ideal. Read-only: never writes a record, never changes a scored number. */
#ifndef BRW_TPS_H
#define BRW_TPS_H
#include <stddef.h>
#include <stdint.h>
#include "turing/ty_qcont.h"
#include "brownian/brw_tps_adapter.h"
#include "brw_protocol.h"

enum { BRW_TPS_NOT_EVALUATED = 0, BRW_TPS_PASS = 1, BRW_TPS_GATE_FAIL = 2, BRW_TPS_OUT_OF_RANGE = 3 };
/* TPS1 verified range (spec v1.3 A3.6, R3-48): the double-precision qint reference (ty_qcont_bits) cannot meet the 1e-9 bit gate above about
 * 3e6 bits per observation (measured on synthetic streams), so an observation costing more than 2^20 bits is outside the verified range. */
#define BRW_TPS_RANGE_BITS 1048576.0

typedef struct {
    uint64_t n_obs, n_steps;          /* held-out observations, binary steps handed to the coders */
    int64_t ideal_ub;                 /* tc_ideal_ub of the TPS1 streams, micro-bits (sum over worlds) */
    uint64_t range_bytes, rans_bytes; /* coder payload bytes (56-byte coded header excluded), summed over one stream per world */
    double max_dev_exact;             /* worst |sum of step bits - exact Normal bin bits| */
    int state;                        /* BRW_TPS_* */
    int code;                         /* adapter/coder code when not PASS (BRW_TPS_E_PROOF for a gate failure) */
    size_t bad_world, bad_index;      /* first failing world and observation (gate failure) */
} brw_tps_arm;

typedef struct {
    int state;                        /* BRW_TPS_NOT_EVALUATED (records missing or adapter refusal), PASS, GATE_FAIL (either arm), OUT_OF_RANGE (an arm skipped a world, no gate failure) */
    brw_tps_arm arm[2];               /* 0 = baseline B, 1 = model M */
    char why[160];                    /* when NOT_EVALUATED */
} brw_tps_gain_res;

/* One stream (one world): n observations. Accumulates into *a (a->state is set to GATE_FAIL on E_PROOF). Returns the adapter code. */
int brw_tps_stream(const tyq_pred *rec, const int64_t *k, size_t n, size_t world, brw_tps_hook hook, void *hctx, brw_tps_arm *a);
/* All worlds of a stored qgain (verify_chain, so every stored file is digest-checked first). hook may be NULL (production). */
/* Folds one world's result into a running arm total (world order gives a deterministic first failure). */
void brw_tps_fold(brw_tps_arm *a, const brw_tps_arm *w, size_t world);
int brw_tps_of_gain(const char *gain_path, brw_tps_hook hook, void *hctx, brw_tps_gain_res *r);
/* sidecar tps.<qgain digest>.txt beside the qgain: written by `tps --write`, read by verdict and results. Never part of a record. */
int brw_tps_render(const tyqr_gain *g, const ty_digest *gd, const brw_tps_gain_res *r, char *out, size_t cap);
int brw_tps_sidecar_write(const char *gain_path, const tyqr_gain *g, const ty_digest *gd, const brw_tps_gain_res *r, char *path, size_t pcap);
void brw_tps_sidecar_read(const char *gain_path, const tyqr_gain *g, const ty_digest *gd, brw_tps_gain_res *r);
#endif

/* brw_cells.h: every numeric constant of the compiled cell table (plan §12-§14, §18).
 * Values frozen from DESIGN_CHECK_R2 1fd3189 (R3-19; design/cell_sizes.txt).
 * No semantics live here, only numbers. */
#ifndef BRW_CELLS_H
#define BRW_CELLS_H

#define BRW_DELTA_EXP        20          /* qint.v1: delta = 2^-20 (plan §8) */
#define BRW_RANGE_LIMIT      2147483648.0 /* 2^31: |x| >= this is refused */

/* Diffusion prior: D = exp(U), U uniform on [ln D_MIN, ln D_MAX] (plan §12) */
#define BRW_D_MIN            0.05
#define BRW_D_MAX            20.0
/* Irregular grid: h = exp(V), V uniform on [ln H_MIN, ln H_MAX] (plan §12) */
#define BRW_H_MIN            0.25
#define BRW_H_MAX            4.0

/* Cell sizes (DESIGN_CHECK_R2 1fd3189, cell_sizes.txt). W = worlds per block,
 * H = held-out points per world, N_POINTS = SPLIT + H. */
#define BRW_N_POINTS_PRIMARY 256u        /* SPLIT 128 + H 128 */
#define BRW_SPLIT_PRIMARY    128u
#define BRW_N_POINTS_SHORT   8u
#define BRW_SPLIT_SHORT      4u
#define BRW_N_POINTS_H256    384u        /* SPLIT 128 + H 256: B1-3, B1-4n, B2-fast */
#define BRW_N_POINTS_H512    640u        /* SPLIT 128 + H 512: B2-noise, B2-emerging */
#define BRW_W_B0_B1_NOISE    400u        /* B0-*, B1-*, B2-noise */
#define BRW_W_B2             200u        /* B2-weak, B2-clear, B2-fast */
#define BRW_W_B2_EMERGING    1600u
#define BRW_DEV_BLOCKS       20u         /* stop #13 = ">= 5 of 20" (R3-3, R3-19b) */

/* B1 signal-to-noise: mu = s * sqrt(2 D / T_FULL), T_FULL = T_ref = 255 (plan §13) */
#define BRW_B1_TFULL         255.0
#define BRW_S_B1_0           0.0
#define BRW_S_B1_1           1.0
#define BRW_S_B1_3           4.5         /* R3-2 */
#define BRW_S_B1_4N          (-5.0)      /* R3-2 */

/* EXP-002B Occam sweep (spec 14 "Occam curve deliverable", spec 22 U10, R3-26 G11, R3-41): OCC-s<+x.xx>-H<h>, D1 world family,
 * mu = s * sqrt(2D/255) (same T_ref = 255 as B1, BRW_B1_TFULL), s x H = 31 x 4 = 124 cells, W = 400, SPLIT 128, N_POINTS = 128 + H.
 * BRW_OCC_LIST(X): X(name, s, H). Order: H ascending within each s. */
#define BRW_OCC_W            400u
#define BRW_OCC_EXP          "EXP-002B-OCC"
#define BRW_OCC_COUNT        124u
#define BRW_OCC_LIST(X) \
    X("OCC-s+0.00-H128", 0.0, 128) \
    X("OCC-s+0.00-H256", 0.0, 256) \
    X("OCC-s+0.00-H512", 0.0, 512) \
    X("OCC-s+0.00-H1024", 0.0, 1024) \
    X("OCC-s+0.50-H128", 0.50, 128) \
    X("OCC-s+0.50-H256", 0.50, 256) \
    X("OCC-s+0.50-H512", 0.50, 512) \
    X("OCC-s+0.50-H1024", 0.50, 1024) \
    X("OCC-s-0.50-H128", -0.50, 128) \
    X("OCC-s-0.50-H256", -0.50, 256) \
    X("OCC-s-0.50-H512", -0.50, 512) \
    X("OCC-s-0.50-H1024", -0.50, 1024) \
    X("OCC-s+1.00-H128", 1.00, 128) \
    X("OCC-s+1.00-H256", 1.00, 256) \
    X("OCC-s+1.00-H512", 1.00, 512) \
    X("OCC-s+1.00-H1024", 1.00, 1024) \
    X("OCC-s-1.00-H128", -1.00, 128) \
    X("OCC-s-1.00-H256", -1.00, 256) \
    X("OCC-s-1.00-H512", -1.00, 512) \
    X("OCC-s-1.00-H1024", -1.00, 1024) \
    X("OCC-s+1.50-H128", 1.50, 128) \
    X("OCC-s+1.50-H256", 1.50, 256) \
    X("OCC-s+1.50-H512", 1.50, 512) \
    X("OCC-s+1.50-H1024", 1.50, 1024) \
    X("OCC-s-1.50-H128", -1.50, 128) \
    X("OCC-s-1.50-H256", -1.50, 256) \
    X("OCC-s-1.50-H512", -1.50, 512) \
    X("OCC-s-1.50-H1024", -1.50, 1024) \
    X("OCC-s+2.00-H128", 2.00, 128) \
    X("OCC-s+2.00-H256", 2.00, 256) \
    X("OCC-s+2.00-H512", 2.00, 512) \
    X("OCC-s+2.00-H1024", 2.00, 1024) \
    X("OCC-s-2.00-H128", -2.00, 128) \
    X("OCC-s-2.00-H256", -2.00, 256) \
    X("OCC-s-2.00-H512", -2.00, 512) \
    X("OCC-s-2.00-H1024", -2.00, 1024) \
    X("OCC-s+2.50-H128", 2.50, 128) \
    X("OCC-s+2.50-H256", 2.50, 256) \
    X("OCC-s+2.50-H512", 2.50, 512) \
    X("OCC-s+2.50-H1024", 2.50, 1024) \
    X("OCC-s-2.50-H128", -2.50, 128) \
    X("OCC-s-2.50-H256", -2.50, 256) \
    X("OCC-s-2.50-H512", -2.50, 512) \
    X("OCC-s-2.50-H1024", -2.50, 1024) \
    X("OCC-s+3.00-H128", 3.00, 128) \
    X("OCC-s+3.00-H256", 3.00, 256) \
    X("OCC-s+3.00-H512", 3.00, 512) \
    X("OCC-s+3.00-H1024", 3.00, 1024) \
    X("OCC-s-3.00-H128", -3.00, 128) \
    X("OCC-s-3.00-H256", -3.00, 256) \
    X("OCC-s-3.00-H512", -3.00, 512) \
    X("OCC-s-3.00-H1024", -3.00, 1024) \
    X("OCC-s+3.25-H128", 3.25, 128) \
    X("OCC-s+3.25-H256", 3.25, 256) \
    X("OCC-s+3.25-H512", 3.25, 512) \
    X("OCC-s+3.25-H1024", 3.25, 1024) \
    X("OCC-s-3.25-H128", -3.25, 128) \
    X("OCC-s-3.25-H256", -3.25, 256) \
    X("OCC-s-3.25-H512", -3.25, 512) \
    X("OCC-s-3.25-H1024", -3.25, 1024) \
    X("OCC-s+3.50-H128", 3.50, 128) \
    X("OCC-s+3.50-H256", 3.50, 256) \
    X("OCC-s+3.50-H512", 3.50, 512) \
    X("OCC-s+3.50-H1024", 3.50, 1024) \
    X("OCC-s-3.50-H128", -3.50, 128) \
    X("OCC-s-3.50-H256", -3.50, 256) \
    X("OCC-s-3.50-H512", -3.50, 512) \
    X("OCC-s-3.50-H1024", -3.50, 1024) \
    X("OCC-s+3.75-H128", 3.75, 128) \
    X("OCC-s+3.75-H256", 3.75, 256) \
    X("OCC-s+3.75-H512", 3.75, 512) \
    X("OCC-s+3.75-H1024", 3.75, 1024) \
    X("OCC-s-3.75-H128", -3.75, 128) \
    X("OCC-s-3.75-H256", -3.75, 256) \
    X("OCC-s-3.75-H512", -3.75, 512) \
    X("OCC-s-3.75-H1024", -3.75, 1024) \
    X("OCC-s+4.00-H128", 4.00, 128) \
    X("OCC-s+4.00-H256", 4.00, 256) \
    X("OCC-s+4.00-H512", 4.00, 512) \
    X("OCC-s+4.00-H1024", 4.00, 1024) \
    X("OCC-s-4.00-H128", -4.00, 128) \
    X("OCC-s-4.00-H256", -4.00, 256) \
    X("OCC-s-4.00-H512", -4.00, 512) \
    X("OCC-s-4.00-H1024", -4.00, 1024) \
    X("OCC-s+4.25-H128", 4.25, 128) \
    X("OCC-s+4.25-H256", 4.25, 256) \
    X("OCC-s+4.25-H512", 4.25, 512) \
    X("OCC-s+4.25-H1024", 4.25, 1024) \
    X("OCC-s-4.25-H128", -4.25, 128) \
    X("OCC-s-4.25-H256", -4.25, 256) \
    X("OCC-s-4.25-H512", -4.25, 512) \
    X("OCC-s-4.25-H1024", -4.25, 1024) \
    X("OCC-s+4.50-H128", 4.50, 128) \
    X("OCC-s+4.50-H256", 4.50, 256) \
    X("OCC-s+4.50-H512", 4.50, 512) \
    X("OCC-s+4.50-H1024", 4.50, 1024) \
    X("OCC-s-4.50-H128", -4.50, 128) \
    X("OCC-s-4.50-H256", -4.50, 256) \
    X("OCC-s-4.50-H512", -4.50, 512) \
    X("OCC-s-4.50-H1024", -4.50, 1024) \
    X("OCC-s+5.00-H128", 5.00, 128) \
    X("OCC-s+5.00-H256", 5.00, 256) \
    X("OCC-s+5.00-H512", 5.00, 512) \
    X("OCC-s+5.00-H1024", 5.00, 1024) \
    X("OCC-s-5.00-H128", -5.00, 128) \
    X("OCC-s-5.00-H256", -5.00, 256) \
    X("OCC-s-5.00-H512", -5.00, 512) \
    X("OCC-s-5.00-H1024", -5.00, 1024) \
    X("OCC-s+5.50-H128", 5.50, 128) \
    X("OCC-s+5.50-H256", 5.50, 256) \
    X("OCC-s+5.50-H512", 5.50, 512) \
    X("OCC-s+5.50-H1024", 5.50, 1024) \
    X("OCC-s-5.50-H128", -5.50, 128) \
    X("OCC-s-5.50-H256", -5.50, 256) \
    X("OCC-s-5.50-H512", -5.50, 512) \
    X("OCC-s-5.50-H1024", -5.50, 1024) \
    X("OCC-s+6.00-H128", 6.00, 128) \
    X("OCC-s+6.00-H256", 6.00, 256) \
    X("OCC-s+6.00-H512", 6.00, 512) \
    X("OCC-s+6.00-H1024", 6.00, 1024) \
    X("OCC-s-6.00-H128", -6.00, 128) \
    X("OCC-s-6.00-H256", -6.00, 256) \
    X("OCC-s-6.00-H512", -6.00, 512) \
    X("OCC-s-6.00-H1024", -6.00, 1024)

/* B2 (D2, m = 0, sigma = 1) (plan §14) */
#define BRW_B2_SIGMA         1.0
#define BRW_THETA_WEAK       0.01
#define BRW_THETA_CLEAR      0.5
#define BRW_THETA_FAST       2.0
#define BRW_THETA_EMERGING   0.05

/* EXP-002C-INT (R3-19c): theta = 0.05 only, W = 1600, H = 512, sigma = 1,
 * set-state x = d * sd_stat. near d=2 (gating), moderate d=5 (descriptive),
 * far d=8 (gating); d=0 and d=1 are descriptive near classes. Not used by Lane A generation. */
#define BRW_INT_DISP_NEAR     2.0
#define BRW_INT_DISP_MODERATE 5.0
#define BRW_INT_DISP_FAR      8.0
/* EXP-002C-INT construction (R3-36 (i)-(iii), DESIGN_CHECK_R2 "EXP-002C intervention (task 5)"): a 128-point observational prefix
 * (indices 0..127) whose x_0 is drawn from the cell's own stationary law, then at index S = 128 the state is SET to x = d * sd_stat and the
 * law continues for H held-out points (indices 129..128+H). N_POINTS = 128 + 1 + H; the cell table split is 129, the first SCORED index;
 * the fit prefix is split - 1 = 128 points; the set-state point (index 128) and the score of index 128 are not counted.
 * sd_stat of theta = 0.05, sigma = 1 is sqrt(10) = 0x1.94c583ada5b53p+1 (correctly rounded; a test compares it with sqrt(sigma^2 / (2 theta))).
 * The controls CTL-d* use the same ABSOLUTE displacement d * sqrt(10) (R3-36 (ii)). */
#define BRW_INT_SD_STAT       0x1.94c583ada5b53p+1
#define BRW_INT_W             1600u      /* R3-19c: W = 1600 (same as B2-emerging), H = 512 */
#define BRW_INT_N_POINTS      641u       /* 128 prefix + 1 set-state point + 512 held-out */
#define BRW_INT_SPLIT         129u       /* first scored index; fit prefix = 128 points */
#define BRW_CTL_D             0.5        /* pure diffusion, 2D = sigma^2 = 1 (R3-36 (ii)) */
/* theta = 0.5 descriptive row (R3-36 (iii)): sd_stat = sigma / sqrt(2 theta) = 1, W = 200, H = 128 (the B2-clear size) */
#define BRW_INT05_THETA       0.5
#define BRW_INT05_SD_STAT     1.0
#define BRW_INT05_W           200u
#define BRW_INT05_N_POINTS    257u       /* 128 prefix + 1 set-state point + 128 held-out */

/* Null-calibration block (R3-3): one dedicated block of 1000000 worlds per cell
 * (DESIGN_CHECK_R2 1fd3189 "Nullcal block: 1000000 worlds per cell") */
#define BRW_NULLCAL_LABEL    "brownian.nullcal.v1"
#define BRW_NULLCAL_BLOCKS   1u
#define BRW_NULLCAL_WORLDS   1000000u

/* Hostile cells (plan §18 hostile cell table, OI-9) */
#define BRW_H_OUTLIER_P      0.01
#define BRW_H_OUTLIER_MULT   10.0
#define BRW_H_MISSING_P      0.1
#define BRW_H_BOUNDARY_D     0.05
#define BRW_H_BOUNDARY_THETA 0.01
#define BRW_H_AFFINE_C_MIN   0.1
#define BRW_H_AFFINE_C_MAX   10.0
#define BRW_H_AFFINE_B_MULT  10.0

#endif

/* brw_results.c: `brownian_bench results` (plan §26, B17). Read-only over the q-records; see brw_results.h.
 *
 * Manifest (tab-separated text; '#' lines and empty lines skipped; every other line must be one of these, else refused):
 *   rung <TAB> name <TAB> verdict <TAB> evidence <TAB> rule
 *   failed_run <TAB> gate <TAB> profile <TAB> qfreeze <TAB> reason <TAB> verdict
 *   negative_test <TAB> row <TAB> name <TAB> expected <TAB> verdict
 *   limitation <TAB> text          replay <TAB> command
 *   commit <TAB> name <TAB> 40hex  omega <TAB> 40hex   dirty <TAB> 0|1   kat <TAB> kat1|kat2 <TAB> PASS|FAIL
 * verdict is one of PASS FAIL BLOCKED INCOMPLETE. */
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "brw_occam.h"
#include "brw_predict.h"
#include "brw_tps.h"
#include "brw_results.h"

#define WHYF(...) snprintf(why, cap, __VA_ARGS__)

/* ------------------------------------------------------------------ canonical JSON emitter */
typedef struct { char *s; size_t n, cap; int oom; } sb;
static void sb_raw(sb *b, const char *s, size_t n) {
    if (b->oom) return;
    if (b->n + n + 1 > b->cap) {
        size_t c = b->cap ? b->cap : 256;
        while (c < b->n + n + 1) c *= 2;
        char *p = realloc(b->s, c);
        if (!p) { b->oom = 1; return; }
        b->s = p; b->cap = c;
    }
    memcpy(b->s + b->n, s, n); b->n += n; b->s[b->n] = 0;
}
static void sb_lit(sb *b, const char *s) { sb_raw(b, s, strlen(s)); }
static void sb_qs(sb *b, const char *s) {
    static const char hx[] = "0123456789abcdef";
    sb_raw(b, "\"", 1);
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (*p == '"' || *p == '\\') { char e[2] = { '\\', (char)*p }; sb_raw(b, e, 2); }
        else if (*p < 0x20) { char e[6] = { '\\', 'u', '0', '0', hx[*p >> 4], hx[*p & 15] }; sb_raw(b, e, 6); }
        else sb_raw(b, (const char *)p, 1);
    }
    sb_raw(b, "\"", 1);
}
static void sb_i64(sb *b, int64_t v) { char t[32]; snprintf(t, sizeof t, "%lld", (long long)v); sb_lit(b, t); }
static void sb_u64(sb *b, uint64_t v) { char t[32]; snprintf(t, sizeof t, "%llu", (unsigned long long)v); sb_lit(b, t); }
static void sb_hex(sb *b, const ty_digest *d) { char h[65]; ty_hex(d, h); sb_qs(b, h); }
static void sb_sep(sb *b, size_t *cnt) { if ((*cnt)++) sb_raw(b, ",", 1); }

typedef struct { char *k; sb v; } kv;
typedef struct { kv *a; size_t n, cap; int oom; } obj;
static void o_put(obj *o, const char *k, sb *v) {   /* takes the buffer of v */
    if (o->n == o->cap) {
        size_t c = o->cap ? o->cap * 2 : 16;
        kv *p = realloc(o->a, c * sizeof *p);
        if (!p) { o->oom = 1; free(v->s); return; }
        o->a = p; o->cap = c;
    }
    o->a[o->n].k = strdup(k);
    if (!o->a[o->n].k) o->oom = 1;
    o->a[o->n].v = *v; o->n++;
    memset(v, 0, sizeof *v);
}
static void o_null(obj *o, const char *k) { sb v = { 0 }; sb_lit(&v, "null"); o_put(o, k, &v); }
static void o_str(obj *o, const char *k, const char *s) { if (!s) { o_null(o, k); return; } sb v = { 0 }; sb_qs(&v, s); o_put(o, k, &v); }
static void o_i(obj *o, const char *k, int64_t x) { sb v = { 0 }; sb_i64(&v, x); o_put(o, k, &v); }
static void o_u(obj *o, const char *k, uint64_t x) { sb v = { 0 }; sb_u64(&v, x); o_put(o, k, &v); }
static void o_hex(obj *o, const char *k, const ty_digest *d) { sb v = { 0 }; sb_hex(&v, d); o_put(o, k, &v); }
static void o_bool(obj *o, const char *k, int x) { sb v = { 0 }; sb_lit(&v, x ? "true" : "false"); o_put(o, k, &v); }
static int kv_cmp(const void *a, const void *b) { return strcmp(((const kv *)a)->k, ((const kv *)b)->k); }
static void o_render(obj *o, sb *out) {   /* keys in byte order; frees the object */
    if (o->n > 1) qsort(o->a, o->n, sizeof *o->a, kv_cmp);
    sb_raw(out, "{", 1);
    for (size_t i = 0; i < o->n; i++) {
        if (i) sb_raw(out, ",", 1);
        sb_qs(out, o->a[i].k); sb_raw(out, ":", 1);
        sb_raw(out, o->a[i].v.s ? o->a[i].v.s : "null", o->a[i].v.s ? o->a[i].v.n : 4);
        free(o->a[i].k); free(o->a[i].v.s);
    }
    sb_raw(out, "}", 1);
    if (o->oom) out->oom = 1;
    free(o->a); memset(o, 0, sizeof *o);
}
static void o_obj(obj *o, const char *k, obj *child) { sb v = { 0 }; o_render(child, &v); o_put(o, k, &v); }
static void o_arr(obj *o, const char *k, sb *items, int have) {   /* items = comma-joined elements; have=0: null */
    sb v = { 0 };
    if (!have) sb_lit(&v, "null"); else { sb_raw(&v, "[", 1); if (items->s) sb_raw(&v, items->s, items->n); sb_raw(&v, "]", 1); }
    free(items->s); memset(items, 0, sizeof *items);
    o_put(o, k, &v);
}

/* ------------------------------------------------------------------ manifest */
typedef struct {
    sb ceiling, failed, neg, lim, replay, repos; size_t nc, nf, nn, nl, nr, np;
    char omega[41]; int have_omega, dirty; char kat[2][5];
} manifest;

static int is_verdict(const char *s) { return !strcmp(s, "PASS") || !strcmp(s, "FAIL") || !strcmp(s, "BLOCKED") || !strcmp(s, "INCOMPLETE"); }
static int is_hex40(const char *s) { if (strlen(s) != 40) return 0; for (; *s; s++) if (!((*s >= '0' && *s <= '9') || (*s >= 'a' && *s <= 'f'))) return 0; return 1; }

static int manifest_parse(const char *path, manifest *m, char *why, size_t cap) {
    brw_bytes b; memset(m, 0, sizeof *m); m->dirty = -1;
    if (brw_slurp(path, &b) != 0) { WHYF("cannot read the manifest %s", path); return TYQ_E_IO; }
    char *buf = malloc(b.n + 1);
    if (!buf) { brw_bytes_free(&b); WHYF("out of memory"); return TYQ_E_IO; }
    memcpy(buf, b.b, b.n); buf[b.n] = 0; brw_bytes_free(&b);
    int rc = 0; size_t lineno = 0;
    for (char *line = buf; *line && rc == 0;) {
        char *nl = strchr(line, '\n'); if (nl) *nl = 0;
        char *next = nl ? nl + 1 : line + strlen(line);
        size_t ll = strlen(line); if (ll && line[ll - 1] == '\r') line[ll - 1] = 0;
        lineno++;
        if (line[0] && line[0] != '#') {
            char *f[8] = { 0 }; size_t nf = 0; char *p = line;
            for (;;) {
                if (nf == 8) { WHYF("manifest line %zu: too many fields", lineno); rc = TYQ_E_ARG; break; }
                f[nf++] = p;
                char *t = strchr(p, '\t');
                if (!t) break;
                *t = 0; p = t + 1;
            }
            if (rc) break;
            const char *tag = f[0];
            obj o; memset(&o, 0, sizeof o);
            #define NEED(k) do { if (nf != (k)) { WHYF("manifest line %zu: '%s' needs %d fields", lineno, tag, (k)); rc = TYQ_E_ARG; } } while (0)
            #define VERD(s) do { if (!is_verdict(s)) { WHYF("manifest line %zu: verdict word '%s' is not PASS, FAIL, BLOCKED or INCOMPLETE", lineno, s); rc = TYQ_E_ARG; } } while (0)
            if (!strcmp(tag, "rung")) {
                NEED(5); if (!rc) VERD(f[2]);
                if (!rc) { o_str(&o, "rung", f[1]); o_str(&o, "verdict", f[2]); o_str(&o, "evidence", f[3]); o_str(&o, "rule", f[4]); sb_sep(&m->ceiling, &m->nc); o_render(&o, &m->ceiling); }
            } else if (!strcmp(tag, "failed_run")) {
                NEED(6); if (!rc) VERD(f[5]);
                if (!rc) { o_str(&o, "gate", f[1]); o_str(&o, "profile", f[2]); o_str(&o, "qfreeze", f[3]); o_str(&o, "reason", f[4]); o_str(&o, "verdict", f[5]); sb_sep(&m->failed, &m->nf); o_render(&o, &m->failed); }
            } else if (!strcmp(tag, "negative_test")) {
                NEED(5); if (!rc) VERD(f[4]);
                if (!rc) { o_str(&o, "row", f[1]); o_str(&o, "name", f[2]); o_str(&o, "expected", f[3]); o_str(&o, "verdict", f[4]); sb_sep(&m->neg, &m->nn); o_render(&o, &m->neg); }
            } else if (!strcmp(tag, "limitation")) {
                NEED(2); if (!rc) { sb_sep(&m->lim, &m->nl); sb_qs(&m->lim, f[1]); }
            } else if (!strcmp(tag, "replay")) {
                NEED(2); if (!rc) { sb_sep(&m->replay, &m->nr); sb_qs(&m->replay, f[1]); }
            } else if (!strcmp(tag, "commit")) {
                NEED(3); if (!rc && !is_hex40(f[2])) { WHYF("manifest line %zu: commit sha must be 40 lowercase hex", lineno); rc = TYQ_E_ARG; }
                if (!rc) { o_str(&o, "name", f[1]); o_str(&o, "sha", f[2]); sb_sep(&m->repos, &m->np); o_render(&o, &m->repos); }
            } else if (!strcmp(tag, "omega")) {
                NEED(2); if (!rc && (m->have_omega || !is_hex40(f[1]))) { WHYF("manifest line %zu: omega must be given once, 40 lowercase hex", lineno); rc = TYQ_E_ARG; }
                if (!rc) { memcpy(m->omega, f[1], 41); m->have_omega = 1; }
            } else if (!strcmp(tag, "dirty")) {
                NEED(2); if (!rc && (m->dirty != -1 || (strcmp(f[1], "0") && strcmp(f[1], "1")))) { WHYF("manifest line %zu: dirty must be given once, 0 or 1", lineno); rc = TYQ_E_ARG; }
                if (!rc) m->dirty = f[1][0] - '0';
            } else if (!strcmp(tag, "kat")) {
                NEED(3); int which = nf > 1 ? (!strcmp(f[1], "kat1") ? 0 : !strcmp(f[1], "kat2") ? 1 : -1) : -1;
                if (!rc && (which < 0 || m->kat[which][0] || (strcmp(f[2], "PASS") && strcmp(f[2], "FAIL")))) { WHYF("manifest line %zu: kat needs kat1|kat2 once and PASS|FAIL", lineno); rc = TYQ_E_ARG; }
                if (!rc) snprintf(m->kat[which], sizeof m->kat[which], "%s", f[2]);
            } else { WHYF("manifest line %zu: unknown line type '%s'", lineno, tag); rc = TYQ_E_ARG; }
            #undef NEED
            #undef VERD
            for (size_t i = 0; i < o.n; i++) { free(o.a[i].k); free(o.a[i].v.s); }
            free(o.a);
        }
        line = next;
    }
    free(buf);
    return rc;
}
static void manifest_free(manifest *m) { free(m->ceiling.s); free(m->failed.s); free(m->neg.s); free(m->lim.s); free(m->replay.s); free(m->repos.s); }

/* ------------------------------------------------------------------ directory scans (sorted: readdir order is not stable) */
typedef struct { char (*n)[BRW_PATH]; size_t cnt, cap; } names_t;
static int cmp_names(const void *a, const void *b) { return strcmp((const char *)a, (const char *)b); }
static int list_prefix(const char *dir, const char *prefix, names_t *out) {
    DIR *d = opendir(dir);
    if (!d) return -1;
    struct dirent *e; size_t pl = strlen(prefix);
    out->cnt = 0;
    while ((e = readdir(d)) != NULL) {
        if (strncmp(e->d_name, prefix, pl) != 0) continue;
        if (out->cnt == out->cap) {
            size_t c = out->cap ? out->cap * 2 : 256;
            void *p = realloc(out->n, c * BRW_PATH);
            if (!p) { closedir(d); return -1; }
            out->n = p; out->cap = c;
        }
        brw_join(out->n[out->cnt++], BRW_PATH, dir, "%s", e->d_name);
    }
    closedir(d);
    if (out->cnt > 1) qsort(out->n, out->cnt, BRW_PATH, cmp_names);
    return 0;
}

typedef struct { tyqr_gain g; ty_digest d; char path[BRW_PATH]; } gain_t;
typedef struct { tyqr_world w; ty_digest d; const char *dir; } world_t;
typedef struct { char hex[65]; size_t idx; } gsort_t;
static int gsort_cmp(const void *a, const void *b) { return strcmp(((const gsort_t *)a)->hex, ((const gsort_t *)b)->hex); }
static int strp_cmp(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }

/* the sentence of plan §26 for a scored gain; NULL when the rule table does not decide (never guessed) */
static const char *outcome_of(const tyqr_gain *g) {
    if (!strcmp(g->status, "STOPPED") || !strcmp(g->classification, "STOPPED")) return "STOPPED";
    if (strstr(g->status, "PROTOCOL")) return "protocol failure";
    if (strstr(g->status, "LEAK") || !strcmp(g->leak_flag, "1")) return "leakage";
    if (strstr(g->status, "FLOOR")) return "floor exploitation";
    if (strcmp(g->status, "PASS") != 0) return NULL;
    if (g->t_lo_ub > 0) return "found structure";
    if (g->t_hi_ub < 0) return "no additional structure";
    return g->t_ub > 0 ? "weak evidence" : "uncertain";
}

static void coded_json(obj *o, const char *path, const tyqr_gain *g, const ty_digest *gd) {   /* coded_lengths from the TPS1 sidecar; null without one */
    brw_tps_gain_res tr; brw_tps_sidecar_read(path, g, gd, &tr);
    if (tr.state == BRW_TPS_GATE_FAIL) {   /* stop 27: no lengths, only where it failed */
        obj f; memset(&f, 0, sizeof f); o_str(&f, "gate", "FAIL");
        const brw_tps_arm *a = tr.arm[0].state == BRW_TPS_GATE_FAIL ? &tr.arm[0] : &tr.arm[1];
        o_str(&f, "arm", tr.arm[0].state == BRW_TPS_GATE_FAIL ? "B" : "M"); o_u(&f, "bad_world", a->bad_world); o_u(&f, "bad_index", a->bad_index);
        o_obj(o, "coded_lengths", &f); return;
    }
    if (tr.state != BRW_TPS_PASS) { o_null(o, "coded_lengths"); return; }
    obj c; memset(&c, 0, sizeof c);
    static const char *const nm[2] = { "B", "M" };
    for (int m = 0; m < 2; m++) {
        const brw_tps_arm *a = &tr.arm[m]; obj e; memset(&e, 0, sizeof e);
        o_i(&e, "ideal_ub", a->ideal_ub); o_u(&e, "n_obs", a->n_obs); o_u(&e, "n_steps", a->n_steps); o_u(&e, "range_bytes", a->range_bytes); o_u(&e, "rans_bytes", a->rans_bytes);
        o_obj(&c, nm[m], &e);
    }
    o_str(&c, "gate", "PASS");
    o_obj(o, "coded_lengths", &c);
}
static void gain_json(obj *o, const tyqr_gain *g, const ty_digest *gd, const brw_cellinfo *ci, int lm_ok, const char *path) {
    const brw_ref *rb = brw_ref_get((int)g->baseline_opcode), *rm = brw_ref_get((int)g->candidate_opcode);
    o_hex(o, "digest", gd);
    o_str(o, "mode", g->mode);
    if (!strcmp(g->mode, "certification") && rm) o_str(o, "candidate", rm->name); else { char h[65]; ty_hex(&g->candidate, h); o_str(o, "candidate", h); }
    o_u(o, "candidate_opcode", g->candidate_opcode);
    o_str(o, "baseline", rb ? rb->name : NULL);
    o_u(o, "official", g->official);
    o_str(o, "ladder_item", g->ladder_item);
    { sb a = { 0 }; size_t c = 0; for (int i = 0; i < 6; i++) { sb_sep(&a, &c); sb_i64(&a, g->lengths[i]); } o_arr(o, "lengths", &a, 1); }
    { obj r; memset(&r, 0, sizeof r);
      if (lm_ok && rb) o_u(&r, "k_b", (uint64_t)rb->k); else o_null(&r, "k_b");
      if (lm_ok && rm) o_u(&r, "k_m", (uint64_t)rm->k); else o_null(&r, "k_m");
      /* n: the prefix increments the rider is charged on: (fit split) - 1, the fit split being split, or split - 1 on the set-state cells */
      if (lm_ok && ci && ci->s.split >= 2u + (ci->s.set_state ? 1u : 0u)) o_u(&r, "n", ci->s.split - (ci->s.set_state ? 1u : 0u) - 1u); else o_null(&r, "n");
      o_obj(o, "rider", &r); }
    { sb a = { 0 }; size_t c = 0; for (int i = 0; i < 4; i++) { sb_sep(&a, &c); sb_u64(&a, g->counts[i]); } o_arr(o, "counts", &a, 1); }
    o_i(o, "t_ub", g->t_ub); o_i(o, "t_lo_ub", g->t_lo_ub); o_i(o, "t_hi_ub", g->t_hi_ub);
    o_str(o, "leak_flag", g->leak_flag);
    o_i(o, "mc_err_ub", g->mc_err_ub); o_i(o, "numeric_bound_ub", g->numeric_bound_ub);
    o_u(o, "floor_hits", g->floor_hits);
    o_str(o, "classification", g->classification); o_str(o, "status", g->status);
    o_str(o, "outcome", outcome_of(g));
    coded_json(o, path, g, gd);
}

/* the Occam curve (spec v1.3 A3.4) as the object of results.json: null when no OCC DIFFUSION_DRIFT-against-DIFFUSION qgain exists */
static void o_f(obj *o, const char *k, double x) { char t[40]; snprintf(t, sizeof t, "%.17g", x); sb v = { 0 }; sb_lit(&v, t); o_put(o, k, &v); }
static void occam_json(obj *top, const gain_t *gains, size_t ng, const brw_occ_curve *cv, int used) {
    (void)gains; (void)ng;
    if (used <= 0) { o_null(top, "occam_curve"); return; }
    sb arr = { 0 }; size_t nc = 0;
    for (int i = 0; i < 2 * BRW_OCC_NHS; i++) {
        const brw_occ_curve *c = &cv[i]; obj o; memset(&o, 0, sizeof o);
        o_u(&o, "h", c->H); o_str(&o, "sign", c->sign > 0 ? "+" : "-");
        { sb pa = { 0 }; size_t pn = 0;
          for (size_t k = 0; k < c->n; k++) {
              obj p; memset(&p, 0, sizeof p);
              o_f(&p, "s", c->pt[k].s); o_f(&p, "ratio", c->pt[k].ratio); o_f(&p, "dt", brw_occ_bits(c->pt[k].t)); o_f(&p, "lo", brw_occ_bits(c->pt[k].lo)); o_f(&p, "hi", brw_occ_bits(c->pt[k].hi));
              sb_sep(&pa, &pn); o_render(&p, &pa);
          }
          o_arr(&o, "points", &pa, 1); }
        if (c->has_cross) o_f(&o, "crossing_point", c->cross_s); else o_str(&o, "crossing_point", "no crossing in grid");
        o_bool(&o, "non_monotone", c->nonmono);
        if (c->has_lo_end) o_f(&o, "interval_from", c->lo_end); else o_str(&o, "interval_from", "beyond grid");
        if (c->has_hi_end) o_f(&o, "interval_to", c->hi_end); else o_str(&o, "interval_to", "beyond grid");
        if (c->have_cross_ref) { o_f(&o, "occ_cross", c->cross_ref); o_str(&o, "occ_position", c->inside ? "inside" : "outside"); }
        else { o_null(&o, "occ_cross"); o_null(&o, "occ_position"); }
        sb_sep(&arr, &nc); o_render(&o, &arr);
    }
    obj oc; memset(&oc, 0, sizeof oc);
    o_arr(&oc, "curves", &arr, 1);
    o_str(&oc, "note", "descriptive; dt = certification T of DIFFUSION_DRIFT against DIFFUSION in bits with its world-bootstrap interval; ratio = |mu|/sqrt(2D) = |s|/sqrt(255); never a verdict item, never a threshold of the world");
    o_obj(top, "occam_curve", &oc);
}

int brw_results_run(const brw_res_args *a, char hex_out[65], char *why, size_t cap) {
    int rc = 0;
    manifest m; memset(&m, 0, sizeof m);
    tyqr_profile pr; ty_digest pd, fd; tyqr_freeze fr;
    gain_t *gains = NULL; size_t ng = 0, gcap = 0;
    world_t *ws = NULL; size_t nw = 0, wcap = 0;
    names_t nm; memset(&nm, 0, sizeof nm);
    char **cells = NULL; size_t ncell = 0;
    sb out; memset(&out, 0, sizeof out);
    char w2[BRW_WHY];
    if (!a->qprofile || !a->manifest || !a->out || !a->ndirs) { WHYF("results needs --qprofile --manifest --out and at least one --dir"); return TYQ_E_ARG; }
    if ((rc = manifest_parse(a->manifest, &m, why, cap)) != 0) goto done;
    if ((rc = brw_load_profile(a->qprofile, &pr, &pd, w2, sizeof w2)) != 0) { WHYF("%s", w2); goto done; }
    /* qgain records of this profile, digest-checked, deduplicated */
    for (size_t d = 0; d < a->ndirs; d++) {
        if (list_prefix(a->dirs[d], "turing.qgain.", &nm) != 0) { WHYF("cannot read directory %s", a->dirs[d]); rc = TYQ_E_IO; goto done; }
        for (size_t k = 0; k < nm.cnt; k++) {
            tyqr_gain g; ty_digest gd;
            if ((rc = brw_load_gain(nm.n[k], &g, &gd, w2, sizeof w2)) != 0) { WHYF("%s: %s", nm.n[k], w2); goto done; }
            if (!ty_digest_eq(&g.qprofile, &pd)) continue;
            int dup = 0; for (size_t j = 0; j < ng; j++) if (ty_digest_eq(&gains[j].d, &gd)) { dup = 1; break; }
            if (dup) continue;
            if (ng == gcap) { gcap = gcap ? gcap * 2 : 256; gain_t *p = realloc(gains, gcap * sizeof *gains); if (!p) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; } gains = p; }
            gains[ng].g = g; gains[ng].d = gd; snprintf(gains[ng].path, sizeof gains[ng].path, "%s", nm.n[k]); ng++;
        }
    }
    if (!ng) { WHYF("no qgain of the given qprofile found in the given directories"); rc = TYQ_E_ARG; goto done; }
    for (size_t k = 1; k < ng; k++)
        if (!ty_digest_eq(&gains[k].g.qfreeze, &gains[0].g.qfreeze)) { WHYF("the qgain records of this profile name more than one qfreeze"); rc = TYQ_FAIL_PROFILE; goto done; }
    { int okf = 0; char p[BRW_PATH];
      for (size_t d = 0; d < a->ndirs && !okf; d++) {
          brw_record_path(p, sizeof p, a->dirs[d], "turing.qfreeze", &gains[0].g.qfreeze);
          if (access(p, R_OK) == 0) { if ((rc = brw_load_freeze(p, &fr, &fd, w2, sizeof w2)) != 0) { WHYF("%s", w2); goto done; } okf = 1; }
      }
      if (!okf) { WHYF("the qfreeze named by the qgain records is not in any given directory"); rc = TYQ_FAIL_PROTOCOL; goto done; }
      if (!ty_digest_eq(&fr.qprofile, &pd)) { WHYF("the qfreeze names a different qprofile"); rc = TYQ_FAIL_PROFILE; goto done; } }
    /* sealed qworlds of this freeze */
    for (size_t d = 0; d < a->ndirs; d++) {
        if (list_prefix(a->dirs[d], "turing.qworld.", &nm) != 0) { WHYF("cannot read directory %s", a->dirs[d]); rc = TYQ_E_IO; goto done; }
        for (size_t k = 0; k < nm.cnt; k++) {
            tyqr_world w; ty_digest wd;
            if ((rc = brw_load_world(nm.n[k], &w, &wd, w2, sizeof w2)) != 0) { WHYF("%s: %s", nm.n[k], w2); goto done; }
            if (strcmp(w.parent_kind, "sealed") != 0 || !ty_digest_eq(&w.qfreeze, &fd)) continue;
            int dup = 0; for (size_t j = 0; j < nw; j++) if (ty_digest_eq(&ws[j].d, &wd)) { dup = 1; break; }
            if (dup) continue;
            if (nw == wcap) { wcap = wcap ? wcap * 2 : 32; world_t *p = realloc(ws, wcap * sizeof *ws); if (!p) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; } ws = p; }
            ws[nw].w = w; ws[nw].d = wd; ws[nw].dir = a->dirs[d]; nw++;
        }
    }
    for (size_t k = 1; k < nw; k++)
        if (strcmp(ws[k].w.gen_version, ws[0].w.gen_version) != 0 || !ty_digest_eq(&ws[k].w.generator, &ws[0].w.generator)) { WHYF("the sealed qworlds name different generators"); rc = TYQ_FAIL_PROFILE; goto done; }
    /* cell names: union of the gains and the sealed worlds, byte order */
    cells = calloc(ng + nw + 1, sizeof *cells);
    if (!cells) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
    for (size_t k = 0; k < ng + nw; k++) {
        const char *c = k < ng ? gains[k].g.cell : ws[k - ng].w.cell; int dup = 0;
        for (size_t j = 0; j < ncell; j++) if (!strcmp(cells[j], c)) dup = 1;
        if (!dup) cells[ncell++] = (char *)c;
    }
    qsort(cells, ncell, sizeof *cells, strp_cmp);

    obj top; memset(&top, 0, sizeof top);
    { sb arr = { 0 }; size_t cc = 0;
      int lm_ok = strcmp(pr.lm_rule, BRW_LM_RULE) == 0;
      for (size_t ci_ = 0; ci_ < ncell; ci_++) {
          const char *cn = cells[ci_];
          obj c; memset(&c, 0, sizeof c);
          o_str(&c, "name", cn);
          const world_t *cw = NULL; size_t nwc = 0;
          for (size_t j = 0; j < nw; j++) if (!strcmp(ws[j].w.cell, cn)) { cw = &ws[j]; nwc++; }
          if (nwc > 1) { WHYF("more than one sealed qworld of cell %s", cn); rc = TYQ_FAIL_PROTOCOL; goto done; }
          size_t ngc = 0; gsort_t *gs = calloc(ng ? ng : 1, sizeof *gs);
          if (!gs) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
          for (size_t k = 0; k < ng; k++) if (!strcmp(gains[k].g.cell, cn)) { ty_hex(&gains[k].d, gs[ngc].hex); gs[ngc].idx = k; ngc++; }
          qsort(gs, ngc, sizeof *gs, gsort_cmp);
          for (size_t k = 1; k < ngc; k++) if (!ty_digest_eq(&gains[gs[k].idx].g.qworld, &gains[gs[0].idx].g.qworld)) { free(gs); WHYF("the qgain records of cell %s name different qworlds", cn); rc = TYQ_FAIL_PROFILE; goto done; }
          if (cw && ngc && !ty_digest_eq(&cw->d, &gains[gs[0].idx].g.qworld)) { free(gs); WHYF("the sealed qworld of cell %s is not the one its qgain names", cn); rc = TYQ_FAIL_PROFILE; goto done; }
          if (cw) o_hex(&c, "qworld", &cw->d); else if (ngc) o_hex(&c, "qworld", &gains[gs[0].idx].g.qworld); else o_null(&c, "qworld");
          if (cw) { o_str(&c, "label", cw->w.label); o_u(&c, "reps", cw->w.rep_count); o_u(&c, "blocks", 1); }
          else { o_null(&c, "label"); o_null(&c, "reps"); o_null(&c, "blocks"); }
          /* QBW1 digests in world order, from the digest-checked trajectory sidecar (file bytes are not re-hashed here: verify does that) */
          { sb q = { 0 }; int have = 0;
            if (cw) {
                char p[BRW_PATH], h[65]; brw_bytes mb; ty_hex(&cw->w.traj_manifest, h);
                brw_join(p, sizeof p, cw->dir, "traj.%s.man", h);
                if (brw_slurp(p, &mb) == 0) {
                    ty_digest md; tyqr_sidecar_digest((const char *)mb.b, mb.n, &md);
                    tyqr_repline *rl = calloc((size_t)cw->w.rep_count + 1, sizeof *rl); size_t n = 0;
                    if (!ty_digest_eq(&md, &cw->w.traj_manifest) || !rl || tyqr_repman_parse((const char *)mb.b, mb.n, rl, (size_t)cw->w.rep_count, &n) != TY_OK || n != cw->w.rep_count) {
                        free(rl); brw_bytes_free(&mb); free(gs); WHYF("trajectory sidecar of cell %s is not the one its qworld names", cn); rc = TYQ_FAIL_DIGEST; goto done; }
                    size_t qc = 0;
                    for (size_t k = 0; k < n; k++) { sb_sep(&q, &qc); sb_hex(&q, &rl[k].d); }
                    have = 1; free(rl); brw_bytes_free(&mb);
                } else fprintf(stderr, "results: trajectory sidecar of %s not found in the given directories: qbw1 is null\n", cn);
            }
            o_arr(&c, "qbw1", &q, have); }
          { brw_cellinfo ci; int haveci = brw_cellinfo_get(cn, &ci) == 0;
            sb qg = { 0 }; size_t qc = 0; size_t nofficial = 0, oi = 0;
            for (size_t k = 0; k < ngc; k++) {
                const gain_t *gt = &gains[gs[k].idx];
                obj go; memset(&go, 0, sizeof go);
                gain_json(&go, &gt->g, &gt->d, haveci ? &ci : NULL, lm_ok, gt->path);
                sb_sep(&qg, &qc); o_render(&go, &qg);
                if (gt->g.official == 1 && !strcmp(gt->g.mode, "certification")) { nofficial++; oi = gs[k].idx; }
            }
            o_arr(&c, "qgain", &qg, 1);
            if (nofficial == 1) { sb cv = { 0 }; size_t cn2 = 0; for (int i = 0; i < 3; i++) { sb_sep(&cv, &cn2); sb_i64(&cv, gains[oi].g.coverage[i]); } o_arr(&c, "coverage", &cv, 1); }
            else o_null(&c, "coverage"); }
          o_null(&c, "diagnostics");
          free(gs);
          sb_sep(&arr, &cc); o_render(&c, &arr);
      }
      o_arr(&top, "cells", &arr, 1); }

    { obj o; memset(&o, 0, sizeof o); char h[65];
      o_str(&o, "id", pr.profile); ty_hex(&pd, h); o_str(&o, "qprofile", h); o_hex(&o, "spec_sha256", &pr.spec); o_obj(&top, "profile", &o); }
    { obj o; memset(&o, 0, sizeof o);
      o_str(&o, "version", pr.gen_version);
      if (nw) o_hex(&o, "digest", &ws[0].w.generator); else o_null(&o, "digest");
      o_str(&o, "cflags", a->cflags); o_obj(&top, "generator", &o); }
    { obj o; memset(&o, 0, sizeof o);
      o_str(&o, "rule", pr.quantizer); o_i(&o, "delta_log2", pr.delta_log2); o_str(&o, "edge", pr.edge_rule); o_i(&o, "sd_min_log2", pr.sd_min_log2); o_obj(&top, "quantizer", &o); }
    { obj o; memset(&o, 0, sizeof o);
      o_null(&o, "recurrence"); o_null(&o, "uniform"); o_null(&o, "normal"); o_null(&o, "streams");
      o_str(&o, "kat1", m.kat[0][0] ? m.kat[0] : NULL); o_str(&o, "kat2", m.kat[1][0] ? m.kat[1] : NULL); o_obj(&top, "rng", &o); }
    { obj o; memset(&o, 0, sizeof o); ty_digest sp;
      brw_sealed_parent(fd.b, sp.b);
      o_null(&o, "dev_parent"); o_hex(&o, "sealed_parent", &sp); o_hex(&o, "qfreeze", &fd); o_obj(&top, "seeds", &o); }
    { obj o; memset(&o, 0, sizeof o);
      if (m.dirty < 0) o_null(&o, "dirty"); else o_bool(&o, "dirty", m.dirty == 1);
      o_str(&o, "omega", m.have_omega ? m.omega : NULL);
      o_arr(&o, "repos", &m.repos, 1); o_obj(&top, "commits", &o); }
    { obj o; memset(&o, 0, sizeof o); o_null(&o, "pit_bins"); o_null(&o, "fw_rate_20block"); o_null(&o, "rows"); o_obj(&top, "calibration", &o); }
    o_arr(&top, "ceiling_matrix", &m.ceiling, 1);
    o_arr(&top, "failed_runs", &m.failed, 1);
    o_arr(&top, "negative_tests", &m.neg, 1);
    o_arr(&top, "known_limitations", &m.lim, 1);
    o_arr(&top, "replay", &m.replay, 1);
    { /* Occam curve (A3.4): only when OCC qgains exist; otherwise null and the output is unchanged */
      tyqr_gain *og = malloc((ng ? ng : 1) * sizeof *og); ty_digest *od2 = malloc((ng ? ng : 1) * sizeof *od2);
      brw_occ_curve *cv = calloc(2 * BRW_OCC_NHS, sizeof *cv);
      double cross[BRW_OCC_NHS]; int have[BRW_OCC_NHS] = { 0, 0, 0, 0 }; int used = 0; char w2[BRW_WHY] = "";
      if (!og || !od2 || !cv) { free(og); free(od2); free(cv); WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
      for (size_t k = 0; k < ng; k++) { og[k] = gains[k].g; od2[k] = gains[k].d; }
      if (a->calibration) {
          brw_bytes cb;
          if (brw_slurp(a->calibration, &cb) != 0) { free(og); free(od2); free(cv); WHYF("cannot read %s", a->calibration); rc = TYQ_E_IO; goto done; }
          char *t = malloc(cb.n + 1);
          if (!t) { brw_bytes_free(&cb); free(og); free(od2); free(cv); WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
          memcpy(t, cb.b, cb.n); t[cb.n] = 0; brw_bytes_free(&cb);
          int pr2 = brw_occ_parse_calib(t, cross, have, w2, sizeof w2); free(t);
          if (pr2) { free(og); free(od2); free(cv); WHYF("%s: %s", a->calibration, w2); rc = TYQ_E_ARG; goto done; }
      }
      used = brw_occ_build(og, od2, ng, a->calibration ? cross : NULL, a->calibration ? have : NULL, cv, w2, sizeof w2);
      if (used < 0) { free(og); free(od2); free(cv); WHYF("%s", w2); rc = TYQ_E_ARG; goto done; }
      occam_json(&top, gains, ng, cv, used);
      free(og); free(od2); free(cv); }
    o_null(&top, "intervention"); o_null(&top, "chance_trend_worlds");
    o_render(&top, &out);
    if (out.oom) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
    { ty_digest od; brw_sha256(out.s, out.n, &od); ty_hex(&od, hex_out); }
    unlink(a->out);
    if (brw_write_excl(a->out, out.s, out.n) != 0) { WHYF("cannot write %s", a->out); rc = TYQ_E_IO; goto done; }
    rc = 0;
done:
    free(gains); free(ws); free(nm.n); free(cells); free(out.s); manifest_free(&m);
    return rc;
}

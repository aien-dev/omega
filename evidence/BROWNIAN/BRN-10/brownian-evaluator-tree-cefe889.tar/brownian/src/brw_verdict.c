/* brw_verdict.c: `brownian_bench verdict` (Lane D5). See brw_verdict.h. Private, sealed. C only.
 * Item tables follow spec sections 13, 14, 15 (item ids per R3-35 G8: s13.k, s14.<cell>.k, s15.<k or item>).
 * Bands: sidecar brw_thr_v1.txt at run time, or a value written in the spec text (cited). Nothing else is compiled in. */
#include <dirent.h>
#include <errno.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "brw_cells.h"
#include "brw_verdict.h"

#define WHYF(...) do { if (why && cap) snprintf(why, cap, __VA_ARGS__); } while (0)

const char *brw_vd_res_name(brw_vd_res r) { return r == BRW_VD_PASS ? "PASS" : r == BRW_VD_FAIL ? "FAIL" : r == BRW_VD_NC ? "NOT_COMPUTABLE" : "DESCRIPTIVE"; }
const char *brw_vd_verdict_name(brw_vd_verdict v) {
    return v == BRW_VD_V_PASS ? "PASS" : v == BRW_VD_V_FAIL ? "FAIL" : v == BRW_VD_V_STOPPED ? "BLOCKED" : "INCOMPLETE";
}

/* ------------------------------------------------------------------ sidecar lookup */
int brw_vd_thr_get(const char *buf, size_t len, const char *item, const char *field, char *val, size_t cap) {
    size_t p = 0;
    while (p < len) {
        size_t e = p;
        while (e < len && buf[e] != '\n') e++;
        char line[256];
        size_t l = e - p < sizeof line - 1 ? e - p : sizeof line - 1;
        memcpy(line, buf + p, l); line[l] = 0;
        char a[96], b[96], c[96];
        if (sscanf(line, "%95s %95s %95s", a, b, c) == 3 && strcmp(a, item) == 0 && strcmp(b, field) == 0) {
            snprintf(val, cap, "%s", c);
            return 0;
        }
        p = e + 1;
    }
    return -1;
}
/* numeric sidecar value; the whole token must parse */
static int thr_num(const brw_vd_in *in, const char *item, const char *field, double *out, char *why, size_t cap) {
    char v[96], *e;
    if (brw_vd_thr_get(in->thr, in->thrlen, item, field, v, sizeof v) != 0) { WHYF("thresholds sidecar has no \"%s %s\" line", item, field); return -1; }
    errno = 0; *out = strtod(v, &e);
    if (*e || e == v || errno || !isfinite(*out)) { WHYF("thresholds sidecar value \"%s\" of %s %s is not a number", v, item, field); return -1; }
    return 0;
}

/* ------------------------------------------------------------------ report helpers */
static void catf(char *dst, size_t cap, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
static void catf(char *dst, size_t cap, const char *fmt, ...) {
    size_t n = strlen(dst);
    va_list ap; va_start(ap, fmt);
    if (n < cap) vsnprintf(dst + n, cap - n, fmt, ap);
    va_end(ap);
}
static brw_vd_item *add(brw_vd_report *r, const char *id, const char *cell, const char *text, int required) {
    if (r->n >= BRW_VD_MAXITEMS) return &r->it[BRW_VD_MAXITEMS - 1];
    brw_vd_item *i = &r->it[r->n++];
    memset(i, 0, sizeof *i);
    snprintf(i->id, sizeof i->id, "%s", id); snprintf(i->cell, sizeof i->cell, "%s", cell); snprintf(i->text, sizeof i->text, "%s", text);
    i->required = required; i->res = BRW_VD_NC;
    return i;
}
static brw_vd_item *find_item(brw_vd_report *r, const char *id, const char *cell) {
    for (size_t k = 0; k < r->n; k++) if (!strcmp(r->it[k].id, id) && !strcmp(r->it[k].cell, cell)) return &r->it[k];
    return NULL;
}
static void nc(brw_vd_item *i, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void nc(brw_vd_item *i, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vsnprintf(i->why, sizeof i->why, fmt, ap); va_end(ap);
    i->res = BRW_VD_NC;
}
static void add_stop(brw_vd_report *r, int no, int state, const char *text, const char *why) {
    if (r->nst >= BRW_VD_MAXSTOPS) return;
    brw_vd_stop *s = &r->st[r->nst++];
    s->no = no; s->state = state; snprintf(s->text, sizeof s->text, "%s", text); snprintf(s->why, sizeof s->why, "%s", why);
}

/* ------------------------------------------------------------------ gain lookup and sign evaluation */
typedef enum { W_POS, W_NEG, W_NOTPOS, W_NOTNEG } vd_want;
static const char *want_text(vd_want w) {
    return w == W_POS ? "lower end above 0" : w == W_NEG ? "upper end below 0" : w == W_NOTPOS ? "lower end not above 0" : "class not NEGATIVE (upper end not below 0)";
}
/* 0 found, 1 missing, 2 two different gains for the same (cell, candidate, baseline) */
static int find_gain(const brw_vd_in *in, const char *cell, int cand, int base, const tyqr_gain **g, const ty_digest **d) {
    int found = 0;
    *g = NULL; *d = NULL;
    for (size_t k = 0; k < in->ng; k++) {
        const tyqr_gain *x = &in->g[k];
        if (strcmp(x->cell, cell) || (int)x->candidate_opcode != cand || (int)x->baseline_opcode != base) continue;
        if (found && !ty_digest_eq(&in->gd[k], *d)) return 2;
        *g = x; *d = &in->gd[k]; found = 1;
    }
    return found ? 0 : 1;
}
static const char *opname(int op) {
    const brw_ref *r = brw_ref_get(op);
    return r ? r->name : op == BRW_OP_VARIANT_H1 ? "DIFFUSION_H1" : "?";
}
typedef struct { const char *cell; int cand, base; vd_want want; } vd_part;
/* one or more gains combined into one item: FAIL if any part fails, NOT_COMPUTABLE if none fails and one cannot be evaluated */
static void sign_item(brw_vd_item *it, const brw_vd_in *in, const vd_part *p, size_t np) {
    int nfail = 0, nnc = 0;
    it->measured[0] = it->band[0] = it->why[0] = it->gains[0] = 0;
    for (size_t k = 0; k < np; k++) {
        const tyqr_gain *g; const ty_digest *d; char h[65];
        catf(it->band, sizeof it->band, "%s%s %s vs %s: %s", k ? "; " : "", p[k].cell, opname(p[k].cand), opname(p[k].base), want_text(p[k].want));
        int f = find_gain(in, p[k].cell, p[k].cand, p[k].base, &g, &d);
        if (f) { nnc++; catf(it->why, sizeof it->why, "%sno unique qgain for %s %s vs %s", it->why[0] ? "; " : "", p[k].cell, opname(p[k].cand), opname(p[k].base)); continue; }
        ty_hex(d, h); h[8] = 0; catf(it->gains, sizeof it->gains, "%s%s", it->gains[0] ? " " : "", h);
        catf(it->measured, sizeof it->measured, "%sT=%.6f [%.6f, %.6f] bits", k ? "; " : "", (double)g->t_ub / 1e6, (double)g->t_lo_ub / 1e6, (double)g->t_hi_ub / 1e6);
        if (!strcmp(g->status, "STOPPED") || !strcmp(g->classification, "STOPPED")) { nnc++; catf(it->why, sizeof it->why, "%sgain is STOPPED", it->why[0] ? "; " : ""); continue; }
        if (strcmp(brw_class_label(g->t_ub, g->t_lo_ub, g->t_hi_ub), g->classification) != 0) {
            nnc++; catf(it->why, sizeof it->why, "%sstored classification %s disagrees with the stored interval", it->why[0] ? "; " : "", g->classification); continue; }
        int pos = g->t_lo_ub > 0, neg = g->t_hi_ub < 0, ok;
        switch (p[k].want) { case W_POS: ok = pos; break; case W_NEG: ok = neg; break; case W_NOTPOS: ok = !pos; break; default: ok = !neg; break; }
        if (!ok) nfail++;
    }
    it->res = nfail ? BRW_VD_FAIL : nnc ? BRW_VD_NC : BRW_VD_PASS;
    if (nfail && nnc) catf(it->why, sizeof it->why, "%s(other parts failed)", it->why[0] ? "; " : "");
}
static void sign1(brw_vd_report *r, const brw_vd_in *in, const char *id, const char *cell, const char *text, int cand, int base, vd_want w) {
    vd_part p = { cell, cand, base, w };
    sign_item(add(r, id, cell, text, 1), in, &p, 1);
}

/* fail flags: no FAIL_LEAK, FAIL_FLOOR, FAIL_PROTOCOL on any gain of the cell (spec 13 row 8, 14 last row, 15 row 7) */
static void flags_item(brw_vd_report *r, const brw_vd_in *in, const char *id, const char *cell) {
    brw_vd_item *it = add(r, id, cell, "no FAIL_LEAK, FAIL_FLOOR, FAIL_PROTOCOL", 1);
    size_t ng = 0; int bad = 0;
    snprintf(it->band, sizeof it->band, "every qgain of the cell: status PASS, leak_flag not 1, protocol_failures 0");
    for (size_t k = 0; k < in->ng; k++) {
        const tyqr_gain *g = &in->g[k];
        if (strcmp(g->cell, cell)) continue;
        ng++;
        if (strncmp(g->status, "FAIL_", 5) == 0 || !strcmp(g->leak_flag, "1") || g->protocol_failures) {
            bad++; catf(it->why, sizeof it->why, "%s%s vs %s status %s", it->why[0] ? "; " : "", opname((int)g->candidate_opcode), opname((int)g->baseline_opcode), g->status);
        }
    }
    snprintf(it->measured, sizeof it->measured, "%zu qgain(s), %d flagged", ng, bad);
    if (!ng) nc(it, "no qgain for the cell");
    else it->res = bad ? BRW_VD_FAIL : BRW_VD_PASS;
    if (!bad && ng) it->why[0] = 0;
}

/* ------------------------------------------------------------------ world statistics */
int brw_vd_stats_from(const brw_cellinfo *ci, const brw_traj *tr, const brw_params *par, size_t W, brw_vd_wstats *out) {
    memset(out, 0, sizeof *out);
    if (!W) { snprintf(out->why, sizeof out->why, "no worlds"); return TYQ_E_ARG; }
    double *dlo = calloc(W, sizeof *dlo), *dhi = calloc(W, sizeof *dhi), *dtr = calloc(W, sizeof *dtr);
    double *mlo = calloc(W, sizeof *mlo), *mhi = calloc(W, sizeof *mhi), *mtr = calloc(W, sizeof *mtr);
    double *y = calloc((size_t)ci->s.n_points + 1, sizeof *y);
    int rc = 0;
    if (!dlo || !dhi || !dtr || !mlo || !mhi || !mtr || !y) { rc = TYQ_E_IO; snprintf(out->why, sizeof out->why, "out of memory"); goto done; }
    for (size_t w = 0; w < W; w++) {
        uint32_t S = brw_world_split(&ci->s, &tr[w]);
        double h;
        if (tr[w].count > ci->s.n_points || S < 2 || S > tr[w].count) { rc = TYQ_FAIL_PROFILE; snprintf(out->why, sizeof out->why, "world %zu does not match the cell", w); goto done; }
        for (size_t i = 0; i < tr[w].count; i++) y[i] = brw_symbol_value(tr[w].k[i]);
        if (brw_d_interval(tr[w].t, y, S, &h, &dlo[w], &dhi[w]) != BRW_OK || brw_mu_interval(tr[w].t, y, S, &h, &mlo[w], &mhi[w]) != BRW_OK) {
            rc = TYQ_FAIL_PROTOCOL; snprintf(out->why, sizeof out->why, "reference interval undefined in world %zu", w); goto done; }
        dtr[w] = par[w].D; mtr[w] = par[w].mu;
    }
    out->n = (uint32_t)W;
    out->cov_d = brw_count_cover(dlo, dhi, dtr, W);
    out->cov_mu = brw_count_cover(mlo, mhi, mtr, W);
    out->excl0 = brw_count_excludes(mlo, mhi, W, 0.0);
    out->below0 = brw_count_below(mhi, W, 0.0);
    out->have = 1;
done:
    free(dlo); free(dhi); free(dtr); free(mlo); free(mhi); free(mtr); free(y);
    return rc;
}
int brw_vd_world_stats(const brw_cellinfo *ci, const brw_traj *tr, size_t W, const ty_digest *qfreeze, brw_vd_wstats *out, char *why, size_t cap) {
    memset(out, 0, sizeof *out);
    uint8_t parent[32]; char label[128];
    brw_params *par = calloc(W ? W : 1, sizeof *par);
    if (!par) { WHYF("out of memory"); return TYQ_E_IO; }
    brw_sealed_parent(qfreeze->b, parent);
    int rc = 0;
    if (brw_world_label("seal", ci->s.name, 0, label, sizeof label) != BRW_OK) { WHYF("cannot form the world label"); rc = TYQ_E_ARG; goto done; }
    for (size_t w = 0; w < W; w++) {
        uint8_t seed[32]; brw_traj g; memset(&g, 0, sizeof g);
        if (brw_world_seed(label, parent, 32, w, seed) != BRW_OK || brw_world_generate(&ci->s, seed, &g, &par[w]) != BRW_OK) { brw_traj_free(&g); WHYF("cannot regenerate world %zu", w); rc = TYQ_FAIL_PROTOCOL; goto done; }
        int same = g.count == tr[w].count && memcmp(g.k, tr[w].k, g.count * sizeof *g.k) == 0 && memcmp(g.t, tr[w].t, g.count * sizeof *g.t) == 0;
        brw_traj_free(&g);
        if (!same) { WHYF("world %zu is not the world the sealed seed generates", w); rc = TYQ_FAIL_DIGEST; goto done; }
    }
    rc = brw_vd_stats_from(ci, tr, par, W, out);
    if (rc) WHYF("%s", out->why);
done:
    free(par);
    if (rc) snprintf(out->why, sizeof out->why, "%s", why && cap ? why : "");
    return rc;
}
/* Item 9 (spec 13): the gain of the h = 1 DIFFUSION variant (brw_variant_h1) against true-gap DIFFUSION on the sealed B0-irregular worlds.
 * The same scorer as every official qgain (brw_prd_for_program, brw_gain_compute); the variant is charged 22 bytes (parent + 1, spec 6) while its
 * PRD1 files come from the 17 measured bytes. Not an official gain: the ladder item is "s13.9", the candidate opcode is BRW_OP_VARIANT_H1,
 * and the record is never written. */
int brw_vd_variant_gain(const brw_cellinfo *ci, const brw_traj *tr, size_t W, const tyqr_profile *pr, const ty_digest *pd, const tyqr_freeze *fr, const ty_digest *fd,
                        const tyqr_world *wo, const ty_digest *wd, tyqr_gain *g, char *why, size_t cap) {
    const brw_variant *v = brw_variant_h1();
    brw_prog pv, pcharged, pdif; char err[128];
    brw_bytes *pb = NULL, *pm = NULL;
    int rc = 0;
    memset(g, 0, sizeof *g);
    if (brw_prog_from_bytes(v->bytes, v->nbytes, &pv, err, sizeof err) != TYQ_OK || brw_ref_program(BRW_OP_DIFFUSION, &pdif) != TYQ_OK) { WHYF("variant program rejected: %s", err); return TYQ_FAIL_PROTOCOL; }
    pcharged = pv; pcharged.n = v->charged_bytes;   /* the spec charge: parent bytes + 1 */
    pb = calloc(W ? W : 1, sizeof *pb); pm = calloc(W ? W : 1, sizeof *pm);
    if (!pb || !pm) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
    for (size_t w = 0; w < W && rc == 0; w++) {
        rc = brw_prd_for_program(&pdif, &tr[w], &ci->s, &pb[w], why, cap);
        if (rc == 0) rc = brw_prd_for_program(&pv, &tr[w], &ci->s, &pm[w], why, cap);
    }
    if (rc == 0) {
        brw_gain_in in; memset(&in, 0, sizeof in);
        in.profile = pr; in.profile_d = *pd; in.freeze = fr; in.freeze_d = *fd; in.world = wo; in.world_d = *wd; in.ci = *ci; in.tr = tr; in.W = W;
        in.pb = &pdif; in.pm = &pcharged; in.base_op = BRW_OP_DIFFUSION; in.cand_op = BRW_OP_VARIANT_H1;
        in.prd_b = pb; in.prd_m = pm; in.ladder_item = "s13.9";
        rc = brw_gain_compute(&in, g, why, cap);
    }
done:
    if (pb) for (size_t w = 0; w < W; w++) brw_bytes_free(&pb[w]);
    if (pm) for (size_t w = 0; w < W; w++) brw_bytes_free(&pm[w]);
    free(pb); free(pm);
    return rc;
}
static const brw_vd_wstats *cellstats(const brw_vd_in *in, const char *cell) {
    for (size_t k = 0; k < in->ncs; k++) if (!strcmp(in->cs[k].cell, cell)) return &in->cs[k].s;
    return NULL;
}

/* ------------------------------------------------------------------ band items */
typedef enum { K_COVD, K_COVMU, K_EXCL, K_BELOW } vd_kind;
typedef struct { double lo, hi, slo, shi; } vd_band;
static int get_band(const brw_vd_in *in, const char *item, const char *lof, const char *hif, const char *sitem, const char *slof, const char *shif,
                    vd_band *b, char *why, size_t cap) {
    if (thr_num(in, item, lof, &b->lo, why, cap) || thr_num(in, item, hif, &b->hi, why, cap)) return -1;
    if (sitem) { if (thr_num(in, sitem, slof, &b->slo, why, cap) || thr_num(in, sitem, shif, &b->shi, why, cap)) return -1; }
    else { b->slo = b->lo; b->shi = b->hi; }
    return 0;
}
/* a count band item. stop_on: the STOP result of brw_band_check trips stop 15 (spec 19 row 15) */
static void band_item(brw_vd_report *r, const brw_vd_in *in, const char *id, const char *cell, const char *text, vd_kind k, const vd_band *b, int one_sided, int stop_on, const char *bwhy) {
    brw_vd_item *it = add(r, id, cell, text, 1);
    const brw_vd_wstats *s = cellstats(in, cell);
    if (bwhy && bwhy[0]) { nc(it, "%s", bwhy); return; }
    if (!s || !s->have) { nc(it, "reference intervals not recomputed: %s", s && s->why[0] ? s->why : "no sealed qworld with its trajectories was given for the cell (qgain key 25 coverage is -1 in every stored record)"); return; }
    uint32_t c = k == K_COVD ? s->cov_d : k == K_COVMU ? s->cov_mu : k == K_EXCL ? s->excl0 : s->below0;
    snprintf(it->measured, sizeof it->measured, "%u of %u worlds = %.6f", c, s->n, (double)c / (double)s->n);
    if (one_sided) snprintf(it->band, sizeof it->band, "at least %.4g", b->lo);
    else if (stop_on) snprintf(it->band, sizeof it->band, "[%.4g, %.4g], stop outside [%.4g, %.4g]", b->lo, b->hi, b->slo, b->shi);
    else snprintf(it->band, sizeof it->band, "[%.4g, %.4g]", b->lo, b->hi);
    int res = one_sided ? brw_band_check(c, s->n, b->lo, 1.0, b->lo, 1.0) : brw_band_check(c, s->n, b->lo, b->hi, b->slo, b->shi);   /* one-sided: brw_stats.h, f_hi = stop_hi = 1 */
    it->res = res == BRW_BAND_PASS ? BRW_VD_PASS : BRW_VD_FAIL;
    if (stop_on && res == BRW_BAND_STOP) it->stop_no = 15;
}
static void cov_item(brw_vd_report *r, const brw_vd_in *in, const char *id, const char *cell, const char *text, vd_kind k,
                     const char *thr_item, const char *lof, const char *hif, const char *sitem, const char *slof, const char *shif) {
    vd_band b; char w[200] = "";
    memset(&b, 0, sizeof b);
    get_band(in, thr_item, lof, hif, sitem, slof, shif, &b, w, sizeof w);
    band_item(r, in, id, cell, text, k, &b, 0, 1, w);
}

/* ------------------------------------------------------------------ experiments */
static const char *const CELLS_A[] = { "B0-regular", "B0-irregular", "B0-short", NULL };
static const char *const CELLS_B[] = { "B1-0", "B1-1", "B1-3", "B1-4n", NULL };
static const char *const CELLS_C[] = { "B2-noise", "B2-weak", "B2-clear", "B2-fast", "B2-emerging", NULL };
/* EXP-002B-OCC (spec v1.3 A3.1): the 124 OCC-* cells of U10 */
static const char *const CELLS_OCC[] = {
#define OCC_NAME(nm, s, h) nm,
    BRW_OCC_LIST(OCC_NAME)
#undef OCC_NAME
    NULL };
static const char *const *cells_of(const char *e) {
    return !strcmp(e, "EXP-002A") ? CELLS_A : !strcmp(e, "EXP-002B") ? CELLS_B : !strcmp(e, "EXP-002C") ? CELLS_C : !strcmp(e, BRW_OCC_EXP) ? CELLS_OCC : NULL;
}
static int in_cells(const char *const *cs, const char *c) { for (; *cs; cs++) if (!strcmp(*cs, c)) return 1; return 0; }
static const char *const INT_D[] = { "0", "1", "2", "5", "8" };   /* spec 15, EXP-002C-INT displacement column; U5 cell names INT-d<d>, CTL-d<d> */
#define ND ((size_t)5)

static void exp_a(brw_vd_report *r, const brw_vd_in *in) {
    const int IID = BRW_OP_IID, LIN = BRW_OP_LINEAR_TREND, CUB = BRW_OP_CUBIC_TREND, DIF = BRW_OP_DIFFUSION, DRF = BRW_OP_DIFF_DRIFT, MR = BRW_OP_MEAN_REVERT, LK = BRW_OP_LOOKUP_FLOOR;
    for (const char *const *c = CELLS_A; *c; c++) {
        int reg = !strcmp(*c, "B0-regular"), irr = !strcmp(*c, "B0-irregular"), sh = !strcmp(*c, "B0-short");
        /* spec 13 table: which rows are required in which cell */
        if (reg || irr) sign1(r, in, "s13.1", *c, "T of DIFFUSION against IID_NORMAL", DIF, IID, W_POS);
        if (reg) sign1(r, in, "s13.2", *c, "T of LINEAR_TREND against DIFFUSION", LIN, DIF, W_NEG);
        if (reg) sign1(r, in, "s13.3", *c, "T of CUBIC_TREND against DIFFUSION", CUB, DIF, W_NEG);
        if (reg || sh) sign1(r, in, "s13.4", *c, "T of DIFFUSION_DRIFT against DIFFUSION", DRF, DIF, W_NEG);
        sign1(r, in, "s13.5", *c, "T of MEAN_REVERT against DIFFUSION", MR, DIF, W_NEG);
        if (reg) sign1(r, in, "s13.6", *c, "T of LOOKUP_FLOOR against DIFFUSION", LK, DIF, W_NEG);
        if (reg || irr) cov_item(r, in, "s13.7", *c, "reference D interval coverage", K_COVD, "s13.7", "d_cov_lo", "d_cov_hi", "s13.7", "d_cov_stop_lo", "d_cov_stop_hi");
        if (reg) cov_item(r, in, "s13.7b", *c, "reference mu interval coverage", K_COVMU, "s13.7b", "mu_cov_lo", "mu_cov_hi", "s19.15", "cov_stop_lo", "cov_stop_hi");
        flags_item(r, in, "s13.8", *c);
        if (irr) {   /* row 9: the h = 1 DIFFUSION variant (brw_variant_h1: 17 bytes measured, charged 22, k = 1), scored at verdict time by brw_vd_variant_gain */
            const tyqr_gain *vg; const ty_digest *vd;
            if (find_gain(in, *c, BRW_OP_VARIANT_H1, DIF, &vg, &vd) == 1) {
                brw_vd_item *it = add(r, "s13.9", *c, "h = 1 DIFFUSION variant against true-gap DIFFUSION: upper below 0", 1);
                nc(it, "variant qgain not computed: it needs the sealed B0-irregular qworld with its trajectories among the given directories (brw_variant_h1, charged 22 bytes)");
            } else sign1(r, in, "s13.9", *c, "h = 1 DIFFUSION variant against true-gap DIFFUSION: upper below 0", BRW_OP_VARIANT_H1, DIF, W_NEG);
        }
    }
}
static void exp_b(brw_vd_report *r, const brw_vd_in *in) {
    const int DIF = BRW_OP_DIFFUSION, DRF = BRW_OP_DIFF_DRIFT, MR = BRW_OP_MEAN_REVERT;
    vd_band b; char w[200];
    /* B1-0 */
    sign1(r, in, "s14.B1-0.1", "B1-0", "T of DIFFUSION_DRIFT against DIFFUSION", DRF, DIF, W_NEG);
    sign1(r, in, "s14.B1-0.2", "B1-0", "T of MEAN_REVERT against DIFFUSION", MR, DIF, W_NEG);
    cov_item(r, in, "s14.B1-0.3", "B1-0", "coverage of the reference mu interval", K_COVMU, "s14.B1-0.3", "mu_cov_lo", "mu_cov_hi", "s19.15", "cov_stop_lo", "cov_stop_hi");
    memset(&b, 0, sizeof b); w[0] = 0;   /* acceptance band and stop band both from the sidecar: s14.B1-0.4 and s19.15 (spec 14 row B1-0.4, stop 15) */
    get_band(in, "s14.B1-0.4", "excl_frac_lo", "excl_frac_hi", "s19.15", "b1_0_excl_stop_lo", "b1_0_excl_stop_hi", &b, w, sizeof w);
    band_item(r, in, "s14.B1-0.4", "B1-0", "fraction of worlds whose reference interval excludes 0", K_EXCL, &b, 0, 1, w);
    flags_item(r, in, "s14.B1-0.F", "B1-0");
    /* B1-1 */
    sign1(r, in, "s14.B1-1.1", "B1-1", "T of DIFFUSION_DRIFT against DIFFUSION", DRF, DIF, W_NEG);
    memset(&b, 0, sizeof b); w[0] = 0;
    get_band(in, "s14.B1-1.2", "excl_frac_lo", "excl_frac_hi", NULL, NULL, NULL, &b, w, sizeof w);
    band_item(r, in, "s14.B1-1.2", "B1-1", "fraction of reference intervals that exclude 0", K_EXCL, &b, 0, 0, w);
    {   /* B1-1.3: "more than half" is the spec's own wording; the sidecar carries the token `half` */
        brw_vd_item *it = add(r, "s14.B1-1.3", "B1-1", "reference mu interval excludes 0 on more than half of the worlds fails the cell", 1);
        const brw_vd_wstats *s = cellstats(in, "B1-1"); char v[96];
        if (brw_vd_thr_get(in->thr, in->thrlen, "s14.B1-1.3", "excl_frac_gt", v, sizeof v) != 0) nc(it, "thresholds sidecar has no \"s14.B1-1.3 excl_frac_gt\" line");
        else if (strcmp(v, "half") != 0) nc(it, "sidecar value \"%s\" is not the token \"half\" the spec text uses (spec 14 row B1-1.3)", v);
        else if (!s || !s->have) nc(it, "reference intervals not recomputed: %s", s && s->why[0] ? s->why : "no sealed qworld with its trajectories was given for the cell");
        else {
            snprintf(it->measured, sizeof it->measured, "%u of %u worlds = %.6f", s->excl0, s->n, (double)s->excl0 / (double)s->n);
            snprintf(it->band, sizeof it->band, "not more than half (excl_frac_gt = half)");
            it->res = 2ull * s->excl0 > s->n ? BRW_VD_FAIL : BRW_VD_PASS;
        }
    }
    cov_item(r, in, "s14.B1-1.4", "B1-1", "coverage of true mu", K_COVMU, "s14.B1-1.4", "mu_cov_lo", "mu_cov_hi", "s19.15", "cov_stop_lo", "cov_stop_hi");
    flags_item(r, in, "s14.B1-1.F", "B1-1");
    /* B1-3 */
    sign1(r, in, "s14.B1-3.1", "B1-3", "T of DIFFUSION_DRIFT against DIFFUSION", DRF, DIF, W_POS);
    cov_item(r, in, "s14.B1-3.2", "B1-3", "coverage of true mu", K_COVMU, "s14.B1-3.2", "mu_cov_lo", "mu_cov_hi", "s19.15", "cov_stop_lo", "cov_stop_hi");
    memset(&b, 0, sizeof b); w[0] = 0;
    if (thr_num(in, "s14.B1-3.3", "excl_frac_min", &b.lo, w, sizeof w) == 0) b.hi = 1.0;
    band_item(r, in, "s14.B1-3.3", "B1-3", "exclusion of 0 on at least a fraction of worlds", K_EXCL, &b, 1, 0, w);
    sign1(r, in, "s14.B1-3.4", "B1-3", "T of MEAN_REVERT against DIFFUSION_DRIFT", MR, DRF, W_NEG);
    flags_item(r, in, "s14.B1-3.F", "B1-3");
    /* B1-4n */
    sign1(r, in, "s14.B1-4n.1", "B1-4n", "T of DIFFUSION_DRIFT against DIFFUSION", DRF, DIF, W_POS);
    sign1(r, in, "s14.B1-4n.2", "B1-4n", "T of MEAN_REVERT against DIFFUSION_DRIFT", MR, DRF, W_NEG);
    memset(&b, 0, sizeof b); w[0] = 0;
    if (thr_num(in, "s14.B1-4n.3", "below0_frac_min", &b.lo, w, sizeof w) == 0) b.hi = 1.0;
    band_item(r, in, "s14.B1-4n.3", "B1-4n", "reference mu interval entirely below 0 on a fraction of worlds", K_BELOW, &b, 1, 0, w);
    cov_item(r, in, "s14.B1-4n.4", "B1-4n", "coverage of true mu", K_COVMU, "s14.B1-4n.4", "mu_cov_lo", "mu_cov_hi", "s19.15", "cov_stop_lo", "cov_stop_hi");
    flags_item(r, in, "s14.B1-4n.F", "B1-4n");
    {   /* the Occam curve is a deliverable with no acceptance number (spec 14, R3-6b): reported, never a verdict item */
        brw_vd_item *it = add(r, "s14.occam", "OCC-*", "Occam curve deliverable (dT against |mu|/sqrt(2D))", 0);
        nc(it, "descriptive deliverable: the OCC-* cells carry no acceptance number and are not read by verdict");
    }
}
/* EXP-002B-OCC (spec v1.3 A3.3): s14.occ0. For each H in {128, 256, 512, 1024}, on OCC-s+0.00-H<h> the class of T(DIFFUSION_DRIFT vs DIFFUSION)
 * is not POSITIVE ("drift earns credit" = POSITIVE), and no FAIL_LEAK, FAIL_FLOOR or FAIL_PROTOCOL occurs on any OCC-* cell. PASS iff both hold at all four H.
 * FAIL wins over missing data; a missing or STOPPED qgain, or no OCC qgain at all, is NOT_COMPUTABLE (INCOMPLETE), never PASS.
 * R3-48: a scoring abort writes no qgain, so every OCC-* cell must carry its DIFFUSION_DRIFT vs DIFFUSION qgain (A3.2) or the item is NOT_COMPUTABLE. */
static void exp_occ(brw_vd_report *r, const brw_vd_in *in) {
    static const char *const Z[4] = { "OCC-s+0.00-H128", "OCC-s+0.00-H256", "OCC-s+0.00-H512", "OCC-s+0.00-H1024" };
    vd_part p[4]; size_t nocc = 0; int bad = 0;
    char badwhy[300] = "";
    brw_vd_item *it = add(r, "s14.occ0", "OCC-s+0.00", "s = 0 earns no credit at any H: T of DIFFUSION_DRIFT against DIFFUSION not POSITIVE; no FAIL_LEAK, FAIL_FLOOR, FAIL_PROTOCOL on any OCC cell", 1);
    for (size_t k = 0; k < 4; k++) { p[k].cell = Z[k]; p[k].cand = BRW_OP_DIFF_DRIFT; p[k].base = BRW_OP_DIFFUSION; p[k].want = W_NOTPOS; }
    sign_item(it, in, p, 4);
    for (size_t k = 0; k < in->ng; k++) {
        const tyqr_gain *g = &in->g[k];
        if (!in_cells(CELLS_OCC, g->cell)) continue;
        nocc++;
        if (strncmp(g->status, "FAIL_", 5) == 0 || !strcmp(g->leak_flag, "1") || g->protocol_failures) {
            bad++; catf(badwhy, sizeof badwhy, "%s%s %s vs %s status %s", badwhy[0] ? "; " : "", g->cell, opname((int)g->candidate_opcode), opname((int)g->baseline_opcode), g->status);
        }
    }
    size_t ncell = 0, nmiss = 0; char misswhy[200] = "";
    for (const char *const *cs = CELLS_OCC; *cs; cs++, ncell++) {
        int have = 0;
        for (size_t k = 0; k < in->ng && !have; k++) { const tyqr_gain *g = &in->g[k]; have = !strcmp(g->cell, *cs) && (int)g->candidate_opcode == BRW_OP_DIFF_DRIFT && (int)g->baseline_opcode == BRW_OP_DIFFUSION; }
        if (!have && nmiss++ < 4) catf(misswhy, sizeof misswhy, "%s%s", misswhy[0] ? ", " : "", *cs);
    }
    catf(it->band, sizeof it->band, "; and no FAIL_LEAK, FAIL_FLOOR, FAIL_PROTOCOL on any of the %zu OCC qgains", nocc);
    catf(it->band, sizeof it->band, "; every one of the %zu OCC cells carries its DIFFUSION_DRIFT vs DIFFUSION qgain", ncell);
    if (bad) { it->res = BRW_VD_FAIL; catf(it->why, sizeof it->why, "%s%s", it->why[0] ? "; " : "", badwhy); }
    else if (!nocc) { it->res = BRW_VD_NC; if (!it->why[0]) nc(it, "no OCC qgain"); }
    else if (nmiss && it->res != BRW_VD_FAIL) { it->res = BRW_VD_NC; catf(it->why, sizeof it->why, "%smissing OCC qgain on %zu of %zu cells (%s%s)", it->why[0] ? "; " : "", nmiss, ncell, misswhy, nmiss > 4 ? ", ..." : ""); }
}
static void exp_c(brw_vd_report *r, const brw_vd_in *in) {
    const int IID = BRW_OP_IID, CUB = BRW_OP_CUBIC_TREND, DIF = BRW_OP_DIFFUSION, DRF = BRW_OP_DIFF_DRIFT, MR = BRW_OP_MEAN_REVERT;
    {   vd_part p[2] = { { "B2-noise", MR, DIF, W_NEG }, { "B2-noise", DIF, IID, W_POS } };
        sign_item(add(r, "s15.1", "B2-noise", "T of MEAN_REVERT against DIFFUSION (upper below 0) and T of DIFFUSION against IID_NORMAL (lower above 0)", 1), in, p, 2); }
    sign1(r, in, "s15.2", "B2-weak", "T of MEAN_REVERT against DIFFUSION_DRIFT: lower interval not above 0", MR, DRF, W_NOTPOS);
    for (int k = 0; k < 2; k++) {
        const char *c = k ? "B2-fast" : "B2-clear";
        vd_part p[2] = { { c, MR, DRF, W_POS }, { c, CUB, MR, W_NEG } };
        sign_item(add(r, "s15.3", c, "T of MEAN_REVERT against DIFFUSION_DRIFT lower above 0; T of CUBIC_TREND against MEAN_REVERT upper below 0", 1), in, p, 2);
    }
    {   /* row 4: IID_NORMAL beating MEAN_REVERT (lower above 0) fails the cell and stops the harness (spec 15 row 4, stop 15) */
        brw_vd_item *it = add(r, "s15.4", "B2-fast", "T of IID_NORMAL against MEAN_REVERT: lower above 0 fails the cell and stops", 1);
        vd_part p = { "B2-fast", IID, MR, W_NOTPOS };
        sign_item(it, in, &p, 1);
        if (it->res == BRW_VD_FAIL) it->stop_no = 15;
    }
    {   /* row 5: sealed class of MEAN_REVERT vs DIFFUSION_DRIFT against the frozen development label (qfreeze b2_emerging_label) */
        brw_vd_item *it = add(r, "s15.5", "B2-emerging", "sealed class is not the opposite of the development label", 1);
        const tyqr_gain *g; const ty_digest *d; char h[65];
        snprintf(it->band, sizeof it->band, "POSITIVE label with NEGATIVE class, or the reverse, fails; AMBIGUOUS on either side does not");
        if (find_gain(in, "B2-emerging", MR, DRF, &g, &d)) nc(it, "no unique official qgain for B2-emerging MEAN_REVERT vs DIFFUSION_DRIFT");
        else if (strcmp(g->status, "STOPPED") == 0) nc(it, "gain is STOPPED");
        else {
            const char *lab = in->fr->b2_emerging_label;
            const char *cls = brw_class_label(g->t_ub, g->t_lo_ub, g->t_hi_ub);
            ty_hex(d, h); h[8] = 0; snprintf(it->gains, sizeof it->gains, "%s", h);
            snprintf(it->measured, sizeof it->measured, "label %.100s, sealed class %s, T=%.6f [%.6f, %.6f] bits", lab, cls, (double)g->t_ub / 1e6, (double)g->t_lo_ub / 1e6, (double)g->t_hi_ub / 1e6);
            if (strcmp(lab, "POSITIVE") && strcmp(lab, "NEGATIVE") && strcmp(lab, "AMBIGUOUS")) nc(it, "qfreeze b2_emerging_label \"%s\" is not POSITIVE, NEGATIVE or AMBIGUOUS", lab);
            else it->res = (!strcmp(lab, "POSITIVE") && !strcmp(cls, "NEGATIVE")) || (!strcmp(lab, "NEGATIVE") && !strcmp(cls, "POSITIVE")) ? BRW_VD_FAIL : BRW_VD_PASS;
        }
    }
    {   /* row 6: held-out T only. The stored records show it: mode certification, fit-once L(M) rule, held-out points scored */
        brw_vd_item *it = add(r, "s15.6", "all", "no positive cell passes on prefix fit alone; the interval is held-out T", 1);
        size_t ng = 0, bad = 0;
        snprintf(it->band, sizeof it->band, "every qgain: lm_rule %s, held-out points per world > 0, scored points > 0", BRW_LM_RULE);
        for (size_t k = 0; k < in->ng; k++) {
            if (!in_cells(CELLS_C, in->g[k].cell)) continue;
            ng++;
            if (in->g[k].counts[2] == 0 || in->g[k].counts[3] == 0) bad++;
        }
        snprintf(it->measured, sizeof it->measured, "%zu qgain(s), %zu without held-out scored points, profile lm_rule %.200s", ng, bad, in->pr->lm_rule);
        if (!ng) nc(it, "no qgain");
        else it->res = bad || strcmp(in->pr->lm_rule, BRW_LM_RULE) ? BRW_VD_FAIL : BRW_VD_PASS;
    }
    for (const char *const *c = CELLS_C; *c; c++) flags_item(r, in, "s15.7", *c);
}
/* EXP-002C-INT (spec 15): cells INT-d<d> and CTL-d<d> by the names of spec 22 U5; evaluated when their qgain records exist */
static void exp_int(brw_vd_report *r, const brw_vd_in *in) {
    const int DIF = BRW_OP_DIFFUSION, DRF = BRW_OP_DIFF_DRIFT, MR = BRW_OP_MEAN_REVERT;
    char c8[24], c2[24];
    snprintf(c8, sizeof c8, "INT-d%s", INT_D[4]); snprintf(c2, sizeof c2, "INT-d%s", INT_D[2]);
    for (size_t k = 0; k < in->ng; k++) if (!strncmp(in->g[k].cell, "INT-d", 5) || !strncmp(in->g[k].cell, "CTL-d", 5)) r->has_int = 1;
    {   vd_part p[2] = { { c8, MR, DRF, W_POS }, { c8, MR, DIF, W_POS } };
        sign_item(add(r, "s15.I-far", c8, "MEAN_REVERT beats both DIFFUSION_DRIFT and DIFFUSION (lower above 0 on both)", 1), in, p, 2); }
    sign1(r, in, "s15.I-near", c2, "class of MEAN_REVERT versus DIFFUSION is not NEGATIVE", MR, DIF, W_NOTNEG);
    {   vd_part p[ND];
        char cells[ND][24];
        for (size_t k = 0; k < ND; k++) { snprintf(cells[k], sizeof cells[k], "INT-d%s", INT_D[k]); p[k].cell = cells[k]; p[k].cand = MR; p[k].base = DRF; p[k].want = W_POS; }
        sign_item(add(r, "s15.I-drift", "INT-d*", "MEAN_REVERT beats DIFFUSION_DRIFT at every displacement", 1), in, p, ND); }
    {   /* I-control: at every displacement the pure-diffusion control must NOT satisfy the both-beat criterion */
        brw_vd_item *it = add(r, "s15.I-control", "CTL-d*", "pure-diffusion control never earns MEAN_REVERT credit under the both-beat criterion", 1);
        int nfail = 0, nnc = 0; char pm[96] = "";
        it->measured[0] = it->band[0] = it->why[0] = it->gains[0] = 0;
        for (size_t k = 0; k < ND; k++) {
            char c[24]; brw_vd_item t; vd_part p[2];
            snprintf(c, sizeof c, "CTL-d%s", INT_D[k]);
            p[0].cell = c; p[0].cand = MR; p[0].base = DIF; p[0].want = W_POS;
            p[1].cell = c; p[1].cand = MR; p[1].base = DRF; p[1].want = W_POS;
            memset(&t, 0, sizeof t);
            sign_item(&t, in, p, 2);
            catf(it->measured, sizeof it->measured, "%sd=%s %s", k ? "; " : "", INT_D[k], t.res == BRW_VD_PASS ? "both-beat earned" : t.res == BRW_VD_FAIL ? "no credit" : "missing");
            if (t.res == BRW_VD_PASS) nfail++;           /* both-beat holds on the control: credit earned, the item fails */
            else if (t.res == BRW_VD_NC) { nnc++; catf(it->why, sizeof it->why, "%sCTL-d%s: %s", it->why[0] ? "; " : "", INT_D[k], t.why); }
        }
        if (brw_vd_thr_get(in->thr, in->thrlen, "s15.I-control", "p_min", pm, sizeof pm) == 0) snprintf(it->band, sizeof it->band, "no credit at any d (design P at least %s)", pm);
        else snprintf(it->band, sizeof it->band, "no credit at any d");
        it->res = nfail ? BRW_VD_FAIL : nnc ? BRW_VD_NC : BRW_VD_PASS;
    }
    flags_item(r, in, "s15.I-flags", c8);
    /* descriptive rows (spec 15): reported, never gating */
    static const struct { const char *id; size_t di; const char *text; } DR[] = {
        { "s15.I-near0", 0, "near d = 0: class of MEAN_REVERT versus DIFFUSION" }, { "s15.I-near1", 1, "near d = 1: class of MEAN_REVERT versus DIFFUSION" },
        { "s15.I-mod5", 3, "moderate d = 5: class of MEAN_REVERT versus DIFFUSION" } };
    for (size_t k = 0; k < 3; k++) {
        char c[24]; const tyqr_gain *g; const ty_digest *d;
        snprintf(c, sizeof c, "INT-d%s", INT_D[DR[k].di]);
        brw_vd_item *it = add(r, DR[k].id, c, DR[k].text, 0);
        if (find_gain(in, c, MR, DIF, &g, &d)) nc(it, "no qgain");
        else { it->res = BRW_VD_DESC; snprintf(it->measured, sizeof it->measured, "class %s, T=%.6f [%.6f, %.6f] bits", brw_class_label(g->t_ub, g->t_lo_ub, g->t_hi_ub), (double)g->t_ub / 1e6, (double)g->t_lo_ub / 1e6, (double)g->t_hi_ub / 1e6); }
    }
    /* theta = 0.5 worlds (INT05-d<d>, 200 worlds, H 128): descriptive only, never gated, never counted in has_int or the INT verdict */
    for (size_t k = 0; k < ND; k++) {
        char c[24], id[24]; const tyqr_gain *g; const ty_digest *d;
        snprintf(c, sizeof c, "INT05-d%s", INT_D[k]); snprintf(id, sizeof id, "s15.I05-d%s", INT_D[k]);
        brw_vd_item *it = add(r, id, c, "theta = 0.5 (descriptive): class of MEAN_REVERT versus DIFFUSION", 0);
        if (find_gain(in, c, MR, DIF, &g, &d)) nc(it, "no qgain");
        else { it->res = BRW_VD_DESC; snprintf(it->measured, sizeof it->measured, "class %s, T=%.6f [%.6f, %.6f] bits", brw_class_label(g->t_ub, g->t_lo_ub, g->t_hi_ub), (double)g->t_ub / 1e6, (double)g->t_lo_ub / 1e6, (double)g->t_hi_ub / 1e6); }
    }
}

/* ------------------------------------------------------------------ stop conditions (spec 19) */
static int has_int_cell(const char *c) { return !strncmp(c, "INT-d", 5) || !strncmp(c, "CTL-d", 5); }
static int has_int05_cell(const char *c) { return !strncmp(c, "INT05-d", 7); }   /* theta = 0.5, descriptive only: loaded and reported, never gating (no stop, no INT verdict) */
static void stops(brw_vd_report *r, const brw_vd_in *in, const char *const *cells) {
    char why[8192];
    int hit, seen;
    /* 5 and 7: FAIL_PROTOCOL / FAIL_FLOOR runs (spec 19 rows 5, 7) */
    hit = seen = 0; why[0] = 0;
    for (size_t k = 0; k < in->ng; k++) {
        const tyqr_gain *g = &in->g[k];
        if (!in_cells(cells, g->cell)) continue;
        seen = 1;
        if (!strcmp(g->status, "FAIL_PROTOCOL") || g->protocol_failures) { hit = 1; catf(why, sizeof why, "%s: FAIL_PROTOCOL ", g->cell); }
    }
    add_stop(r, 5, hit ? 1 : seen ? 0 : 2, "candidate protocol violation (a FAIL_PROTOCOL run)", seen ? why : "no qgain");
    hit = seen = 0; why[0] = 0;
    for (size_t k = 0; k < in->ng; k++) {
        const tyqr_gain *g = &in->g[k];
        if (!in_cells(cells, g->cell)) continue;
        seen = 1;
        if (!strcmp(g->status, "FAIL_FLOOR")) { hit = 1; catf(why, sizeof why, "%s: FAIL_FLOOR ", g->cell); }
    }
    add_stop(r, 7, hit ? 1 : seen ? 0 : 2, "the run is FAIL_FLOOR", seen ? why : "no qgain");
    hit = 0; why[0] = 0;
    for (size_t k = 0; k < in->ng; k++) if (!strcmp(in->g[k].status, "STOPPED") && (in_cells(cells, in->g[k].cell) || has_int_cell(in->g[k].cell))) { hit = 1; catf(why, sizeof why, "%s ", in->g[k].cell); }
    add_stop(r, 0, hit ? 1 : 0, "a qgain records STOPPED (its own stop condition)", why);
    /* 6 and 8: development stability / lengthening tests written into the qfreeze (spec 19 rows 6, 8) */
    { const char *v = in->fr->stability_test;
      add_stop(r, 6, !strcmp(v, "FAIL") ? 1 : !strcmp(v, "PASS") ? 0 : 2, "sign of T on a primary cell flips across development blocks (qfreeze stability_test)", !strcmp(v, "PASS") || !strcmp(v, "FAIL") ? "" : "qfreeze stability_test is neither PASS nor FAIL"); }
    { const char *v = in->fr->lengthening_test;
      add_stop(r, 8, !strcmp(v, "FAIL") ? 1 : !strcmp(v, "PASS") ? 0 : 2, "classification changes when the candidate side is lengthened by one byte (qfreeze lengthening_test)", !strcmp(v, "PASS") || !strcmp(v, "FAIL") ? "" : "qfreeze lengthening_test is neither PASS nor FAIL"); }
    /* 9: parameter coverage inside its band while the true-family official T has its upper end below 0 (spec 19 row 9) */
    {   static const struct { const char *exp, *cell, *cov_id; int cand, base; } T9[] = {
            { "EXP-002A", "B0-regular", "s13.7", BRW_OP_DIFFUSION, BRW_OP_IID }, { "EXP-002A", "B0-irregular", "s13.7", BRW_OP_DIFFUSION, BRW_OP_IID },
            { "EXP-002B", "B1-3", "s14.B1-3.2", BRW_OP_DIFF_DRIFT, BRW_OP_DIFFUSION }, { "EXP-002B", "B1-4n", "s14.B1-4n.4", BRW_OP_DIFF_DRIFT, BRW_OP_DIFFUSION } };
        int nh = 0, ne = 0, applicable = 0; why[0] = 0;
        for (size_t k = 0; k < sizeof T9 / sizeof T9[0]; k++) {
            if (strcmp(T9[k].exp, r->experiment)) continue;
            applicable = 1;
            brw_vd_item *ci = find_item(r, T9[k].cov_id, T9[k].cell);
            const tyqr_gain *g; const ty_digest *d;
            if (!ci || ci->res == BRW_VD_NC || find_gain(in, T9[k].cell, T9[k].cand, T9[k].base, &g, &d)) { ne++; continue; }
            if (ci->res == BRW_VD_PASS && g->t_hi_ub < 0) { nh++; catf(why, sizeof why, "%s ", T9[k].cell); }
        }
        add_stop(r, 9, nh ? 1 : !applicable ? 2 : ne ? 2 : 0, "coverage inside its band while the true-family official T is below 0", nh ? why : !applicable ? "no parameter coverage item on this experiment's cells" : ne ? "coverage or the true-family qgain is not computable for some cell" : ""); }
    add_stop(r, 10, 2, "median chi-square-to-reported interval width ratio at least 2 at claimed coverage 0.95", "not evaluable: no stored record carries a candidate-reported interval width");
    /* 11: CUBIC_TREND or LOOKUP_FLOOR beats a structure reference on a primary cell (lower above 0) (spec 19 row 11; items 13.3, 13.6) */
    { int nh2 = 0, n = 0; why[0] = 0;
      for (size_t k = 0; k < in->ng; k++) {
          const tyqr_gain *g = &in->g[k];
          if (!strcmp(r->experiment, BRW_OCC_EXP) || !in_cells(cells, g->cell) || (g->candidate_opcode != BRW_OP_CUBIC_TREND && g->candidate_opcode != BRW_OP_LOOKUP_FLOOR) || g->baseline_opcode < BRW_OP_DIFFUSION || g->baseline_opcode > BRW_OP_MEAN_REVERT) continue;
          n++;
          if (g->t_lo_ub > 0) { nh2++; catf(why, sizeof why, "%s %s vs %s ", g->cell, opname((int)g->candidate_opcode), opname((int)g->baseline_opcode)); }
      }
      add_stop(r, 11, nh2 ? 1 : n ? 0 : 2, "LOOKUP_FLOOR or a cubic trend wins a primary cell", nh2 ? why : n ? "" : "no CUBIC_TREND or LOOKUP_FLOOR qgain against a structure reference"); }
    /* 13: familywise diagnostic rejected in at least blocks_reject_min of blocks_total development blocks (spec 19 row 13, spec line 636; qfreeze key 10 list format at line 720); it is `<cell>:<ppm>` per cell */
    { double mn, tot; char w2[200]; why[0] = 0;
      if (thr_num(in, "s19.13", "blocks_reject_min", &mn, w2, sizeof w2) || thr_num(in, "s19.13", "blocks_total", &tot, w2, sizeof w2)) add_stop(r, 13, 2, "familywise diagnostic rejection in development blocks", w2);
      else {
          int n = 0, nh2 = 0; char t[TYQR_VAL]; snprintf(t, sizeof t, "%s", in->fr->diag_fw_rate_ppm);
          for (char *s = strtok(t, " ,;"); s; s = strtok(NULL, " ,;")) {
              char *col = strchr(s, ':'); if (!col) continue;
              *col = 0;
              if (!in_cells(cells, s)) continue;
              char *e; double ppm = strtod(col + 1, &e);
              if (*e || e == col + 1) continue;
              n++;
              if (ppm * tot >= mn * 1e6) { nh2++; catf(why, sizeof why, "%s:%.0f ppm ", s, ppm); }
          }
          add_stop(r, 13, nh2 ? 1 : n ? 0 : 2, "familywise diagnostic rejection in development blocks (qfreeze diag_fw_rate_ppm)", nh2 ? why : n ? "" : "qfreeze diag_fw_rate_ppm has no <cell>:<ppm> entry for these cells");
      } }
    add_stop(r, 14, 2, "generator fails an RNG or D2 known-answer test", "not derivable from the records: run `brownian_bench kat`");
    /* 15: coverage outside its stop band, B1-0 exclusion outside its band, bayes_plugin_check STOP, B2-fast IID beats MEAN_REVERT */
    { int nh2 = 0, n = 0; why[0] = 0;
      for (size_t k = 0; k < r->n; k++) {
          if (r->it[k].stop_no == 15 && r->it[k].res == BRW_VD_FAIL) { nh2++; catf(why, sizeof why, "%s %s ", r->it[k].id, r->it[k].cell); }
          if ((r->it[k].res == BRW_VD_PASS || r->it[k].res == BRW_VD_FAIL) && (!strncmp(r->it[k].id, "s13.7", 5) || strstr(r->it[k].id, ".3") || strstr(r->it[k].id, ".4") || !strcmp(r->it[k].id, "s15.4"))) n++;
      }
      if (!strcmp(in->fr->bayes_plugin_check, "STOP")) { nh2++; catf(why, sizeof why, "bayes_plugin_check STOP "); }
      else if (!strcmp(in->fr->bayes_plugin_check, "AGREE")) n++;
      add_stop(r, 15, nh2 ? 1 : n ? 0 : 2, "coverage or exclusion outside its stop band; fit-once versus prequential disagreement; B2-fast IID_NORMAL beats MEAN_REVERT", nh2 ? why : n ? "" : "no coverage, exclusion or fit-once check was computable"); }
    add_stop(r, 16, 2, "second sealed attempt for the same (candidate, profile)", "not derivable from these records: the one-attempt ledger refuses it at seal time");
    add_stop(r, 23, 2, "replay fails to reproduce a stored qgain digest", "not evaluated here: run `brownian_bench verify` and `replay`");
    /* 27: a TPS1 adapter gate failure, hard gate or qint gate (spec Section 8, Section 19 row 27, R3-28f), on any observation of any
     * scored qgain arm. The gates are run by `brownian_bench tps --write` on the stored PRD1 files (too heavy to run inside verdict);
     * a qgain with no sidecar cannot be judged, so it is NOT counted as a pass. */
    { size_t nf = 0, ne = 0, n = in->tps ? in->ntps : 0; char oks[8192]; why[0] = 0; oks[0] = 0;
      for (size_t k = 0; k < n; k++) {
          const brw_tps_gain_res *t = &in->tps[k]; char h[65];
          if (t->state == BRW_TPS_NOT_EVALUATED) { ne++; continue; }
          if (t->state == BRW_TPS_GATE_FAIL) {
              const brw_tps_arm *a = t->arm[0].state == BRW_TPS_GATE_FAIL ? &t->arm[0] : &t->arm[1];
              nf++; ty_hex(&in->gd[k], h); h[8] = 0;
              catf(why, sizeof why, "%s %s arm %s world %zu obs %zu ", h, in->g[k].cell, t->arm[0].state == BRW_TPS_GATE_FAIL ? "B" : "M", a->bad_world, a->bad_index);
          }
          else if (t->state == BRW_TPS_OUT_OF_RANGE) {   /* v1.3 A3.6: admissible only on the arm that lost, the other arm passing */
              const char *cls = brw_class_label(in->g[k].t_ub, in->g[k].t_lo_ub, in->g[k].t_hi_ub);
              int bo = t->arm[0].state == BRW_TPS_OUT_OF_RANGE, mo = t->arm[1].state == BRW_TPS_OUT_OF_RANGE;
              int adm = (mo && !bo && !strcmp(cls, "NEGATIVE") && t->arm[0].state == BRW_TPS_PASS) || (bo && !mo && !strcmp(cls, "POSITIVE") && t->arm[1].state == BRW_TPS_PASS);
              ty_hex(&in->gd[k], h); h[8] = 0;
              if (adm) catf(oks, sizeof oks, "%s %s arm %s outside TPS1 verified range (admissible, losing arm); ", h, in->g[k].cell, mo ? "M" : "B");
              else { nf++; catf(why, sizeof why, "%s %s arm %s outside TPS1 verified range on the winning arm, on both arms, or with class %s; ", h, in->g[k].cell, bo && mo ? "B+M" : mo ? "M" : "B", cls); }
          }
      }
      if (nf) add_stop(r, 27, 1, "TPS1 adapter gate failure", why);
      else if (n && !ne) add_stop(r, 27, 0, "TPS1 adapter gate failure", oks);
      else { snprintf(why, sizeof why, "%zu of %zu qgain records have no usable TPS1 sidecar (run `brownian_bench tps --qgain <qgain> --write`)", n ? ne : (size_t)0, n); add_stop(r, 27, 2, "TPS1 adapter gate failure", n ? why : "no TPS1 sidecar result supplied"); } }
    add_stop(r, -1, 2, "process-level stops 1-4, 17-22, 24-26 and Wave-2 stop 12", "not derivable from the scored records");
}

/* ------------------------------------------------------------------ evaluate */
static brw_vd_verdict combine(const brw_vd_report *r, int only_int, int *stopped_out) {
    int stopped = 0, fail = 0, inc = 0;
    for (size_t k = 0; k < r->n; k++) {
        const brw_vd_item *i = &r->it[k];
        int isint = !strncmp(i->id, "s15.I-", 6);
        if (isint != only_int || !i->required) continue;
        if (i->res == BRW_VD_FAIL) { fail = 1; if (i->stop_no) stopped = 1; }
        else if (i->res == BRW_VD_NC) inc = 1;
    }
    if (!only_int) for (size_t k = 0; k < r->nst; k++) if (r->st[k].state == 1) stopped = 1;
    if (stopped_out) *stopped_out = stopped;
    return stopped ? BRW_VD_V_STOPPED : fail ? BRW_VD_V_FAIL : inc ? BRW_VD_V_INCOMPLETE : BRW_VD_V_PASS;
}
int brw_vd_evaluate(const brw_vd_in *in, const char *experiment, brw_vd_report *r) {
    const char *const *cells = cells_of(experiment);
    memset(r, 0, sizeof *r);
    if (!cells || !in || !in->fr || !in->pr || !in->thr) return TYQ_E_ARG;
    snprintf(r->experiment, sizeof r->experiment, "%s", experiment);
    if (!strcmp(experiment, "EXP-002A")) exp_a(r, in);
    else if (!strcmp(experiment, "EXP-002B")) exp_b(r, in);
    else if (!strcmp(experiment, BRW_OCC_EXP)) exp_occ(r, in);
    else { exp_c(r, in); exp_int(r, in); }
    stops(r, in, cells);
    r->verdict = combine(r, 0, NULL);
    if (!strcmp(experiment, "EXP-002C")) r->int_verdict = combine(r, 1, NULL);
    snprintf(r->rule, sizeof r->rule,
             "BLOCKED if any stop condition of spec section 19 is hit (spec line 620: record BLOCKED, STOPPED for a sealed receipt, not a scientific claim; stops also raised by 15 row 4 and 14 B1-0.4); "
             "else FAIL if a required item fails (line 806: FAIL = a breach; a failed rung is listed and not passed, line 804); else INCOMPLETE if a required item is NOT_COMPUTABLE (line 806: some cell unclassified); "
             "else PASS (line 806; rung %s is then passed for the claim-ceiling matrix, line 804). Vocabulary PASS, FAIL, BLOCKED, INCOMPLETE only (line 806). Descriptive rows never change it%s.",
             experiment, strcmp(experiment, "EXP-002C") ? "" : "; EXP-002C-INT is a separate rung and never changes the observational verdict (line 539)");
    return 0;
}

/* ------------------------------------------------------------------ rendering */
int brw_vd_render(const brw_vd_report *r, const tyqr_profile *pr, const ty_digest *pd, const ty_digest *fd, char *out, size_t cap, size_t *len) {
    char h[65]; size_t o = 0;
#define P(...) do { if (o < cap) { int n_ = snprintf(out + o, cap - o, __VA_ARGS__); if (n_ < 0) return TYQ_E_ARG; o += (size_t)n_; } } while (0)
    P("brw.verdict.v1\nexperiment %s\n", r->experiment);
    ty_hex(pd, h); P("qprofile %s\n", h);
    ty_hex(fd, h); P("qfreeze %s\n", h);
    ty_hex(&pr->thresholds, h); P("thresholds %s\n", h);
    for (size_t k = 0; k < r->n; k++) {
        const brw_vd_item *i = &r->it[k];
        P("%s %s %s: %s%s | measured: %s | band: %s%s%s%s%s%s\n", brw_vd_res_name(i->res), i->id, i->cell, i->text, i->required ? "" : " (descriptive)",
          i->measured[0] ? i->measured : "-", i->band[0] ? i->band : "-", i->why[0] ? " | " : "", i->why, i->gains[0] ? " | qgain " : "", i->gains, i->stop_no ? " | STOP 15" : "");
    }
    for (size_t k = 0; k < r->nst; k++) {
        const brw_vd_stop *s = &r->st[k];
        P("stop %d %s: %s%s%s\n", s->no, s->state == 1 ? "HIT" : s->state == 0 ? "clear" : "not evaluated", s->text, s->why[0] ? " | " : "", s->why);
    }
    P("verdict %s %s\n", r->experiment, brw_vd_verdict_name(r->verdict));
    if (r->has_int || !strcmp(r->experiment, "EXP-002C")) P("verdict EXP-002C-INT %s\n", brw_vd_verdict_name(r->int_verdict));
    P("rule: %s\n", r->rule);
#undef P
    if (o >= cap) return TYQ_E_ARG;
    if (len) *len = o;
    return 0;
}

/* ------------------------------------------------------------------ the CLI body */
typedef struct { char path[BRW_PATH]; char dir[BRW_PATH]; tyqr_world w; ty_digest d; } vd_world;

static int list_prefix(const char *dir, const char *prefix, char (*names)[BRW_PATH], size_t max, size_t *n) {
    DIR *d = opendir(dir);
    if (!d) return -1;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) if (!strncmp(e->d_name, prefix, strlen(prefix)) && *n < max) brw_join(names[(*n)++], BRW_PATH, dir, "%s", e->d_name);
    closedir(d);
    return 0;
}
static int cmp_names(const void *a, const void *b) { return strcmp((const char *)a, (const char *)b); }

int brw_verdict_run(const brw_vd_args *a, brw_vd_verdict *verdict, char *record_path, size_t pcap, char *why, size_t cap) {
    const char *const *cells = a->experiment ? cells_of(a->experiment) : NULL;
    if (!cells) { WHYF("experiment must be EXP-002A, EXP-002B, EXP-002C or EXP-002B-OCC"); return TYQ_E_ARG; }
    if (!a->ndirs || !a->thresholds || !a->outdir) { WHYF("verdict needs --experiment --thresholds --out and at least one --dir"); return TYQ_E_ARG; }
    enum { MAXG = 2048, MAXW = 256 };
    int rc = 0;
    char (*names)[BRW_PATH] = malloc((size_t)(MAXG + MAXW) * BRW_PATH);
    tyqr_gain *gains = calloc(MAXG, sizeof *gains);
    ty_digest *gds = calloc(MAXG, sizeof *gds);
    vd_world *ws = calloc(MAXW, sizeof *ws);
    brw_vd_cellstats *cs = calloc(16, sizeof *cs);
    brw_tps_gain_res *tps = calloc(MAXG, sizeof *tps);
    brw_vd_report *rep = calloc(1, sizeof *rep);
    char *text = malloc(65536);
    brw_bytes thr = { NULL, 0 };
    tyqr_profile pr; tyqr_freeze fr; ty_digest pd, fd; size_t ng = 0, nw = 0, ncs = 0, nn = 0, chain = 0;
    if (!names || !tps || !gains || !gds || !ws || !cs || !rep || !text) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
    /* every qgain of every directory, digest-checked, deduplicated */
    for (size_t d = 0; d < a->ndirs; d++) {
        nn = 0;
        if (list_prefix(a->dirs[d], "turing.qgain.", names, MAXG, &nn)) { WHYF("cannot read directory %s", a->dirs[d]); rc = TYQ_E_IO; goto done; }
        qsort(names, nn, BRW_PATH, cmp_names);
        for (size_t k = 0; k < nn; k++) {
            tyqr_gain g; ty_digest gd; char w2[BRW_WHY];
            if ((rc = brw_load_gain(names[k], &g, &gd, w2, sizeof w2)) != 0) { WHYF("%s: %s", names[k], w2); goto done; }
            int dup = 0;
            for (size_t j = 0; j < ng; j++) if (ty_digest_eq(&gds[j], &gd)) dup = 1;
            if (dup) continue;
            if (ng >= MAXG) { WHYF("more than %d qgain records", MAXG); rc = TYQ_E_ARG; goto done; }
            if (!in_cells(cells, g.cell) && !(!strcmp(a->experiment, "EXP-002C") && (has_int_cell(g.cell) || has_int05_cell(g.cell)))) continue;
            if (strcmp(g.mode, "certification") != 0) continue;
            gains[ng] = g; gds[ng] = gd; brw_tps_sidecar_read(names[k], &g, &gd, &tps[ng]); ng++;
        }
    }
    if (!ng) { WHYF("no certification qgain of %s found in the given directories", a->experiment); rc = TYQ_E_ARG; goto done; }
    for (size_t k = 1; k < ng; k++)
        if (!ty_digest_eq(&gains[k].qprofile, &gains[0].qprofile) || !ty_digest_eq(&gains[k].qfreeze, &gains[0].qfreeze)) { WHYF("the qgain records name different qprofile or qfreeze digests"); rc = TYQ_FAIL_PROFILE; goto done; }
    /* qprofile, qfreeze, thresholds */
    { int okp = 0, okf = 0; char p[BRW_PATH], w2[BRW_WHY];
      for (size_t d = 0; d < a->ndirs; d++) {
          brw_record_path(p, sizeof p, a->dirs[d], "turing.qprofile", &gains[0].qprofile);
          if (!okp && access(p, R_OK) == 0) { if ((rc = brw_load_profile(p, &pr, &pd, w2, sizeof w2))) { WHYF("%s", w2); goto done; } okp = 1; }
          brw_record_path(p, sizeof p, a->dirs[d], "turing.qfreeze", &gains[0].qfreeze);
          if (!okf && access(p, R_OK) == 0) { if ((rc = brw_load_freeze(p, &fr, &fd, w2, sizeof w2))) { WHYF("%s", w2); goto done; } okf = 1; }
      }
      if (!okp) { WHYF("the qprofile named by the qgain records is not in any given directory"); rc = TYQ_FAIL_PROFILE; goto done; }
      if (!okf) { WHYF("the qfreeze named by the qgain records is not in any given directory"); rc = TYQ_FAIL_PROTOCOL; goto done; }
      if (!ty_digest_eq(&fr.qprofile, &pd)) { WHYF("the qfreeze names a different qprofile"); rc = TYQ_FAIL_PROFILE; goto done; } }
    if (strcmp(fr.mode, "certification") != 0) { WHYF("verdict evaluates certification acceptance; the qfreeze mode is %s", fr.mode); rc = TYQ_FAIL_PROFILE; goto done; }
    if ((rc = brw_thr_file_check(&pr, a->thresholds, why, cap)) != 0) goto done;   /* FAIL_PROFILE on a digest mismatch or bad format */
    if ((rc = brw_slurp(a->thresholds, &thr)) != 0) { WHYF("cannot read the thresholds sidecar"); goto done; }
    { int want = !strcmp(a->experiment, "EXP-002A") ? BRW_OP_IID : (!strcmp(a->experiment, "EXP-002B") || !strcmp(a->experiment, BRW_OCC_EXP)) ? BRW_OP_DIFFUSION : BRW_OP_DIFF_DRIFT;   /* spec 13, 14, 15 headers */
      if (brw_declared_baseline(&pr, !strcmp(a->experiment, BRW_OCC_EXP) ? "EXP-002B" : a->experiment) != want) { /* A3.2: the OCC declared baseline is DIFFUSION "as EXP-002B"; the profile string names no EXP-002B-OCC tag */ WHYF("the qprofile declared baseline of %s is not the spec baseline", a->experiment); rc = TYQ_FAIL_BASELINE; goto done; } }
    /* sealed qworlds of this freeze */
    for (size_t d = 0; d < a->ndirs; d++) {
        nn = 0;
        if (list_prefix(a->dirs[d], "turing.qworld.", names, MAXW, &nn)) continue;
        qsort(names, nn, BRW_PATH, cmp_names);
        for (size_t k = 0; k < nn && nw < MAXW; k++) {
            tyqr_world w; ty_digest wd; char w2[BRW_WHY];
            if ((rc = brw_load_world(names[k], &w, &wd, w2, sizeof w2)) != 0) { WHYF("%s: %s", names[k], w2); goto done; }
            if (strcmp(w.parent_kind, "sealed") != 0 || !ty_digest_eq(&w.qfreeze, &fd)) continue;
            snprintf(ws[nw].path, sizeof ws[nw].path, "%s", names[k]); snprintf(ws[nw].dir, sizeof ws[nw].dir, "%s", a->dirs[d]); ws[nw].w = w; ws[nw].d = wd; nw++;
        }
    }
    for (size_t k = 0; k < ng; k++) {   /* chain binding where the qworld is present (`verify` remains the full chain check) */
        for (size_t j = 0; j < nw; j++) if (ty_digest_eq(&ws[j].d, &gains[k].qworld)) {
            char w2[BRW_WHY];
            if (tyqr_gain_bind(&gains[k], &gds[k], &ws[j].w, &ws[j].d, &fr, &fd, &pd, w2, sizeof w2) != TY_OK) { WHYF("qgain binding failed: %s", w2); rc = TYQ_FAIL_PROFILE; goto done; }
            chain++;
        }
    }
    size_t nrec = ng;
    /* item 9 (spec 13): the h = 1 variant gain, scored here from the sealed B0-irregular worlds (never written as a record) */
    if (!strcmp(a->experiment, "EXP-002A") && ng < MAXG) {
        size_t j; for (j = 0; j < nw; j++) if (!strcmp(ws[j].w.cell, "B0-irregular")) break;
        if (j < nw) {
            brw_traj *tr = NULL; size_t W = 0; brw_cellinfo ci; char w2[BRW_WHY] = "";
            if (brw_cellinfo_get("B0-irregular", &ci) == 0 && brw_world_load(ws[j].dir, &ws[j].w, &tr, &W, w2, sizeof w2) == 0) {
                tyqr_gain vg; int vrc = brw_vd_variant_gain(&ci, tr, W, &pr, &pd, &fr, &fd, &ws[j].w, &ws[j].d, &vg, w2, sizeof w2);
                if (vrc == 0 || vrc == TYQ_FAIL_FLOOR || vrc == TYQ_FAIL_LEAK) {
                    snprintf(vg.mode, sizeof vg.mode, "certification");
                    gains[ng] = vg; tyqr_gain_digest(&vg, &gds[ng]); ng++;
                } else fprintf(stderr, "s13.9 variant gain not computed: %s\n", w2);
                brw_world_free(tr, W);
            } else fprintf(stderr, "s13.9 variant gain not computed: %s\n", w2[0] ? w2 : "unknown cell or trajectories not loadable");
        }
    }
    /* reference-interval counts for the cells with coverage, exclusion or below-0 items */
    { static const char *const COVCELLS[] = { "B0-regular", "B0-irregular", "B1-0", "B1-1", "B1-3", "B1-4n", NULL };
      for (const char *const *c = COVCELLS; *c; c++) {
          if (!in_cells(cells, *c)) continue;
          snprintf(cs[ncs].cell, sizeof cs[ncs].cell, "%s", *c);
          brw_vd_wstats *s = &cs[ncs++].s;
          size_t j; for (j = 0; j < nw; j++) if (!strcmp(ws[j].w.cell, *c)) break;
          if (j == nw) { snprintf(s->why, sizeof s->why, "no sealed qworld of this freeze for the cell in the given directories"); continue; }
          brw_traj *tr = NULL; size_t W = 0; brw_cellinfo ci; char w2[BRW_WHY] = "";
          if (brw_cellinfo_get(*c, &ci) != 0) { snprintf(s->why, sizeof s->why, "unknown cell"); continue; }
          if (brw_world_load(ws[j].dir, &ws[j].w, &tr, &W, w2, sizeof w2) != 0) { snprintf(s->why, sizeof s->why, "trajectories not loadable: %.100s", w2); continue; }
          char w3[BRW_WHY] = "";
          if (brw_vd_world_stats(&ci, tr, W, &fd, s, w3, sizeof w3) != 0) { s->have = 0; snprintf(s->why, sizeof s->why, "%.150s", w3); }
          brw_world_free(tr, W);
      } }
    { brw_vd_in in; memset(&in, 0, sizeof in); in.tps = tps; in.ntps = nrec;
      in.g = gains; in.gd = gds; in.ng = ng; in.fr = &fr; in.fd = &fd; in.pr = &pr; in.cs = cs; in.ncs = ncs; in.thr = (const char *)thr.b; in.thrlen = thr.n;
      if ((rc = brw_vd_evaluate(&in, a->experiment, rep)) != 0) { WHYF("evaluation refused"); goto done; } }
    size_t tl = 0;
    if ((rc = brw_vd_render(rep, &pr, &pd, &fd, text, 65536, &tl)) != 0) { WHYF("verdict text too long"); goto done; }
    { char note[160]; snprintf(note, sizeof note, "records: %zu qgain, %zu of them bound to a qworld found in the directories\n", ng, chain);
      fputs(text, stdout); fputs(note, stdout); }
    { ty_digest vd; char hx[65], p[BRW_PATH];
      brw_sha256(text, tl, &vd); ty_hex(&vd, hx);
      if (mkdir(a->outdir, 0755) != 0 && errno != EEXIST) { WHYF("cannot create the output directory"); rc = TYQ_E_IO; goto done; }
      brw_join(p, sizeof p, a->outdir, "verdict.%s.txt", hx);
      int w = brw_write_excl(p, text, tl);
      if (w != 0 && w != TYQR_E_EXISTS) { WHYF("cannot write the verdict record"); rc = TYQ_E_IO; goto done; }
      if (record_path && pcap) snprintf(record_path, pcap, "%s", p);
      printf("verdict-record %s\n", p); }
    *verdict = rep->verdict;
    rc = 0;
done:
    brw_bytes_free(&thr);
    free(tps); free(names); free(gains); free(gds); free(ws); free(cs); free(rep); free(text);
    return rc;
}

/* brw_occam.c: the Occam curve of spec v1.3 Amendment 3 A3.4. See brw_occam.h. Private, sealed. C only. */
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "brw_cells.h"
#include "brw_occam.h"

#define WHYF(...) do { if (why && cap) snprintf(why, cap, __VA_ARGS__); } while (0)
static const uint32_t OCC_H[BRW_OCC_NHS] = { 128, 256, 512, 1024 };

double brw_occ_bits(int64_t ub) { return (double)ub / 1e6; }

void brw_occ_analyze(brw_occ_curve *c) {
    c->has_cross = 0; c->cross_s = 0; c->nonmono = 0; c->changes = 0;
    c->has_lo_end = c->has_hi_end = 0; c->lo_end = c->hi_end = 0;
    c->inside = 0;
    for (size_t i = 0; i < c->n; i++) {
        const brw_occ_pt *p = &c->pt[i];
        double as = fabs(p->s);
        if (i + 1 < c->n) {
            const brw_occ_pt *q = &c->pt[i + 1];
            int a = p->t > 0, b = q->t > 0;      /* state: dT <= 0 is 0, dT > 0 is 1 */
            if (a != b) c->changes++;
            if (!c->has_cross && !a && b) {      /* first adjacent pair with dT(s_i) <= 0 < dT(s_i+1) */
                double d0 = brw_occ_bits(p->t), d1 = brw_occ_bits(q->t), a1 = fabs(q->s);
                c->has_cross = 1; c->cross_s = as + (0.0 - d0) * (a1 - as) / (d1 - d0);
            }
        }
        if (!c->has_lo_end && p->hi >= 0) { c->has_lo_end = 1; c->lo_end = as; }
        if (!c->has_hi_end && p->lo > 0) { c->has_hi_end = 1; c->hi_end = as; }
    }
    c->nonmono = c->changes > 1;
    if (c->have_cross_ref) {
        double x = c->cross_ref;
        /* a missing end is beyond the grid, i.e. unbounded on that side; with no lower end at all the interval lies wholly beyond the grid */
        c->inside = c->has_lo_end && x >= c->lo_end && (!c->has_hi_end || x <= c->hi_end);
    }
}

int brw_occ_parse_calib(const char *text, double cross[BRW_OCC_NHS], int have[BRW_OCC_NHS], char *why, size_t cap) {
    const char *p = text;
    for (int i = 0; i < BRW_OCC_NHS; i++) have[i] = 0;
    if (strncmp(text, "brw.calib.v1\n", 13) != 0) { WHYF("calibration file does not start with brw.calib.v1"); return -1; }
    while (*p) {
        const char *e = strchr(p, '\n'); size_t len = e ? (size_t)(e - p) : strlen(p);
        if (len >= 10 && !strncmp(p, "occ_cross ", 10)) {
            char line[128], *end, *end2;
            if (len >= sizeof line) { WHYF("occ_cross line too long"); return -1; }
            memcpy(line, p + 10, len - 10); line[len - 10] = 0;
            errno = 0; unsigned long h = strtoul(line, &end, 10);
            if (end == line || *end != ' ') { WHYF("bad occ_cross line"); return -1; }
            double v = strtod(end + 1, &end2);
            if (*end2 || end2 == end + 1 || errno || !isfinite(v)) { WHYF("bad occ_cross value"); return -1; }
            int k = -1; for (int i = 0; i < BRW_OCC_NHS; i++) if (OCC_H[i] == h) k = i;
            if (k < 0) { WHYF("occ_cross for an H outside 128 256 512 1024"); return -1; }
            if (have[k]) { WHYF("duplicate occ_cross for H %lu", h); return -1; }
            have[k] = 1; cross[k] = v;
        }
        if (!e) break;
        p = e + 1;
    }
    return 0;
}

static int put(brw_occ_curve *c, const brw_occ_pt *pt, char *why, size_t cap) {
    size_t at = c->n;
    for (size_t i = 0; i < c->n; i++) {
        if (c->pt[i].s == pt->s) {
            if (ty_digest_eq(&c->pt[i].gain, &pt->gain)) return 0;
            WHYF("two different qgains for H %u s %+.2f", c->H, pt->s); return -1;
        }
    }
    if (c->n >= BRW_OCC_MAXPTS) { WHYF("more than %d points on one curve", BRW_OCC_MAXPTS); return -1; }
    for (size_t i = 0; i < c->n; i++) if (fabs(pt->s) < fabs(c->pt[i].s)) { at = i; break; }
    memmove(&c->pt[at + 1], &c->pt[at], (c->n - at) * sizeof c->pt[0]);
    c->pt[at] = *pt; c->n++;
    return 0;
}

int brw_occ_build(const tyqr_gain *g, const ty_digest *gd, size_t ng, const double *cross, const int *have, brw_occ_curve curves[2 * BRW_OCC_NHS], char *why, size_t cap) {
    int used = 0;
    for (int h = 0; h < BRW_OCC_NHS; h++) for (int sg = 0; sg < 2; sg++) {
        brw_occ_curve *c = &curves[2 * h + sg];
        memset(c, 0, sizeof *c);
        c->H = OCC_H[h]; c->sign = sg ? -1 : 1;
        if (cross && have && have[h]) { c->have_cross_ref = 1; c->cross_ref = cross[h]; }
    }
    for (size_t k = 0; k < ng; k++) {
        const tyqr_gain *x = &g[k]; brw_cellinfo ci; int h = -1;
        if ((int)x->candidate_opcode != BRW_OP_DIFF_DRIFT || (int)x->baseline_opcode != BRW_OP_DIFFUSION) continue;
        if (strcmp(x->status, "STOPPED") == 0 || strcmp(x->classification, "STOPPED") == 0) continue;
        if (brw_cellinfo_get(x->cell, &ci) != 0 || !ci.experiment || strcmp(ci.experiment, BRW_OCC_EXP) != 0) continue;
        for (int i = 0; i < BRW_OCC_NHS; i++) if (OCC_H[i] == ci.H) h = i;
        if (h < 0) continue;
        brw_occ_pt pt;
        pt.s = ci.s.snr_s;
        pt.ratio = fabs(ci.s.snr_s) / sqrt(BRW_B1_TFULL);   /* |mu|/sqrt(2D) with mu = s*sqrt(2D/255): D cancels */
        pt.t = x->t_ub; pt.lo = x->t_lo_ub; pt.hi = x->t_hi_ub; pt.gain = gd[k];
        if (pt.s >= 0 && put(&curves[2 * h], &pt, why, cap)) return -1;
        if (pt.s <= 0 && put(&curves[2 * h + 1], &pt, why, cap)) return -1;
        used++;
    }
    for (int i = 0; i < 2 * BRW_OCC_NHS; i++) brw_occ_analyze(&curves[i]);
    return used;
}

int brw_occ_render(const brw_occ_curve curves[2 * BRW_OCC_NHS], const char *modes, char *out, size_t cap) {
    size_t o = 0;
#define P(...) do { if (o < cap) { int n_ = snprintf(out + o, cap - o, __VA_ARGS__); if (n_ < 0) return -1; o += (size_t)n_; } } while (0)
    P("brw.occam.v1\nmodes %s\n", modes && modes[0] ? modes : "-");
    P("descriptive: dT = T of DIFFUSION_DRIFT against DIFFUSION in bits with its world-bootstrap interval; ratio = |mu|/sqrt(2D) = |s|/sqrt(255); never a verdict item, never a threshold of the world\n");
    for (int i = 0; i < 2 * BRW_OCC_NHS; i++) {
        const brw_occ_curve *c = &curves[i];
        P("curve H %u sign %c points %zu\n", c->H, c->sign > 0 ? '+' : '-', c->n);
        for (size_t k = 0; k < c->n; k++) {
            const brw_occ_pt *p = &c->pt[k];
            P("point s %.17g ratio %.17g dT %.17g lo %.17g hi %.17g\n", p->s, p->ratio, brw_occ_bits(p->t), brw_occ_bits(p->lo), brw_occ_bits(p->hi));
        }
        if (c->has_cross) P("crossing_point %.17g\n", c->cross_s); else P("crossing_point no crossing in grid\n");
        if (c->nonmono) P("flag non-monotone (%zu sign changes)\n", c->changes);
        P("crossing_interval "); if (c->has_lo_end) P("%.17g ", c->lo_end); else P("beyond grid "); if (c->has_hi_end) P("%.17g\n", c->hi_end); else P("beyond grid\n");
        if (c->have_cross_ref) P("occ_cross %.17g %s\n", c->cross_ref, c->inside ? "inside" : "outside"); else P("occ_cross not given\n");
    }
#undef P
    return o < cap ? (int)o : -1;
}

/* ------------------------------------------------------------------ CLI body */
#include <dirent.h>
#include <unistd.h>
static int cmp_path(const void *a, const void *b) { return strcmp((const char *)a, (const char *)b); }

int brw_occ_run(const char *const *dirs, size_t nd, const char *calib, const char *out, char *why, size_t cap) {
    enum { MAXG = 2048 };
    int rc = 0; size_t ng = 0;
    char (*names)[BRW_PATH] = malloc((size_t)MAXG * BRW_PATH);
    tyqr_gain *g = calloc(MAXG, sizeof *g);
    ty_digest *gd = calloc(MAXG, sizeof *gd);
    brw_occ_curve *cv = calloc(2 * BRW_OCC_NHS, sizeof *cv);
    char *text = malloc(1 << 20), modes[64] = "";
    brw_bytes cb = { NULL, 0 };
    double cross[BRW_OCC_NHS]; int have[BRW_OCC_NHS] = { 0, 0, 0, 0 };
    if (!names || !g || !gd || !cv || !text) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
    for (size_t d = 0; d < nd; d++) {
        size_t nn = 0; DIR *dp = opendir(dirs[d]); struct dirent *e;
        if (!dp) { WHYF("cannot read directory %s", dirs[d]); rc = TYQ_E_IO; goto done; }
        while ((e = readdir(dp)) != NULL) if (!strncmp(e->d_name, "turing.qgain.", 13) && nn < MAXG) brw_join(names[nn++], BRW_PATH, dirs[d], "%s", e->d_name);
        closedir(dp);
        qsort(names, nn, BRW_PATH, cmp_path);
        for (size_t k = 0; k < nn; k++) {
            tyqr_gain x; ty_digest xd; char w2[BRW_WHY]; int dup = 0;
            if ((rc = brw_load_gain(names[k], &x, &xd, w2, sizeof w2)) != 0) { WHYF("%s: %s", names[k], w2); goto done; }
            for (size_t j = 0; j < ng; j++) if (ty_digest_eq(&gd[j], &xd)) dup = 1;
            if (dup) continue;
            if (ng >= MAXG) { WHYF("more than %d qgain records", MAXG); rc = TYQ_E_ARG; goto done; }
            g[ng] = x; gd[ng] = xd; ng++;
        }
    }
    for (size_t k = 0; k < ng; k++) {   /* one profile and one freeze, as verdict requires */
        if (!ty_digest_eq(&g[k].qprofile, &g[0].qprofile) || !ty_digest_eq(&g[k].qfreeze, &g[0].qfreeze)) { WHYF("the qgain records name different qprofile or qfreeze digests"); rc = TYQ_FAIL_PROFILE; goto done; }
    }
    if (calib) {
        char w2[BRW_WHY] = "";
        if (brw_slurp(calib, &cb) != 0) { WHYF("cannot read %s", calib); rc = TYQ_E_IO; goto done; }
        char *t = malloc(cb.n + 1); if (!t) { WHYF("out of memory"); rc = TYQ_E_IO; goto done; }
        memcpy(t, cb.b, cb.n); t[cb.n] = 0;
        int pr = brw_occ_parse_calib(t, cross, have, w2, sizeof w2); free(t);
        if (pr) { WHYF("%s: %s", calib, w2); rc = TYQ_E_ARG; goto done; }
    }
    { char w2[BRW_WHY] = "";
      int used = brw_occ_build(g, gd, ng, calib ? cross : NULL, calib ? have : NULL, cv, w2, sizeof w2);
      if (used < 0) { WHYF("%s", w2); rc = TYQ_E_ARG; goto done; }
      if (used == 0) { WHYF("no OCC qgain of DIFFUSION_DRIFT against DIFFUSION in the given directories"); rc = TYQ_E_ARG; goto done; } }
    for (size_t k = 0; k < ng; k++) {   /* the modes seen among the OCC gains used (a header line, never filtered) */
        brw_cellinfo ci;
        if (brw_cellinfo_get(g[k].cell, &ci) != 0 || !ci.experiment || strcmp(ci.experiment, BRW_OCC_EXP) != 0) continue;
        if (!strstr(modes, g[k].mode)) snprintf(modes + strlen(modes), sizeof modes - strlen(modes), "%s%s", modes[0] ? "," : "", g[k].mode);
    }
    { int n = brw_occ_render(cv, modes, text, 1 << 20);
      if (n < 0) { WHYF("occam text too long"); rc = TYQ_E_ARG; goto done; }
      fwrite(text, 1, (size_t)n, stdout);
      if (out) { unlink(out); if (brw_write_excl(out, text, (size_t)n) != 0) { WHYF("cannot write %s", out); rc = TYQ_E_IO; goto done; } } }
done:
    brw_bytes_free(&cb); free(names); free(g); free(gd); free(cv); free(text);
    return rc;
}

/* brw_predict.h: certification reference predictors (BRW-DL programs 0x01-0x07), fit-once scorer glue
 * (plan §11, §15; decisions R3-1, R3-14, R3-15, R3-16, R3-22a). Private, sealed. C only.
 * Scoring is FIT ONCE on the prefix (plan B20). Prequential mode exists ONLY for the R3-22a check. */
#ifndef BRW_PREDICT_H
#define BRW_PREDICT_H
#include <stddef.h>
#include <stdint.h>
#include "brw_dl.h"
#include "brw_world.h"
#include "turing/ty_qcont.h"

#define BRW_OP_IID          0x01
#define BRW_OP_LINEAR_TREND 0x02
#define BRW_OP_CUBIC_TREND  0x03
#define BRW_OP_DIFFUSION    0x04
#define BRW_OP_DIFF_DRIFT   0x05
#define BRW_OP_MEAN_REVERT  0x06
#define BRW_OP_LOOKUP_FLOOR 0x07
#define BRW_OP_VARIANT_H1   0x84   /* pseudo opcode naming the h = 1 DIFFUSION variant in a verdict-time qgain (not a reference opcode) */
#define BRW_MEMO_PAIR_BITS  144   /* stored pair = 18 bytes = 144 bits (R3-14) */

/* Status codes are the tyq_* codes: TYQ_OK, TYQ_FAIL_PROTOCOL (program error, non-finite or non-positive
 * scale), TYQ_E_ARG (malformed argument: NULL, empty prefix, no held-out points, non-finite or
 * non-increasing time, non-finite value, N > BRW_MAXPOINTS). */

typedef struct { int opcode; const char *name; const uint8_t *bytes; int nbytes; int k; } brw_ref;
typedef struct { uint8_t bytes[BRW_MAXBYTES]; int n; BrwInfo info; } brw_prog;
typedef enum { BRW_MODE_FIT_ONCE = 0, BRW_MODE_PREQUENTIAL = 1 } brw_mode;

/* Hostile variant of a reference program (not an opcode). nbytes is what the checker measures, charged_bytes what the spec charges
 * (parent bytes + 1, once per cell), k is the parent k. */
typedef struct { const char *name; const uint8_t *bytes; int nbytes; int charged_bytes; int k; int parent_op; } brw_variant;
const brw_variant *brw_variant_h1(void);   /* h = 1 DIFFUSION (spec section 13 item 9) */

/* Reference table entry for opcode 1..7; NULL otherwise. */
const brw_ref *brw_ref_get(int opcode);
/* Check canonical bytes with the BRW-DL checker (k comes from the bytes). */
int brw_prog_from_bytes(const uint8_t *bytes, int n, brw_prog *out, char *err, size_t errcap);
/* Reference opcode -> checked program; fails if the checker's byte count or k differs from the table. */
int brw_ref_program(int opcode, brw_prog *out);
/* Stored-pairs memorizer control: exact stored value at a stored time, else previous value with scale 1.
 * n pairs, 1 <= n <= 100 (limits of the 4096-byte program). Charged length is 144 bits per pair. */
int brw_memorizer_build(const double *t, const double *y, size_t n, brw_prog *out);
uint64_t brw_memorizer_charged_bits(size_t n_pairs);

/* Predict held-out indices S..N-1 as Normal(loc, scale) with the parameters fit once on points 0..S-1.
 * out has N-S entries (index = S+i). The raw scale is returned; the qint.v1 scorer applies sd_min. */
int brw_predict_fit_once(const brw_prog *p, const double *t, const double *y, size_t N, size_t S,
                         tyq_pred *out, const char **why);
/* R3-22a check ONLY: index i is predicted from a refit on points 0..i-1. Never used in scoring. */
int brw_predict_prequential(const brw_prog *p, const double *t, const double *y, size_t N, size_t S,
                            tyq_pred *out, const char **why);

/* One world. y_j = (k_j + 0.5) * 2^-20 (qint.v1 symbol value). data_ub = predictive micro-bits over
 * held-out points only. rider_ub = k/2*log2(S-1) micro-bits (0 in prequential mode: the refit cost is
 * inside the prequential codelength). */
typedef struct { int64_t data_ub, rider_ub; uint64_t floor_hits, scored; } brw_world_score;
int brw_score_world(const brw_prog *p, const brw_traj *tr, uint32_t split, brw_mode mode, brw_world_score *out);

/* Per-cell description length: DL = 8*bytes (ONCE) + sum of per-world riders + sum of predictive ub. */
typedef struct { uint64_t model_bits; uint32_t k; int64_t bytes_ub, rider_ub, data_ub; uint64_t worlds, floor_hits, scored; } brw_cell_dl;
int brw_cell_dl_init(brw_cell_dl *c, const brw_prog *p);
int brw_cell_dl_init_bits(brw_cell_dl *c, uint64_t model_bits, uint32_t k);   /* e.g. memorizer control */
int brw_cell_dl_add(brw_cell_dl *c, const brw_world_score *w);
int brw_cell_dl_total(const brw_cell_dl *c, int64_t *dl_ub);
/* T = DL(B,D) - DL(M,D) in micro-bits via ty_gain. Positive = M better. */
int brw_cell_gain(const brw_cell_dl *baseline, const brw_cell_dl *model, int64_t *t_ub);

/* Certification artifact digest: SHA-256 of the bytes of the file at path (brownian/src/brw_predict.c). */
int brw_predict_artifact_digest(const char *path, char hex[65]);
#endif

/* brw_protocol.h: the Brownian blind lifecycle (plan §10 steps 1-9, §11, §25, §28.2; decisions R3-1..R3-23).
 * Private, sealed. C only. The pinned omega tyqr_* records are the record layer (plan §28.2 drafted ty_qprofile*
 * names; the pinned omega ships tyqr_* with different shapes, which are authoritative).
 *
 * Verdict codes are the TYQ_* refusals of ty_qcont.h (FAIL_PROTOCOL -101, FAIL_FLOOR -102, FAIL_LEAK -103,
 * FAIL_DIGEST -104, FAIL_PROFILE -105, FAIL_BASELINE -106, E_ARG -107, E_IO -108) plus the three below.
 * Every function that can refuse takes (char *why, size_t cap) and writes one plain sentence.
 *
 * File layout (all names digest-named, write-once, mode 0444, in ONE flat directory per role; the omega writers
 * name records turing.qprofile.<hex>.omg0 and so on):
 *   turing.{qprofile,qworld,qfreeze,qgain}.<hex>.omg0   (omega tyqr writers)
 *   <hex>.qbw            trajectory (QBW1), name = SHA-256 of the file
 *   traj.<hex>.man       brw.traj.v1 sidecar, name = SHA-256 of the file
 *   <hex>.prd            PRD1 file, name = SHA-256 of the file
 *   prd.<hex>.man        brw.prd.v1 sidecar
 *   devman.txt           brw.devman.v1 sidecar (rewritten by `dev`; digested by freeze)
 *   artifact.<hex>.brwdl the discovery artifact copy stored beside a discovery gain
 *   attempt.<artifact8>.<profile8>.<cell>   one-sealed-attempt ledger (O_EXCL) */
#ifndef BRW_PROTOCOL_H
#define BRW_PROTOCOL_H
#include <stddef.h>
#include <stdint.h>
#include "brw_predict.h"
#include "brw_rng.h"
#include "brw_stats.h"
#include "brw_world.h"
#include "turing/ty_prd.h"
#include "turing/ty_qrecord.h"

#define BRW_LM_RULE "brw.lm.brwdl.v0.fitonce"   /* R3-24 U1 */
#define BRW_STOPPED (-120)   /* stop condition hit: the run is STOPPED (plan §19) */
#define BRW_KATFAIL (-121)   /* a known-answer test failed */
#define BRW_BLOCKED (-122)   /* the sandbox tool is absent: BLOCKED, never PASS */
const char *brw_verdict_name(int rc);

#define BRW_WHY 256
#define BRW_PATH 1024

typedef struct { uint8_t *b; size_t n; } brw_bytes;
void brw_bytes_free(brw_bytes *x);

/* ---- build environment bound into the generator digest (plan §9) ---- */
typedef struct {
    char root[BRW_PATH];      /* the checkout root: the directory that holds brownian/src (as in test_brw_world.c) */
    char omega[BRW_PATH];     /* pinned omega checkout */
    char cflags[1024];        /* exact CFLAGS string of the build */
    char cc_line[512];        /* "$(CC)\n<first line of $(CC) --version>" */
} brw_env;
void brw_env_default(brw_env *e);
int  brw_generator_digest_of(const brw_env *e, ty_digest *out);

/* ---- utilities ---- */
int brw_slurp(const char *path, brw_bytes *out);                     /* TYQ_E_IO on failure */
int brw_write_excl(const char *path, const void *b, size_t n);       /* O_CREAT|O_EXCL, 0444; TYQR_E_EXISTS if present */
void brw_sha256(const void *b, size_t n, ty_digest *out);
int brw_dir_of(const char *path, char *dir, size_t cap);
int brw_join(char *out, size_t cap, const char *dir, const char *fmt, ...);

/* ---- cell table (plan §12-§14, §18; spec §6) ---- */
typedef struct {
    brw_cell_spec s;
    uint32_t W, H;                  /* worlds per block, held-out points per world */
    const char *experiment;         /* "EXP-002A" / "EXP-002B" / "EXP-002C"; NULL for hostile cells */
    int hostile;                    /* H- cells: development only, never sealed */
    int descriptive;                /* EXP-002C-INT INT05-d* rows (R3-36 iii): reported, never gated */
} brw_cellinfo;
size_t brw_cellinfo_count(void);
int brw_cellinfo_at(size_t i, brw_cellinfo *o);                      /* byte order of the name */
int brw_cellinfo_get(const char *name, brw_cellinfo *o);
/* brw.cells.v1 sidecar; fields in brw_cell_spec order then `w`, reals as %.17g. */
int brw_cells_sidecar(char *out, size_t cap, size_t *len);

/* opcode from a reference name ("DIFFUSION") or "0x04"; 0 when unknown */
int brw_opcode_of(const char *name);

/* ---- profile and thresholds ---- */
typedef struct { ty_digest spec, packet, thresholds; const char *lm_rule; } brw_profile_in;
int brw_profile_make(const brw_profile_in *in, tyqr_profile *out, char *why, size_t cap);
/* The thresholds sidecar is read from a path and refused (FAIL_PROFILE) if its digest differs from the
 * qprofile `thresholds` attribute or its line format is bad. No band value is compiled into code. */
int brw_thr_check(const tyqr_profile *p, const char *buf, size_t len, char *why, size_t cap);
int brw_thr_file_check(const tyqr_profile *p, const char *path, char *why, size_t cap);
/* the declared baseline opcode of the cell's experiment, parsed from the qprofile `baselines` list; 0 if none */
int brw_declared_baseline(const tyqr_profile *p, const char *experiment);

/* ---- record loaders: file digest (name and content) then field rebuild; TYQ_FAIL_DIGEST on any mismatch ---- */
int brw_load_profile(const char *path, tyqr_profile *r, ty_digest *d, char *why, size_t cap);
int brw_load_world(const char *path, tyqr_world *r, ty_digest *d, char *why, size_t cap);
int brw_load_freeze(const char *path, tyqr_freeze *r, ty_digest *d, char *why, size_t cap);
int brw_load_gain(const char *path, tyqr_gain *r, ty_digest *d, char *why, size_t cap);
/* <dir>/<record>.<hex>.omg0, record = "turing.qworld" and so on */
int brw_record_path(char *out, size_t cap, const char *dir, const char *record, const ty_digest *d);

/* ---- step 2: development worlds (parent brownian.dev.v1) ---- */
int brw_dev_block(const brw_env *env, const char *outdir, const char *cell, uint32_t block,
                  const ty_digest *qprofile, tyqr_world *w, ty_digest *wd, char *why, size_t cap);
/* rewrite <dir>/devman.txt from every dev qworld file in the directory; returns its digest */
int brw_devman_refresh(const char *dir, ty_digest *digest, char *why, size_t cap);
/* qworld(dev) files of a devman sidecar, loaded from the sidecar's directory */
int brw_devman_load(const char *devman_path, tyqr_devline **lines, size_t *n, char *why, size_t cap);

/* ---- step 5: freeze ---- */
/* brw.calib.v1 (R3-24 U6): header line, then `<cell> <stat> <center> <lo> <hi>` lines rendered from the frozen table
 * of brw_stats.c. brw_calib_check refuses (FAIL_PROFILE) any file that is not exactly that rendering. Its SHA-256
 * goes into qfreeze key 13 as `calib=<hex> turing_profile=<hex>` (R3-26 G3). */
int brw_calib_render(char *out, size_t cap, size_t *len);
int brw_calib_check(const char *path, ty_digest *d, char *why, size_t cap);
/* The qfreeze fields the harness cannot derive come from a `key=value` meta file (value = rest of the line):
 * mode artifact_kind b2_emerging_label bayes_plugin_check diag_fw_rate_ppm lengthening_test stability_test run_commit
 * tree_dirty base_commits producer_tool producer_model prompt_digest transcript_digest n_lineage lineage.NN.
 * calibration_extra and artifact_bin are derived and refused in the meta file. */
typedef struct {
    const char *artifact;        /* certification: brw_predict.c; discovery: canonical BRW-DL bytes (U4) */
    const char *qprofile, *devman, *calibration, *meta;
    const char *interp;          /* discovery: the static interpreter executable; artifact_bin = its SHA-256 (U3) */
    const char *turing_profile;  /* 64 hex digits; NULL = 64 zeros until the turing profile digest is provided (G3) */
    const char *outdir;
} brw_freeze_args;
int brw_freeze(const brw_freeze_args *a, tyqr_freeze *f, ty_digest *fd, char *why, size_t cap);

/* ---- steps 6-7: seal ---- */
typedef struct {
    tyqr_profile profile; ty_digest profile_d;
    tyqr_freeze freeze; ty_digest freeze_d;
    uint8_t parent[32];
} brw_seal_ctx;
/* The refusals of spec §11: no qfreeze, artifact digest mismatch, qprofile mismatch, a hostile cell, a dirty tree.
 * The trajectory-exists refusal is O_EXCL inside brw_seal. */
int brw_seal_check(const char *qfreeze_path, const char *artifact_path, const char *cell, brw_seal_ctx *ctx,
                   char *why, size_t cap);
/* seal_check, then the one-attempt ledger (STOPPED on a second attempt), then sealed generation and the sealed
 * qworld. ledger_dir NULL = the directory of the qfreeze. */
int brw_seal(const brw_env *env, const char *qfreeze_path, const char *artifact_path, const char *cell,
             const char *outdir, const char *ledger_dir, tyqr_world *w, ty_digest *wd, char *why, size_t cap);

/* ---- step 8-9: gain computation (the one scoring path: always from PRD1 bytes) ---- */
typedef struct {
    const tyqr_profile *profile; ty_digest profile_d;
    const tyqr_freeze *freeze; ty_digest freeze_d;
    const tyqr_world *world; ty_digest world_d;
    brw_cellinfo ci;
    const brw_traj *tr; size_t W;                 /* the world's trajectories, rep order */
    const brw_prog *pb, *pm;                      /* programs whose canonical bytes are charged */
    int base_op, cand_op;                         /* reference opcode of B; of M (255 = discovery artifact) */
    ty_digest baseline_artifact, candidate;
    ty_digest prdman_b, prdman_m;                 /* brw.prd.v1 sidecar digests */
    const brw_bytes *prd_b, *prd_m;               /* W PRD1 files each */
    const char *ladder_item;                      /* NULL or "-" for the declared baseline */
} brw_gain_in;
int brw_gain_compute(const brw_gain_in *in, tyqr_gain *g, char *why, size_t cap);
/* Leak oracle (spec section 7; hostile #5, #6). Regenerates the true parameters of the W worlds from (label_mode, block, parent),
 * requires the regenerated worlds to equal tr (else TYQ_FAIL_DIGEST), scores the oracle beside the candidate PRD1 files prd_m and
 * bootstraps the summed difference. flag = "0", "1" or "INCONCLUSIVE" (measurement-noise, Student-t and outlier cells).
 * Returns TYQ_FAIL_LEAK iff the 2.5% bound of sum(L oracle - L candidate) is above 0. lo/hi (may be NULL) receive the interval. */
int brw_leak_check(const brw_cellinfo *ci, const char *label_mode, uint64_t block, const uint8_t *parent, size_t plen,
                   const brw_traj *tr, size_t W, const brw_bytes *prd_m, const uint8_t analysis_seed[32], uint32_t B,
                   char flag[16], int64_t *lo, int64_t *hi, char *why, size_t cap);
/* R3-30c: per-world numeric bound in ub for H held-out points: ceil(2 H (0.5 + q) + 1), q = (-log2(1 - 2^-23) + 1e-9) x 1e6 */
int64_t brw_numeric_bound_world_ub(size_t H);
const char *brw_class_label(int64_t t, int64_t lo, int64_t hi);   /* R3-26 G6 */
/* load the trajectories of a world from dir (sidecar and file digests checked); free with brw_world_free */
int brw_world_load(const char *dir, const tyqr_world *w, brw_traj **out, size_t *W, char *why, size_t cap);
void brw_world_free(brw_traj *t, size_t W);
/* PRD1 byte builder for a reference/candidate program on one trajectory (in process, fit once) */
int brw_prd_for_program(const brw_prog *p, const brw_traj *tr, const brw_cell_spec *cs, brw_bytes *out, char *why, size_t cap);   /* per-world split from cs (original-index split on H-missing) */
/* PRD1 files of every world of a set, and the brw.prd.v1 sidecar over them */
int brw_prd_manifest(const brw_bytes *prd, size_t W, brw_bytes *man, ty_digest *man_d);
/* z-scores are not needed here; analysis seed = SHA-256("brownian.v1|analysis|<mode>|<cell>|<block>" || 0 || parent) */
void brw_analysis_seed(const char *mode, const char *cell, uint64_t block, const uint8_t parent[32], uint8_t out[32]);

/* ---- discovery: the candidate is a BRW-DL program run by the evaluator's interpreter inside bwrap ---- */
/* Runs the frozen argv (spec §12, C-1) over brw.line.v1. interp_cmd is a static interpreter executable
 * (build/brw_interp). Returns TYQ_OK and W PRD1 files, TYQ_FAIL_PROTOCOL for any protocol violation (not retried),
 * BRW_BLOCKED when /usr/bin/bwrap cannot be run. stderr_note (may be NULL) receives up to 63 KiB of child stderr. */
int brw_run_discovery(const char *interp_cmd, const char *artifact_path, const brw_traj *tr, size_t W,
                      const brw_cell_spec *cs, brw_bytes *prd_out, char *stderr_note, size_t note_cap, char *why, size_t cap);
/* run any static executable in the same sandbox and line session (hostile sandbox test); prog_path is bound at /prog */
int brw_run_in_sandbox(const char *exe_path, const char *prog_path, const brw_traj *tr, size_t W, const brw_cell_spec *cs,
                       brw_bytes *prd_out, char *stderr_note, size_t note_cap, char *why, size_t cap);
/* the frozen argv text, for the tests and the spec (NULL-terminated) */
const char *const *brw_sandbox_argv(void);

/* ---- packet scanner and allow-list (spec §16; hostile 3, 4) ---- */
int brw_packet_scan(const char *dir, char *why, size_t cap);
/* scan one text buffer for the word list; returns TYQ_FAIL_PROTOCOL on a hit */
int brw_scan_text(const char *buf, size_t len, char *why, size_t cap);
/* seed scan (hostile #5): refuses the text if it holds any of the n secret 32-byte seeds as hex (64 or the first 16 digits),
 * as 0x%016llx state words, or as decimal state words. TYQ_FAIL_PROTOCOL on a hit. */
int brw_seed_scan(const char *buf, size_t len, const uint8_t (*seeds)[32], size_t n, char *why, size_t cap);

/* ---- score / verify / replay ---- */
typedef struct {
    const char *mode;              /* "certification" | "discovery" */
    const char *qfreeze, *qworld;  /* record paths */
    const char *candidate;         /* opcode name (certification) or BRW-DL artifact path (discovery) */
    const char *baseline;          /* opcode name */
    const char *candidate_cmd;     /* discovery: static interpreter executable */
    const char *packet;            /* discovery: packet directory to scan (not bound into the sandbox) */
    const char *predict_src;       /* brw_predict.c path: certification artifact check, baseline artifact digest */
    const char *ladder_item;       /* required when the baseline is not the declared one */
    const char *thresholds;        /* optional sidecar path, refused on a digest mismatch */
    const char *outdir;
} brw_score_args;
int brw_score(const brw_score_args *a, tyqr_gain *g, ty_digest *gd, char *gain_path, size_t path_cap,
              char *why, size_t cap);
/* Rebuilds everything from stored files: record chain and binding, QBW1/PRD1 digests, L(M) from canonical bytes,
 * all gain fields and the bootstrap. TYQ_FAIL_DIGEST on any difference. */
int brw_verify(const char *gain_path, const char *thresholds, const char *predict_src, char *why, size_t cap);
/* verify, then re-run the predictors and compare PRD1 digests; regenerate=1 also regenerates the QBW1 files from
 * the sealed seed and compares them byte for byte. interp_cmd is used to re-run a discovery candidate. */
int brw_replay(const brw_env *env, const char *gain_path, int regenerate, const char *interp_cmd,
               char *why, size_t cap);

/* ---- calibration (pre-seal, development only) ---- */
/* Runs the matching reference over the first `blocks` development blocks of every cell that has a frozen null row
 * and writes <outdir>/calibration.txt with diag_fw_rate_ppm. stop13 = 1 if any cell rejects in >= 5 of 20. */
int brw_calibrate(const char *devman_path, uint32_t blocks, const char *outdir, int *stop13, char *why, size_t cap);

/* kind C re-score (plan §24): reads the stored QBW1 and PRD1 files of a gain and writes <outdir>/rescore.txt with
 * every per-point code length, T, its interval and the classification. Tolerant, unlike brw_verify. */
int brw_rescore(const char *gain_path, const char *outdir, char *why, size_t cap);
/* kind C comparison of two output directories of score/verify runs (plan §24) */
int brw_compare_ub(const char *dir_a, const char *dir_b, char *why, size_t cap);

#endif

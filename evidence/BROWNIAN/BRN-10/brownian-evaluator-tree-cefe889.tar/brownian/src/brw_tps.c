#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "brw_protocol.h"
#include "brw_tps.h"
#include "turing/tc_range.h"
#include "turing/tc_rans.h"

int brw_tps_stream(const tyq_pred *rec, const int64_t *k, size_t n, size_t world, brw_tps_hook hook, void *hctx, brw_tps_arm *a) {
    double *mu = malloc((n ? n : 1) * sizeof *mu), *sd = malloc((n ? n : 1) * sizeof *sd);
    tc_pstream p; tc_symbols s; memset(&p, 0, sizeof p); memset(&s, 0, sizeof s);
    int rc = 0; size_t bad = 0; double dev = 0; uint8_t *ro = NULL, *ao = NULL; size_t rl = 0, al = 0; char why[128];
    if (!mu || !sd) { free(mu); free(sd); return BRW_TPS_E_ARG; }
    for (size_t i = 0; i < n; i++) { mu[i] = rec[i].loc; sd[i] = rec[i].scale; }
    for (size_t i = 0; i < n; i++) {   /* TPS1 verified range (v1.3 A3.6): skip a world holding an observation above 2^20 qint bits */
        double qb = 0; int fh = 0;
        if (ty_qcont_bits(&rec[i], k[i], &qb, &fh) == 0 && qb > BRW_TPS_RANGE_BITS) {
            free(mu); free(sd); a->state = BRW_TPS_OUT_OF_RANGE; a->bad_world = world; a->bad_index = i; return 0;
        }
    }
    rc = brw_tps_build(mu, sd, k, n, hook, hctx, &p, &s, &bad, &dev);
    free(mu); free(sd);
    if (rc == BRW_TPS_E_PROOF) { a->bad_world = world; a->bad_index = bad; a->state = BRW_TPS_GATE_FAIL; a->code = rc; return rc; }
    if (rc != 0) { a->code = rc; return rc; }
    if (dev > a->max_dev_exact) a->max_dev_exact = dev;
    int64_t ub = 0;
    if (tc_ideal_ub(&p, &s, 0, p.n, &ub) != 0) rc = BRW_TPS_E_CODER;
    else if (tc_range_encode(&p, &s, &ro, &rl, why, sizeof why) != 0 || tc_rans_encode(&p, &s, &ao, &al, why, sizeof why) != 0) rc = BRW_TPS_E_CODER;
    else {
        a->n_obs += n; a->n_steps += p.n; a->ideal_ub += ub;
        a->range_bytes += rl - TC_CODED_HEADER; a->rans_bytes += al - TC_CODED_HEADER;
        a->state = BRW_TPS_PASS;
    }
    free(ro); free(ao); tc_ps_free(&p); tc_sy_free(&s);
    if (rc) a->code = rc;
    return rc;
}

void brw_tps_fold(brw_tps_arm *a, const brw_tps_arm *w, size_t world) {
    if (w->state == BRW_TPS_OUT_OF_RANGE) {   /* GATE_FAIL beats OUT_OF_RANGE beats PASS; a skipped world adds nothing */
        if (a->state != BRW_TPS_GATE_FAIL && a->state != BRW_TPS_OUT_OF_RANGE) { a->state = BRW_TPS_OUT_OF_RANGE; a->bad_world = world; a->bad_index = w->bad_index; }
        return;
    }
    if (w->state == BRW_TPS_GATE_FAIL) {
        if (a->state != BRW_TPS_GATE_FAIL) { a->state = BRW_TPS_GATE_FAIL; a->code = w->code; a->bad_world = world; a->bad_index = w->bad_index; }
        return;
    }
    if (w->code && !a->code) a->code = w->code;
    a->n_obs += w->n_obs; a->n_steps += w->n_steps; a->ideal_ub += w->ideal_ub;
    a->range_bytes += w->range_bytes; a->rans_bytes += w->rans_bytes;
    if (w->max_dev_exact > a->max_dev_exact) a->max_dev_exact = w->max_dev_exact;
}

/* ---- sidecar: tps.<qgain digest>.txt beside the qgain (brw.tps.v1). Not a Turing record; the qgain bytes never change. ---- */
static void sidecar_path(char *out, size_t cap, const char *gain_path, const ty_digest *gd) {
    char dir[BRW_PATH], h[65]; brw_dir_of(gain_path, dir, sizeof dir); ty_hex(gd, h);
    brw_join(out, cap, dir, "tps.%s.txt", h);
}
int brw_tps_render(const tyqr_gain *g, const ty_digest *gd, const brw_tps_gain_res *r, char *out, size_t cap) {
    char h[65], hb[65], hm[65]; ty_hex(gd, h); ty_hex(&g->prd_b, hb); ty_hex(&g->prd_m, hm);
    int o = snprintf(out, cap, "brw.tps.v1\ngain %s\nprd_b %s\nprd_m %s\nstate %d\n", h, hb, hm, r->state);
    for (int m = 0; m < 2 && o > 0 && (size_t)o < cap; m++) {
        const brw_tps_arm *a = &r->arm[m];
        o += snprintf(out + o, cap - (size_t)o, "%s %d %llu %llu %lld %llu %llu %.17g %zu %zu %d\n", m ? "M" : "B", a->state, (unsigned long long)a->n_obs,
                      (unsigned long long)a->n_steps, (long long)a->ideal_ub, (unsigned long long)a->range_bytes, (unsigned long long)a->rans_bytes,
                      a->max_dev_exact, a->bad_world, a->bad_index, a->code);
    }
    return (o > 0 && (size_t)o < cap) ? o : -1;
}
int brw_tps_sidecar_write(const char *gain_path, const tyqr_gain *g, const ty_digest *gd, const brw_tps_gain_res *r, char *path, size_t pcap) {
    char p[BRW_PATH], buf[1024]; sidecar_path(p, sizeof p, gain_path, gd);
    int n = brw_tps_render(g, gd, r, buf, sizeof buf);
    if (n < 0) return TYQ_E_IO;
    if (path) snprintf(path, pcap, "%s", p);
    int w = brw_write_excl(p, buf, (size_t)n);
    if (w == 0) return 0;
    brw_bytes ex;   /* exists: accept only identical bytes (the computation is deterministic) */
    if (brw_slurp(p, &ex) != 0) return TYQ_E_IO;
    int same = ex.n == (size_t)n && memcmp(ex.b, buf, (size_t)n) == 0;
    brw_bytes_free(&ex);
    return same ? 0 : TYQ_FAIL_DIGEST;
}
/* Reads the sidecar of one qgain into *r. Absent, malformed or bound to other PRD1 digests: state NOT_EVALUATED and r->why says so. */
void brw_tps_sidecar_read(const char *gain_path, const tyqr_gain *g, const ty_digest *gd, brw_tps_gain_res *r) {
    char p[BRW_PATH]; brw_bytes b; memset(r, 0, sizeof *r); sidecar_path(p, sizeof p, gain_path, gd);
    if (brw_slurp(p, &b) != 0) { snprintf(r->why, sizeof r->why, "no TPS1 sidecar (run `brownian_bench tps --qgain <qgain> --write`)"); return; }
    char *t = malloc(b.n + 1);
    if (!t) { brw_bytes_free(&b); snprintf(r->why, sizeof r->why, "out of memory"); return; }
    memcpy(t, b.b, b.n); t[b.n] = 0; brw_bytes_free(&b);
    char h[65], hb[65], hm[65], eh[65], ehb[65], ehm[65]; ty_hex(gd, eh); ty_hex(&g->prd_b, ehb); ty_hex(&g->prd_m, ehm);
    int st = -1, off = 0, ok = 0;
    if (sscanf(t, "brw.tps.v1\ngain %64s\nprd_b %64s\nprd_m %64s\nstate %d\n%n", h, hb, hm, &st, &off) == 4 && off > 0 && !strcmp(h, eh) && !strcmp(hb, ehb) && !strcmp(hm, ehm)) {
        ok = 1;
        const char *q = t + off;
        for (int m = 0; m < 2 && ok; m++) {
            brw_tps_arm *a = &r->arm[m]; char tag; unsigned long long no, ns, rb, ab; long long ub; double dev; size_t bw, bi; int as, code, used = 0;
            if (sscanf(q, "%c %d %llu %llu %lld %llu %llu %lg %zu %zu %d\n%n", &tag, &as, &no, &ns, &ub, &rb, &ab, &dev, &bw, &bi, &code, &used) != 11 || tag != (m ? 'M' : 'B') || used <= 0) { ok = 0; break; }
            a->state = as; a->n_obs = no; a->n_steps = ns; a->ideal_ub = ub; a->range_bytes = rb; a->rans_bytes = ab; a->max_dev_exact = dev; a->bad_world = bw; a->bad_index = bi; a->code = code;
            q += used;
        }
        if (ok && (*q || q == t || q[-1] != '\n')) ok = 0;   /* trailing garbage, or a cut-off last line */
    }
    free(t);
    if (!ok || (st != BRW_TPS_PASS && st != BRW_TPS_GATE_FAIL && st != BRW_TPS_OUT_OF_RANGE && st != BRW_TPS_NOT_EVALUATED)) { memset(r, 0, sizeof *r); snprintf(r->why, sizeof r->why, "the TPS1 sidecar is malformed or names other digests"); return; }
    r->state = st;
    if (st == BRW_TPS_NOT_EVALUATED) snprintf(r->why, sizeof r->why, "the TPS1 sidecar records an adapter refusal (code %d)", r->arm[0].code ? r->arm[0].code : r->arm[1].code);
}

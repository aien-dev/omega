/* brw_predict.c: certification reference predictors and scorer glue. See brw_predict.h.
 * The reference programs are the canonical bytes of brownian/design/ref_programs (the .brwdl files) as assembled by the
 * BRW-DL assembler (design/brw_dl info); the test re-assembles the .brwdl sources and compares.
 * Certification artifact: the SHA-256 of THIS file's bytes at the freeze commit (plan §11 qfreeze B3). */
#include "brw_predict.h"
#include "turing/ty_math.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const uint8_t PROG_iid[] = {
    0x00,0x10,0x60,0x01,0x54,0x56,0x33,0x90,0x60,0x05,0x54,0x80,0x31,0x40,0x32,0x56,
    0x33,0x91,0x04,0x80,0x81,0x37,0xe0
};
static const uint8_t PROG_linear_trend[] = {
    0x02,0x01,0x01,0x05,0x50,0x80,0x31,0x81,0x33,0x10,0x60,0x01,0x50,0x56,0x33,0x90,
    0x59,0x58,0x31,0x02,0x33,0x91,0x65,0x02,0x00,0x01,0x0a,0xa0,0x82,0x32,0xa1,0x83,
    0x32,0x30,0x84,0x37,0xe0
};
static const uint8_t PROG_cubic_trend[] = {
    0x04,0x01,0x01,0x05,0x50,0x80,0x31,0x81,0x33,0x03,0xa1,0x40,0x32,0x03,0xa2,0xa1,
    0x32,0x12,0x60,0x01,0x50,0x56,0x33,0x90,0x59,0x58,0x31,0x02,0x33,0x91,0x67,0x02,
    0x00,0x01,0x02,0x03,0x12,0xa0,0x82,0x32,0xa1,0x83,0x32,0x30,0xa2,0x84,0x32,0x30,
    0xa3,0x85,0x32,0x30,0x86,0x37,0xe0
};
static const uint8_t PROG_diffusion[] = {
    0x00,0x0c,0x61,0x07,0x54,0x55,0x31,0x40,0x32,0x51,0x33,0x57,0x33,0x90,0x06,0x55,
    0x80,0x51,0x32,0x37,0xe0
};
static const uint8_t PROG_diffusion_drift[] = {
    0x00,0x18,0x5b,0x5a,0x31,0x59,0x58,0x31,0x33,0x90,0x61,0x0b,0x54,0x55,0x31,0x80,
    0x51,0x32,0x31,0x40,0x32,0x51,0x33,0x57,0x33,0x91,0x0a,0x55,0x80,0x51,0x32,0x30,
    0x81,0x51,0x32,0x37,0xe0
};
static const uint8_t PROG_mean_revert_exact[] = {
    0x00,0x43,0x61,0x03,0x54,0x55,0x32,0x61,0x03,0x55,0x40,0x32,0x33,0x23,0x2b,0x87,
    0x16,0xd9,0xce,0xf7,0xef,0x3f,0x3a,0x01,0x22,0x00,0x00,0x7a,0x44,0x33,0x3b,0x36,
    0x34,0x59,0x58,0x31,0x57,0x33,0x33,0x90,0x61,0x18,0x54,0x80,0x51,0x32,0x34,0x35,
    0x55,0x32,0x31,0x40,0x32,0x80,0x51,0x32,0x02,0x32,0x34,0x38,0x34,0x02,0x80,0x32,
    0x33,0x33,0x57,0x33,0x91,0x17,0x80,0x51,0x32,0x34,0x35,0x55,0x32,0x81,0x80,0x51,
    0x32,0x02,0x32,0x34,0x38,0x34,0x32,0x02,0x80,0x32,0x33,0x37,0xe0
};
static const uint8_t PROG_lookup_floor[] = {
    0x00,0x00,0x07,0x55,0x22,0x00,0x00,0x80,0x3a,0xe0
};

static const brw_ref REFS[7] = {
    { BRW_OP_IID,          "IID_NORMAL",      PROG_iid,               23, 2 },
    { BRW_OP_LINEAR_TREND, "LINEAR_TREND",    PROG_linear_trend,      37, 3 },
    { BRW_OP_CUBIC_TREND,  "CUBIC_TREND",     PROG_cubic_trend,       55, 5 },
    { BRW_OP_DIFFUSION,    "DIFFUSION",       PROG_diffusion,         21, 1 },
    { BRW_OP_DIFF_DRIFT,   "DIFFUSION_DRIFT", PROG_diffusion_drift,   37, 2 },
    { BRW_OP_MEAN_REVERT,  "MEAN_REVERT",     PROG_mean_revert_exact, 93, 2 },
    { BRW_OP_LOOKUP_FLOOR, "LOOKUP_FLOOR",    PROG_lookup_floor,      10, 0 },
};

/* Hostile variant, not an opcode (spec section 6 line 310, section 13 item 9): h = 1 DIFFUSION. Source design/ref_programs/diffusion_h1.brwdl.
 * The checker measures 17 bytes, k = 1; the spec CHARGES it parent bytes + 1 = 22 (design check R2 records "22 B by plan rule (actually 17 B)"). */
static const uint8_t PROG_diffusion_h1[] = {
    0x00,0x0a,0x61,0x05,0x54,0x55,0x31,0x40,0x32,0x57,0x33,0x90,0x04,0x55,0x80,0x37,0xe0
};
static const brw_variant VAR_H1 = { "DIFFUSION_H1", PROG_diffusion_h1, 17, 22, 1, BRW_OP_DIFFUSION };
const brw_variant *brw_variant_h1(void) { return &VAR_H1; }

const brw_ref *brw_ref_get(int opcode) {
    return (opcode >= 1 && opcode <= 7) ? &REFS[opcode - 1] : NULL;
}

int brw_prog_from_bytes(const uint8_t *bytes, int n, brw_prog *out, char *err, size_t errcap) {
    char local[128];
    if (!err || errcap == 0) { err = local; errcap = sizeof local; }
    err[0] = 0;
    if (!bytes || !out || n <= 0 || n > BRW_MAXBYTES) return TYQ_E_ARG;
    memset(out, 0, sizeof *out);
    memcpy(out->bytes, bytes, (size_t)n);
    out->n = n;
    if (brwdl_check(out->bytes, n, &out->info, err, (int)errcap)) return TYQ_FAIL_PROTOCOL;
    return TYQ_OK;
}

int brw_ref_program(int opcode, brw_prog *out) {
    const brw_ref *r = brw_ref_get(opcode);
    if (!r || !out) return TYQ_E_ARG;
    int s = brw_prog_from_bytes(r->bytes, r->nbytes, out, NULL, 0);
    if (s != TYQ_OK) return s;
    if (out->info.bytes != r->nbytes || out->info.k != r->k) return TYQ_FAIL_PROTOCOL;
    return TYQ_OK;
}

uint64_t brw_memorizer_charged_bits(size_t n_pairs) { return (uint64_t)BRW_MEMO_PAIR_BITS * (uint64_t)n_pairs; }

int brw_memorizer_build(const double *t, const double *y, size_t n, brw_prog *out) {
    if (!t || !y || !out || n < 1 || n > 100) return TYQ_E_ARG;
    for (size_t i = 0; i < n; i++) if (!isfinite(t[i]) || !isfinite(y[i])) return TYQ_E_ARG;
    size_t cap = 256 + n * 160;
    char *txt = malloc(cap);
    if (!txt) return TYQ_E_ARG;
    size_t o = 0;
    o += (size_t)snprintf(txt + o, cap - o, "fit { }\npredict {\n  prevobs\n");
    for (size_t i = 0; i < n; i++)
        o += (size_t)snprintf(txt + o, cap - o, "  %.17g swap now %.17g sub abs 0 le sel\n", y[i], t[i]);
    o += (size_t)snprintf(txt + o, cap - o, "  0.0009765625 1 0\n");
    for (size_t i = 0; i < n; i++)
        o += (size_t)snprintf(txt + o, cap - o, "  now %.17g sub abs 0 le add\n", t[i]);
    snprintf(txt + o, cap - o, "  sel\n  emit_normal\n}\n");
    uint8_t code[BRW_MAXBYTES + 16]; int nb = 0; char err[128];
    int rc = brwdl_assemble(txt, code, &nb, err, (int)sizeof err);
    free(txt);
    if (rc || nb <= 0 || nb > BRW_MAXBYTES) return TYQ_FAIL_PROTOCOL;
    return brw_prog_from_bytes(code, nb, out, NULL, 0);
}

/* Shared argument checks for both modes. Nothing here looks at held-out values beyond finiteness. */
static int check_series(const brw_prog *p, const double *t, const double *y, size_t N, size_t S) {
    if (!p || !t || !y || p->n <= 0) return TYQ_E_ARG;
    if (S == 0 || N <= S || N > BRW_MAXPOINTS) return TYQ_E_ARG;
    for (size_t i = 0; i < N; i++) {
        if (!isfinite(t[i]) || !isfinite(y[i])) return TYQ_E_ARG;
        if (i > 0 && !(t[i] > t[i - 1])) return TYQ_E_ARG;
    }
    return TYQ_OK;
}

static int pred_ok(double loc, double scale) { return isfinite(loc) && isfinite(scale) && scale > 0.0; }

int brw_predict_fit_once(const brw_prog *p, const double *t, const double *y, size_t N, size_t S,
                         tyq_pred *out, const char **why) {
    const char *w = "";
    if (!why) why = &w;
    *why = "";
    int s = check_series(p, t, y, N, S);
    if (s != TYQ_OK || !out) { *why = "bad argument"; return TYQ_E_ARG; }
    size_t H = N - S;
    double *loc = malloc(H * sizeof(double)), *sc = malloc(H * sizeof(double));
    if (!loc || !sc) { free(loc); free(sc); *why = "alloc"; return TYQ_E_ARG; }
    int rc = brwdl_run(p->bytes, &p->info, t, y, (int)N, (int)S, loc, sc, why);
    s = TYQ_OK;
    if (rc) s = TYQ_FAIL_PROTOCOL;
    else for (size_t i = 0; i < H; i++) {
        if (!pred_ok(loc[i], sc[i])) { *why = "non-finite location or scale not > 0"; s = TYQ_FAIL_PROTOCOL; break; }
        memset(&out[i], 0, sizeof out[i]);
        out[i].index = (uint32_t)(S + i); out[i].family = TYQ_FAM_GAUSS;
        out[i].loc = loc[i]; out[i].scale = sc[i];
    }
    free(loc); free(sc);
    return s;
}

int brw_predict_prequential(const brw_prog *p, const double *t, const double *y, size_t N, size_t S,
                            tyq_pred *out, const char **why) {
    const char *w = "";
    if (!why) why = &w;
    *why = "";
    int s = check_series(p, t, y, N, S);
    if (s != TYQ_OK || !out) { *why = "bad argument"; return TYQ_E_ARG; }
    for (size_t i = S; i < N; i++) {
        double loc = 0, sc = 0;
        /* refit on points 0..i-1 only; index i is predicted with y_{i-1} revealed */
        if (brwdl_run(p->bytes, &p->info, t, y, (int)(i + 1), (int)i, &loc, &sc, why)) return TYQ_FAIL_PROTOCOL;
        if (!pred_ok(loc, sc)) { *why = "non-finite location or scale not > 0"; return TYQ_FAIL_PROTOCOL; }
        tyq_pred *o = &out[i - S];
        memset(o, 0, sizeof *o);
        o->index = (uint32_t)i; o->family = TYQ_FAM_GAUSS; o->loc = loc; o->scale = sc;
    }
    return TYQ_OK;
}

int brw_score_world(const brw_prog *p, const brw_traj *tr, uint32_t split, brw_mode mode, brw_world_score *out) {
    if (!p || !tr || !out || !tr->t || !tr->k || split == 0 || tr->count <= split || tr->count > BRW_MAXPOINTS)
        return TYQ_E_ARG;
    if (mode != BRW_MODE_FIT_ONCE && mode != BRW_MODE_PREQUENTIAL) return TYQ_E_ARG;
    size_t N = (size_t)tr->count, S = split, H = N - S;
    double *y = malloc(N * sizeof(double));
    tyq_pred *pr = malloc(H * sizeof(tyq_pred));
    if (!y || !pr) { free(y); free(pr); return TYQ_E_ARG; }
    int s = TYQ_OK;
    for (size_t i = 0; i < N; i++) y[i] = brw_symbol_value(tr->k[i]);
    const char *why = "";
    s = mode == BRW_MODE_FIT_ONCE ? brw_predict_fit_once(p, tr->t, y, N, S, pr, &why)
                                  : brw_predict_prequential(p, tr->t, y, N, S, pr, &why);
    if (s == TYQ_OK) {
        int64_t ub = 0; uint64_t fh = 0;
        s = ty_qcont_sum_ub(pr, tr->k + S, H, &ub, &fh);
        if (s == TYQ_OK) {
            int64_t rider = 0;
            if (mode == BRW_MODE_FIT_ONCE) s = ty_qcont_rider_ub((uint32_t)p->info.k, (uint32_t)(S - 1), &rider);
            if (s == TYQ_OK) { out->data_ub = ub; out->rider_ub = rider; out->floor_hits = fh; out->scored = H; }
        }
    }
    free(y); free(pr);
    return s;
}

int brw_cell_dl_init_bits(brw_cell_dl *c, uint64_t model_bits, uint32_t k) {
    if (!c) return TYQ_E_ARG;
    memset(c, 0, sizeof *c);
    c->model_bits = model_bits; c->k = k;
    return ty_bits_to_ub(model_bits, &c->bytes_ub) == TY_OK ? TYQ_OK : TYQ_FAIL_PROTOCOL;
}

int brw_cell_dl_init(brw_cell_dl *c, const brw_prog *p) {
    if (!c || !p || p->n <= 0) return TYQ_E_ARG;
    int s = brw_cell_dl_init_bits(c, 8u * (uint64_t)p->n, (uint32_t)p->info.k);
    if (s == TYQ_OK) s = ty_qcont_bytes_ub((uint32_t)p->n, &c->bytes_ub);   /* 8e6 * bytes, once per cell */
    return s;
}

int brw_cell_dl_add(brw_cell_dl *c, const brw_world_score *w) {
    if (!c || !w) return TYQ_E_ARG;
    int64_t r, d;
    if (ty_add(c->rider_ub, w->rider_ub, &r) || ty_add(c->data_ub, w->data_ub, &d)) return TYQ_FAIL_PROTOCOL;
    c->rider_ub = r; c->data_ub = d; c->worlds++; c->floor_hits += w->floor_hits; c->scored += w->scored;
    return TYQ_OK;
}

int brw_cell_dl_total(const brw_cell_dl *c, int64_t *dl_ub) {
    int64_t a;
    if (!c || !dl_ub) return TYQ_E_ARG;
    if (ty_add(c->bytes_ub, c->rider_ub, &a) || ty_add(a, c->data_ub, dl_ub)) return TYQ_FAIL_PROTOCOL;
    return TYQ_OK;
}

int brw_cell_gain(const brw_cell_dl *baseline, const brw_cell_dl *model, int64_t *t_ub) {
    int64_t b, m;
    if (!t_ub) return TYQ_E_ARG;
    int s = brw_cell_dl_total(baseline, &b);
    if (s == TYQ_OK) s = brw_cell_dl_total(model, &m);
    if (s != TYQ_OK) return s;
    return ty_gain(b, m, t_ub) == TY_OK ? TYQ_OK : TYQ_FAIL_PROTOCOL;
}

int brw_predict_artifact_digest(const char *path, char hex[65]) {
    if (!path || !hex) return TYQ_E_ARG;
    FILE *f = fopen(path, "rb");
    if (!f) return TYQ_E_IO;
    size_t cap = 1 << 16, n = 0;
    uint8_t *buf = malloc(cap);
    if (!buf) { fclose(f); return TYQ_E_IO; }
    for (;;) {
        if (n == cap) { cap *= 2; uint8_t *nb = realloc(buf, cap); if (!nb) { free(buf); fclose(f); return TYQ_E_IO; } buf = nb; }
        size_t r = fread(buf + n, 1, cap - n, f);
        if (r == 0) break;
        n += r;
    }
    int bad = ferror(f);
    fclose(f);
    if (bad) { free(buf); return TYQ_E_IO; }
    brwdl_sha256(buf, n, hex);
    free(buf);
    return TYQ_OK;
}

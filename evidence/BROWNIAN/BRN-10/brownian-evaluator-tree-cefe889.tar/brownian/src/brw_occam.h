/* brw_occam.h: the Occam curve (spec v1.3 Amendment 3, A3.4; Section 14 deliverable). Descriptive only: never a verdict item.
 * Points come from the qgains of DIFFUSION_DRIFT against DIFFUSION on the OCC-* cells. Private, sealed. C only.
 * ratio = |mu| / sqrt(2D) with mu = s * sqrt(2D / T_ref), T_ref = 255 (brw_world.c, BRW_B1_TFULL): D cancels, so
 * ratio = |s| / sqrt(255), computed from the cell's stored generator parameter snr_s. */
#ifndef BRW_OCCAM_H
#define BRW_OCCAM_H
#include <stddef.h>
#include <stdint.h>
#include "brw_protocol.h"

#define BRW_OCC_MAXPTS 16          /* |s| grid points per side (s = 0 counted on both sides) */
#define BRW_OCC_NHS 4
typedef struct { double s, ratio; int64_t t, lo, hi; ty_digest gain; } brw_occ_pt;   /* t, lo, hi in micro-bits (T of DIFFUSION_DRIFT vs DIFFUSION, its world-bootstrap interval) */

typedef struct {
    uint32_t H; int sign;                    /* +1 or -1 */
    brw_occ_pt pt[BRW_OCC_MAXPTS]; size_t n; /* |s| ascending, s = 0 shared */
    int has_cross; double cross_s;           /* first adjacent pair with dT(s_i) <= 0 < dT(s_i+1); |s| where the straight line is 0 */
    int nonmono; size_t changes;             /* number of <=0 / >0 transitions between adjacent points; > 1 flags non-monotone */
    int has_lo_end; double lo_end;           /* smallest |s| whose dT upper end is >= 0; else "beyond grid" */
    int has_hi_end; double hi_end;           /* smallest |s| whose dT lower end is > 0; else "beyond grid" */
    int have_cross_ref; double cross_ref;    /* occ_cross of brw.calib.v1 for this H */
    int inside;                              /* 1 inside, 0 outside (valid when have_cross_ref) */
} brw_occ_curve;

/* Pure analysis of curve->pt[0..n) (already sorted by |s| ascending). Fills every field after `pt`/`n`. */
void brw_occ_analyze(brw_occ_curve *c);
/* occ_cross of each H from brw.calib.v1 text (lines `occ_cross <H> <real>`); have[i] for H = 128, 256, 512, 1024. 0 or -1 with why. */
int brw_occ_parse_calib(const char *text, double cross[BRW_OCC_NHS], int have[BRW_OCC_NHS], char *why, size_t cap);
/* Builds the 8 curves (H 128, 256, 512, 1024 x sign +, -; index 2*h + (sign < 0)) from the gains of DIFFUSION_DRIFT against DIFFUSION
 * on OCC-* cells (gains of other cells, candidates or baselines are ignored; STOPPED gains are skipped). cross/have may be NULL.
 * Returns the number of OCC points used (0 = no OCC qgain, curves untouched) or -1 with why (two different gains for one cell). */
int brw_occ_build(const tyqr_gain *g, const ty_digest *gd, size_t ng, const double *cross, const int *have, brw_occ_curve curves[2 * BRW_OCC_NHS], char *why, size_t cap);
/* Deterministic text (brw.occam.v1), reals %.17g. Returns the length, or -1 on overflow. */
int brw_occ_render(const brw_occ_curve curves[2 * BRW_OCC_NHS], const char *modes, char *out, size_t cap);
/* "%.17g" of dT etc. in bits: micro-bits / 1e6 */
double brw_occ_bits(int64_t ub);
/* the `brownian_bench occam` body: reads the qgains of every directory (digest-checked), prints the text and writes it to `out` (if not NULL). 0 or a TYQ_* refusal. */
int brw_occ_run(const char *const *dirs, size_t nd, const char *calib, const char *out, char *why, size_t cap);
#endif

#include "brw_qbw.h"
#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define QBW_HDR 16u
#define QBW_REC 16u

static void put_u32(uint8_t *p, uint32_t v) { for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static void put_u64(uint8_t *p, uint64_t v) { for (int i = 0; i < 8; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static uint32_t get_u32(const uint8_t *p) { uint32_t v = 0; for (int i = 3; i >= 0; i--) v = (v << 8) | p[i]; return v; }
static uint64_t get_u64(const uint8_t *p) { uint64_t v = 0; for (int i = 7; i >= 0; i--) v = (v << 8) | p[i]; return v; }

int brw_qbw_encode(const brw_traj *t, uint8_t **buf, size_t *len) {
    size_t total;
    uint8_t *b;
    if (!t || !buf || !len || (t->count && (!t->t || !t->k))) return BRW_E_ARG;
    if (t->count > (SIZE_MAX - QBW_HDR) / QBW_REC) return BRW_E_ARG;
    total = QBW_HDR + QBW_REC * (size_t)t->count;
    b = malloc(total);
    if (!b) return BRW_E_IO;
    memcpy(b, "QBW1", 4);
    put_u32(b + 4, 1);
    put_u64(b + 8, t->count);
    for (uint64_t i = 0; i < t->count; i++) {
        uint64_t bits;
        memcpy(&bits, &t->t[i], 8);
        put_u64(b + QBW_HDR + QBW_REC * i, bits);
        put_u64(b + QBW_HDR + QBW_REC * i + 8, (uint64_t)t->k[i]);
    }
    *buf = b; *len = total;
    return BRW_OK;
}

int brw_qbw_decode(const uint8_t *buf, size_t len, brw_traj *out) {
    uint64_t count;
    if (!buf || !out) return BRW_E_ARG;
    out->count = 0; out->t = NULL; out->k = NULL;
    if (len < QBW_HDR || memcmp(buf, "QBW1", 4) != 0) return BRW_E_PROTOCOL;
    if (get_u32(buf + 4) != 1) return BRW_E_PROTOCOL;
    count = get_u64(buf + 8);
    if (count > (SIZE_MAX - QBW_HDR) / QBW_REC || len != QBW_HDR + QBW_REC * (size_t)count)
        return BRW_E_PROTOCOL;
    out->t = malloc((count ? count : 1) * sizeof *out->t);
    out->k = malloc((count ? count : 1) * sizeof *out->k);
    if (!out->t || !out->k) { brw_traj_free(out); return BRW_E_IO; }
    for (uint64_t i = 0; i < count; i++) {
        uint64_t bits = get_u64(buf + QBW_HDR + QBW_REC * i);
        double tv;
        memcpy(&tv, &bits, 8);
        if (!isfinite(tv) || (i > 0 && !(tv > out->t[i - 1]))) { brw_traj_free(out); return BRW_E_PROTOCOL; }
        out->t[i] = tv;
        out->k[i] = (int64_t)get_u64(buf + QBW_HDR + QBW_REC * i + 8);
    }
    out->count = count;
    return BRW_OK;
}

int brw_qbw_write_excl(const char *path, const brw_traj *t) {
    uint8_t *b = NULL;
    size_t len, off = 0;
    int fd, rc;
    if (!path) return BRW_E_ARG;
    if ((rc = brw_qbw_encode(t, &b, &len)) != BRW_OK) return rc;
    fd = open(path, O_WRONLY | O_CREAT | O_EXCL, 0444);
    if (fd < 0) { free(b); return BRW_E_IO; }
    while (off < len) {
        ssize_t w = write(fd, b + off, len - off);
        if (w <= 0) { close(fd); unlink(path); free(b); return BRW_E_IO; }
        off += (size_t)w;
    }
    if (close(fd) != 0) { unlink(path); free(b); return BRW_E_IO; }
    free(b);
    return BRW_OK;
}

int brw_qbw_read(const char *path, brw_traj *out) {
    FILE *f;
    uint8_t *b = NULL;
    long sz;
    int rc;
    if (!path || !out) return BRW_E_ARG;
    f = fopen(path, "rb");
    if (!f) return BRW_E_IO;
    if (fseek(f, 0, SEEK_END) != 0 || (sz = ftell(f)) < 0 || fseek(f, 0, SEEK_SET) != 0) { fclose(f); return BRW_E_IO; }
    b = malloc(sz ? (size_t)sz : 1);
    if (!b) { fclose(f); return BRW_E_IO; }
    if (fread(b, 1, (size_t)sz, f) != (size_t)sz) { fclose(f); free(b); return BRW_E_IO; }
    fclose(f);
    rc = brw_qbw_decode(b, (size_t)sz, out);
    free(b);
    return rc;
}

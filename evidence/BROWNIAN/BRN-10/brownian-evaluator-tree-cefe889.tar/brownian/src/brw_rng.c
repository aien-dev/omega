#include "brw_rng.h"
#include "sha256.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *const k_streams[] = {
    "param", "latent", "meas", "missing", "outlier",
    "policy-random", "eig-mc", "bootstrap", "search"
};

void brw_stream_digest(const uint8_t *seed, size_t seed_len, const char *name, uint8_t out[32]) {
    sha256_ctx c;
    const uint8_t z = 0;
    sha256_init(&c);
    if (seed_len) sha256_update(&c, seed, seed_len);
    sha256_update(&c, &z, 1);
    sha256_update(&c, (const uint8_t *)name, strlen(name));
    sha256_final(&c, out);
}

int brw_world_seed(const char *label, const uint8_t *parent, size_t parent_len,
                   uint64_t rep, uint8_t out[32]) {
    sha256_ctx c;
    const uint8_t z = 0;
    uint8_t r[8];
    if (!label || !out || (!parent && parent_len)) return BRW_E_ARG;
    for (int i = 0; i < 8; i++) r[i] = (uint8_t)(rep >> (8 * i));
    sha256_init(&c);
    sha256_update(&c, (const uint8_t *)label, strlen(label));
    sha256_update(&c, &z, 1);
    if (parent_len) sha256_update(&c, parent, parent_len);
    sha256_update(&c, r, 8);
    sha256_final(&c, out);
    return BRW_OK;
}

int brw_world_label(const char *mode, const char *cell, uint64_t block, char *buf, size_t cap) {
    int n;
    if (!mode || !cell || !buf) return BRW_E_ARG;
    if (strcmp(mode, "dev") != 0 && strcmp(mode, "seal") != 0) return BRW_E_ARG;
    n = snprintf(buf, cap, "brownian.v1|%s|%s|%llu", mode, cell, (unsigned long long)block);
    return (n > 0 && (size_t)n < cap) ? BRW_OK : BRW_E_ARG;
}

void brw_rng_from_digest(ClRng *r, const uint8_t d[32]) {
    for (int w = 0; w < 4; w++) {
        uint64_t v = 0;
        for (int b = 7; b >= 0; b--) v = (v << 8) | d[8 * w + b];
        r->s[w] = v;
    }
    if (!(r->s[0] | r->s[1] | r->s[2] | r->s[3])) r->s[0] = 1;
}

int brw_stream_init(ClRng *r, const uint8_t world_seed[32], const char *name) {
    uint8_t d[32];
    int ok = 0;
    if (!r || !world_seed || !name) return BRW_E_ARG;
    for (size_t i = 0; i < sizeof k_streams / sizeof k_streams[0]; i++)
        if (strcmp(name, k_streams[i]) == 0) ok = 1;
    if (!ok) return BRW_E_ARG;
    brw_stream_digest(world_seed, 32, name, d);
    brw_rng_from_digest(r, d);
    return BRW_OK;
}

/* The plan formula ((double)m + 0.5) / 2^53 rounds to exactly 1.0 when m = 2^53 - 1 (m + 0.5 is not
 * representable, ties-to-even goes up). That would break "strictly inside (0,1)" (and give an
 * infinite normal), so that single word is clamped to the largest double below 1. Every other
 * word follows the plan formula exactly (KAT 1 unaffected). */
double brw_uniform_from_word(uint64_t w) {
    double u = ((double)(w >> 11) + 0.5) / 9007199254740992.0;
    return u < 1.0 ? u : 1.0 - 0x1p-53;
}

double brw_uniform(ClRng *r) { return brw_uniform_from_word(cl_rng_next(r)); }

void brw_sealed_parent(const uint8_t qfreeze_digest[32], uint8_t out[32]) {
    sha256_ctx c;
    const uint8_t z = 0;
    sha256_init(&c);
    sha256_update(&c, (const uint8_t *)BRW_SEAL_DOMAIN, strlen(BRW_SEAL_DOMAIN));
    sha256_update(&c, &z, 1);
    sha256_update(&c, qfreeze_digest, 32);
    sha256_final(&c, out);
}

typedef struct { const char *root; const char *rel; } gd_ent;

static int gd_cmp(const void *a, const void *b) {
    return strcmp(((const gd_ent *)a)->rel, ((const gd_ent *)b)->rel);
}

int brw_generator_digest_rooted(const char *const *roots, const char *const *rels, size_t n,
                                const char *cflags, const char *cc_version_line,
                                uint8_t out[32]) {
    sha256_ctx c;
    gd_ent *e;
    const uint8_t z = 0;
    if (!rels || !cflags || !cc_version_line || !out || n == 0) return BRW_E_ARG;
    e = malloc(n * sizeof *e);
    if (!e) return BRW_E_IO;
    for (size_t i = 0; i < n; i++) { e[i].root = roots ? roots[i] : NULL; e[i].rel = rels[i]; }
    qsort(e, n, sizeof *e, gd_cmp);
    sha256_init(&c);
    for (size_t i = 0; i < n; i++) {
        char path[4096];
        uint8_t buf[4096];
        size_t got;
        FILE *f;
        int len = e[i].root ? snprintf(path, sizeof path, "%s/%s", e[i].root, e[i].rel)
                            : snprintf(path, sizeof path, "%s", e[i].rel);
        if (len <= 0 || (size_t)len >= sizeof path) { free(e); return BRW_E_ARG; }
        f = fopen(path, "rb");
        if (!f) { free(e); return BRW_E_IO; }
        sha256_update(&c, (const uint8_t *)e[i].rel, strlen(e[i].rel));
        sha256_update(&c, &z, 1);
        while ((got = fread(buf, 1, sizeof buf, f)) > 0) sha256_update(&c, buf, got);
        if (ferror(f)) { fclose(f); free(e); return BRW_E_IO; }
        fclose(f);
    }
    sha256_update(&c, (const uint8_t *)cflags, strlen(cflags));
    sha256_update(&c, (const uint8_t *)cc_version_line, strlen(cc_version_line));
    sha256_final(&c, out);
    free(e);
    return BRW_OK;
}

int brw_generator_digest(const char *const *paths, size_t n, const char *cflags,
                         const char *cc_version_line, uint8_t out[32]) {
    return brw_generator_digest_rooted(NULL, paths, n, cflags, cc_version_line, out);
}

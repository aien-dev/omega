/* brw_results.h: `brownian_bench results` (plan §26, results.json, B17). Read-only: loads the digest-checked q-records
 * of one profile and freeze from flat directories, reads a judgement manifest, and prints the canonical results.json
 * (compact JSON, keys in byte order, integers decimal). No scoring, verdict or threshold code is called or changed.
 * Fields with no source in the records are JSON null; nothing is invented. Private, sealed. C only. */
#ifndef BRW_RESULTS_H
#define BRW_RESULTS_H
#include <stddef.h>
#include "brw_protocol.h"

#define BRW_RES_MAXDIRS 64

typedef struct {
    const char *qprofile, *manifest, *out;
    const char *dirs[BRW_RES_MAXDIRS]; size_t ndirs;
    const char *cflags;              /* BRN_CFLAGS as built, or NULL (then generator.cflags is null) */
    const char *calibration;         /* optional brw.calib.v1: occ_cross values printed beside the Occam curve (else null there) */
} brw_res_args;

/* Writes the file and its SHA-256 (64 hex) into hex_out. 0 or a TYQ_* refusal with `why`. */
int brw_results_run(const brw_res_args *a, char hex_out[65], char *why, size_t cap);
#endif

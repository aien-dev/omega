/* brw_rng.h: Brownian evaluator RNG, streams and generator digest (plan §9, §28.2). */
#ifndef BRW_RNG_H
#define BRW_RNG_H
#include <stddef.h>
#include <stdint.h>
#include "crumbline/cl_common.h"   /* ClRng, cl_rng_next */

#define BRW_GEN_VERSION   "brownian.eval.xoshiro256ss.v1"
#define BRW_DEV_PARENT    "brownian.dev.v1"     /* ASCII, no NUL in the hash */
#define BRW_SEAL_DOMAIN   "brownian.seal.v1"

enum {
    BRW_OK = 0, BRW_E_ARG = -1, BRW_E_RANGE = -2, BRW_E_IO = -3, BRW_E_FORMAT = -4,
    BRW_E_KAT = -5, BRW_E_PROTOCOL = -6, BRW_E_DIGEST = -7, BRW_E_REFUSED = -8
};

/* SHA-256(seed || 0x00 || name). Generic form; KAT 2 calls it with seed = "brownian.eval.v1". */
void brw_stream_digest(const uint8_t *seed, size_t seed_len, const char *name, uint8_t out[32]);
/* SHA-256(label || 0x00 || parent || rep_u64_le) */
int  brw_world_seed(const char *label, const uint8_t *parent, size_t parent_len,
                    uint64_t rep, uint8_t out[32]);
/* OI-1 label "brownian.v1|<mode>|<cell>|<block>"; mode "dev" or "seal". buf >= 96 bytes. */
int  brw_world_label(const char *mode, const char *cell, uint64_t block, char *buf, size_t cap);
/* s[i] = LE u64 words of d; all zero -> s[0] = 1. Never calls cl_rng_seed. */
void brw_rng_from_digest(ClRng *r, const uint8_t d[32]);
/* brw_stream_digest(world_seed, 32, name) then brw_rng_from_digest; refuses unknown names. */
int  brw_stream_init(ClRng *r, const uint8_t world_seed[32], const char *name);
/* ((cl_rng_next(r) >> 11) + 0.5) / 2^53, strictly inside (0,1) */
double brw_uniform(ClRng *r);
/* Same map from a raw 64-bit word (clamps the one word that would round to 1.0). */
double brw_uniform_from_word(uint64_t w);
/* SHA-256("brownian.seal.v1" || 0x00 || qfreeze_digest) */
void brw_sealed_parent(const uint8_t qfreeze_digest[32], uint8_t out[32]);
/* SHA-256 over sorted (path || 0x00 || bytes) || cflags || cc_version_line.
 * Here the hashed label equals the path opened. */
int  brw_generator_digest(const char *const *paths, size_t n, const char *cflags,
                          const char *cc_version_line, uint8_t out[32]);
/* Same, but file i is opened at roots[i]/rels[i] (roots[i] may be NULL) and the hashed
 * label is rels[i] (checkout-location independent, plan §9 "omega-relative path"). */
int  brw_generator_digest_rooted(const char *const *roots, const char *const *rels, size_t n,
                                 const char *cflags, const char *cc_version_line,
                                 uint8_t out[32]);
#endif

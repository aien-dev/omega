/* brw_protocol.c: the Brownian blind lifecycle, records, scoring, sandbox and line protocol (Lane D3).
 * The only file built with BRN_PROTO_CFLAGS (-std=gnu11 -D_GNU_SOURCE, spec §1). Private, sealed. C only.
 * No threshold or band value lives here: acceptance bands are read from the thresholds sidecar by path (spec §20).
 * Values this file cannot decide are marked UNDECIDED and listed in the Lane D3 report. */
#include "brw_protocol.h"

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <poll.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>

#include "brw_cells.h"
#include "brw_qbw.h"
#include "brw_tps.h"
#include "sha256.h"
#include "turing/ty_math.h"
#include "turing/ty_qcont.h"

#define WHY(...) do { if (why && cap) snprintf(why, cap, __VA_ARGS__); } while (0)

/* ------------------------------------------------------------------ verdicts */
const char *brw_verdict_name(int rc) {
    switch (rc) {
    case 0: return "PASS";
    case TYQ_FAIL_PROTOCOL: return "FAIL_PROTOCOL";
    case TYQ_FAIL_FLOOR: return "FAIL_FLOOR";
    case TYQ_FAIL_LEAK: return "FAIL_LEAK";
    case TYQ_FAIL_DIGEST: return "FAIL_DIGEST";
    case TYQ_FAIL_PROFILE: return "FAIL_PROFILE";
    case TYQ_FAIL_BASELINE: return "FAIL_BASELINE";
    case TYQ_E_ARG: return "E_ARG";
    case TYQ_E_IO: return "E_IO";
    case BRW_STOPPED: return "STOPPED";
    case BRW_KATFAIL: return "KAT FAIL";
    case BRW_BLOCKED: return "BLOCKED";
    default: return "ERROR";
    }
}

/* ----------------------------------------------------------------- utilities */
void brw_bytes_free(brw_bytes *x) { if (x) { free(x->b); x->b = NULL; x->n = 0; } }

int brw_slurp(const char *path, brw_bytes *out) {
    out->b = NULL; out->n = 0;
    FILE *f = fopen(path, "rb");
    if (!f) return TYQ_E_IO;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return TYQ_E_IO; }
    long z = ftell(f);
    if (z < 0 || fseek(f, 0, SEEK_SET) != 0) { fclose(f); return TYQ_E_IO; }
    uint8_t *b = malloc((size_t)z + 1);
    if (!b) { fclose(f); return TYQ_E_IO; }
    if (fread(b, 1, (size_t)z, f) != (size_t)z) { free(b); fclose(f); return TYQ_E_IO; }
    fclose(f);
    b[z] = 0;
    out->b = b; out->n = (size_t)z;
    return TYQ_OK;
}

int brw_write_excl(const char *path, const void *b, size_t n) {
    int fd = open(path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0444);
    if (fd < 0) return errno == EEXIST ? TYQR_E_EXISTS : TYQ_E_IO;
    const uint8_t *q = b;
    while (n) {
        ssize_t w = write(fd, q, n);
        if (w < 0 && errno == EINTR) continue;
        if (w <= 0) { close(fd); unlink(path); return TYQ_E_IO; }
        q += w; n -= (size_t)w;
    }
    if (close(fd) != 0) { unlink(path); return TYQ_E_IO; }
    return 0;
}

/* write a digest-named content file; an identical existing file is fine (idempotent), a different one is refused */
static int write_named(const char *path, const void *b, size_t n) {
    int rc = brw_write_excl(path, b, n);
    if (rc != TYQR_E_EXISTS) return rc;
    brw_bytes old;
    if (brw_slurp(path, &old) != 0) return TYQ_E_IO;
    int same = old.n == n && (n == 0 || memcmp(old.b, b, n) == 0);
    brw_bytes_free(&old);
    return same ? 0 : TYQR_E_EXISTS;
}

void brw_sha256(const void *b, size_t n, ty_digest *out) { sha256_hash(b, n, out->b); }

int brw_dir_of(const char *path, char *dir, size_t cap) {
    const char *s = strrchr(path, '/');
    if (!s) { if (cap < 2) return TYQ_E_ARG; strcpy(dir, "."); return 0; }
    size_t n = (size_t)(s - path);
    if (n == 0) n = 1;
    if (n >= cap) return TYQ_E_ARG;
    memcpy(dir, path, n); dir[n] = 0;
    return 0;
}

int brw_join(char *out, size_t cap, const char *dir, const char *fmt, ...) {
    size_t n = (size_t)snprintf(out, cap, "%s/", dir);
    if (n >= cap) return TYQ_E_ARG;
    va_list ap; va_start(ap, fmt);
    int k = vsnprintf(out + n, cap - n, fmt, ap);
    va_end(ap);
    return (k < 0 || (size_t)k >= cap - n) ? TYQ_E_ARG : 0;
}

static int exists(const char *p) { struct stat st; return lstat(p, &st) == 0; }

static const char *base_of(const char *p) { const char *s = strrchr(p, '/'); return s ? s + 1 : p; }

static void hex8(const ty_digest *d, char out[9]) { char h[65]; ty_hex(d, h); memcpy(out, h, 8); out[8] = 0; }

/* -------------------------------------------------------------- environment */
void brw_env_default(brw_env *e) {
    memset(e, 0, sizeof *e);
    snprintf(e->root, sizeof e->root, "%s", ".");
    const char *h = getenv("HOME");
    snprintf(e->omega, sizeof e->omega, "%s/workspace/omega-pin-brn2", h ? h : ".");
    snprintf(e->cflags, sizeof e->cflags, "%s", "");
    snprintf(e->cc_line, sizeof e->cc_line, "%s", "unknown\nunknown");
}

/* Same 13 files and label convention as test_brw_world.c: nine brownian files opened under the checkout root,
 * four omega files opened under the pinned omega checkout; the hashed label is the relative path. */
int brw_generator_digest_of(const brw_env *e, ty_digest *out) {
    static const char *const rels[13] = {
        "brownian/src/brw_rng.h", "brownian/src/brw_rng.c", "brownian/src/brw_normal.h",
        "brownian/src/brw_normal.c", "brownian/src/brw_world.h", "brownian/src/brw_world.c",
        "brownian/src/brw_qbw.h", "brownian/src/brw_qbw.c", "brownian/src/brw_cells.h",
        "src/crumbline/cl_common.h", "src/crumbline/cl_common.c", "src/sha256.h", "src/sha256.c" };
    const char *roots[13];
    for (int i = 0; i < 13; i++) roots[i] = i < 9 ? e->root : e->omega;
    return brw_generator_digest_rooted(roots, rels, 13, e->cflags, e->cc_line, out->b) == BRW_OK ? 0 : TYQ_E_IO;
}

/* ---------------------------------------------------------------- cell table */
static const struct { const char *name; uint32_t W; const char *exp; int hostile; int descriptive; } CT[] = {
    { "B0-regular", 400, "EXP-002A", 0, 0 }, { "B0-irregular", 400, "EXP-002A", 0, 0 }, { "B0-short", 400, "EXP-002A", 0, 0 },
    { "B1-0", 400, "EXP-002B", 0, 0 }, { "B1-1", 400, "EXP-002B", 0, 0 }, { "B1-3", 400, "EXP-002B", 0, 0 },
    { "B1-4n", 400, "EXP-002B", 0, 0 }, { "B2-noise", 400, "EXP-002C", 0, 0 }, { "B2-weak", 200, "EXP-002C", 0, 0 },
    { "B2-clear", 200, "EXP-002C", 0, 0 }, { "B2-fast", 200, "EXP-002C", 0, 0 }, { "B2-emerging", 1600, "EXP-002C", 0, 0 },
    /* UNDECIDED: worlds per block of an H- cell; 400 assumed (development only, never sealed) */
    { "H-meas", 400, NULL, 1, 0 }, { "H-t4", 400, NULL, 1, 0 }, { "H-outlier", 400, NULL, 1, 0 },
    { "H-missing", 400, NULL, 1, 0 }, { "H-boundary-D", 400, NULL, 1, 0 }, { "H-boundary-theta", 400, NULL, 1, 0 },
    { "H-affine", 400, NULL, 1, 0 },
    /* EXP-002C-INT worlds (spec section 15, U5): sealed-capable extra cells; a distinct experiment tag declares no baseline, so every
     * INT score names its ladder item */
    { "INT-d0", BRW_INT_W, "EXP-002C-INT", 0, 0 }, { "INT-d1", BRW_INT_W, "EXP-002C-INT", 0, 0 }, { "INT-d2", BRW_INT_W, "EXP-002C-INT", 0, 0 },
    { "INT-d5", BRW_INT_W, "EXP-002C-INT", 0, 0 }, { "INT-d8", BRW_INT_W, "EXP-002C-INT", 0, 0 },
    /* R3-36 (ii): pure-diffusion controls, same tag, same size and construction */
    { "CTL-d0", BRW_INT_W, "EXP-002C-INT", 0, 0 }, { "CTL-d1", BRW_INT_W, "EXP-002C-INT", 0, 0 }, { "CTL-d2", BRW_INT_W, "EXP-002C-INT", 0, 0 },
    { "CTL-d5", BRW_INT_W, "EXP-002C-INT", 0, 0 }, { "CTL-d8", BRW_INT_W, "EXP-002C-INT", 0, 0 },
    /* R3-36 (iii): theta = 0.5 row, W = 200, H = 128, DESCRIPTIVE (not gated): the last field */
    { "INT05-d0", BRW_INT05_W, "EXP-002C-INT", 0, 1 }, { "INT05-d1", BRW_INT05_W, "EXP-002C-INT", 0, 1 }, { "INT05-d2", BRW_INT05_W, "EXP-002C-INT", 0, 1 },
    { "INT05-d5", BRW_INT05_W, "EXP-002C-INT", 0, 1 }, { "INT05-d8", BRW_INT05_W, "EXP-002C-INT", 0, 1 },
    /* EXP-002B Occam sweep (spec 14, U10): 124 cells, W = 400, own tag (no declared baseline unless the profile names one) */
#define OCC_ENTRY(nm, s, h) { nm, BRW_OCC_W, BRW_OCC_EXP, 0, 0 },
    BRW_OCC_LIST(OCC_ENTRY)
#undef OCC_ENTRY
};
#define NCT (sizeof CT / sizeof CT[0])

static int ct_cmp(const void *a, const void *b) { return strcmp(CT[*(const int *)a].name, CT[*(const int *)b].name); }

size_t brw_cellinfo_count(void) { return NCT; }

static int ct_fill(size_t i, brw_cellinfo *o) {
    if (brw_cell_lookup(CT[i].name, &o->s) != BRW_OK) return TYQ_E_ARG;
    o->W = CT[i].W; o->H = o->s.n_points - o->s.split;   /* set-state cells: split is the first scored index, so H counts scored rows only */ o->experiment = CT[i].exp; o->hostile = CT[i].hostile; o->descriptive = CT[i].descriptive;
    return 0;
}

int brw_cellinfo_at(size_t i, brw_cellinfo *o) {
    int idx[NCT];
    if (i >= NCT) return TYQ_E_ARG;
    for (size_t k = 0; k < NCT; k++) idx[k] = (int)k;
    qsort(idx, NCT, sizeof idx[0], ct_cmp);
    return ct_fill((size_t)idx[i], o);
}

int brw_cellinfo_get(const char *name, brw_cellinfo *o) {
    for (size_t i = 0; i < NCT; i++)
        if (name && strcmp(CT[i].name, name) == 0) return ct_fill(i, o);
    return TYQ_E_ARG;
}

int brw_cells_sidecar(char *out, size_t cap, size_t *len) {
    size_t o = 0;
    for (size_t i = 0; i < NCT; i++) {
        brw_cellinfo c;
        if (brw_cellinfo_at(i, &c) != 0) return TYQ_E_ARG;
        const brw_cell_spec *s = &c.s;
        int k = snprintf(out + o, cap - o,
            "%s family=%d grid=%d obs=%d n_points=%u split=%u snr_s=%.17g theta=%.17g sigma=%.17g x0_fixed=%d "
            "x0=%.17g d_fixed=%d d_value=%.17g obs_p=%.17g w=%u",
            s->name, (int)s->family, (int)s->grid, (int)s->obs, s->n_points, s->split, s->snr_s, s->theta, s->sigma,
            s->x0_fixed, s->x0, s->d_fixed, s->d_value, s->obs_p, c.W);
        if (k < 0 || (size_t)k >= cap - o) return TYQ_E_ARG;
        o += (size_t)k;
        /* R3-36: the set-state and descriptive fields are appended only on the EXP-002C-INT cells, so every older line is unchanged */
        if (s->set_state) {
            k = snprintf(out + o, cap - o, " set_state=1 set_x=%.17g x0_sd=%.17g", s->set_x, s->x0_sd);
            if (k < 0 || (size_t)k >= cap - o) return TYQ_E_ARG;
            o += (size_t)k;
        }
        if (c.descriptive) {
            k = snprintf(out + o, cap - o, " descriptive=1");
            if (k < 0 || (size_t)k >= cap - o) return TYQ_E_ARG;
            o += (size_t)k;
        }
        k = snprintf(out + o, cap - o, "\n");
        if (k < 0 || (size_t)k >= cap - o) return TYQ_E_ARG;
        o += (size_t)k;
    }
    *len = o;
    return 0;
}

int brw_opcode_of(const char *name) {
    if (!name || !*name) return 0;
    for (int op = 1; op <= 7; op++) {
        const brw_ref *r = brw_ref_get(op);
        if (r && strcmp(r->name, name) == 0) return op;
    }
    if (name[0] == '0' && name[1] == 'x') {
        char *e; long v = strtol(name, &e, 16);
        if (!*e && v >= 1 && v <= 7) return (int)v;
    }
    return 0;
}

/* ------------------------------------------------------------ profile, thresholds */
static int cpy(char *dst, const char *src) { if (strlen(src) >= TYQR_VAL) return -1; strcpy(dst, src); return 0; }

int brw_profile_make(const brw_profile_in *in, tyqr_profile *p, char *why, size_t cap) {
    static char cells[65536];
    size_t cl = 0;
    memset(p, 0, sizeof *p);
    if (!in) { WHY("no profile input"); return TYQ_E_ARG; }
    if (brw_cells_sidecar(cells, sizeof cells, &cl) != 0 || tyqr_celltab_check(cells, cl) != 0) {
        WHY("cell table sidecar is malformed"); return TYQ_FAIL_PROFILE; }
    /* every string below is a descriptive constant of spec section 20 (R3-24 U1, U12), not a threshold */
    int bad = cpy(p->profile, "brownian.profile.v1") || cpy(p->protocol, "brw.line.v1") ||
              cpy(p->quantizer, TYQ_QUANTIZER_ID) || cpy(p->edge_rule, "floor.halfopen.lower") ||
              cpy(p->floor_rule, "raise.count.fail_above_ppm.1000") || cpy(p->families, "0") ||
              cpy(p->rider, "k*0.5*log2(n_prefix_increments).per_world") ||
              cpy(p->lm_rule, in->lm_rule && *in->lm_rule ? in->lm_rule : BRW_LM_RULE) ||
              cpy(p->baselines, "EXP-002A:0x01 EXP-002B:0x04 EXP-002B-OCC:0x04 EXP-002C:0x05") ||
              cpy(p->thresholds_format, "brw.thr.v1") || cpy(p->gen_version, BRW_GEN_VERSION) ||
              cpy(p->unit, "micro-bits (1 T = 1 bit = 1000000 ub)");
    if (bad) { WHY("a profile string is too long"); return TYQ_E_ARG; }
    p->spec = in->spec; p->packet = in->packet; p->thresholds = in->thresholds;
    p->delta_log2 = -20; p->sd_min_log2 = -10; p->kmax = 1;
    p->n_points = BRW_N_POINTS_PRIMARY; p->split = BRW_SPLIT_PRIMARY; p->bootstrap_b = BRW_BOOT_B;
    tyqr_sidecar_digest(cells, cl, &p->cells);
    ty_digest d;
    int rc = tyqr_profile_digest(p, &d);
    if (rc != TY_OK) { WHY("the omega profile builder refused the profile"); return TYQ_FAIL_PROFILE; }
    return 0;
}

int brw_thr_check(const tyqr_profile *p, const char *buf, size_t len, char *why, size_t cap) {
    ty_digest d;
    tyqr_sidecar_digest(buf, len, &d);
    if (!ty_digest_eq(&d, &p->thresholds)) { WHY("thresholds sidecar digest differs from the qprofile thresholds attribute"); return TYQ_FAIL_PROFILE; }
    if (tyqr_thrtab_check(buf, len) != 0) { WHY("thresholds sidecar line format is bad"); return TYQ_FAIL_PROFILE; }
    return 0;
}

int brw_thr_file_check(const tyqr_profile *p, const char *path, char *why, size_t cap) {
    brw_bytes b;
    if (brw_slurp(path, &b) != 0) { WHY("cannot read the thresholds sidecar"); return TYQ_E_IO; }
    int rc = brw_thr_check(p, (const char *)b.b, b.n, why, cap);
    brw_bytes_free(&b);
    return rc;
}

int brw_declared_baseline(const tyqr_profile *p, const char *experiment) {
    if (!experiment) return 0;
    char t[TYQR_VAL];
    snprintf(t, sizeof t, "%s", p->baselines);
    for (char *s = strtok(t, " "); s; s = strtok(NULL, " ")) {
        char *c = strchr(s, ':');
        if (!c) continue;
        *c = 0;
        if (strcmp(s, experiment) == 0) return brw_opcode_of(c + 1);
    }
    return 0;
}

/* ------------------------------------------------------------------ OMG0 reader */
typedef struct { char k[64]; char v[TYQR_VAL]; } kv_t;
typedef struct { kv_t a[64]; int n; int err; } kvs_t;

/* "OMG0", u8 version 1, u8 kind, u16 BE attribute count, per attribute u8 klen, key, u16 BE vlen, value, then u16 BE
 * relation count = 0. Canonical order is verified indirectly: the record digest is rebuilt from the parsed fields
 * by the omega builder and must equal the digest of the file. */
static int omg_parse(const uint8_t *b, size_t n, kvs_t *o) {
    memset(o, 0, sizeof *o);
    if (n < 8 || memcmp(b, "OMG0", 4) != 0 || b[4] != 1) return -1;
    unsigned cnt = (unsigned)b[6] << 8 | b[7];
    size_t p = 8;
    if (cnt > 64) return -1;
    for (unsigned i = 0; i < cnt; i++) {
        if (p >= n) return -1;
        size_t kl = b[p++];
        if (kl == 0 || kl >= 64 || p + kl + 2 > n) return -1;
        memcpy(o->a[i].k, b + p, kl); o->a[i].k[kl] = 0; p += kl;
        size_t vl = (size_t)b[p] << 8 | b[p + 1]; p += 2;
        if (vl > 512 || p + vl > n) return -1;
        memcpy(o->a[i].v, b + p, vl); o->a[i].v[vl] = 0; p += vl;
        if (strlen(o->a[i].v) != vl) return -1;
    }
    if (p + 8 != n) return -1;
    for (int z = 0; z < 8; z++) if (b[p + (size_t)z] != 0) return -1;   /* four empty u16 counts: relations, constraints, ... */
    o->n = (int)cnt;
    return 0;
}

static const char *kv_get(kvs_t *o, const char *k) {
    for (int i = 0; i < o->n; i++)
        if (strcmp(o->a[i].k, k) == 0) return o->a[i].v;
    o->err = 1;
    return NULL;
}
static void g_str(kvs_t *o, const char *k, char *dst) { const char *v = kv_get(o, k); if (v) snprintf(dst, TYQR_VAL, "%s", v); }
static void g_u64(kvs_t *o, const char *k, uint64_t *dst) {
    const char *v = kv_get(o, k);
    if (!v || !*v || *v == '-' || *v == '+') { o->err = 1; return; }
    char *e; errno = 0; unsigned long long x = strtoull(v, &e, 10);
    if (*e || errno) { o->err = 1; return; }
    *dst = x;
}
static int parse_i64(const char *v, int64_t *dst, char **end) {
    char *e; errno = 0; long long x = strtoll(v, &e, 10);
    if (e == v || errno) return -1;
    *dst = x; if (end) *end = e;
    return 0;
}
static void g_i64(kvs_t *o, const char *k, int64_t *dst) {
    const char *v = kv_get(o, k); char *e;
    if (!v || parse_i64(v, dst, &e) || *e) o->err = 1;
}
static void g_dig(kvs_t *o, const char *k, ty_digest *dst) { const char *v = kv_get(o, k); if (!v || ty_parse_hex(v, dst) != 0) o->err = 1; }
static void g_ilist(kvs_t *o, const char *k, int64_t *dst, int n) {
    const char *v = kv_get(o, k); char *e;
    if (!v) return;
    for (int i = 0; i < n; i++) {
        if (parse_i64(v, &dst[i], &e)) { o->err = 1; return; }
        if (i < n - 1) { if (*e != ' ') { o->err = 1; return; } v = e + 1; } else if (*e) o->err = 1;
    }
}

static int file_digest(const char *path, const char *domain, brw_bytes *raw, ty_digest *d) {
    if (brw_slurp(path, raw) != 0) return TYQ_E_IO;
    sha256_ctx c;
    sha256_init(&c);
    sha256_update(&c, (const uint8_t *)domain, strlen(domain) + 1);
    sha256_update(&c, raw->b, raw->n);
    sha256_final(&c, d->b);
    return 0;
}

/* the digest in the file name must equal the recomputed digest of the bytes (tamper, rename) */
static int name_matches(const char *path, const ty_digest *d) {
    char h[65];
    ty_hex(d, h);
    return strstr(base_of(path), h) != NULL;
}

typedef int (*fill_fn)(kvs_t *o, void *rec);
typedef int (*dig_fn)(const void *rec, ty_digest *d);

static int load_rec(const char *path, const char *domain, void *rec, size_t recsz, fill_fn fill, dig_fn dg,
                    ty_digest *d, char *why, size_t cap) {
    brw_bytes raw; ty_digest fd; kvs_t o;
    int rc = file_digest(path, domain, &raw, &fd);
    if (rc) { WHY("cannot read the record file"); return TYQ_E_IO; }
    if (!name_matches(path, &fd)) { WHY("file bytes do not match the digest in the file name"); brw_bytes_free(&raw); return TYQ_FAIL_DIGEST; }
    if (omg_parse(raw.b, raw.n, &o) != 0) { WHY("not a canonical OMG0 record"); brw_bytes_free(&raw); return TYQ_FAIL_DIGEST; }
    brw_bytes_free(&raw);
    memset(rec, 0, recsz);
    if (fill(&o, rec) != 0) { WHY("record attributes are missing or malformed"); return TYQ_FAIL_DIGEST; }
    ty_digest rd;
    if (dg(rec, &rd) != TY_OK || !ty_digest_eq(&rd, &fd)) { WHY("record does not rebuild to its digest"); return TYQ_FAIL_DIGEST; }
    if (d) *d = fd;
    return 0;
}

static int fill_profile(kvs_t *o, void *v) {
    tyqr_profile *r = v;
    g_str(o, "profile", r->profile); g_dig(o, "spec", &r->spec); g_dig(o, "packet", &r->packet);
    g_str(o, "protocol", r->protocol); g_str(o, "quantizer", r->quantizer); g_i64(o, "delta_log2", &r->delta_log2);
    g_str(o, "edge_rule", r->edge_rule); g_i64(o, "sd_min_log2", &r->sd_min_log2); g_str(o, "floor_rule", r->floor_rule);
    g_str(o, "families", r->families); g_u64(o, "kmax", &r->kmax); g_u64(o, "n_points", &r->n_points);
    g_u64(o, "split", &r->split); g_dig(o, "cells", &r->cells); g_str(o, "rider", r->rider); g_str(o, "lm_rule", r->lm_rule);
    g_str(o, "baselines", r->baselines); g_dig(o, "thresholds", &r->thresholds);
    g_str(o, "thresholds_format", r->thresholds_format); g_str(o, "gen_version", r->gen_version);
    g_u64(o, "bootstrap_b", &r->bootstrap_b); g_str(o, "unit", r->unit);
    return o->err;
}
static int fill_world(kvs_t *o, void *v) {
    tyqr_world *r = v;
    g_dig(o, "qprofile", &r->qprofile); g_str(o, "mode", r->mode); g_str(o, "parent_kind", r->parent_kind);
    g_dig(o, "qfreeze", &r->qfreeze); g_str(o, "cell", r->cell); g_u64(o, "block", &r->block); g_str(o, "label", r->label);
    g_str(o, "gen_version", r->gen_version); g_dig(o, "generator", &r->generator); g_u64(o, "rep_first", &r->rep_first);
    g_u64(o, "rep_count", &r->rep_count); g_dig(o, "traj_manifest", &r->traj_manifest); g_str(o, "traj_format", r->traj_format);
    return o->err;
}
static int fill_freeze(kvs_t *o, void *v) {
    tyqr_freeze *r = v;
    g_str(o, "mode", r->mode); g_dig(o, "artifact", &r->artifact); g_str(o, "artifact_kind", r->artifact_kind);
    g_dig(o, "artifact_bin", &r->artifact_bin); g_dig(o, "qprofile", &r->qprofile); g_dig(o, "dev_manifest", &r->dev_manifest);
    g_str(o, "b2_emerging_label", r->b2_emerging_label); g_str(o, "bayes_plugin_check", r->bayes_plugin_check);
    g_str(o, "diag_fw_rate_ppm", r->diag_fw_rate_ppm); g_str(o, "lengthening_test", r->lengthening_test);
    g_str(o, "stability_test", r->stability_test); g_str(o, "calibration_extra", r->calibration_extra);
    const char *rc = kv_get(o, "run_commit");
    if (rc && strlen(rc) == 40) strcpy(r->run_commit, rc); else o->err = 1;
    g_u64(o, "tree_dirty", &r->tree_dirty); g_str(o, "base_commits", r->base_commits);
    g_str(o, "producer_tool", r->producer_tool); g_str(o, "producer_model", r->producer_model);
    g_dig(o, "prompt_digest", &r->prompt_digest); g_dig(o, "transcript_digest", &r->transcript_digest);
    g_u64(o, "n_lineage", &r->n_lineage);
    if (r->n_lineage > TYQR_MAX_LINEAGE) return 1;
    for (uint64_t i = 0; i < r->n_lineage; i++) { char k[16]; snprintf(k, sizeof k, "lineage.%02u", (unsigned)i); g_dig(o, k, &r->lineage[i]); }
    return o->err;
}
static int fill_gain(kvs_t *o, void *v) {
    tyqr_gain *r = v;
    g_dig(o, "qprofile", &r->qprofile); g_dig(o, "qworld", &r->qworld); g_dig(o, "qfreeze", &r->qfreeze);
    g_str(o, "mode", r->mode); g_str(o, "cell", r->cell); g_str(o, "gen_version", r->gen_version);
    const char *bl = kv_get(o, "baseline");
    if (bl) {
        char *e; errno = 0; unsigned long long op = strtoull(bl, &e, 10);
        if (errno || *e != ' ' || ty_parse_hex(e + 1, &r->baseline_artifact) != 0) o->err = 1;
        r->baseline_opcode = op;
    }
    g_dig(o, "candidate", &r->candidate); g_u64(o, "candidate_opcode", &r->candidate_opcode);
    g_dig(o, "prd_b", &r->prd_b); g_dig(o, "prd_m", &r->prd_m); g_u64(o, "official", &r->official);
    g_str(o, "ladder_item", r->ladder_item); g_ilist(o, "lengths", r->lengths, 6);
    g_i64(o, "t_ub", &r->t_ub); g_i64(o, "t_lo_ub", &r->t_lo_ub); g_i64(o, "t_hi_ub", &r->t_hi_ub);
    g_i64(o, "numeric_bound_ub", &r->numeric_bound_ub); g_i64(o, "mc_err_ub", &r->mc_err_ub);
    const char *c = kv_get(o, "counts");
    if (c) {
        unsigned long long a[4];
        if (sscanf(c, "%llu %llu %llu %llu", &a[0], &a[1], &a[2], &a[3]) != 4) o->err = 1;
        else for (int i = 0; i < 4; i++) r->counts[i] = a[i];
    }
    g_u64(o, "floor_hits", &r->floor_hits); g_u64(o, "protocol_failures", &r->protocol_failures);
    g_str(o, "leak_flag", r->leak_flag); g_ilist(o, "coverage", r->coverage, 3); g_str(o, "diag_warnings", r->diag_warnings);
    g_str(o, "classification", r->classification); g_str(o, "status", r->status); g_str(o, "unit", r->unit);
    return o->err;
}

#define DIGFN(T, f) static int dg_##f(const void *r, ty_digest *d) { return f((const T *)r, d); }
DIGFN(tyqr_profile, tyqr_profile_digest) DIGFN(tyqr_world, tyqr_world_digest)
DIGFN(tyqr_freeze, tyqr_freeze_digest) DIGFN(tyqr_gain, tyqr_gain_digest)

int brw_load_profile(const char *p, tyqr_profile *r, ty_digest *d, char *why, size_t cap) {
    return load_rec(p, TYQR_DOMAIN_PROFILE, r, sizeof *r, fill_profile, dg_tyqr_profile_digest, d, why, cap); }
int brw_load_world(const char *p, tyqr_world *r, ty_digest *d, char *why, size_t cap) {
    return load_rec(p, TYQR_DOMAIN_WORLD, r, sizeof *r, fill_world, dg_tyqr_world_digest, d, why, cap); }
int brw_load_freeze(const char *p, tyqr_freeze *r, ty_digest *d, char *why, size_t cap) {
    return load_rec(p, TYQR_DOMAIN_FREEZE, r, sizeof *r, fill_freeze, dg_tyqr_freeze_digest, d, why, cap); }
int brw_load_gain(const char *p, tyqr_gain *r, ty_digest *d, char *why, size_t cap) {
    return load_rec(p, TYQR_DOMAIN_GAIN, r, sizeof *r, fill_gain, dg_tyqr_gain_digest, d, why, cap); }

int brw_record_path(char *out, size_t cap, const char *dir, const char *record, const ty_digest *d) {
    char h[65];
    ty_hex(d, h);
    return brw_join(out, cap, dir, "%s.%s.omg0", record, h);
}

/* ---------------------------------------------------------- small file helpers */
static int copy_named(const char *src, const char *outdir) {
    brw_bytes b;
    char dst[BRW_PATH];
    if (brw_slurp(src, &b) != 0) return TYQ_E_IO;
    int rc = brw_join(dst, sizeof dst, outdir, "%s", base_of(src));
    if (rc == 0) rc = write_named(dst, b.b, b.n);
    brw_bytes_free(&b);
    return rc;
}


static int cmp_str(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }

/* sorted names in dir with the given prefix and suffix */
static int list_dir(const char *dir, const char *prefix, const char *suffix, char ***names, size_t *n) {
    DIR *d = opendir(dir);
    *names = NULL; *n = 0;
    if (!d) return TYQ_E_IO;
    size_t cap = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        size_t l = strlen(e->d_name), sl = strlen(suffix);
        if (strncmp(e->d_name, prefix, strlen(prefix)) != 0 || l < sl || strcmp(e->d_name + l - sl, suffix) != 0) continue;
        if (*n == cap) {
            cap = cap ? cap * 2 : 64;
            char **nn = realloc(*names, cap * sizeof *nn);
            if (!nn) { closedir(d); return TYQ_E_IO; }
            *names = nn;
        }
        (*names)[(*n)++] = strdup(e->d_name);
    }
    closedir(d);
    if (*n) qsort(*names, *n, sizeof **names, cmp_str);
    return 0;
}
static void free_names(char **names, size_t n) { for (size_t i = 0; i < n; i++) free(names[i]); free(names); }

/* ------------------------------------------------------------ trajectory sets */
typedef struct {
    size_t W;
    uint8_t **buf;       /* QBW1 bytes */
    size_t *len;
    ty_digest *dg;       /* SHA-256 of each file */
    char *man; size_t man_len; ty_digest man_d;   /* brw.traj.v1 sidecar */
} genset;

static void genset_free(genset *g) {
    for (size_t i = 0; i < g->W; i++) free(g->buf ? g->buf[i] : NULL);
    free(g->buf); free(g->len); free(g->dg); free(g->man);
    memset(g, 0, sizeof *g);
}

/* generate the W worlds of (mode label, cell, block) under parent, encode them, build the trajectory sidecar */
static int genset_make(const brw_cellinfo *ci, const char *label_mode, uint64_t block, const uint8_t *parent,
                       size_t plen, genset *g, char *label, size_t lcap, char *why, size_t cap) {
    memset(g, 0, sizeof *g);
    g->W = ci->W;
    g->buf = calloc(g->W, sizeof *g->buf); g->len = calloc(g->W, sizeof *g->len); g->dg = calloc(g->W, sizeof *g->dg);
    tyqr_repline *rl = calloc(g->W, sizeof *rl);
    if (!g->buf || !g->len || !g->dg || !rl) { WHY("out of memory"); free(rl); genset_free(g); return TYQ_E_IO; }
    if (brw_world_label(label_mode, ci->s.name, block, label, lcap) != BRW_OK) { WHY("cannot form the world label"); free(rl); genset_free(g); return TYQ_E_ARG; }
    for (size_t r = 0; r < g->W; r++) {
        uint8_t seed[32];
        brw_traj tr;
        memset(&tr, 0, sizeof tr);
        if (brw_world_seed(label, parent, plen, r, seed) != BRW_OK ||
            brw_world_generate(&ci->s, seed, &tr, NULL) != BRW_OK ||
            brw_qbw_encode(&tr, &g->buf[r], &g->len[r]) != BRW_OK) {
            brw_traj_free(&tr);
            WHY("world generation failed at repetition %zu", r); free(rl); genset_free(g); g->W = 0; return TYQ_FAIL_PROTOCOL; }
        brw_traj_free(&tr);
        brw_sha256(g->buf[r], g->len[r], &g->dg[r]);
        rl[r].rep = r; rl[r].d = g->dg[r];
    }
    size_t mcap = g->W * 100 + 64;
    g->man = malloc(mcap);
    if (!g->man || tyqr_repman_build(rl, g->W, g->man, mcap, &g->man_len) != TY_OK) {
        WHY("cannot build the trajectory sidecar"); free(rl); genset_free(g); return TYQ_E_IO; }
    tyqr_sidecar_digest(g->man, g->man_len, &g->man_d);
    free(rl);
    return 0;
}

static int genset_write(const genset *g, const char *outdir, int excl, char *why, size_t cap) {
    char p[BRW_PATH], h[65];
    for (size_t r = 0; r < g->W; r++) {
        ty_hex(&g->dg[r], h);
        if (brw_join(p, sizeof p, outdir, "%s.qbw", h) != 0) return TYQ_E_ARG;
        int rc = excl ? brw_write_excl(p, g->buf[r], g->len[r]) : write_named(p, g->buf[r], g->len[r]);
        if (rc) { WHY("cannot write trajectory file %s (%s)", h, rc == TYQR_E_EXISTS ? "already exists" : "io"); return rc == TYQR_E_EXISTS ? TYQ_FAIL_PROTOCOL : rc; }
    }
    ty_hex(&g->man_d, h);
    if (brw_join(p, sizeof p, outdir, "traj.%s.man", h) != 0) return TYQ_E_ARG;
    int rc = excl ? brw_write_excl(p, g->man, g->man_len) : write_named(p, g->man, g->man_len);
    if (rc) { WHY("cannot write the trajectory sidecar"); return rc == TYQR_E_EXISTS ? TYQ_FAIL_PROTOCOL : rc; }
    return 0;
}

static int genset_precheck_absent(const genset *g, const char *outdir, char *why, size_t cap) {
    char p[BRW_PATH], h[65];
    for (size_t r = 0; r < g->W; r++) {
        ty_hex(&g->dg[r], h);
        if (brw_join(p, sizeof p, outdir, "%s.qbw", h) != 0) return TYQ_E_ARG;
        if (exists(p)) { WHY("sealed generation refused: trajectory file %s already exists", h); return TYQ_FAIL_PROTOCOL; }
    }
    ty_hex(&g->man_d, h);
    if (brw_join(p, sizeof p, outdir, "traj.%s.man", h) != 0) return TYQ_E_ARG;
    if (exists(p)) { WHY("sealed generation refused: trajectory sidecar already exists"); return TYQ_FAIL_PROTOCOL; }
    return 0;
}

static void fill_world_rec(tyqr_world *w, const ty_digest *qprofile, const char *mode, const char *kind,
                           const ty_digest *qfreeze, const char *cell, uint64_t block, const char *label,
                           const ty_digest *generator, const genset *g) {
    memset(w, 0, sizeof *w);
    w->qprofile = *qprofile;
    snprintf(w->mode, sizeof w->mode, "%s", mode);
    snprintf(w->parent_kind, sizeof w->parent_kind, "%s", kind);
    if (qfreeze) w->qfreeze = *qfreeze;
    snprintf(w->cell, sizeof w->cell, "%s", cell);
    w->block = block;
    snprintf(w->label, sizeof w->label, "%s", label);
    snprintf(w->gen_version, sizeof w->gen_version, "%s", BRW_GEN_VERSION);
    w->generator = *generator;
    w->rep_first = 0; w->rep_count = g->W;
    w->traj_manifest = g->man_d;
    snprintf(w->traj_format, sizeof w->traj_format, "%s", "brw.traj.v1");
}

/* Load and check the W trajectories of a world from `dir`: sidecar digest, every file's name and content digest. */
typedef struct { brw_traj *t; size_t W; } trajset;
static void trajset_free(trajset *s) {
    for (size_t i = 0; i < s->W; i++) brw_traj_free(&s->t[i]);
    free(s->t); memset(s, 0, sizeof *s);
}
static int trajset_load(const char *dir, const tyqr_world *w, trajset *s, char *why, size_t cap) {
    char p[BRW_PATH], h[65];
    brw_bytes mb;
    memset(s, 0, sizeof *s);
    ty_hex(&w->traj_manifest, h);
    if (brw_join(p, sizeof p, dir, "traj.%s.man", h) != 0 || brw_slurp(p, &mb) != 0) { WHY("trajectory sidecar is missing"); return TYQ_FAIL_DIGEST; }
    ty_digest md;
    tyqr_sidecar_digest((const char *)mb.b, mb.n, &md);
    if (!ty_digest_eq(&md, &w->traj_manifest)) { brw_bytes_free(&mb); WHY("trajectory sidecar bytes do not match the world record"); return TYQ_FAIL_DIGEST; }
    size_t n = 0;
    tyqr_repline *rl = calloc(w->rep_count ? w->rep_count : 1, sizeof *rl);
    if (!rl || tyqr_repman_parse((const char *)mb.b, mb.n, rl, (size_t)w->rep_count, &n) != TY_OK || n != w->rep_count) {
        brw_bytes_free(&mb); free(rl); WHY("trajectory sidecar is malformed or has the wrong number of lines"); return TYQ_FAIL_DIGEST; }
    brw_bytes_free(&mb);
    s->t = calloc(n ? n : 1, sizeof *s->t);
    if (!s->t) { free(rl); WHY("out of memory"); return TYQ_E_IO; }
    s->W = n;
    for (size_t i = 0; i < n; i++) {
        brw_bytes b; ty_digest d;
        if (rl[i].rep != w->rep_first + i) { WHY("trajectory sidecar reps are not first..first+count-1"); free(rl); trajset_free(s); return TYQ_FAIL_DIGEST; }
        ty_hex(&rl[i].d, h);
        if (brw_join(p, sizeof p, dir, "%s.qbw", h) != 0 || brw_slurp(p, &b) != 0) { WHY("trajectory file %s is missing", h); free(rl); trajset_free(s); return TYQ_FAIL_DIGEST; }
        brw_sha256(b.b, b.n, &d);
        if (!ty_digest_eq(&d, &rl[i].d)) { WHY("trajectory file %s does not match its digest", h); brw_bytes_free(&b); free(rl); trajset_free(s); return TYQ_FAIL_DIGEST; }
        int rc = brw_qbw_decode(b.b, b.n, &s->t[i]);
        brw_bytes_free(&b);
        if (rc != BRW_OK) { WHY("trajectory file %s is not valid QBW1", h); free(rl); trajset_free(s); s->W = 0; return TYQ_FAIL_DIGEST; }
    }
    free(rl);
    return 0;
}

/* -------------------------------------------------------------- step 2: dev worlds */
int brw_dev_block(const brw_env *env, const char *outdir, const char *cell, uint32_t block, const ty_digest *qprofile,
                  tyqr_world *w, ty_digest *wd, char *why, size_t cap) {
    brw_cellinfo ci; ty_digest gen; genset g; char label[128];
    if (brw_cellinfo_get(cell, &ci) != 0) { WHY("unknown cell"); return TYQ_E_ARG; }
    if (brw_generator_digest_of(env, &gen) != 0) { WHY("cannot compute the generator digest"); return TYQ_E_IO; }
    int rc = genset_make(&ci, "dev", block, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), &g, label, sizeof label, why, cap);
    if (rc) return rc;
    rc = genset_write(&g, outdir, 0, why, cap);
    if (rc == 0) {
        tyqr_world tmp;
        fill_world_rec(&tmp, qprofile, "dev", "dev", NULL, ci.s.name, block, label, &gen, &g);
        ty_digest d;
        char path[BRW_PATH];
        rc = tyqr_world_write(outdir, &tmp, &d, path, sizeof path);
        if (rc == TYQR_E_EXISTS) rc = 0;   /* deterministic: the same dev block written again is the same file */
        if (rc != 0) { WHY("cannot write the qworld record"); rc = TYQ_E_IO; }
        else { if (w) *w = tmp; if (wd) *wd = d; }
    }
    genset_free(&g);
    return rc;
}

/* ------------------------------------------------- devman (evaluator) and devman.pub (producer, G7) */
static int devline_cmp(const void *a, const void *b) {
    const tyqr_devline *x = a, *y = b;
    int c = strcmp(x->cell, y->cell);
    if (c) return c;
    return x->block < y->block ? -1 : x->block > y->block;
}

static int write_replace(const char *path, const void *b, size_t n) {
    char tmp[BRW_PATH + 8];
    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    unlink(tmp);
    int fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0644);
    if (fd < 0) return TYQ_E_IO;
    const uint8_t *q = b;
    size_t left = n;
    while (left) {
        ssize_t w = write(fd, q, left);
        if (w < 0 && errno == EINTR) continue;
        if (w <= 0) { close(fd); unlink(tmp); return TYQ_E_IO; }
        q += w; left -= (size_t)w;
    }
    if (close(fd) != 0 || rename(tmp, path) != 0) { unlink(tmp); return TYQ_E_IO; }
    return 0;
}

static int pub_cmp(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }

int brw_devman_refresh(const char *dir, ty_digest *digest, char *why, size_t cap) {
    char **names; size_t nn;
    if (list_dir(dir, "turing.qworld.", ".omg0", &names, &nn) != 0) { WHY("cannot read the directory"); return TYQ_E_IO; }
    tyqr_devline *dl = calloc(nn ? nn : 1, sizeof *dl);
    char **pub = NULL; size_t npub = 0, pcap = 0;
    int rc = 0;
    size_t nd = 0;
    for (size_t i = 0; i < nn && rc == 0; i++) {
        char p[BRW_PATH]; tyqr_world w; ty_digest d;
        brw_join(p, sizeof p, dir, "%s", names[i]);
        if (brw_load_world(p, &w, &d, why, cap) != 0) { rc = TYQ_FAIL_DIGEST; break; }
        if (strcmp(w.mode, "dev") != 0) continue;
        snprintf(dl[nd].cell, sizeof dl[nd].cell, "%.127s", w.cell);
        dl[nd].block = w.block; dl[nd].d = d;
        nd++;
        trajset ts;
        char why2[BRW_WHY];
        if (trajset_load(dir, &w, &ts, why2, sizeof why2) != 0) { WHY("%s", why2); rc = TYQ_FAIL_DIGEST; break; }
        trajset_free(&ts);
        /* producer list: sha8 and sha256 of every qbw file of this world, read from its sidecar */
        char mp[BRW_PATH], mh[65]; brw_bytes mb;
        ty_hex(&w.traj_manifest, mh);
        brw_join(mp, sizeof mp, dir, "traj.%s.man", mh);
        if (brw_slurp(mp, &mb) != 0) { rc = TYQ_E_IO; break; }
        tyqr_repline *rl = calloc((size_t)w.rep_count + 1, sizeof *rl);
        size_t n = 0;
        if (rl && tyqr_repman_parse((const char *)mb.b, mb.n, rl, (size_t)w.rep_count, &n) == TY_OK) {
            for (size_t k = 0; k < n; k++) {
                char h[65]; ty_hex(&rl[k].d, h);
                if (npub == pcap) { pcap = pcap ? pcap * 2 : 1024; pub = realloc(pub, pcap * sizeof *pub); }
                pub[npub] = malloc(8 + 1 + 64 + 2);
                snprintf(pub[npub], 8 + 1 + 64 + 2, "%.8s %s\n", h, h);
                npub++;
            }
        } else rc = TYQ_E_IO;
        free(rl); brw_bytes_free(&mb);
    }
    free_names(names, nn);
    if (rc == 0) {
        qsort(dl, nd, sizeof *dl, devline_cmp);
        for (size_t i = 1; i < nd; i++)
            if (devline_cmp(&dl[i - 1], &dl[i]) == 0) { WHY("two dev worlds for the same cell and block"); rc = TYQ_FAIL_PROTOCOL; }
    }
    if (rc == 0) {
        size_t mcap = nd * (TYQR_CELL_MAX + 100) + 64, ml = 0;
        char *m = malloc(mcap);
        if (!m || tyqr_devman_build(dl, nd, m, mcap, &ml) != TY_OK) { WHY("cannot build the dev manifest"); rc = TYQ_E_IO; }
        else {
            char p[BRW_PATH];
            brw_join(p, sizeof p, dir, "devman.txt");
            rc = write_replace(p, m, ml);
            if (rc == 0 && digest) tyqr_sidecar_digest(m, ml, digest);
        }
        free(m);
    }
    if (rc == 0) {
        /* brw.devman.pub.v1: `<sha8> <sha256>` sorted by sha8, no cell, block or label (G7); duplicates removed */
        qsort(pub, npub, sizeof *pub, pub_cmp);
        size_t tot = 0;
        for (size_t i = 0; i < npub; i++) tot += strlen(pub[i]);
        char *m = malloc(tot + 1);
        size_t o = 0;
        for (size_t i = 0; i < npub; i++)
            if (i == 0 || strcmp(pub[i], pub[i - 1]) != 0) { size_t l = strlen(pub[i]); memcpy(m + o, pub[i], l); o += l; }
        char p[BRW_PATH];
        brw_join(p, sizeof p, dir, "devman.pub.txt");
        rc = write_replace(p, m, o);
        free(m);
    }
    for (size_t i = 0; i < npub; i++) free(pub[i]);
    free(pub); free(dl);
    return rc;
}

int brw_devman_load(const char *devman_path, tyqr_devline **lines, size_t *n, char *why, size_t cap) {
    brw_bytes b;
    *lines = NULL; *n = 0;
    if (brw_slurp(devman_path, &b) != 0) { WHY("cannot read the dev manifest"); return TYQ_E_IO; }
    size_t cnt = 0;
    for (size_t i = 0; i < b.n; i++) if (b.b[i] == '\n') cnt++;
    tyqr_devline *dl = calloc(cnt ? cnt : 1, sizeof *dl);
    int rc = 0;
    if (!dl || tyqr_devman_parse((const char *)b.b, b.n, dl, cnt, n) != TY_OK) { WHY("the dev manifest is malformed"); free(dl); rc = TYQ_FAIL_DIGEST; }
    else *lines = dl;
    brw_bytes_free(&b);
    return rc;
}

/* ------------------------------------------------- calibration file brw.calib.v1 (R3-24 U6) */
static const char *const STAT_NAMES[6] = { "mean_z", "mean_z2", "ac1", "spearman_z2_t", "slope_z_yprev", "exkurt" };

static int frozen_cmp(const void *a, const void *b) {
    return strcmp(BRW_FROZEN_NULLS[*(const int *)a].cell, BRW_FROZEN_NULLS[*(const int *)b].cell);
}

/* header line `brw.calib.v1`, then LF lines `<cell> <stat> <center> <lo> <hi>` (reals %.17g), cells in byte order,
 * stats in the fixed order above. The content is the frozen table of DESIGN_CHECK_R2 (brw_stats.c). */
int brw_calib_render(char *out, size_t cap, size_t *len) {
    int idx[16];
    size_t n = BRW_FROZEN_NULLS_N, o = 0;
    if (n > 16) return TYQ_E_ARG;
    for (size_t i = 0; i < n; i++) idx[i] = (int)i;
    qsort(idx, n, sizeof idx[0], frozen_cmp);
    int k = snprintf(out, cap, "brw.calib.v1\n");
    o = (size_t)k;
    for (size_t i = 0; i < n; i++) {
        const brw_frozen_null *f = &BRW_FROZEN_NULLS[idx[i]];
        for (int s = 0; s < 6; s++) {
            k = snprintf(out + o, cap - o, "%s %s %.17g %.17g %.17g\n", f->cell, STAT_NAMES[s], f->nc.center[s], f->nc.lo[s], f->nc.hi[s]);
            if (k < 0 || (size_t)k >= cap - o) return TYQ_E_ARG;
            o += (size_t)k;
        }
    }
    *len = o;
    return 0;
}

/* refuse (FAIL_PROFILE) a calibration file that is not the frozen table's rendering, optionally followed by
 * occ_cross lines (U6, R3-28d): `occ_cross <H dec> <s %.17g>`, H strictly ascending, LF-terminated, nothing else. */
int brw_calib_check(const char *path, ty_digest *d, char *why, size_t cap) {
    static char want[16384];
    size_t wl = 0;
    brw_bytes b;
    if (brw_calib_render(want, sizeof want, &wl) != 0) { WHY("cannot render the frozen calibration table"); return TYQ_E_ARG; }
    if (brw_slurp(path, &b) != 0) { WHY("cannot read the calibration file"); return TYQ_E_IO; }
    int same = b.n >= wl && memcmp(b.b, want, wl) == 0;
    if (same) {
        const char *p = (const char *)b.b + wl, *end = (const char *)b.b + b.n;
        long prevH = -1;
        while (same && p < end) {
            const char *nl = memchr(p, '\n', (size_t)(end - p));
            if (!nl) { same = 0; break; }
            char ln[128]; size_t L = (size_t)(nl - p);
            if (L == 0 || L >= sizeof ln) { same = 0; break; }
            memcpy(ln, p, L); ln[L] = 0;
            char *tk[4]; int k = 0; char *q = ln;
            for (;;) { if (k == 3) { k = 4; break; } tk[k++] = q; char *sp = strchr(q, ' '); if (!sp) break; *sp = 0; q = sp + 1; }
            char *e1, *e2;
            if (k != 3 || strcmp(tk[0], "occ_cross") != 0 || !*tk[1] || !*tk[2]) { same = 0; break; }
            errno = 0; long H = strtol(tk[1], &e1, 10);
            double s = strtod(tk[2], &e2);
            if (*e1 || errno || H <= prevH || H < 1 || *e2 || errno == ERANGE || !isfinite(s) || tk[1][0] == '+' || tk[1][0] == '0') same = 0;
            prevH = H; p = nl + 1;
        }
    }
    if (same && d) brw_sha256(b.b, b.n, d);
    brw_bytes_free(&b);
    if (!same) { WHY("calibration file is not the frozen brw.calib.v1 table plus optional occ_cross lines"); return TYQ_FAIL_PROFILE; }
    return 0;
}

/* ------------------------------------------------------------------ step 5: freeze */
static int meta_apply(tyqr_freeze *f, const char *key, const char *v, char *why, size_t cap) {
    if (strlen(v) >= TYQR_VAL) { WHY("meta value too long: %s", key); return TYQ_E_ARG; }
#define SETS(name) if (strcmp(key, #name) == 0) { snprintf(f->name, sizeof f->name, "%s", v); return 0; }
    SETS(mode) SETS(artifact_kind) SETS(b2_emerging_label) SETS(bayes_plugin_check) SETS(diag_fw_rate_ppm)
    SETS(lengthening_test) SETS(stability_test) SETS(base_commits) SETS(producer_tool) SETS(producer_model)
#undef SETS
    if (strcmp(key, "run_commit") == 0) { snprintf(f->run_commit, sizeof f->run_commit, "%.40s", v); return 0; }
    if (strcmp(key, "tree_dirty") == 0) { f->tree_dirty = strtoull(v, NULL, 10); return 0; }
    if (strcmp(key, "n_lineage") == 0) { f->n_lineage = strtoull(v, NULL, 10); return 0; }
    if (strcmp(key, "prompt_digest") == 0) return ty_parse_hex(v, &f->prompt_digest) == 0 ? 0 : TYQ_E_ARG;
    if (strcmp(key, "transcript_digest") == 0) return ty_parse_hex(v, &f->transcript_digest) == 0 ? 0 : TYQ_E_ARG;
    if (strncmp(key, "lineage.", 8) == 0) {
        unsigned i = (unsigned)strtoul(key + 8, NULL, 10);
        if (i >= TYQR_MAX_LINEAGE) return TYQ_E_ARG;
        return ty_parse_hex(v, &f->lineage[i]) == 0 ? 0 : TYQ_E_ARG;
    }
    WHY("unknown or derived meta key: %s", key);
    return TYQ_E_ARG;
}

static int meta_load(const char *path, tyqr_freeze *f, char *why, size_t cap) {
    brw_bytes b;
    if (brw_slurp(path, &b) != 0) { WHY("cannot read the meta file"); return TYQ_E_IO; }
    char *s = (char *)b.b, *save = NULL;
    int rc = 0;
    for (char *l = strtok_r(s, "\n", &save); l && rc == 0; l = strtok_r(NULL, "\n", &save)) {
        if (l[0] == 0 || l[0] == '#') continue;
        char *eq = strchr(l, '=');
        if (!eq) { WHY("meta line without ="); rc = TYQ_E_ARG; break; }
        *eq = 0;
        rc = meta_apply(f, l, eq + 1, why, cap);
        if (rc && !(why && why[0])) WHY("bad meta value for %s", l);
    }
    brw_bytes_free(&b);
    return rc;
}

int brw_freeze(const brw_freeze_args *a, tyqr_freeze *fout, ty_digest *fd, char *why, size_t cap) {
    tyqr_freeze f; tyqr_profile pr; ty_digest pd, cd, ad;
    brw_bytes ab;
    memset(&f, 0, sizeof f);
    if (!a || !a->artifact || !a->qprofile || !a->devman || !a->calibration || !a->meta || !a->outdir) { WHY("freeze needs artifact, qprofile, dev manifest, calibration, meta and out"); return TYQ_E_ARG; }
    int rc = brw_load_profile(a->qprofile, &pr, &pd, why, cap);
    if (rc) return rc;
    f.qprofile = pd;
    /* derived fields first so a meta file cannot override them */
    if ((rc = meta_load(a->meta, &f, why, cap)) != 0) return rc;
    if (strcmp(f.mode, "certification") != 0 && strcmp(f.mode, "discovery") != 0) { WHY("meta mode must be certification or discovery"); return TYQ_E_ARG; }
    int cert = strcmp(f.mode, "certification") == 0;
    if (!f.artifact_kind[0]) snprintf(f.artifact_kind, sizeof f.artifact_kind, "%s", cert ? "brw_predict.c" : "brwdl");   /* UNDECIDED for certification; U3 names brwdl */
    if (cert) {
        snprintf(f.producer_tool, sizeof f.producer_tool, "%s", "none");
        snprintf(f.producer_model, sizeof f.producer_model, "%s", "none");
    }
    /* artifact */
    if (brw_slurp(a->artifact, &ab) != 0) { WHY("cannot read the artifact"); return TYQ_E_IO; }
    brw_sha256(ab.b, ab.n, &ad);
    if (!cert) {
        brw_prog pg; char err[128];
        if (brw_prog_from_bytes(ab.b, (int)ab.n, &pg, err, sizeof err) != TYQ_OK) { brw_bytes_free(&ab); WHY("artifact is not a valid BRW-DL program: %s", err); return TYQ_FAIL_PROTOCOL; }
    }
    brw_bytes_free(&ab);
    f.artifact = ad;
    if (!cert) {
        brw_bytes ib;
        if (!a->interp || brw_slurp(a->interp, &ib) != 0) { WHY("discovery freeze needs the interpreter executable (--interp)"); return TYQ_E_ARG; }
        brw_sha256(ib.b, ib.n, &f.artifact_bin);
        brw_bytes_free(&ib);
    }
    /* calibration (G3) */
    if ((rc = brw_calib_check(a->calibration, &cd, why, cap)) != 0) return rc;
    {
        char ch[65], th[65];
        ty_hex(&cd, ch);
        if (a->turing_profile) {
            ty_digest t;
            if (ty_parse_hex(a->turing_profile, &t) != 0) { WHY("turing profile is not 64 hex digits"); return TYQ_E_ARG; }
            snprintf(th, sizeof th, "%s", a->turing_profile);
        } else memset(th, '0', 64), th[64] = 0;
        snprintf(f.calibration_extra, sizeof f.calibration_extra, "calib=%s turing_profile=%s", ch, th);
    }
    /* dev manifest: every line names a dev qworld under this profile in the manifest's directory */
    {
        brw_bytes mb; tyqr_devline *dl; size_t n;
        if (brw_slurp(a->devman, &mb) != 0) { WHY("cannot read the dev manifest"); return TYQ_E_IO; }
        tyqr_sidecar_digest((const char *)mb.b, mb.n, &f.dev_manifest);
        brw_bytes_free(&mb);
        if ((rc = brw_devman_load(a->devman, &dl, &n, why, cap)) != 0) return rc;
        char dir[BRW_PATH];
        brw_dir_of(a->devman, dir, sizeof dir);
        if (n == 0) { free(dl); WHY("the dev manifest is empty"); return TYQ_FAIL_PROFILE; }
        for (size_t i = 0; i < n; i++) {
            char p[BRW_PATH]; tyqr_world w; ty_digest d;
            brw_record_path(p, sizeof p, dir, "turing.qworld", &dl[i].d);
            if (brw_load_world(p, &w, &d, why, cap) != 0) { free(dl); return TYQ_FAIL_DIGEST; }
            if (strcmp(w.mode, "dev") != 0 || !ty_digest_eq(&w.qprofile, &pd) || strcmp(w.cell, dl[i].cell) != 0 || w.block != dl[i].block) {
                free(dl); WHY("dev manifest line %zu does not match its qworld or qprofile", i); return TYQ_FAIL_PROFILE; }
        }
        free(dl);
    }
    ty_digest d;
    char path[BRW_PATH];
    rc = tyqr_freeze_write(a->outdir, &f, &d, path, sizeof path);
    if (rc == TYQR_E_EXISTS) { WHY("qfreeze already exists: a freeze is written once"); return TYQR_E_EXISTS; }
    if (rc != TY_OK) { WHY("omega refused the qfreeze record"); return TYQ_FAIL_PROFILE; }
    if (fout) *fout = f;
    if (fd) *fd = d;
    return 0;
}

/* ---------------------------------------------------------------- steps 6-7: seal */
int brw_seal_check(const char *qfreeze_path, const char *artifact_path, const char *cell, brw_seal_ctx *ctx,
                   char *why, size_t cap) {
    memset(ctx, 0, sizeof *ctx);
    if (!qfreeze_path || !exists(qfreeze_path)) { WHY("sealed generation refused: no qfreeze"); return TYQ_FAIL_PROTOCOL; }
    int rc = brw_load_freeze(qfreeze_path, &ctx->freeze, &ctx->freeze_d, why, cap);
    if (rc) return rc;
    char dir[BRW_PATH], pp[BRW_PATH];
    brw_dir_of(qfreeze_path, dir, sizeof dir);
    brw_record_path(pp, sizeof pp, dir, "turing.qprofile", &ctx->freeze.qprofile);
    if (!exists(pp)) { WHY("sealed generation refused: the qprofile named by the qfreeze is not beside it"); return TYQ_FAIL_PROFILE; }
    if (brw_load_profile(pp, &ctx->profile, &ctx->profile_d, why, cap) != 0) return TYQ_FAIL_PROFILE;
    if (!ty_digest_eq(&ctx->profile_d, &ctx->freeze.qprofile)) { WHY("qprofile digest differs from the qfreeze"); return TYQ_FAIL_PROFILE; }
    brw_bytes ab;
    if (!artifact_path || brw_slurp(artifact_path, &ab) != 0) { WHY("cannot read the artifact"); return TYQ_E_IO; }
    ty_digest ad;
    brw_sha256(ab.b, ab.n, &ad);
    brw_bytes_free(&ab);
    if (!ty_digest_eq(&ad, &ctx->freeze.artifact)) { WHY("sealed generation refused: artifact digest differs from the qfreeze"); return TYQ_FAIL_DIGEST; }
    brw_cellinfo ci;
    if (brw_cellinfo_get(cell, &ci) != 0) { WHY("unknown cell"); return TYQ_E_ARG; }
    if (ci.hostile) { WHY("hostile cells are development only and are never sealed"); return TYQ_FAIL_PROTOCOL; }
    if (ctx->freeze.tree_dirty) { WHY("sealed generation refused: the tree was dirty at freeze"); return TYQ_FAIL_PROTOCOL; }
    /* plan §16 row 5-6 and step 5 pre-seal confirmations: a recorded failure stops the run; the seed is never opened (UNDECIDED: exact stop wording) */
    if (strcmp(ctx->freeze.stability_test, "PASS") != 0 || strcmp(ctx->freeze.lengthening_test, "PASS") != 0 || strcmp(ctx->freeze.bayes_plugin_check, "AGREE") != 0) {
        WHY("STOPPED: a pre-seal confirmation recorded in the qfreeze did not pass (stability, lengthening or Bayes/plug-in check)"); return BRW_STOPPED; }
    brw_sealed_parent(ctx->freeze_d.b, ctx->parent);
    return 0;
}

int brw_seal(const brw_env *env, const char *qfreeze_path, const char *artifact_path, const char *cell,
             const char *outdir, const char *ledger_dir, tyqr_world *w, ty_digest *wd, char *why, size_t cap) {
    brw_seal_ctx c;
    int rc = brw_seal_check(qfreeze_path, artifact_path, cell, &c, why, cap);
    if (rc) return rc;
    char ld[BRW_PATH], lp[BRW_PATH], a8[9], p8[9];
    if (ledger_dir) snprintf(ld, sizeof ld, "%s", ledger_dir); else brw_dir_of(qfreeze_path, ld, sizeof ld);
    hex8(&c.freeze.artifact, a8); hex8(&c.profile_d, p8);
    brw_join(lp, sizeof lp, ld, "attempt.%s.%s.%s", a8, p8, cell);
    if (exists(lp)) { WHY("a sealed attempt for this candidate and profile already exists"); return BRW_STOPPED; }
    brw_cellinfo ci; ty_digest gen; genset g; char label[128];
    brw_cellinfo_get(cell, &ci);
    if (brw_generator_digest_of(env, &gen) != 0) { WHY("cannot compute the generator digest"); return TYQ_E_IO; }
    rc = genset_make(&ci, "seal", 0, c.parent, 32, &g, label, sizeof label, why, cap);
    if (rc) return rc;
    if ((rc = genset_precheck_absent(&g, outdir, why, cap)) != 0) { genset_free(&g); return rc; }
    rc = brw_write_excl(lp, "sealed\n", 7);
    if (rc == TYQR_E_EXISTS) { genset_free(&g); WHY("a sealed attempt for this candidate and profile already exists"); return BRW_STOPPED; }
    if (rc) { genset_free(&g); WHY("cannot write the attempt ledger"); return TYQ_E_IO; }
    rc = genset_write(&g, outdir, 1, why, cap);
    if (rc == 0) {
        tyqr_world tmp; ty_digest d; char path[BRW_PATH];
        fill_world_rec(&tmp, &c.profile_d, c.freeze.mode, "sealed", &c.freeze_d, ci.s.name, 0, label, &gen, &g);
        if (tyqr_world_write(outdir, &tmp, &d, path, sizeof path) != TY_OK) { WHY("cannot write the sealed qworld record"); rc = TYQ_E_IO; }
        else { if (w) *w = tmp; if (wd) *wd = d; }
    }
    genset_free(&g);
    return rc;
}

/* ---------------------------------------------------------------- PRD1 builders */
int brw_prd_for_program(const brw_prog *p, const brw_traj *tr, const brw_cell_spec *cs, brw_bytes *out, char *why, size_t cap) {
    uint32_t split = cs && tr ? brw_world_split(cs, tr) : 0;
    out->b = NULL; out->n = 0;
    if (!p || !tr || tr->count <= split || tr->count > BRW_MAXPOINTS) { WHY("bad trajectory for prediction"); return TYQ_E_ARG; }
    /* set-state cells: fit on split - 1 rows, the set-state row is queried but never scored, the PRD1 covers the scored rows [split, N) */
    size_t N = (size_t)tr->count, S = split, Sf = brw_world_fit_split(cs, tr), Hf = N - Sf, H = N - S;
    double *y = malloc(N * sizeof *y);
    tyq_pred *pr = malloc(Hf * sizeof *pr);
    if (!y || !pr) { free(y); free(pr); WHY("out of memory"); return TYQ_E_IO; }
    for (size_t i = 0; i < N; i++) y[i] = brw_symbol_value(tr->k[i]);
    const char *w = "";
    int rc = brw_predict_fit_once(p, tr->t, y, N, Sf, pr, &w);
    if (rc != TYQ_OK) { WHY("predictor refused: %s", w); free(y); free(pr); return rc; }
    ty_prd prd = { (uint32_t)H, (uint32_t)S, pr + (S - Sf) };
    uint8_t *buf = NULL; size_t len = 0;
    rc = ty_prd_encode(&prd, &buf, &len);
    free(y); free(pr);
    if (rc != TYQ_OK) { WHY("cannot encode PRD1"); return rc; }
    out->b = buf; out->n = len;
    return 0;
}

int brw_prd_manifest(const brw_bytes *prd, size_t W, brw_bytes *man, ty_digest *man_d) {
    tyqr_repline *rl = calloc(W ? W : 1, sizeof *rl);
    size_t cap = W * 100 + 64, len = 0;
    char *m = malloc(cap);
    if (!rl || !m) { free(rl); free(m); return TYQ_E_IO; }
    for (size_t i = 0; i < W; i++) { rl[i].rep = i; brw_sha256(prd[i].b, prd[i].n, &rl[i].d); }
    int rc = tyqr_repman_build(rl, W, m, cap, &len) == TY_OK ? 0 : TYQ_E_IO;
    free(rl);
    if (rc) { free(m); return rc; }
    man->b = (uint8_t *)m; man->n = len;
    tyqr_sidecar_digest(m, len, man_d);
    return 0;
}

/* write W PRD1 files (<hex>.prd) and their sidecar (prd.<hex>.man) into dir */
static int prd_write_set(const char *dir, const brw_bytes *prd, size_t W, ty_digest *man_d, char *why, size_t cap) {
    brw_bytes man; char p[BRW_PATH], h[65];
    for (size_t i = 0; i < W; i++) {
        ty_digest d;
        brw_sha256(prd[i].b, prd[i].n, &d);
        ty_hex(&d, h);
        if (brw_join(p, sizeof p, dir, "%s.prd", h) != 0 || write_named(p, prd[i].b, prd[i].n) != 0) { WHY("cannot write PRD1 file"); return TYQ_E_IO; }
    }
    if (brw_prd_manifest(prd, W, &man, man_d) != 0) { WHY("cannot build the PRD1 sidecar"); return TYQ_E_IO; }
    ty_hex(man_d, h);
    int rc = brw_join(p, sizeof p, dir, "prd.%s.man", h);
    if (rc == 0) rc = write_named(p, man.b, man.n);
    brw_bytes_free(&man);
    if (rc) { WHY("cannot write the PRD1 sidecar"); return TYQ_E_IO; }
    return 0;
}

/* load the W PRD1 files named by prd.<man>.man in dir; every name and digest is checked */
static int prd_load_set(const char *dir, const ty_digest *man_d, size_t W, brw_bytes **out, char *why, size_t cap) {
    char p[BRW_PATH], h[65];
    brw_bytes mb;
    *out = NULL;
    ty_hex(man_d, h);
    if (brw_join(p, sizeof p, dir, "prd.%s.man", h) != 0 || brw_slurp(p, &mb) != 0) { WHY("PRD1 sidecar %s is missing", h); return TYQ_FAIL_DIGEST; }
    ty_digest md;
    tyqr_sidecar_digest((const char *)mb.b, mb.n, &md);
    tyqr_repline *rl = calloc(W ? W : 1, sizeof *rl);
    size_t n = 0;
    if (!ty_digest_eq(&md, man_d) || !rl || tyqr_repman_parse((const char *)mb.b, mb.n, rl, W, &n) != TY_OK || n != W) {
        brw_bytes_free(&mb); free(rl); WHY("PRD1 sidecar is tampered or has the wrong number of lines"); return TYQ_FAIL_DIGEST; }
    brw_bytes_free(&mb);
    brw_bytes *arr = calloc(W ? W : 1, sizeof *arr);
    for (size_t i = 0; i < W; i++) {
        ty_hex(&rl[i].d, h);
        ty_digest d;
        if (rl[i].rep != i || brw_join(p, sizeof p, dir, "%s.prd", h) != 0 || brw_slurp(p, &arr[i]) != 0) {
            WHY("PRD1 file %s is missing", h); goto bad; }
        brw_sha256(arr[i].b, arr[i].n, &d);
        if (!ty_digest_eq(&d, &rl[i].d)) { WHY("PRD1 file %s does not match its digest", h); goto bad; }
    }
    free(rl);
    *out = arr;
    return 0;
bad:
    for (size_t i = 0; i < W; i++) brw_bytes_free(&arr[i]);
    free(arr); free(rl);
    return TYQ_FAIL_DIGEST;
}
static void prd_free_set(brw_bytes *a, size_t W) { if (!a) return; for (size_t i = 0; i < W; i++) brw_bytes_free(&a[i]); free(a); }

/* -------------------------------------------------------------------- analysis seed, labels */
void brw_analysis_seed(const char *mode, const char *cell, uint64_t block, const uint8_t parent[32], uint8_t out[32]) {
    char s[512];
    int n = snprintf(s, sizeof s, "brownian.v1|analysis|%s|%s|%llu", mode, cell, (unsigned long long)block);
    sha256_ctx c;
    uint8_t z = 0;
    sha256_init(&c);
    sha256_update(&c, (const uint8_t *)s, (size_t)n);
    sha256_update(&c, &z, 1);
    sha256_update(&c, parent, 32);
    sha256_final(&c, out);
}

/* R3-26 G6: disjoint labels. POSITIVE lower > 0; NEGATIVE upper < 0; WEAK covers 0 and point > 0;
 * AMBIGUOUS covers 0 and point <= 0. */
const char *brw_class_label(int64_t t, int64_t lo, int64_t hi) {
    if (lo > 0) return "POSITIVE";
    if (hi < 0) return "NEGATIVE";
    return t > 0 ? "WEAK" : "AMBIGUOUS";
}

/* -------------------------------------------------------------------- gain */
/* R3-30c (spec line 356): nb_w = 2 H (0.5 + q) + 1 ub; q = the b^2/8 qint bound at sd_min (b = 2^-10) plus 1e-9 bit, in ub;
 * the final +1 is both L(M) roundings of 0.5 ub. Long double, rounded up to an integer ub. */
int64_t brw_numeric_bound_world_ub(size_t H) {
    long double q = (-log2l(1.0L - ldexpl(1.0L, -23)) + 1e-9L) * 1e6L;
    return (int64_t)ceill(2.0L * (long double)H * (0.5L + q) + 1.0L);
}

/* ---- leak oracle (spec §7 "Oracle and leak ceiling", hostile #5 and #6) ---- */
/* The oracle uses the true family and true parameters and conditions on the revealed y = (k+0.5) delta of the previous
 * point (never the latent x, OI-8). Per world diff_w = L(D_w|oracle) - L(D_w|M), predictive micro-bits only, no L(M)
 * on either side; FAIL_LEAK iff the world-bootstrap 2.5% bound of sum diff_w is above 0. Evaluated where the true
 * one-step predictive given the revealed y is Gaussian up to the quantizer: not on the measurement-noise, Student-t
 * and outlier cells (flag INCONCLUSIVE; FAIL_LEAK is not evaluated there).
 * The true parameters are not stored anywhere: they are regenerated from the parent seed and label exactly as the
 * generator made the world, and the regenerated symbols must equal the stored ones (a mismatch is FAIL_DIGEST). */
int brw_leak_check(const brw_cellinfo *ci, const char *label_mode, uint64_t block, const uint8_t *parent, size_t plen,
                   const brw_traj *tr, size_t W, const brw_bytes *prd_m, const uint8_t analysis_seed[32], uint32_t B,
                   char flag[16], int64_t *lo_out, int64_t *hi_out, char *why, size_t cap) {
    snprintf(flag, 16, "INCONCLUSIVE");
    if (lo_out) *lo_out = 0;
    if (hi_out) *hi_out = 0;
    if (ci->s.obs == BRW_OBS_MEAS_NOISE || ci->s.obs == BRW_OBS_T4_INNOV || ci->s.obs == BRW_OBS_OUTLIER) return 0;
    uint32_t S;
    char label[128];
    int64_t *diff = calloc(W ? W : 1, sizeof *diff);
    tyq_pred *op = calloc((size_t)ci->s.n_points + 1, sizeof *op);
    if (!diff || !op) { free(diff); free(op); WHY("out of memory"); return TYQ_E_IO; }
    int rc = 0;
    if (brw_world_label(label_mode, ci->s.name, block, label, sizeof label) != BRW_OK) { WHY("cannot form the world label"); rc = TYQ_E_ARG; goto out; }
    for (size_t w = 0; w < W; w++) {
        uint8_t seed[32];
        brw_traj g;
        brw_params par; size_t Hw; S = brw_world_split(&ci->s, &tr[w]);
        memset(&g, 0, sizeof g); memset(&par, 0, sizeof par);
        if (brw_world_seed(label, parent, plen, w, seed) != BRW_OK || brw_world_generate(&ci->s, seed, &g, &par) != BRW_OK) {
            brw_traj_free(&g); WHY("leak oracle: cannot regenerate world %zu", w); rc = TYQ_FAIL_PROTOCOL; goto out; }
        int same = g.count == tr[w].count && memcmp(g.k, tr[w].k, g.count * sizeof *g.k) == 0 && memcmp(g.t, tr[w].t, g.count * sizeof *g.t) == 0;
        brw_traj_free(&g);
        if (!same) { WHY("leak oracle: world %zu is not the world the seed generates", w); rc = TYQ_FAIL_DIGEST; goto out; }
        if (tr[w].count <= S || tr[w].count > ci->s.n_points) { WHY("leak oracle: world %zu has no held-out rows", w); rc = TYQ_FAIL_PROTOCOL; goto out; }
        Hw = (size_t)tr[w].count - S;
        for (size_t j = 0; j < Hw; j++) {
            size_t i = (size_t)S + j;
            double mean, var, c = ci->s.obs == BRW_OBS_AFFINE ? par.aff_c : 1.0, b = ci->s.obs == BRW_OBS_AFFINE ? par.aff_b : 0.0;
            double yprev = brw_symbol_value(tr[w].k[i - 1]);
            if (brw_transition(ci->s.family, &par, (yprev - b) / c, tr[w].t[i] - tr[w].t[i - 1], &mean, &var) != BRW_OK) {
                WHY("leak oracle: transition refused"); rc = TYQ_FAIL_PROTOCOL; goto out; }
            memset(&op[j], 0, sizeof op[j]);
            op[j].index = (uint32_t)i; op[j].family = TYQ_FAM_GAUSS;
            op[j].loc = c * mean + b; op[j].scale = fabs(c) * sqrt(var);
        }
        int64_t lo_ld, lm_ld;
        uint64_t fh;
        ty_prd prd;
        memset(&prd, 0, sizeof prd);
        if (ty_prd_parse(prd_m[w].b, prd_m[w].n, S, (uint32_t)Hw, &prd) != TYQ_OK ||
            ty_qcont_sum_ub(prd.rec, tr[w].k + S, Hw, &lm_ld, &fh) != TYQ_OK) {
            ty_prd_free(&prd); WHY("leak oracle: candidate predictions cannot be scored"); rc = TYQ_FAIL_PROTOCOL; goto out; }
        ty_prd_free(&prd);
        if (ty_qcont_sum_ub(op, tr[w].k + S, Hw, &lo_ld, &fh) != TYQ_OK || ty_sub(lo_ld, lm_ld, &diff[w])) {
            WHY("leak oracle: oracle predictions cannot be scored"); rc = TYQ_FAIL_PROTOCOL; goto out; }
    }
    {
        ClRng boot; int64_t lo = 0, hi = 0;
        if (brw_boot_init(&boot, analysis_seed) != BRW_OK || brw_bootstrap_interval(diff, W, 0, B, &boot, &lo, &hi, NULL) != BRW_OK) {
            WHY("leak oracle: bootstrap failed"); rc = TYQ_FAIL_PROTOCOL; goto out; }
        if (lo_out) *lo_out = lo;
        if (hi_out) *hi_out = hi;
        if (lo > 0) { snprintf(flag, 16, "1"); WHY("FAIL_LEAK: the candidate beats the oracle (bootstrap 2.5%% bound of the summed difference is %lld ub, above 0)", (long long)lo); rc = TYQ_FAIL_LEAK; }
        else snprintf(flag, 16, "0");
    }
out:
    free(diff); free(op);
    return rc;
}

int brw_gain_compute(const brw_gain_in *in, tyqr_gain *g, char *why, size_t cap) {
    const brw_cellinfo *ci = &in->ci;
    size_t W = in->W, H = ci->H;
    uint32_t S = ci->s.split;
    uint32_t Sf = S - (ci->s.set_state ? 1u : 0u);   /* fit prefix length: 128 on the set-state cells, the rider charges log2(Sf - 1) */
    memset(g, 0, sizeof *g);
    if (W != ci->W || H == 0) { WHY("world count does not match the cell table"); return TYQ_FAIL_PROFILE; }
    int rc;
    int64_t *diff = calloc(W, sizeof *diff);
    int64_t dB = 0, dM = 0, rB = 0, rM = 0, riderB1, riderM1;
    uint64_t fhB = 0, fhM = 0;
    if (!diff) { WHY("out of memory"); return TYQ_E_IO; }
    if (ty_qcont_rider_ub((uint32_t)in->pb->info.k, Sf - 1, &riderB1) || ty_qcont_rider_ub((uint32_t)in->pm->info.k, Sf - 1, &riderM1)) {
        free(diff); WHY("rider computation failed"); return TYQ_FAIL_PROTOCOL; }
    for (size_t w = 0; w < W; w++) {
        if (in->tr[w].count != ci->s.n_points) { free(diff); WHY("trajectory length does not match the cell"); return TYQ_FAIL_PROFILE; }
        int64_t ld[2]; uint64_t fh[2];
        for (int m = 0; m < 2; m++) {
            const brw_bytes *pb = m ? &in->prd_m[w] : &in->prd_b[w];
            ty_prd prd;
            memset(&prd, 0, sizeof prd);
            rc = ty_prd_parse(pb->b, pb->n, S, (uint32_t)H, &prd);
            if (rc != TYQ_OK) { free(diff); WHY("%s PRD1 of world %zu is invalid", m ? "candidate" : "baseline", w); return TYQ_FAIL_PROTOCOL; }
            rc = ty_qcont_sum_ub(prd.rec, in->tr[w].k + S, H, &ld[m], &fh[m]);
            ty_prd_free(&prd);
            if (rc != TYQ_OK) { free(diff); WHY("%s predictions could not be scored (non-finite or overflow)", m ? "candidate" : "baseline"); return TYQ_FAIL_PROTOCOL; }
        }
        int64_t a = 0, b2 = 0, d;
        if (ty_add(ld[0], riderB1, &a) || ty_add(ld[1], riderM1, &b2) || ty_sub(a, b2, &d) ||
            ty_add(dB, ld[0], &dB) || ty_add(dM, ld[1], &dM) || ty_add(rB, riderB1, &rB) || ty_add(rM, riderM1, &rM)) {
            free(diff); WHY("integer overflow while scoring"); return TYQ_FAIL_PROTOCOL; }
        diff[w] = d;
        fhB += fh[0]; fhM += fh[1];
    }
    int64_t LB, LM, LDB, LDM, DLB, DLM, t, cell_term;
    if (ty_qcont_bytes_ub((uint32_t)in->pb->n, &LB) || ty_qcont_bytes_ub((uint32_t)in->pm->n, &LM) ||
        ty_add(dB, rB, &LDB) || ty_add(dM, rM, &LDM) || ty_add(LB, LDB, &DLB) || ty_add(LM, LDM, &DLM) ||
        ty_gain(DLB, DLM, &t) || ty_sub(LB, LM, &cell_term)) { free(diff); WHY("integer overflow in totals"); return TYQ_FAIL_PROTOCOL; }
    uint8_t parent[32], seed[32];
    brw_sealed_parent(in->freeze_d.b, parent);
    brw_analysis_seed(in->world->mode, ci->s.name, in->world->block, parent, seed);
    char leak_flag[16];
    int leak_rc = brw_leak_check(ci, "seal", 0, parent, 32, in->tr, W, in->prd_m, seed, (uint32_t)in->profile->bootstrap_b, leak_flag, NULL, NULL, why, cap);
    if (leak_rc != 0 && leak_rc != TYQ_FAIL_LEAK) { free(diff); return leak_rc; }
    ClRng boot; int64_t lo = 0, hi = 0; double mc = 0;
    if (brw_boot_init(&boot, seed) != BRW_OK || brw_bootstrap_interval(diff, W, cell_term, (uint32_t)in->profile->bootstrap_b, &boot, &lo, &hi, &mc) != BRW_OK) {
        free(diff); WHY("bootstrap failed"); return TYQ_FAIL_PROTOCOL; }
    free(diff);
    uint64_t scored = (uint64_t)W * H;
    g->qprofile = in->profile_d; g->qworld = in->world_d; g->qfreeze = in->freeze_d;
    snprintf(g->mode, sizeof g->mode, "%s", in->world->mode);
    snprintf(g->cell, sizeof g->cell, "%s", ci->s.name);
    snprintf(g->gen_version, sizeof g->gen_version, "%s", in->world->gen_version);
    g->baseline_opcode = (uint64_t)in->base_op; g->baseline_artifact = in->baseline_artifact;
    g->candidate = in->candidate; g->candidate_opcode = (uint64_t)in->cand_op;
    g->prd_b = in->prdman_b; g->prd_m = in->prdman_m;
    int declared = brw_declared_baseline(in->profile, ci->experiment);
    if (declared && declared == in->base_op) { g->official = 1; snprintf(g->ladder_item, sizeof g->ladder_item, "-"); }
    else {
        if (!in->ladder_item || !in->ladder_item[0] || strcmp(in->ladder_item, "-") == 0 || strchr(in->ladder_item, ' ')) {
            WHY("baseline is not the declared one: a ladder item is required"); return TYQ_FAIL_BASELINE; }
        g->official = 0; snprintf(g->ladder_item, sizeof g->ladder_item, "%s", in->ladder_item);
    }
    g->lengths[0] = LB; g->lengths[1] = LDB; g->lengths[2] = LM; g->lengths[3] = LDM; g->lengths[4] = DLB; g->lengths[5] = DLM;
    g->t_ub = t; g->t_lo_ub = lo; g->t_hi_ub = hi;
    g->numeric_bound_ub = (int64_t)W * brw_numeric_bound_world_ub(H);   /* R3-30c: per-world bound summed over worlds (G12) */
    g->mc_err_ub = llrint(1e6 * mc);
    g->counts[0] = in->profile->bootstrap_b; g->counts[1] = W; g->counts[2] = H; g->counts[3] = scored;
    g->floor_hits = fhM;
    g->protocol_failures = 0;
    snprintf(g->leak_flag, sizeof g->leak_flag, "%s", leak_flag);
    g->coverage[0] = g->coverage[1] = g->coverage[2] = -1;         /* UNDECIDED: coverage items are not implemented */
    snprintf(g->diag_warnings, sizeof g->diag_warnings, "-");
    snprintf(g->unit, sizeof g->unit, "%s", in->profile->unit);
    if (leak_rc == TYQ_FAIL_LEAK) {   /* leakage is reported before the floor: it is the more serious finding */
        snprintf(g->status, sizeof g->status, "FAIL_LEAK");
        snprintf(g->classification, sizeof g->classification, "STOPPED");
        return TYQ_FAIL_LEAK;
    }
    int frc = ty_qcont_floor_check(fhM, scored) != TYQ_OK || ty_qcont_floor_check(fhB, scored) != TYQ_OK ? TYQ_FAIL_FLOOR : 0;
    if (frc) {
        snprintf(g->status, sizeof g->status, "FAIL_FLOOR");
        snprintf(g->classification, sizeof g->classification, "STOPPED");
        WHY("floor count above 1000 ppm of scored points");
        return TYQ_FAIL_FLOOR;
    }
    snprintf(g->status, sizeof g->status, "PASS");
    snprintf(g->classification, sizeof g->classification, "%s", brw_class_label(t, lo, hi));
    return 0;
}

/* ---------------------------------------------------------------- packet scanner (spec §16, plan §10) */
static int is_wc(int c) { return isalnum(c) != 0; }

int brw_scan_text(const char *buf, size_t len, char *why, size_t cap) {
    static const char *const PHRASES[] = { "brownian", "wiener", "diffusion", "ornstein", "uhlenbeck", "langevin",
        "gaussian increment", "drift coefficient", "mean reversion", "mean reverting", "white noise",
        "mass", "force", "energy", "momentum", "charge", "temperature", "velocity", "acceleration", NULL };
    static const char *const SYMBOLS[] = { "G", "c", "h-bar", "k_B", "epsilon_0", NULL };
    char *n = malloc(len + 1);
    if (!n) return TYQ_E_IO;
    size_t o = 0;
    /* lower case; hyphen, underscore and any whitespace become one space */
    for (size_t i = 0; i < len; i++) {
        unsigned char ch = (unsigned char)buf[i];
        char c = (ch == '-' || ch == '_' || isspace(ch)) ? ' ' : (char)tolower(ch);
        if (c == ' ' && o > 0 && n[o - 1] == ' ') continue;
        n[o++] = c;
    }
    n[o] = 0;
    for (const char *const *p = PHRASES; *p; p++) {
        size_t pl = strlen(*p);
        for (char *at = n; (at = strstr(at, *p)) != NULL; at++) {
            int before = at == n || !is_wc((unsigned char)at[-1]);
            int after = !is_wc((unsigned char)at[pl]);
            if (before && after) { WHY("packet scanner hit: %s", *p); free(n); return TYQ_FAIL_PROTOCOL; }
        }
    }
    free(n);
    /* named symbols: case-sensitive whole tokens; a token is a maximal run of letters, digits, underscore, hyphen */
    size_t i = 0;
    while (i < len) {
        while (i < len && !(isalnum((unsigned char)buf[i]) || buf[i] == '_' || buf[i] == '-')) i++;
        size_t s = i;
        while (i < len && (isalnum((unsigned char)buf[i]) || buf[i] == '_' || buf[i] == '-')) i++;
        if (i > s)
            for (const char *const *y = SYMBOLS; *y; y++)
                if (strlen(*y) == i - s && memcmp(buf + s, *y, i - s) == 0) { WHY("packet scanner hit: symbol %s", *y); return TYQ_FAIL_PROTOCOL; }
    }
    return 0;
}

/* Seed scan (spec §16 "The candidate never receives ... any seed"; hostile #5). The word list already refuses every seed
 * label (each contains "brownian"). This scan looks for the secret seed VALUES themselves: a 32-byte seed as 64 hex
 * digits, its first 8 bytes as 16 hex digits, and each of its four little-endian state words as 0x%016llx or as a
 * decimal number, matched case-insensitively. It is never a blanket hex rule: brw_dl_spec.txt legitimately carries the
 * BRW-DL specification hash. */
int brw_seed_scan(const char *buf, size_t len, const uint8_t (*seeds)[32], size_t n, char *why, size_t cap) {
    char *lc = malloc(len + 1);
    if (!lc) return TYQ_E_IO;
    for (size_t i = 0; i < len; i++) lc[i] = (char)tolower((unsigned char)buf[i]);
    lc[len] = 0;
    int rc = 0;
    for (size_t s = 0; s < n && rc == 0; s++) {
        char hx[65], pat[32];
        static const char D[] = "0123456789abcdef";
        for (int i = 0; i < 32; i++) { hx[2 * i] = D[seeds[s][i] >> 4]; hx[2 * i + 1] = D[seeds[s][i] & 15]; }
        hx[64] = 0;
        if (strstr(lc, hx)) { WHY("seed scan hit: a 32-byte seed appears as 64 hex digits"); rc = TYQ_FAIL_PROTOCOL; break; }
        hx[16] = 0;
        if (strstr(lc, hx)) { WHY("seed scan hit: the first 8 bytes of a seed appear as hex"); rc = TYQ_FAIL_PROTOCOL; break; }
        for (int w = 0; w < 4 && rc == 0; w++) {
            unsigned long long v = 0;
            for (int i = 7; i >= 0; i--) v = (v << 8) | seeds[s][8 * w + i];
            snprintf(pat, sizeof pat, "0x%016llx", v);
            if (strstr(lc, pat)) { WHY("seed scan hit: a seed state word appears as 0x%016llx", v); rc = TYQ_FAIL_PROTOCOL; break; }
            snprintf(pat, sizeof pat, "%llu", v);
            for (const char *at = lc; (at = strstr(at, pat)) != NULL; at++) {
                int before = at == lc || !isdigit((unsigned char)at[-1]);
                int after = !isdigit((unsigned char)at[strlen(pat)]);
                if (before && after && strlen(pat) >= 10) { WHY("seed scan hit: a seed state word appears as a decimal number"); rc = TYQ_FAIL_PROTOCOL; break; }
            }
        }
    }
    free(lc);
    return rc;
}

/* the two packet text files against the secret seeds of the run: the sealed parent and every sealed world seed */
static int packet_seed_scan(const char *dir, const char *cell, const uint8_t parent[32], size_t W, char *why, size_t cap) {
    static const char *const FILES[] = { "packet.txt", "brw_dl_spec.txt" };
    char label[128];
    uint8_t (*seeds)[32] = calloc(W + 1, 32);
    if (!seeds) return TYQ_E_IO;
    memcpy(seeds[0], parent, 32);
    int rc = 0;
    if (brw_world_label("seal", cell, 0, label, sizeof label) != BRW_OK) rc = TYQ_E_ARG;
    for (size_t w = 0; rc == 0 && w < W; w++) if (brw_world_seed(label, parent, 32, w, seeds[w + 1]) != BRW_OK) rc = TYQ_E_ARG;
    for (int f = 0; rc == 0 && f < 2; f++) {
        char p[BRW_PATH];
        brw_bytes b;
        brw_join(p, sizeof p, dir, "%s", FILES[f]);
        if (access(p, F_OK) != 0) continue;
        if (brw_slurp(p, &b) != 0) { WHY("cannot read %s", FILES[f]); rc = TYQ_E_IO; break; }
        rc = brw_seed_scan((const char *)b.b, b.n, (const uint8_t (*)[32])seeds, W + 1, why, cap);
        brw_bytes_free(&b);
    }
    free(seeds);
    return rc;
}

int brw_packet_scan(const char *dir, char *why, size_t cap) {
    DIR *d = opendir(dir);
    if (!d) { WHY("cannot open the packet directory"); return TYQ_E_IO; }
    struct dirent *e;
    int rc = 0;
    while (rc == 0 && (e = readdir(d)) != NULL) {
        const char *nm = e->d_name;
        char p[BRW_PATH];
        if (strcmp(nm, ".") == 0 || strcmp(nm, "..") == 0) continue;
        brw_join(p, sizeof p, dir, "%s", nm);
        if (strcmp(nm, "packet.txt") == 0 || strcmp(nm, "brw_dl_spec.txt") == 0) {
            brw_bytes b;
            if (brw_slurp(p, &b) != 0) { WHY("cannot read %s", nm); rc = TYQ_E_IO; break; }
            rc = brw_scan_text((const char *)b.b, b.n, why, cap);
            brw_bytes_free(&b);
            continue;
        }
        int ok = 0;
        if (strlen(nm) != 18) ok = 0;   /* "world_" + 8 hex + ".qbw" */
        else {
            ok = strncmp(nm, "world_", 6) == 0 && strcmp(nm + 14, ".qbw") == 0;
            for (int i = 6; ok && i < 14; i++) ok = (nm[i] >= '0' && nm[i] <= '9') || (nm[i] >= 'a' && nm[i] <= 'f');
        }
        if (!ok) { WHY("packet allow-list: %s is not packet.txt, brw_dl_spec.txt or world_<sha8>.qbw", nm); rc = TYQ_FAIL_PROTOCOL; break; }
        brw_bytes b; ty_digest dg; brw_traj tr;
        if (brw_slurp(p, &b) != 0) { WHY("cannot read %s", nm); rc = TYQ_E_IO; break; }
        brw_sha256(b.b, b.n, &dg);
        char h[65]; ty_hex(&dg, h);
        if (strncmp(nm + 6, h, 8) != 0) { WHY("packet file %s: name is not the first 8 hex of its SHA-256", nm); rc = TYQ_FAIL_PROTOCOL; }
        else if (brw_qbw_decode(b.b, b.n, &tr) != BRW_OK) { WHY("packet file %s is not valid QBW1", nm); rc = TYQ_FAIL_PROTOCOL; }
        else brw_traj_free(&tr);
        brw_bytes_free(&b);
    }
    closedir(d);
    return rc;
}

/* ------------------------------------------------- sandbox (spec §12, R3-24 U2) and line protocol brw.line.v1 */
#define BRW_BWRAP "/usr/bin/bwrap"
#define LINE_MAX_BYTES 4096
#define REPLY_MS 10000            /* the per-reply wall limit of 10 s stays (R3-26 G2) */
#define NOTE_MAX (63 * 1024)

/* The frozen argv. Only the two paths are substituted for "<interp>" and "<prog>". */
static const char *const SBX_ARGV[] = { BRW_BWRAP, "--unshare-all", "--die-with-parent", "--new-session", "--clearenv",
    "--ro-bind", "<interp>", "/interp", "--ro-bind", "<prog>", "/prog", "--proc", "/proc", "--dev", "/dev",
    "--chdir", "/", "/interp", "--line", "/prog", NULL };
const char *const *brw_sandbox_argv(void) { return SBX_ARGV; }

typedef struct {
    pid_t pid;
    int in, out, err;
    char ob[LINE_MAX_BYTES + 2]; size_t on;     /* stdout line buffer */
    char *note; size_t note_cap, note_n;        /* captured stderr */
} sbx;

static long now_ms(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (long)t.tv_sec * 1000 + t.tv_nsec / 1000000; }

static void sbx_kill(sbx *s) {
    if (s->pid > 0) { kill(s->pid, SIGKILL); waitpid(s->pid, NULL, 0); s->pid = 0; }
    if (s->in >= 0) close(s->in);
    if (s->out >= 0) close(s->out);
    if (s->err >= 0) close(s->err);
    s->in = s->out = s->err = -1;
}

/* R3-26 G2: RLIMIT_CPU = 10 s x held-out points + 10 s; AS 1 GiB; FSIZE 0; NOFILE 16; CORE 0; NO_NEW_PRIVS.
 * The rlimits are applied to bwrap itself, so they hold for every process in the sandbox.
 * R3-30b: one sandbox serves all W worlds of a cell, so the caller passes cpu_s = 10 x W x (N-SPLIT) + 10; correct as written. */
static void set_limits(unsigned long long cpu_s) {
    struct rlimit r;
    r.rlim_cur = r.rlim_max = (rlim_t)cpu_s; setrlimit(RLIMIT_CPU, &r);
    r.rlim_cur = r.rlim_max = (rlim_t)1 << 30; setrlimit(RLIMIT_AS, &r);
    r.rlim_cur = r.rlim_max = 0; setrlimit(RLIMIT_FSIZE, &r);
    r.rlim_cur = r.rlim_max = 16; setrlimit(RLIMIT_NOFILE, &r);
    r.rlim_cur = r.rlim_max = 0; setrlimit(RLIMIT_CORE, &r);
    prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
}

static int sbx_spawn(const char *exe, const char *prog, unsigned long long cpu_s, sbx *s, char *note, size_t note_cap) {
    int pi[2], po[2], pe[2];
    memset(s, 0, sizeof *s);
    s->in = s->out = s->err = -1;
    s->note = note; s->note_cap = note_cap;
    if (note && note_cap) note[0] = 0;
    if (pipe2(pi, O_CLOEXEC) || pipe2(po, O_CLOEXEC) || pipe2(pe, O_CLOEXEC)) return -1;
    char *argv[24];
    size_t n = 0;
    for (; SBX_ARGV[n]; n++) {
        if (strcmp(SBX_ARGV[n], "<interp>") == 0) argv[n] = (char *)exe;
        else if (strcmp(SBX_ARGV[n], "<prog>") == 0) argv[n] = (char *)prog;
        else argv[n] = (char *)SBX_ARGV[n];
    }
    argv[n] = NULL;
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) {
        char *envp[1] = { NULL };
        dup2(pi[0], 0); dup2(po[1], 1); dup2(pe[1], 2);
        set_limits(cpu_s);
        execve(BRW_BWRAP, argv, envp);
        dprintf(2, "bwrap: cannot exec %s\n", BRW_BWRAP);
        _exit(127);
    }
    close(pi[0]); close(po[1]); close(pe[1]);
    s->pid = pid; s->in = pi[1]; s->out = po[0]; s->err = pe[0];
    fcntl(s->out, F_SETFL, O_NONBLOCK); fcntl(s->err, F_SETFL, O_NONBLOCK); fcntl(s->in, F_SETFL, O_NONBLOCK);
    return 0;
}

static void drain_err(sbx *s) {
    char b[1024];
    for (;;) {
        ssize_t r = read(s->err, b, sizeof b);
        if (r <= 0) break;
        if (s->note && s->note_n + 1 < s->note_cap && s->note_n < NOTE_MAX) {
            size_t k = (size_t)r;
            if (k > s->note_cap - 1 - s->note_n) k = s->note_cap - 1 - s->note_n;
            if (s->note_n + k > NOTE_MAX) k = NOTE_MAX - s->note_n;
            memcpy(s->note + s->note_n, b, k); s->note_n += k; s->note[s->note_n] = 0;
        }
    }
}

enum { LN_OK = 0, LN_TIMEOUT = 1, LN_EOF = 2, LN_BAD = 3 };

/* one ASCII line from the child's stdout, at most 4096 bytes, printable ASCII only */
static int read_line(sbx *s, char *line, int timeout_ms) {
    long end = now_ms() + timeout_ms;
    for (;;) {
        char *nl = memchr(s->ob, '\n', s->on);
        if (nl) {
            size_t l = (size_t)(nl - s->ob);
            if (l > LINE_MAX_BYTES) return LN_BAD;
            for (size_t i = 0; i < l; i++) if ((unsigned char)s->ob[i] < 0x20 || (unsigned char)s->ob[i] > 0x7e) return LN_BAD;
            memcpy(line, s->ob, l); line[l] = 0;
            memmove(s->ob, nl + 1, s->on - l - 1); s->on -= l + 1;
            return LN_OK;
        }
        if (s->on > LINE_MAX_BYTES) return LN_BAD;
        long left = end - now_ms();
        if (left <= 0) return LN_TIMEOUT;
        struct pollfd p[2] = { { s->out, POLLIN, 0 }, { s->err, POLLIN, 0 } };
        int pr = poll(p, 2, (int)left);
        if (pr < 0 && errno != EINTR) return LN_EOF;
        if (p[1].revents & (POLLIN | POLLHUP)) drain_err(s);
        if (p[0].revents & (POLLIN | POLLHUP)) {
            ssize_t r = read(s->out, s->ob + s->on, sizeof s->ob - s->on);
            if (r == 0) { drain_err(s); return LN_EOF; }
            if (r > 0) s->on += (size_t)r;
        }
    }
}

static int write_line(sbx *s, const char *fmt, ...) {
    char b[512];
    va_list ap; va_start(ap, fmt);
    int n = vsnprintf(b, sizeof b, fmt, ap);
    va_end(ap);
    if (n < 0 || (size_t)n >= sizeof b) return -1;
    size_t off = 0;
    long end = now_ms() + REPLY_MS;
    while (off < (size_t)n) {
        ssize_t w = write(s->in, b + off, (size_t)n - off);
        if (w > 0) { off += (size_t)w; continue; }
        if (w < 0 && errno == EINTR) continue;
        if (w < 0 && errno != EAGAIN) return -1;
        long left = end - now_ms();
        if (left <= 0) return -1;
        struct pollfd p[2] = { { s->in, POLLOUT, 0 }, { s->err, POLLIN, 0 } };
        poll(p, 2, (int)left);
        if (p[1].revents & POLLIN) drain_err(s);
    }
    return 0;
}

/* strict token split on single spaces; returns the count */
static int split_tokens(char *line, char **tok, int max) {
    int n = 0;
    char *p = line;
    for (;;) {
        if (n == max) return max + 1;
        tok[n++] = p;
        char *sp = strchr(p, ' ');
        if (!sp) break;
        *sp = 0; p = sp + 1;
    }
    return n;
}

static int parse_real(const char *s, double *v) {
    if (!*s) return -1;
    char *e; errno = 0;
    double x = strtod(s, &e);
    if (*e || errno == ERANGE || !isfinite(x)) return -1;
    *v = x;
    return 0;
}

int brw_run_in_sandbox(const char *exe, const char *prog, const brw_traj *tr, size_t W, const brw_cell_spec *cs,
                       brw_bytes *prd_out, char *note, size_t note_cap, char *why, size_t cap) {
    sbx s;
    int rc = TYQ_FAIL_PROTOCOL;
    for (size_t i = 0; i < W; i++) { prd_out[i].b = NULL; prd_out[i].n = 0; }
    if (access(BRW_BWRAP, X_OK) != 0) { WHY("BLOCKED: /usr/bin/bwrap is not present or not executable"); return BRW_BLOCKED; }
    if (!exe || !prog || (W && (!tr || !cs || tr[0].count <= brw_world_split(cs, &tr[0])))) { WHY("bad sandbox arguments"); return TYQ_E_ARG; }
    unsigned long long held = 0; for (size_t q = 0; q < W; q++) held += tr[q].count - brw_world_fit_split(cs, &tr[q]);   /* the set-state row is queried too (its reply is discarded) */
    void (*old)(int) = signal(SIGPIPE, SIG_IGN);
    if (sbx_spawn(exe, prog, 10ull * held + 10ull, &s, note, note_cap) != 0) { signal(SIGPIPE, old); WHY("cannot start the sandbox"); return TYQ_E_IO; }
    char line[LINE_MAX_BYTES + 2];
    /* handshake: `B 1` -> `R 1` (an interpreter extension of brw.line.v1 that separates BLOCKED from FAIL_PROTOCOL) */
    if (write_line(&s, "B 1\n") != 0) goto proto;
    int lr = read_line(&s, line, REPLY_MS);
    if (lr != LN_OK || strcmp(line, "R 1") != 0) {
        int st = 0;
        usleep(200000);
        drain_err(&s);
        pid_t w = waitpid(s.pid, &st, WNOHANG);
        if (w == s.pid) s.pid = 0;
        int bw = note && strncmp(note, "bwrap:", 6) == 0;
        sbx_kill(&s); signal(SIGPIPE, old);
        if (bw) { WHY("BLOCKED: bwrap cannot run here: %s", note); return BRW_BLOCKED; }
        WHY("FAIL_PROTOCOL: no valid handshake from the interpreter"); return TYQ_FAIL_PROTOCOL;
    }
    for (size_t w = 0; w < W; w++) {
        uint32_t split = brw_world_split(cs, &tr[w]), fit = brw_world_fit_split(cs, &tr[w]);   /* fit = split - 1 on the set-state cells */
        if (tr[w].count <= split) { WHY("FAIL_PROTOCOL: world %zu has no held-out rows", w); rc = TYQ_FAIL_PROTOCOL; goto out; }
        size_t N = (size_t)tr[w].count, H = N - split;
        tyq_pred *pr = calloc(H, sizeof *pr);
        if (!pr) { rc = TYQ_E_IO; WHY("out of memory"); goto out; }
        if (write_line(&s, "W %zu %u\n", N, fit) != 0) { free(pr); goto proto; }
        for (size_t i = 0; i < N; i++) {
            if (i < fit) { if (write_line(&s, "O %zu %.17g %.17g\n", i, tr[w].t[i], brw_symbol_value(tr[w].k[i])) != 0) { free(pr); goto proto; } continue; }
            if (write_line(&s, "Q %zu %.17g\n", i, tr[w].t[i]) != 0) { free(pr); goto proto; }
            lr = read_line(&s, line, REPLY_MS);
            if (lr != LN_OK) { free(pr); WHY("FAIL_PROTOCOL: no valid reply for point %zu of world %zu (%s)", i, w, lr == LN_TIMEOUT ? "10 s wall limit" : lr == LN_EOF ? "interpreter exited" : "malformed line"); goto out; }
            char *tok[6]; double loc, sc;
            if (split_tokens(line, tok, 4) != 4 || strcmp(tok[0], "N") != 0 || strcmp(tok[1], "") == 0 ||
                strtoul(tok[1], NULL, 10) != i || parse_real(tok[2], &loc) || parse_real(tok[3], &sc) || sc <= 0) {
                free(pr); WHY("FAIL_PROTOCOL: reply for point %zu of world %zu is not `N i loc scale` with finite loc and scale > 0", i, w); goto out; }
            if (i >= split) { pr[i - split].index = (uint32_t)i; pr[i - split].family = TYQ_FAM_GAUSS; pr[i - split].loc = loc; pr[i - split].scale = sc; }   /* index fit .. split - 1 (the set-state row) is answered, not scored */
            if (write_line(&s, "O %zu %.17g %.17g\n", i, tr[w].t[i], brw_symbol_value(tr[w].k[i])) != 0) { free(pr); goto proto; }
        }
        ty_prd prd = { (uint32_t)H, split, pr };
        uint8_t *buf; size_t len;
        int er = ty_prd_encode(&prd, &buf, &len);
        free(pr);
        if (er != TYQ_OK) { WHY("FAIL_PROTOCOL: predictions cannot be encoded as PRD1"); goto out; }
        prd_out[w].b = buf; prd_out[w].n = len;
    }
    if (write_line(&s, "X\n") != 0) goto proto;
    {
        /* the interpreter must exit 0 and send nothing more */
        long end = now_ms() + REPLY_MS;
        int st = 0;
        for (;;) {
            drain_err(&s);
            pid_t w = waitpid(s.pid, &st, WNOHANG);
            if (w == s.pid) { s.pid = 0; break; }
            if (now_ms() > end) { WHY("FAIL_PROTOCOL: the interpreter did not exit after X"); goto out; }
            usleep(2000);
        }
        drain_err(&s);
        char extra[64];
        ssize_t r = read(s.out, extra, sizeof extra);
        if (s.on > 0 || r > 0) { WHY("FAIL_PROTOCOL: extra output after X"); goto out; }
        if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) { WHY("FAIL_PROTOCOL: the interpreter did not exit 0"); goto out; }
    }
    rc = 0;
    goto out;
proto:
    WHY("FAIL_PROTOCOL: the interpreter stopped reading input or exited early");
out:
    sbx_kill(&s);
    signal(SIGPIPE, old);
    if (rc != 0) for (size_t i = 0; i < W; i++) brw_bytes_free(&prd_out[i]);
    return rc;
}

int brw_run_discovery(const char *interp_cmd, const char *artifact_path, const brw_traj *tr, size_t W, const brw_cell_spec *cs,
                      brw_bytes *prd_out, char *note, size_t note_cap, char *why, size_t cap) {
    return brw_run_in_sandbox(interp_cmd, artifact_path, tr, W, cs, prd_out, note, note_cap, why, cap);
}

/* ---------------------------------------------------------------- score / verify / replay */
typedef struct {
    char dir[BRW_PATH];
    tyqr_profile pr; ty_digest pd;
    tyqr_freeze fr; ty_digest fd;
    tyqr_world wo; ty_digest wdg;
    brw_cellinfo ci;
    trajset ts;
    brw_prog pb, pm;
    int base_op, cand_op;
    ty_digest base_art;
} chain;

static void chain_free(chain *c) { trajset_free(&c->ts); }

/* load qprofile, qfreeze, qworld from one directory (names from the digests) and check their links */
static int chain_records(chain *c, const char *dir, const ty_digest *fd, const ty_digest *wd, char *why, size_t cap) {
    char p[BRW_PATH];
    int rc;
    snprintf(c->dir, sizeof c->dir, "%s", dir);
    brw_record_path(p, sizeof p, dir, "turing.qfreeze", fd);
    if ((rc = brw_load_freeze(p, &c->fr, &c->fd, why, cap)) != 0) return rc;
    brw_record_path(p, sizeof p, dir, "turing.qworld", wd);
    if ((rc = brw_load_world(p, &c->wo, &c->wdg, why, cap)) != 0) return rc;
    brw_record_path(p, sizeof p, dir, "turing.qprofile", &c->fr.qprofile);
    if (brw_load_profile(p, &c->pr, &c->pd, why, cap) != 0) return TYQ_FAIL_PROFILE;
    if (!ty_digest_eq(&c->pd, &c->fr.qprofile) || !ty_digest_eq(&c->wo.qprofile, &c->pd)) { WHY("the qfreeze and the qworld name different qprofiles"); return TYQ_FAIL_PROFILE; }
    if (strcmp(c->wo.parent_kind, "sealed") != 0 || !ty_digest_eq(&c->wo.qfreeze, &c->fd)) { WHY("the qworld is not sealed by this qfreeze"); return TYQ_FAIL_PROTOCOL; }
    if (strcmp(c->wo.mode, c->fr.mode) != 0) { WHY("the qworld mode differs from the qfreeze mode"); return TYQ_FAIL_PROTOCOL; }
    if (brw_cellinfo_get(c->wo.cell, &c->ci) != 0) { WHY("the qworld names an unknown cell"); return TYQ_FAIL_PROFILE; }
    return trajset_load(dir, &c->wo, &c->ts, why, cap);
}

/* the baseline (always a reference program) and its artifact digest */
static int chain_baseline(chain *c, int op, char *why, size_t cap) {
    if (op < 1 || op > 7 || brw_ref_program(op, &c->pb) != TYQ_OK) { WHY("unknown baseline opcode"); return TYQ_FAIL_BASELINE; }
    c->base_op = op;
    brw_sha256(c->pb.bytes, (size_t)c->pb.n, &c->base_art);
    return 0;
}

static void gain_stub(tyqr_gain *g, const chain *c, const char *status, const char *ladder, int declared_match) {
    memset(g, 0, sizeof *g);
    g->qprofile = c->pd; g->qworld = c->wdg; g->qfreeze = c->fd;
    snprintf(g->mode, sizeof g->mode, "%s", c->wo.mode);
    snprintf(g->cell, sizeof g->cell, "%s", c->ci.s.name);
    snprintf(g->gen_version, sizeof g->gen_version, "%s", c->wo.gen_version);
    g->baseline_opcode = (uint64_t)c->base_op; g->baseline_artifact = c->base_art;
    g->candidate = c->fr.artifact; g->candidate_opcode = (uint64_t)c->cand_op;
    g->official = declared_match ? 1 : 0;
    snprintf(g->ladder_item, sizeof g->ladder_item, "%s", declared_match ? "-" : ladder);
    g->counts[0] = c->pr.bootstrap_b; g->counts[1] = c->ci.W; g->counts[2] = c->ci.H;
    snprintf(g->leak_flag, sizeof g->leak_flag, "INCONCLUSIVE");
    g->coverage[0] = g->coverage[1] = g->coverage[2] = -1;
    snprintf(g->diag_warnings, sizeof g->diag_warnings, "-");
    snprintf(g->classification, sizeof g->classification, "STOPPED");
    snprintf(g->status, sizeof g->status, "%s", status);
    snprintf(g->unit, sizeof g->unit, "%s", c->pr.unit);
}

static int copy_run_files(const chain *c, const char *outdir, const char *qprofile_src_dir) {
    char p[BRW_PATH], h[65];
    (void)qprofile_src_dir;
    brw_record_path(p, sizeof p, c->dir, "turing.qprofile", &c->pd); if (copy_named(p, outdir)) return TYQ_E_IO;
    brw_record_path(p, sizeof p, c->dir, "turing.qfreeze", &c->fd); if (copy_named(p, outdir)) return TYQ_E_IO;
    brw_record_path(p, sizeof p, c->dir, "turing.qworld", &c->wdg); if (copy_named(p, outdir)) return TYQ_E_IO;
    ty_hex(&c->wo.traj_manifest, h);
    brw_join(p, sizeof p, c->dir, "traj.%s.man", h); if (copy_named(p, outdir)) return TYQ_E_IO;
    /* the qbw files named by the sidecar */
    brw_bytes mb; brw_join(p, sizeof p, c->dir, "traj.%s.man", h);
    if (brw_slurp(p, &mb) != 0) return TYQ_E_IO;
    tyqr_repline *rl = calloc(c->wo.rep_count ? c->wo.rep_count : 1, sizeof *rl); size_t n = 0;
    if (!rl || tyqr_repman_parse((const char *)mb.b, mb.n, rl, (size_t)c->wo.rep_count, &n) != TY_OK) { free(rl); brw_bytes_free(&mb); return TYQ_E_IO; }
    brw_bytes_free(&mb);
    for (size_t i = 0; i < n; i++) { ty_hex(&rl[i].d, h); brw_join(p, sizeof p, c->dir, "%s.qbw", h); if (copy_named(p, outdir)) { free(rl); return TYQ_E_IO; } }
    free(rl);
    return 0;
}

static int write_gain_rec(const char *outdir, const tyqr_gain *g, ty_digest *gd, char *gain_path, size_t path_cap, char *why, size_t cap) {
    char path[BRW_PATH];
    int rc = tyqr_gain_write(outdir, g, gd, path, sizeof path);
    if (rc == TYQR_E_EXISTS) rc = TY_OK;     /* deterministic: the same run gives the same record */
    if (rc != TY_OK) { WHY("omega refused the qgain record (%d)", rc); return TYQ_FAIL_PROTOCOL; }
    if (gain_path && path_cap) snprintf(gain_path, path_cap, "%s", path);
    return 0;
}

int brw_score(const brw_score_args *a, tyqr_gain *gout, ty_digest *gdout, char *gain_path, size_t path_cap, char *why, size_t cap) {
    chain c;
    memset(&c, 0, sizeof c);
    if (!a || !a->mode || !a->qfreeze || !a->qworld || !a->candidate || !a->baseline || !a->outdir) { WHY("score needs mode, qfreeze, qworld, candidate, baseline and out"); return TYQ_E_ARG; }
    int cert = strcmp(a->mode, "certification") == 0;
    if (!cert && strcmp(a->mode, "discovery") != 0) { WHY("mode must be certification or discovery"); return TYQ_E_ARG; }
    char dir[BRW_PATH], fp[BRW_PATH];
    brw_dir_of(a->qworld, dir, sizeof dir);
    /* record digests come from the file names */
    tyqr_freeze ftmp; ty_digest fd; tyqr_world wtmp; ty_digest wd;
    int rc = brw_load_freeze(a->qfreeze, &ftmp, &fd, why, cap);
    if (rc) return rc;
    if ((rc = brw_load_world(a->qworld, &wtmp, &wd, why, cap)) != 0) return rc;
    /* the freeze must be beside the world; copy it there in the run dir only, so check the same directory */
    brw_record_path(fp, sizeof fp, dir, "turing.qfreeze", &fd);
    if (!exists(fp)) {
        /* freeze lives elsewhere: bring it (and its qprofile) to the world directory of the OUT dir instead */
        WHY("the qfreeze must sit in the same directory as the qworld"); return TYQ_E_ARG;
    }
    if (strcmp(ftmp.mode, a->mode) != 0) { WHY("score mode differs from the qfreeze mode"); return TYQ_FAIL_PROTOCOL; }
    if ((rc = chain_records(&c, dir, &fd, &wd, why, cap)) != 0) { chain_free(&c); return rc; }
    if (a->thresholds && (rc = brw_thr_file_check(&c.pr, a->thresholds, why, cap)) != 0) { chain_free(&c); return rc; }
    if ((rc = chain_baseline(&c, brw_opcode_of(a->baseline), why, cap)) != 0) { chain_free(&c); return rc; }
    int declared = brw_declared_baseline(&c.pr, c.ci.experiment);
    int dm = declared && declared == c.base_op;
    if (!dm && (!a->ladder_item || !a->ladder_item[0] || strcmp(a->ladder_item, "-") == 0 || strchr(a->ladder_item, ' '))) {
        chain_free(&c); WHY("baseline is not the declared one: a ladder item is required"); return TYQ_FAIL_BASELINE; }
    brw_bytes candbytes = { NULL, 0 };
    ty_digest cand_art;
    if (cert) {
        c.cand_op = brw_opcode_of(a->candidate);
        if (c.cand_op < 1 || c.cand_op > 7 || brw_ref_program(c.cand_op, &c.pm) != TYQ_OK) { chain_free(&c); WHY("unknown certification candidate opcode"); return TYQ_E_ARG; }
        char hex[65];
        if (!a->predict_src || brw_predict_artifact_digest(a->predict_src, hex) != 0 || ty_parse_hex(hex, &cand_art) != 0) { chain_free(&c); WHY("certification needs --predict-src"); return TYQ_E_ARG; }
        if (!ty_digest_eq(&cand_art, &c.fr.artifact)) { chain_free(&c); WHY("the predictor source does not match the qfreeze artifact digest"); return TYQ_FAIL_DIGEST; }
    } else {
        c.cand_op = 255;
        if (brw_slurp(a->candidate, &candbytes) != 0) { chain_free(&c); WHY("cannot read the discovery artifact"); return TYQ_E_IO; }
        brw_sha256(candbytes.b, candbytes.n, &cand_art);
        if (!ty_digest_eq(&cand_art, &c.fr.artifact)) { brw_bytes_free(&candbytes); chain_free(&c); WHY("the artifact does not match the qfreeze artifact digest"); return TYQ_FAIL_DIGEST; }
        char err[128];
        if (brw_prog_from_bytes(candbytes.b, (int)candbytes.n, &c.pm, err, sizeof err) != TYQ_OK) { brw_bytes_free(&candbytes); chain_free(&c); WHY("the artifact is not valid BRW-DL: %s", err); return TYQ_FAIL_PROTOCOL; }
        if (!a->candidate_cmd) { brw_bytes_free(&candbytes); chain_free(&c); WHY("discovery needs --candidate-cmd"); return TYQ_E_ARG; }
        brw_bytes ib; ty_digest idg;
        if (brw_slurp(a->candidate_cmd, &ib) != 0) { brw_bytes_free(&candbytes); chain_free(&c); WHY("cannot read the interpreter"); return TYQ_E_IO; }
        brw_sha256(ib.b, ib.n, &idg); brw_bytes_free(&ib);
        if (!ty_digest_eq(&idg, &c.fr.artifact_bin)) { brw_bytes_free(&candbytes); chain_free(&c); WHY("the interpreter does not match the qfreeze artifact_bin digest"); return TYQ_FAIL_DIGEST; }
    }
    if ((rc = mkdir(a->outdir, 0755)) != 0 && errno != EEXIST) { brw_bytes_free(&candbytes); chain_free(&c); WHY("cannot create the output directory"); return TYQ_E_IO; }
    tyqr_gain g;
    size_t W = c.ts.W;
    /* G9: a packet-scanner hit is FAIL_PROTOCOL + STOPPED, recorded */
    if (!cert && a->packet) {
        char w2[BRW_WHY];
        uint8_t sparent[32];
        brw_sealed_parent(c.fd.b, sparent);
        if (brw_packet_scan(a->packet, w2, sizeof w2) != 0 || packet_seed_scan(a->packet, c.ci.s.name, sparent, c.ts.W, w2, sizeof w2) != 0) {
            gain_stub(&g, &c, "FAIL_PROTOCOL", a->ladder_item ? a->ladder_item : "-", dm);
            copy_run_files(&c, a->outdir, dir);
            rc = write_gain_rec(a->outdir, &g, gdout, gain_path, path_cap, why, cap);
            if (rc == 0) { WHY("FAIL_PROTOCOL, lane STOPPED: %s", w2); rc = TYQ_FAIL_PROTOCOL; }
            if (gout) *gout = g;
            brw_bytes_free(&candbytes); chain_free(&c); return rc;
        }
    }
    brw_bytes *pb = calloc(W ? W : 1, sizeof *pb), *pm = calloc(W ? W : 1, sizeof *pm);
    if (!pb || !pm) { free(pb); free(pm); brw_bytes_free(&candbytes); chain_free(&c); WHY("out of memory"); return TYQ_E_IO; }
    rc = 0;
    for (size_t w = 0; w < W && rc == 0; w++) rc = brw_prd_for_program(&c.pb, &c.ts.t[w], &c.ci.s, &pb[w], why, cap);
    if (rc == 0 && cert) for (size_t w = 0; w < W && rc == 0; w++) rc = brw_prd_for_program(&c.pm, &c.ts.t[w], &c.ci.s, &pm[w], why, cap);
    char note[BRW_PATH * 4] = "";
    if (rc == 0 && !cert) {
        char apath[BRW_PATH];
        char h[65]; ty_hex(&cand_art, h);
        brw_join(apath, sizeof apath, a->outdir, "artifact.%s.brwdl", h);
        if (write_named(apath, candbytes.b, candbytes.n) != 0) { WHY("cannot store the discovery artifact"); rc = TYQ_E_IO; }
        else rc = brw_run_discovery(a->candidate_cmd, apath, c.ts.t, W, &c.ci.s, pm, note, sizeof note, why, cap);
    }
    int result = rc;
    if (rc == BRW_BLOCKED || rc == TYQ_E_IO || rc == TYQ_E_ARG) goto done;
    if (rc == TYQ_FAIL_PROTOCOL) {   /* interpreter/program protocol failure: recorded, STOPPED (G9 shape) */
        gain_stub(&g, &c, "FAIL_PROTOCOL", a->ladder_item ? a->ladder_item : "-", dm);
        copy_run_files(&c, a->outdir, dir);
        int wr = write_gain_rec(a->outdir, &g, gdout, gain_path, path_cap, NULL, 0);
        if (wr != 0) result = wr;
        if (gout) *gout = g;
        goto done;
    }
    if (rc) goto done;
    {
        ty_digest bman, mman;
        if ((rc = prd_write_set(a->outdir, pb, W, &bman, why, cap)) != 0 || (rc = prd_write_set(a->outdir, pm, W, &mman, why, cap)) != 0) { result = rc; goto done; }
        brw_gain_in in;
        memset(&in, 0, sizeof in);
        in.profile = &c.pr; in.profile_d = c.pd; in.freeze = &c.fr; in.freeze_d = c.fd;
        in.world = &c.wo; in.world_d = c.wdg; in.ci = c.ci; in.tr = c.ts.t; in.W = W;
        in.pb = &c.pb; in.pm = &c.pm; in.base_op = c.base_op; in.cand_op = c.cand_op;
        in.baseline_artifact = c.base_art; in.candidate = c.fr.artifact;
        in.prdman_b = bman; in.prdman_m = mman; in.prd_b = pb; in.prd_m = pm; in.ladder_item = a->ladder_item;
        rc = brw_gain_compute(&in, &g, why, cap);
        if (rc != 0 && rc != TYQ_FAIL_FLOOR && rc != TYQ_FAIL_LEAK) { result = rc; goto done; }
        if (copy_run_files(&c, a->outdir, dir) != 0) { WHY("cannot copy the run files"); result = TYQ_E_IO; goto done; }
        int wr = write_gain_rec(a->outdir, &g, gdout, gain_path, path_cap, why, cap);
        if (wr != 0) { result = wr; goto done; }
        if (rc == 0) {
            char w2[BRW_WHY];
            ty_digest gd2;
            tyqr_gain_digest(&g, &gd2);
            if (tyqr_gain_bind(&g, &gd2, &c.wo, &c.wdg, &c.fr, &c.fd, &c.pd, w2, sizeof w2) != TY_OK) { WHY("qgain binding check failed: %s", w2); result = TYQ_FAIL_PROFILE; goto done; }
        }
        if (gout) *gout = g;
        result = rc;
    }
done:
    for (size_t w = 0; w < W; w++) { brw_bytes_free(&pb[w]); brw_bytes_free(&pm[w]); }
    free(pb); free(pm); brw_bytes_free(&candbytes); chain_free(&c);
    return result;
}

/* Verify: everything is rebuilt from the stored files of the gain's directory. */
static int verify_chain(const char *gain_path, const char *thresholds, const char *predict_src, chain *c, tyqr_gain *g,
                        ty_digest *gd, brw_bytes **pb, brw_bytes **pm, int *chain_only, char *why, size_t cap) {
    char dir[BRW_PATH];
    *pb = *pm = NULL; *chain_only = 0;
    int rc = brw_load_gain(gain_path, g, gd, why, cap);
    if (rc) return rc;
    brw_dir_of(gain_path, dir, sizeof dir);
    if ((rc = chain_records(c, dir, &g->qfreeze, &g->qworld, why, cap)) != 0) return rc;
    char w2[BRW_WHY];
    if (tyqr_gain_bind(g, gd, &c->wo, &c->wdg, &c->fr, &c->fd, &c->pd, w2, sizeof w2) != TY_OK) { WHY("qgain binding failed: %s", w2); return TYQ_FAIL_PROFILE; }
    if (thresholds && (rc = brw_thr_file_check(&c->pr, thresholds, why, cap)) != 0) return rc;
    int cert = strcmp(g->mode, "certification") == 0;
    if ((rc = chain_baseline(c, (int)g->baseline_opcode, why, cap)) != 0) return rc;
    if (!ty_digest_eq(&c->base_art, &g->baseline_artifact)) { WHY("baseline artifact digest differs from its canonical bytes"); return TYQ_FAIL_DIGEST; }
    c->cand_op = (int)g->candidate_opcode;
    if (cert) {
        if (c->cand_op < 1 || c->cand_op > 7 || brw_ref_program(c->cand_op, &c->pm) != TYQ_OK) { WHY("bad certification candidate opcode"); return TYQ_FAIL_PROFILE; }
        if (predict_src) {
            char hex[65]; ty_digest d;
            if (brw_predict_artifact_digest(predict_src, hex) != 0 || ty_parse_hex(hex, &d) != 0 || !ty_digest_eq(&d, &c->fr.artifact)) { WHY("predictor source does not match the qfreeze artifact digest"); return TYQ_FAIL_DIGEST; }
        }
    } else {
        char p[BRW_PATH], h[65]; brw_bytes ab; ty_digest d;
        ty_hex(&c->fr.artifact, h);
        brw_join(p, sizeof p, dir, "artifact.%s.brwdl", h);
        if (brw_slurp(p, &ab) != 0) { WHY("the discovery artifact is missing beside the gain"); return TYQ_FAIL_DIGEST; }
        brw_sha256(ab.b, ab.n, &d);
        char err[128];
        int ok = ty_digest_eq(&d, &c->fr.artifact) && brw_prog_from_bytes(ab.b, (int)ab.n, &c->pm, err, sizeof err) == TYQ_OK;
        brw_bytes_free(&ab);
        if (!ok) { WHY("the stored discovery artifact does not match the qfreeze digest or is not valid BRW-DL"); return TYQ_FAIL_DIGEST; }
    }
    ty_digest zero; memset(&zero, 0, sizeof zero);
    if (ty_digest_eq(&g->prd_b, &zero) && ty_digest_eq(&g->prd_m, &zero)) {
        if (strcmp(g->status, "PASS") == 0) { WHY("a PASS gain has no PRD1 digests"); return TYQ_FAIL_DIGEST; }
        *chain_only = 1; return 0;
    }
    size_t W = c->ts.W;
    if (W != g->counts[1]) { WHY("world count in the gain differs from the qworld"); return TYQ_FAIL_DIGEST; }
    if ((rc = prd_load_set(dir, &g->prd_b, W, pb, why, cap)) != 0) return rc;
    if ((rc = prd_load_set(dir, &g->prd_m, W, pm, why, cap)) != 0) { prd_free_set(*pb, W); *pb = NULL; return rc; }
    return 0;
}

int brw_verify(const char *gain_path, const char *thresholds, const char *predict_src, char *why, size_t cap) {
    chain c; tyqr_gain g, g2; ty_digest gd, gd2; brw_bytes *pb, *pm; int only;
    memset(&c, 0, sizeof c);
    int rc = verify_chain(gain_path, thresholds, predict_src, &c, &g, &gd, &pb, &pm, &only, why, cap);
    if (rc != 0 || only) { if (rc == 0 && strcmp(g.status, "PASS") == 0) rc = TYQ_FAIL_DIGEST; chain_free(&c); return rc; }
    brw_gain_in in;
    memset(&in, 0, sizeof in);
    in.profile = &c.pr; in.profile_d = c.pd; in.freeze = &c.fr; in.freeze_d = c.fd;
    in.world = &c.wo; in.world_d = c.wdg; in.ci = c.ci; in.tr = c.ts.t; in.W = c.ts.W;
    in.pb = &c.pb; in.pm = &c.pm; in.base_op = c.base_op; in.cand_op = c.cand_op;
    in.baseline_artifact = c.base_art; in.candidate = c.fr.artifact;
    in.prdman_b = g.prd_b; in.prdman_m = g.prd_m; in.prd_b = pb; in.prd_m = pm;
    in.ladder_item = g.official ? NULL : g.ladder_item;
    rc = brw_gain_compute(&in, &g2, why, cap);
    if (rc == 0 || rc == TYQ_FAIL_FLOOR || rc == TYQ_FAIL_LEAK) {
        if (tyqr_gain_digest(&g2, &gd2) != TY_OK || !ty_digest_eq(&gd, &gd2)) { WHY("recomputed qgain differs from the stored qgain"); rc = TYQ_FAIL_DIGEST; }
        else rc = 0;
    }
    prd_free_set(pb, c.ts.W); prd_free_set(pm, c.ts.W); chain_free(&c);
    return rc;
}

int brw_replay(const brw_env *env, const char *gain_path, int regenerate, const char *interp_cmd, char *why, size_t cap) {
    int rc = brw_verify(gain_path, NULL, NULL, why, cap);
    if (rc) return rc;
    chain c; tyqr_gain g; ty_digest gd; brw_bytes *pb, *pm; int only;
    memset(&c, 0, sizeof c);
    rc = verify_chain(gain_path, NULL, NULL, &c, &g, &gd, &pb, &pm, &only, why, cap);
    if (rc || only) { chain_free(&c); return rc; }
    size_t W = c.ts.W;
    int cert = strcmp(g.mode, "certification") == 0;
    brw_bytes *nb = calloc(W, sizeof *nb), *nm = calloc(W, sizeof *nm);
    for (size_t w = 0; w < W && rc == 0; w++) rc = brw_prd_for_program(&c.pb, &c.ts.t[w], &c.ci.s, &nb[w], why, cap);
    if (rc == 0 && cert) for (size_t w = 0; w < W && rc == 0; w++) rc = brw_prd_for_program(&c.pm, &c.ts.t[w], &c.ci.s, &nm[w], why, cap);
    if (rc == 0 && !cert) {
        char p[BRW_PATH], h[65], note[4096];
        ty_hex(&c.fr.artifact, h); brw_join(p, sizeof p, c.dir, "artifact.%s.brwdl", h);
        if (!interp_cmd) { WHY("replaying a discovery run needs the interpreter (--candidate-cmd)"); rc = TYQ_E_ARG; }
        else rc = brw_run_discovery(interp_cmd, p, c.ts.t, W, &c.ci.s, nm, note, sizeof note, why, cap);
    }
    if (rc == 0) {
        ty_digest bman, mman; brw_bytes m1, m2;
        if (brw_prd_manifest(nb, W, &m1, &bman) != 0 || brw_prd_manifest(nm, W, &m2, &mman) != 0) { WHY("cannot rebuild PRD1 sidecars"); rc = TYQ_E_IO; }
        else {
            brw_bytes_free(&m1); brw_bytes_free(&m2);
            if (!ty_digest_eq(&bman, &g.prd_b) || !ty_digest_eq(&mman, &g.prd_m)) { WHY("replay mismatch: re-run predictions differ from the stored PRD1 digests"); rc = TYQ_FAIL_DIGEST; }
        }
    }
    if (rc == 0 && regenerate) {
        ty_digest gen; genset gs; char label[128]; uint8_t parent[32];
        brw_sealed_parent(c.fd.b, parent);
        if (brw_generator_digest_of(env, &gen) != 0) { WHY("cannot compute the generator digest"); rc = TYQ_E_IO; }
        else if ((rc = genset_make(&c.ci, "seal", 0, parent, 32, &gs, label, sizeof label, why, cap)) == 0) {
            if (!ty_digest_eq(&gs.man_d, &c.wo.traj_manifest)) { WHY("regenerated trajectories differ from the sealed trajectories"); rc = TYQ_FAIL_DIGEST; }
            else if (!ty_digest_eq(&gen, &c.wo.generator)) { WHY("generator digest differs from the qworld"); rc = TYQ_FAIL_DIGEST; }
            genset_free(&gs);
        }
    }
    for (size_t w = 0; w < W; w++) { brw_bytes_free(&nb[w]); brw_bytes_free(&nm[w]); }
    free(nb); free(nm); prd_free_set(pb, W); prd_free_set(pm, W); chain_free(&c);
    return rc;
}

/* ---------------------------------------------------------------- rescore (kind C) and compare */
int brw_rescore(const char *gain_path, const char *outdir, char *why, size_t cap) {
    chain c; tyqr_gain g; ty_digest gd; brw_bytes *pb, *pm; int only;
    memset(&c, 0, sizeof c);
    int rc = verify_chain(gain_path, NULL, NULL, &c, &g, &gd, &pb, &pm, &only, why, cap);
    if (rc != 0) { chain_free(&c); return rc; }
    if (only) { WHY("the gain has no PRD1 files to re-score"); chain_free(&c); return TYQ_FAIL_PROTOCOL; }
    size_t W = c.ts.W, H = c.ci.H; uint32_t S = c.ci.s.split;
    size_t cap2 = W * H * 64 * 2 + 4096; char *out = malloc(cap2); size_t o = 0;
    if (!out) { WHY("out of memory"); chain_free(&c); return TYQ_E_IO; }
    o += (size_t)snprintf(out + o, cap2 - o, "brw.rescore.v1\n");
    for (int m = 0; m < 2 && rc == 0; m++) {
        int64_t sum = 0;
        for (size_t w = 0; w < W && rc == 0; w++) {
            const brw_bytes *b = m ? &pm[w] : &pb[w];
            ty_prd prd;
            if (ty_prd_parse(b->b, b->n, S, (uint32_t)H, &prd) != TYQ_OK) { rc = TYQ_FAIL_PROTOCOL; break; }
            for (size_t i = 0; i < H; i++) {
                int64_t ub; int fh;
                if (ty_qcont_point_ub(&prd.rec[i], c.ts.t[w].k[S + i], &ub, &fh) != TYQ_OK) { rc = TYQ_FAIL_PROTOCOL; break; }
                sum += ub;
                o += (size_t)snprintf(out + o, cap2 - o, "%s %zu %zu %lld\n", m ? "M" : "B", w, i, (long long)ub);
            }
            ty_prd_free(&prd);
        }
        o += (size_t)snprintf(out + o, cap2 - o, "sum %s %lld\n", m ? "M" : "B", (long long)sum);
    }
    if (rc == 0) {
        o += (size_t)snprintf(out + o, cap2 - o, "t_ub %lld\nt_lo_ub %lld\nt_hi_ub %lld\nclass %s\n", (long long)g.t_ub, (long long)g.t_lo_ub, (long long)g.t_hi_ub, brw_class_label(g.t_ub, g.t_lo_ub, g.t_hi_ub));
        char p[BRW_PATH];
        mkdir(outdir, 0755);
        brw_join(p, sizeof p, outdir, "rescore.txt");
        unlink(p);
        if (brw_write_excl(p, out, o) != 0) { WHY("cannot write rescore.txt"); rc = TYQ_E_IO; }
    } else WHY("cannot re-score the stored predictions");
    free(out); prd_free_set(pb, W); prd_free_set(pm, W); chain_free(&c);
    return rc;
}

int brw_compare_ub(const char *dir_a, const char *dir_b, char *why, size_t cap) {
    char **na, **nb; size_t ka, kb;
    if (list_dir(dir_a, "", "", &na, &ka) || list_dir(dir_b, "", "", &nb, &kb)) { WHY("cannot list the directories"); return TYQ_E_IO; }
    int rc = 0;
    size_t i = 0, j = 0;
    while (rc == 0 && (i < ka || j < kb)) {
        const char *x = i < ka ? na[i] : NULL, *y = j < kb ? nb[j] : NULL;
        if (x && (x[0] == '.' )) { i++; continue; }
        if (y && (y[0] == '.')) { j++; continue; }
        int cmp = !x ? 1 : !y ? -1 : strcmp(x, y);
        if (cmp != 0) { WHY("file %s exists in only one directory", cmp < 0 ? x : y); rc = TYQ_FAIL_DIGEST; break; }
        char pa[BRW_PATH], pb2[BRW_PATH]; brw_bytes ba, bb;
        brw_join(pa, sizeof pa, dir_a, "%s", x); brw_join(pb2, sizeof pb2, dir_b, "%s", y);
        struct stat st; if (stat(pa, &st) == 0 && S_ISDIR(st.st_mode)) { i++; j++; continue; }
        if (brw_slurp(pa, &ba) != 0 || brw_slurp(pb2, &bb) != 0) { WHY("cannot read %s", x); rc = TYQ_E_IO; break; }
        if (ba.n != bb.n || memcmp(ba.b, bb.b, ba.n) != 0) { WHY("file %s differs", x); rc = TYQ_FAIL_DIGEST; }
        brw_bytes_free(&ba); brw_bytes_free(&bb);
        i++; j++;
    }
    free_names(na, ka); free_names(nb, kb);
    return rc;
}

/* ---------------------------------------------------------------- calibrate (dev only, stop #13) */
int brw_calibrate(const char *devman_path, uint32_t blocks, const char *outdir, int *stop13, char *why, size_t cap) {
    tyqr_devline *dl; size_t n;
    int rc = brw_devman_load(devman_path, &dl, &n, why, cap);
    if (rc) return rc;
    char dir[BRW_PATH]; brw_dir_of(devman_path, dir, sizeof dir);
    char *out = malloc(65536); size_t o = 0;
    if (!out) { free(dl); WHY("out of memory"); return TYQ_E_IO; }
    o += (size_t)snprintf(out + o, 65536 - o, "brw.calibration.v1\n");
    int stop = 0;
    for (size_t f = 0; f < BRW_FROZEN_NULLS_N && rc == 0; f++) {
        const brw_frozen_null *fn = &BRW_FROZEN_NULLS[f];
        brw_prog pg; brw_cellinfo ci;
        if (brw_cellinfo_get(fn->cell, &ci) != 0 || brw_ref_program(brw_opcode_of(fn->matching_ref), &pg) != TYQ_OK) continue;
        uint32_t seen = 0, rej = 0;
        for (size_t i = 0; i < n && rc == 0; i++) {
            if (strcmp(dl[i].cell, fn->cell) != 0 || dl[i].block >= blocks) continue;
            char p[BRW_PATH]; tyqr_world w; ty_digest d; trajset ts;
            brw_record_path(p, sizeof p, dir, "turing.qworld", &dl[i].d);
            if ((rc = brw_load_world(p, &w, &d, why, cap)) != 0) break;
            if ((rc = trajset_load(dir, &w, &ts, why, cap)) != 0) break;
            uint32_t S = ci.s.split, Sf = S - (ci.s.set_state ? 1u : 0u), H = ci.s.n_points - S;
            brw_diag *wd = calloc(ts.W, sizeof *wd);
            double *z = malloc(H * sizeof *z), *tt = malloc(H * sizeof *tt), *yp = malloc(H * sizeof *yp), *y = malloc(ci.s.n_points * sizeof *y);
            tyq_pred *pr = malloc((ci.s.n_points - Sf) * sizeof *pr);
            size_t okw = 0;
            for (size_t r = 0; r < ts.W && wd && z && tt && yp && y && pr; r++) {
                const char *why2 = "";
                for (size_t k = 0; k < ci.s.n_points; k++) y[k] = brw_symbol_value(ts.t[r].k[k]);
                if (brw_predict_fit_once(&pg, ts.t[r].t, y, ci.s.n_points, Sf, pr, &why2) != TYQ_OK) continue;
                for (uint32_t k = 0; k < H; k++) { z[k] = (y[S + k] - pr[k + (S - Sf)].loc) / pr[k + (S - Sf)].scale; tt[k] = ts.t[r].t[S + k]; yp[k] = y[S + k - 1]; }
                if (brw_diag_world(z, tt, yp, H, &wd[okw]) == BRW_OK) okw++;
            }
            brw_diag bm; int fl[6];
            if (okw && brw_diag_block_mean(wd, okw, &bm) == BRW_OK) { seen++; if (brw_null_reject(&bm, &fn->nc, fl)) rej++; }
            free(wd); free(z); free(tt); free(yp); free(y); free(pr); trajset_free(&ts);
        }
        long ppm = seen ? (long)((1000000ull * rej) / seen) : 0;
        o += (size_t)snprintf(out + o, 65536 - o, "%s %u %u %ld\n", fn->cell, rej, seen, ppm);
        if (seen == BRW_STOP13_BLOCKS) { int s = 0; brw_stop13(rej, seen, &s); if (s) stop = 1; }
    }
    if (rc == 0) {
        char p[BRW_PATH]; mkdir(outdir, 0755);
        brw_join(p, sizeof p, outdir, "calibration.txt"); unlink(p);
        if (brw_write_excl(p, out, o) != 0) { WHY("cannot write calibration.txt"); rc = TYQ_E_IO; }
    }
    if (stop13) *stop13 = stop;
    if (rc == 0 && stop) { WHY("STOPPED: stop #13, a cell rejects the frozen null interval in 5 or more of 20 development blocks"); rc = BRW_STOPPED; }
    free(out); free(dl);
    return rc;
}

/* ---------------------------------------------------------------- world loading for tests and tools */
int brw_world_load(const char *dir, const tyqr_world *w, brw_traj **out, size_t *W, char *why, size_t cap) {
    trajset s;
    int rc = trajset_load(dir, w, &s, why, cap);
    if (rc) { *out = NULL; *W = 0; return rc; }
    *out = s.t; *W = s.W;
    return 0;
}
void brw_world_free(brw_traj *t, size_t W) {
    if (!t) return;
    for (size_t i = 0; i < W; i++) brw_traj_free(&t[i]);
    free(t);
}

/* ---------------------------------------------------------------- TPS1 adapter over a stored qgain (stop 27, coded lengths) */
typedef struct {
    const brw_bytes *prd; const chain *c; size_t W, H; uint32_t S;
    brw_tps_hook hook; void *hctx;
    brw_tps_arm *out;              /* one per world */
    int *perr;                     /* one per world: 1 = PRD1 not parseable */
    size_t next, nthreads; size_t tid;
} tps_job;
static void tps_world(const tps_job *j, size_t w) {
    ty_prd prd;
    if (ty_prd_parse(j->prd[w].b, j->prd[w].n, j->S, (uint32_t)j->H, &prd) != TYQ_OK) { j->perr[w] = 1; return; }
    brw_tps_stream(prd.rec, j->c->ts.t[w].k + j->S, j->H, w, j->hook, j->hctx, &j->out[w]);
    ty_prd_free(&prd);
}
static void *tps_worker(void *p) {
    tps_job *j = (tps_job *)p;
    for (size_t w = j->tid; w < j->W; w += j->nthreads) tps_world(j, w);   /* static striding: deterministic partition */
    return NULL;
}
int brw_tps_of_gain(const char *gain_path, brw_tps_hook hook, void *hctx, brw_tps_gain_res *r) {
    chain c; tyqr_gain g; ty_digest gd; brw_bytes *pb, *pm; int only; char why[BRW_WHY] = "";
    memset(r, 0, sizeof *r); memset(&c, 0, sizeof c);
    int rc = verify_chain(gain_path, NULL, NULL, &c, &g, &gd, &pb, &pm, &only, why, sizeof why);
    if (rc != 0 || only) { snprintf(r->why, sizeof r->why, "%.150s", rc ? why : "the gain has no PRD1 files"); chain_free(&c); return rc ? rc : TYQ_E_ARG; }
    size_t W = c.ts.W;
    long nt = 1;
    if (!hook) { const char *e = getenv("BRW_TPS_THREADS"); nt = e ? atol(e) : sysconf(_SC_NPROCESSORS_ONLN); if (nt < 1) nt = 1; if (nt > 64) nt = 64; if ((size_t)nt > W) nt = (long)(W ? W : 1); }
    for (int m = 0; m < 2; m++) {
        brw_tps_arm *per = calloc(W ? W : 1, sizeof *per); int *perr = calloc(W ? W : 1, sizeof *perr);
        tps_job jb[64]; pthread_t th[64]; int started[64];
        if (!per || !perr) { free(per); free(perr); snprintf(r->why, sizeof r->why, "out of memory"); break; }
        for (long t = 0; t < nt; t++) {
            jb[t] = (tps_job){ m ? pm : pb, &c, W, c.ci.H, c.ci.s.split, hook, hctx, per, perr, 0, (size_t)nt, (size_t)t };
            started[t] = (nt > 1 && t > 0) ? (pthread_create(&th[t], NULL, tps_worker, &jb[t]) == 0) : 0;
        }
        tps_worker(&jb[0]);
        for (long t = 1; t < nt; t++) { if (started[t]) pthread_join(th[t], NULL); else tps_worker(&jb[t]); }
        brw_tps_arm *a = &r->arm[m];
        int perr_any = 0;
        for (size_t w = 0; w < W; w++) {   /* fold in world order: independent of the thread count */
            if (perr[w]) { perr_any = 1; continue; }
            brw_tps_fold(a, &per[w], w);
        }
        if (perr_any && a->state != BRW_TPS_GATE_FAIL) { a->code = TYQ_FAIL_PROTOCOL; snprintf(r->why, sizeof r->why, "a PRD1 file is not parseable"); }
        if (a->state != BRW_TPS_GATE_FAIL && a->state != BRW_TPS_OUT_OF_RANGE && !a->code) a->state = BRW_TPS_PASS;
        if (a->state != BRW_TPS_GATE_FAIL && a->code && !r->why[0]) snprintf(r->why, sizeof r->why, "adapter refused: code %d", a->code);
        free(per); free(perr);
    }
    r->state = (r->arm[0].state == BRW_TPS_GATE_FAIL || r->arm[1].state == BRW_TPS_GATE_FAIL) ? BRW_TPS_GATE_FAIL
             : (r->arm[0].state == BRW_TPS_OUT_OF_RANGE || r->arm[1].state == BRW_TPS_OUT_OF_RANGE) ? BRW_TPS_OUT_OF_RANGE
             : (r->arm[0].state == BRW_TPS_PASS && r->arm[1].state == BRW_TPS_PASS) ? BRW_TPS_PASS : BRW_TPS_NOT_EVALUATED;
    prd_free_set(pb, W); prd_free_set(pm, W); chain_free(&c);
    return 0;
}

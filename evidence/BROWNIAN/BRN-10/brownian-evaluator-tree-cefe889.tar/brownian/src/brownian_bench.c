/* brownian_bench.c: the Brownian benchmark harness CLI (plan §25, Lane D3). Private, sealed. C only.
 * Every subcommand prints one verdict line ("PASS ..." or "<VERDICT>: <plain reason>") and exits 0 on PASS, 1 on a
 * refusal, 2 on bad usage. No acceptance band lives here: bands come from the thresholds sidecar by path. */
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "brw_occam.h"
#include "brw_protocol.h"
#include "brw_results.h"
#include "brw_stats.h"
#include "brw_tps.h"
#include "brw_verdict.h"

static const char *opt(int argc, char **argv, const char *name) {
    for (int i = 2; i + 1 < argc; i++) if (strcmp(argv[i], name) == 0) return argv[i + 1];
    return NULL;
}
static int flag(int argc, char **argv, const char *name) {
    for (int i = 2; i < argc; i++) if (strcmp(argv[i], name) == 0) return 1;
    return 0;
}
static int usage(const char *m) {
    fprintf(stderr, "brownian_bench: %s\n"
        "subcommands: kat | profile | dev | calibrate | freeze | seal | score | verdict | verify | qualify | replay | cells | compare-ub | results | occam\n"
        "common options: --root <checkout> --omega <pinned omega> --cflags <string> --cc <string>\n", m);
    return 2;
}
static int finish(int rc, const char *why, const char *ok) {
    if (rc == 0) { printf("PASS %s\n", ok); return 0; }
    printf("%s: %s\n", brw_verdict_name(rc), why[0] ? why : "refused");
    return 1;
}
static void env_from(int argc, char **argv, brw_env *e) {
    brw_env_default(e);
    struct stat st;
    if (stat("brownian/src/brw_rng.h", &st) == 0) snprintf(e->root, sizeof e->root, "%s", ".");
    else if (stat("../brownian/src/brw_rng.h", &st) == 0) snprintf(e->root, sizeof e->root, "%s", "..");
    const char *v;
    if ((v = opt(argc, argv, "--root"))) snprintf(e->root, sizeof e->root, "%s", v);
    if ((v = opt(argc, argv, "--omega"))) snprintf(e->omega, sizeof e->omega, "%s", v);
    if ((v = opt(argc, argv, "--cflags"))) snprintf(e->cflags, sizeof e->cflags, "%s", v);
    if ((v = opt(argc, argv, "--cc"))) snprintf(e->cc_line, sizeof e->cc_line, "%s", v);
}
/* copy a file into dir under its own name; an identical file already there is fine */
static int copy_into(const char *src, const char *dir) {
    brw_bytes b; char dst[BRW_PATH];
    if (brw_slurp(src, &b) != 0) return -1;
    const char *s = strrchr(src, '/');
    brw_join(dst, sizeof dst, dir, "%s", s ? s + 1 : src);
    int rc = brw_write_excl(dst, b.b, b.n);
    brw_bytes_free(&b);
    return rc == 0 || rc == TYQR_E_EXISTS ? 0 : -1;
}
static int find_qprofile(const char *dir, char *out, size_t cap) {
    DIR *d = opendir(dir);
    if (!d) return 0;
    int n = 0; struct dirent *e;
    while ((e = readdir(d)) != NULL)
        if (strncmp(e->d_name, "turing.qprofile.", 16) == 0) { n++; brw_join(out, cap, dir, "%s", e->d_name); }
    closedir(d);
    return n == 1;
}
static int mkdirp(const char *p) { return mkdir(p, 0755) == 0 || errno == EEXIST ? 0 : -1; }

/* ---- kat: internal known-answer checks of the harness pieces ---- */
static int kat(char *why, size_t cap) {
    ty_digest d; char h[65];
    brw_sha256("abc", 3, &d); ty_hex(&d, h);
    if (strcmp(h, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") != 0) { snprintf(why, cap, "SHA-256 known answer failed"); return BRW_KATFAIL; }
    if (strcmp(brw_class_label(1, 1, 2), "POSITIVE") || strcmp(brw_class_label(-1, -2, -1), "NEGATIVE") ||
        strcmp(brw_class_label(1, -1, 2), "WEAK") || strcmp(brw_class_label(0, -1, 2), "AMBIGUOUS") ||
        strcmp(brw_class_label(-1, -2, 0), "AMBIGUOUS")) { snprintf(why, cap, "classification labels (G6) failed"); return BRW_KATFAIL; }
    char *cal = malloc(16384); size_t cl = 0;
    if (!cal || brw_calib_render(cal, 16384, &cl) != 0 || strncmp(cal, "brw.calib.v1\n", 13) != 0) { free(cal); snprintf(why, cap, "calibration rendering failed"); return BRW_KATFAIL; }
    free(cal);
    if (brw_scan_text("the Brownian motion of a particle", 33, NULL, 0) == 0 || brw_scan_text("a plain packet about numbers", 28, NULL, 0) != 0) {
        snprintf(why, cap, "packet scanner known answers failed"); return BRW_KATFAIL; }
    const char *const *a = brw_sandbox_argv();
    if (!a[0] || strcmp(a[0], "/usr/bin/bwrap") != 0 || strcmp(a[1], "--unshare-all") != 0) { snprintf(why, cap, "frozen sandbox argv changed"); return BRW_KATFAIL; }
    if (brw_cellinfo_count() < 12) { snprintf(why, cap, "cell table too small"); return BRW_KATFAIL; }
    return 0;
}

int main(int argc, char **argv) {
    char why[BRW_WHY * 2] = "";
    if (argc < 2) return usage("no subcommand");
    const char *cmd = argv[1];
    brw_env env;
    env_from(argc, argv, &env);
    int rc;
    if (strcmp(cmd, "kat") == 0) { rc = kat(why, sizeof why); return finish(rc, why, "harness known answers"); }
    if (strcmp(cmd, "calib-file") == 0) {   /* writes the frozen brw.calib.v1 rendering (R3-24 U6) to --out */
        const char *out = opt(argc, argv, "--out");
        if (!out) return usage("calib-file needs --out <file>");
        char *cal = malloc(16384); size_t cl = 0;
        if (!cal || brw_calib_render(cal, 16384, &cl) != 0) { free(cal); return finish(TYQ_E_ARG, "cannot render", ""); }
        unlink(out);
        rc = brw_write_excl(out, cal, cl); free(cal);
        return finish(rc == 0 ? 0 : TYQ_E_IO, "cannot write the file", "brw.calib.v1 written");
    }
    if (strcmp(cmd, "ref-bytes") == 0) {   /* canonical BRW-DL bytes of a reference program, for discovery tests */
        const char *op = opt(argc, argv, "--op"), *out = opt(argc, argv, "--out");
        if (!op || !out) return usage("ref-bytes needs --op <name> --out <file>");
        const brw_ref *r = brw_ref_get(brw_opcode_of(op));
        if (!r) return finish(TYQ_E_ARG, "unknown reference program", "");
        unlink(out);
        rc = brw_write_excl(out, r->bytes, (size_t)r->nbytes);
        return finish(rc == 0 ? 0 : TYQ_E_IO, "cannot write the file", "reference bytes written");
    }
    if (strcmp(cmd, "cells") == 0) {
        for (size_t i = 0; i < brw_cellinfo_count(); i++) {
            brw_cellinfo c; brw_cellinfo_at(i, &c);
            printf("%s W=%u H=%u n=%u split=%u %s%s\n", c.s.name, c.W, c.H, c.s.n_points, c.s.split, c.experiment ? c.experiment : "-", c.hostile ? " hostile(dev only)" : "");
        }
        return 0;
    }
    if (strcmp(cmd, "profile") == 0) {
        const char *sp = opt(argc, argv, "--spec"), *pk = opt(argc, argv, "--packet"), *th = opt(argc, argv, "--thresholds"), *out = opt(argc, argv, "--out");
        if (!sp || !pk || !th || !out) return usage("profile needs --spec --packet --thresholds --out");
        brw_bytes a, b, c; brw_profile_in in; memset(&in, 0, sizeof in);
        if (brw_slurp(sp, &a) || brw_slurp(pk, &b) || brw_slurp(th, &c)) return finish(TYQ_E_IO, "cannot read an input file", "");
        brw_sha256(a.b, a.n, &in.spec); brw_sha256(b.b, b.n, &in.packet); tyqr_sidecar_digest((const char *)c.b, c.n, &in.thresholds);
        brw_bytes_free(&a); brw_bytes_free(&b); brw_bytes_free(&c);
        tyqr_profile p; ty_digest d; char path[BRW_PATH];
        mkdirp(out);
        rc = brw_profile_make(&in, &p, why, sizeof why);
        if (rc == 0) { int w = tyqr_profile_write(out, &p, &d, path, sizeof path); if (w != TY_OK && w != TYQR_E_EXISTS) { rc = TYQ_FAIL_PROFILE; snprintf(why, sizeof why, "omega refused the profile write"); } }
        if (rc == 0) printf("qprofile %s\n", path);
        return finish(rc, why, "qprofile written");
    }
    if (strcmp(cmd, "dev") == 0) {
        const char *cell = opt(argc, argv, "--cell"), *bl = opt(argc, argv, "--block"), *out = opt(argc, argv, "--out"), *qp = opt(argc, argv, "--qprofile");
        if (!cell || !bl || !out) return usage("dev needs --cell --block --out");
        char qpath[BRW_PATH]; tyqr_profile p; ty_digest pd;
        if (!qp) { if (!find_qprofile(out, qpath, sizeof qpath)) return finish(TYQ_FAIL_PROFILE, "no single qprofile in the out directory (use --qprofile)", ""); qp = qpath; }
        if ((rc = brw_load_profile(qp, &p, &pd, why, sizeof why)) != 0) return finish(rc, why, "");
        mkdirp(out);
        unsigned a = 0, b = 0;
        if (sscanf(bl, "%u-%u", &a, &b) != 2) { a = b = (unsigned)strtoul(bl, NULL, 10); }
        rc = 0;
        for (unsigned k = a; k <= b && rc == 0; k++) rc = brw_dev_block(&env, out, cell, k, &pd, NULL, NULL, why, sizeof why);
        ty_digest md;
        if (rc == 0) rc = brw_devman_refresh(out, &md, why, sizeof why);
        return finish(rc, why, "dev blocks written");
    }
    if (strcmp(cmd, "calibrate") == 0) {
        const char *dm = opt(argc, argv, "--dev-manifest"), *bl = opt(argc, argv, "--blocks"), *out = opt(argc, argv, "--out");
        if (!dm || !bl || !out) return usage("calibrate needs --dev-manifest --blocks --out");
        int s13 = 0;
        rc = brw_calibrate(dm, (uint32_t)strtoul(bl, NULL, 10), out, &s13, why, sizeof why);
        return finish(rc, why, "calibration.txt written");
    }
    if (strcmp(cmd, "freeze") == 0) {
        brw_freeze_args a; memset(&a, 0, sizeof a);
        a.artifact = opt(argc, argv, "--artifact"); a.qprofile = opt(argc, argv, "--qprofile"); a.devman = opt(argc, argv, "--dev-manifest");
        a.calibration = opt(argc, argv, "--calibration"); a.outdir = opt(argc, argv, "--out"); a.meta = opt(argc, argv, "--meta");
        a.interp = opt(argc, argv, "--interp"); a.turing_profile = opt(argc, argv, "--turing-profile");
        if (!a.artifact || !a.qprofile || !a.devman || !a.calibration || !a.outdir || !a.meta) return usage("freeze needs --artifact --qprofile --dev-manifest --calibration --meta --out");
        mkdirp(a.outdir);
        tyqr_freeze f; ty_digest fd;
        rc = brw_freeze(&a, &f, &fd, why, sizeof why);
        if (rc == 0) { copy_into(a.qprofile, a.outdir); char p[BRW_PATH]; brw_record_path(p, sizeof p, a.outdir, "turing.qfreeze", &fd); printf("qfreeze %s\n", p); }
        return finish(rc, why, "qfreeze written");
    }
    if (strcmp(cmd, "seal") == 0) {
        const char *qf = opt(argc, argv, "--qfreeze"), *ar = opt(argc, argv, "--artifact"), *cell = opt(argc, argv, "--cell"), *out = opt(argc, argv, "--out"), *led = opt(argc, argv, "--ledger");
        if (!qf || !ar || !cell || !out) return usage("seal needs --qfreeze --artifact --cell --out");
        mkdirp(out);
        tyqr_world w; ty_digest wd;
        rc = brw_seal(&env, qf, ar, cell, out, led, &w, &wd, why, sizeof why);
        if (rc == 0) {   /* the run directory is self-contained: bring the qfreeze and its qprofile beside the qworld */
            char d[BRW_PATH]; brw_dir_of(qf, d, sizeof d);
            copy_into(qf, out);
            char pp[BRW_PATH]; tyqr_freeze f; ty_digest fd; brw_load_freeze(qf, &f, &fd, why, sizeof why);
            brw_record_path(pp, sizeof pp, d, "turing.qprofile", &f.qprofile); copy_into(pp, out);
            brw_record_path(pp, sizeof pp, out, "turing.qworld", &wd); printf("qworld %s\n", pp);
        }
        return finish(rc, why, "sealed world written");
    }
    if (strcmp(cmd, "score") == 0) {
        brw_score_args a; memset(&a, 0, sizeof a);
        a.mode = opt(argc, argv, "--mode"); a.qfreeze = opt(argc, argv, "--qfreeze"); a.qworld = opt(argc, argv, "--qworld");
        a.candidate = opt(argc, argv, "--candidate"); a.baseline = opt(argc, argv, "--baseline"); a.candidate_cmd = opt(argc, argv, "--candidate-cmd");
        a.packet = opt(argc, argv, "--packet"); a.predict_src = opt(argc, argv, "--predict-src"); a.ladder_item = opt(argc, argv, "--ladder-item");
        a.thresholds = opt(argc, argv, "--thresholds"); a.outdir = opt(argc, argv, "--out");
        if (!a.mode || !a.qfreeze || !a.qworld || !a.candidate || !a.baseline || !a.outdir) return usage("score needs --mode --qfreeze --qworld --candidate --baseline --out");
        tyqr_gain g; ty_digest gd; char gp[BRW_PATH] = "";
        rc = brw_score(&a, &g, &gd, gp, sizeof gp, why, sizeof why);
        if (gp[0]) printf("qgain %s\n", gp);
        if (rc == 0) printf("T=%lld ub interval=[%lld, %lld] class=%s\n", (long long)g.t_ub, (long long)g.t_lo_ub, (long long)g.t_hi_ub, g.classification);
        return finish(rc, why, "scored");
    }
    if (strcmp(cmd, "verdict") == 0) {   /* Lane D5: per-item acceptance results and the experiment verdict (spec 13, 14, 15, 19, 21) */
        brw_vd_args va; brw_vd_verdict vv; char rp[BRW_PATH];
        memset(&va, 0, sizeof va);
        va.experiment = opt(argc, argv, "--experiment"); va.thresholds = opt(argc, argv, "--thresholds"); va.outdir = opt(argc, argv, "--out");
        for (int i = 2; i + 1 < argc; i++) if (strcmp(argv[i], "--dir") == 0) { if (va.ndirs >= 8) return usage("verdict takes at most 8 --dir"); va.dirs[va.ndirs++] = argv[i + 1]; }
        if (!va.experiment || !va.thresholds || !va.outdir || !va.ndirs) return usage("verdict needs --experiment EXP-002A|B|C|B-OCC --thresholds --out and one or more --dir");
        rc = brw_verdict_run(&va, &vv, rp, sizeof rp, why, sizeof why);
        if (rc != 0) return finish(rc, why, "");
        printf("%s: %s experiment verdict (record %s)\n", brw_vd_verdict_name(vv), va.experiment, rp);
        return vv == BRW_VD_V_PASS ? 0 : 1;
    }
    if (strcmp(cmd, "results") == 0) {   /* read-only: prints results.json (plan §26) from the q-records and a judgement manifest */
        brw_res_args ra; char hx[65];
        memset(&ra, 0, sizeof ra);
        ra.qprofile = opt(argc, argv, "--qprofile"); ra.manifest = opt(argc, argv, "--manifest"); ra.out = opt(argc, argv, "--out"); ra.cflags = opt(argc, argv, "--cflags"); ra.calibration = opt(argc, argv, "--calibration");
        for (int i = 2; i + 1 < argc; i++) if (strcmp(argv[i], "--dir") == 0) { if (ra.ndirs >= BRW_RES_MAXDIRS) return usage("results takes at most 64 --dir"); ra.dirs[ra.ndirs++] = argv[i + 1]; }
        if (!ra.qprofile || !ra.manifest || !ra.out || !ra.ndirs) return usage("results needs --qprofile --manifest --out and one or more --dir");
        rc = brw_results_run(&ra, hx, why, sizeof why);
        if (rc == 0) printf("sha256 %s %s\n", hx, ra.out);
        return finish(rc, why, "results.json written");
    }
    if (strcmp(cmd, "verify") == 0) {
        const char *q = opt(argc, argv, "--qgain");
        if (!q) return usage("verify needs --qgain");
        rc = brw_verify(q, opt(argc, argv, "--thresholds"), opt(argc, argv, "--predict-src"), why, sizeof why);
        return finish(rc, why, "verified");
    }
    if (strcmp(cmd, "replay") == 0) {
        const char *q = opt(argc, argv, "--qgain");
        if (!q) return usage("replay needs --qgain");
        rc = brw_replay(&env, q, flag(argc, argv, "--regenerate"), opt(argc, argv, "--candidate-cmd"), why, sizeof why);
        return finish(rc, why, "replayed");
    }
    if (strcmp(cmd, "rescore") == 0) {
        const char *q = opt(argc, argv, "--qgain"), *out = opt(argc, argv, "--out");
        if (!q || !out) return usage("rescore needs --qgain --out");
        rc = brw_rescore(q, out, why, sizeof why);
        return finish(rc, why, "rescore.txt written");
    }
    if (strcmp(cmd, "tps") == 0) {   /* TPS1 adapter gates and real coded lengths of a stored qgain (read-only; stop 27) */
        const char *q = opt(argc, argv, "--qgain");
        if (!q) return usage("tps needs --qgain [--write]");
        brw_tps_gain_res tr;
        rc = brw_tps_of_gain(q, NULL, NULL, &tr);
        if (rc == 0 && flag(argc, argv, "--write")) {
            tyqr_gain g; ty_digest gd; char sp[BRW_PATH];
            int wr = brw_load_gain(q, &g, &gd, why, sizeof why);
            if (wr == 0) wr = brw_tps_sidecar_write(q, &g, &gd, &tr, sp, sizeof sp);
            if (wr != 0) { if (why[0] == 0) snprintf(why, sizeof why, "cannot write the TPS1 sidecar"); return finish(wr, why, ""); }
            printf("tps-sidecar %s\n", sp);
        }
        if (rc == 0) {
            static const char *const nm[2] = { "B", "M" };
            for (int m = 0; m < 2; m++) {
                const brw_tps_arm *a = &tr.arm[m];
                printf("tps %s state=%d n_obs=%llu n_steps=%llu ideal_ub=%lld range_bytes=%llu rans_bytes=%llu max_dev_exact=%.3g\n", nm[m], a->state,
                       (unsigned long long)a->n_obs, (unsigned long long)a->n_steps, (long long)a->ideal_ub, (unsigned long long)a->range_bytes,
                       (unsigned long long)a->rans_bytes, a->max_dev_exact);
            }
            if (tr.state == BRW_TPS_GATE_FAIL) { snprintf(why, sizeof why, "STOPPED: stop #27, a TPS1 adapter gate failed"); rc = BRW_STOPPED; }
            else if (tr.state != BRW_TPS_PASS && tr.state != BRW_TPS_OUT_OF_RANGE) { snprintf(why, sizeof why, "not evaluated: %s", tr.why); rc = TYQ_E_ARG; }
        } else snprintf(why, sizeof why, "not evaluated: %s", tr.why);
        return finish(rc, why, "TPS1 gates pass");
    }
    if (strcmp(cmd, "occam") == 0) {   /* the Occam curve of spec v1.3 A3.4 (descriptive, read-only over the q-records) */
        const char *dirs[8]; size_t nd = 0;
        for (int i = 2; i + 1 < argc; i++) if (strcmp(argv[i], "--dir") == 0) { if (nd >= 8) return usage("occam takes at most 8 --dir"); dirs[nd++] = argv[i + 1]; }
        if (!nd) return usage("occam needs one or more --dir [--calibration <brw.calib.v1>] [--out <file>]");
        rc = brw_occ_run(dirs, nd, opt(argc, argv, "--calibration"), opt(argc, argv, "--out"), why, sizeof why);
        return finish(rc, why, "occam curve written");
    }
    if (strcmp(cmd, "compare-ub") == 0) {
        if (argc != 4) return usage("compare-ub <dirA> <dirB>");
        rc = brw_compare_ub(argv[2], argv[3], why, sizeof why);
        return finish(rc, why, "directories are byte-identical");
    }
    if (strcmp(cmd, "qualify") == 0) {
        const char *suite = opt(argc, argv, "--suite"), *out = opt(argc, argv, "--out");
        if (!suite || !out || strcmp(suite, "brn9") != 0) return usage("qualify needs --suite brn9 --out");
        /* UNDECIDED: the scope of the brn9 suite. Here: the harness known answers only; the lifecycle and hostile
         * cases run in `make test-brownian-harness`. */
        rc = kat(why, sizeof why);
        mkdirp(out);
        char p[BRW_PATH]; brw_join(p, sizeof p, out, "qualify.txt"); unlink(p);
        char body[256]; int n = snprintf(body, sizeof body, "suite brn9\nkat %s\n", rc == 0 ? "PASS" : "FAIL");
        brw_write_excl(p, body, (size_t)n);
        return finish(rc, why, "qualify suite brn9 (known answers only, see the report)");
    }
    return usage("unknown subcommand");
}

#include "brw_world.h"
#include "brw_cells.h"
#include "brw_normal.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

/* ---- compiled cell table (names enter the world seed label, OI-1) ---- */

#define CELL_B0(nm, gr, np, sp) \
    { nm, BRW_FAM_D0, gr, BRW_OBS_EXACT, np, sp, 0.0, 0.0, 0.0, 0, 0.0, 0, 0.0, 0.0, 0, 0.0, 0.0 }
#define CELL_B1N(nm, s, np) \
    { nm, BRW_FAM_D1, BRW_GRID_REGULAR, BRW_OBS_EXACT, np, BRW_SPLIT_PRIMARY, \
      s, 0.0, 0.0, 0, 0.0, 0, 0.0, 0.0, 0, 0.0, 0.0 }
#define CELL_B2N(nm, th, np) \
    { nm, BRW_FAM_D2, BRW_GRID_REGULAR, BRW_OBS_EXACT, np, BRW_SPLIT_PRIMARY, \
      0.0, th, BRW_B2_SIGMA, 1, 0.0, 0, 0.0, 0.0, 0, 0.0, 0.0 }
#define CELL_B1(nm, s) \
    { nm, BRW_FAM_D1, BRW_GRID_REGULAR, BRW_OBS_EXACT, BRW_N_POINTS_PRIMARY, BRW_SPLIT_PRIMARY, \
      s, 0.0, 0.0, 0, 0.0, 0, 0.0, 0.0, 0, 0.0, 0.0 }
#define CELL_B2(nm, th) \
    { nm, BRW_FAM_D2, BRW_GRID_REGULAR, BRW_OBS_EXACT, BRW_N_POINTS_PRIMARY, BRW_SPLIT_PRIMARY, \
      0.0, th, BRW_B2_SIGMA, 1, 0.0, 0, 0.0, 0.0, 0, 0.0, 0.0 }
#define CELL_H(nm, ob, p) \
    { nm, BRW_FAM_D0, BRW_GRID_REGULAR, ob, BRW_N_POINTS_PRIMARY, BRW_SPLIT_PRIMARY, \
      0.0, 0.0, 0.0, 0, 0.0, 0, 0.0, p, 0, 0.0, 0.0 }

/* EXP-002C-INT (R3-36 (i)): B2-emerging law, x_0 ~ N(0, sd_stat^2) prefix, state SET at index 128 to d * sd_stat. */
#define CELL_INT(nm, d) \
    { nm, BRW_FAM_D2, BRW_GRID_REGULAR, BRW_OBS_EXACT, BRW_INT_N_POINTS, BRW_INT_SPLIT, \
      0.0, BRW_THETA_EMERGING, BRW_B2_SIGMA, 0, 0.0, 0, 0.0, 0.0, 1, (d) * BRW_INT_SD_STAT, BRW_INT_SD_STAT }
/* R3-36 (ii): pure diffusion 2D = 1 (D = 0.5), x_0 ~ N(0,1), the same absolute set state d * sqrt(10). */
#define CELL_CTL(nm, d) \
    { nm, BRW_FAM_D0, BRW_GRID_REGULAR, BRW_OBS_EXACT, BRW_INT_N_POINTS, BRW_INT_SPLIT, \
      0.0, 0.0, 0.0, 0, 0.0, 1, BRW_CTL_D, 0.0, 1, (d) * BRW_INT_SD_STAT, 1.0 }
/* R3-36 (iii): theta = 0.5, sigma = 1, sd_stat = 1, set state d * sd_stat. */
#define CELL_INT05(nm, d) \
    { nm, BRW_FAM_D2, BRW_GRID_REGULAR, BRW_OBS_EXACT, BRW_INT05_N_POINTS, BRW_INT_SPLIT, \
      0.0, BRW_INT05_THETA, BRW_B2_SIGMA, 0, 0.0, 0, 0.0, 0.0, 1, (d) * BRW_INT05_SD_STAT, BRW_INT05_SD_STAT }

static const brw_cell_spec k_cells[] = {
    CELL_B0("B0-regular",   BRW_GRID_REGULAR,   BRW_N_POINTS_PRIMARY, BRW_SPLIT_PRIMARY),
    CELL_B0("B0-irregular", BRW_GRID_IRREGULAR, BRW_N_POINTS_PRIMARY, BRW_SPLIT_PRIMARY),
    CELL_B0("B0-short",     BRW_GRID_REGULAR,   BRW_N_POINTS_SHORT,   BRW_SPLIT_SHORT),
    CELL_B1("B1-0",  BRW_S_B1_0),
    CELL_B1("B1-1",  BRW_S_B1_1),
    CELL_B1N("B1-3",  BRW_S_B1_3,  BRW_N_POINTS_H256),
    CELL_B1N("B1-4n", BRW_S_B1_4N, BRW_N_POINTS_H256),
    CELL_B0("B2-noise", BRW_GRID_REGULAR, BRW_N_POINTS_H512, BRW_SPLIT_PRIMARY),
    CELL_B2("B2-weak",     BRW_THETA_WEAK),
    CELL_B2("B2-clear",    BRW_THETA_CLEAR),
    CELL_B2N("B2-fast",     BRW_THETA_FAST,     BRW_N_POINTS_H256),
    CELL_B2N("B2-emerging", BRW_THETA_EMERGING, BRW_N_POINTS_H512),
    CELL_H("H-meas",    BRW_OBS_MEAS_NOISE, 0.0),
    CELL_H("H-t4",      BRW_OBS_T4_INNOV,   0.0),
    CELL_H("H-outlier", BRW_OBS_OUTLIER,    BRW_H_OUTLIER_P),
    CELL_H("H-missing", BRW_OBS_MISSING,    BRW_H_MISSING_P),
    { "H-boundary-D", BRW_FAM_D0, BRW_GRID_REGULAR, BRW_OBS_EXACT, BRW_N_POINTS_PRIMARY,
      BRW_SPLIT_PRIMARY, 0.0, 0.0, 0.0, 0, 0.0, 1, BRW_H_BOUNDARY_D, 0.0, 0, 0.0, 0.0 },
    { "H-boundary-theta", BRW_FAM_D2, BRW_GRID_REGULAR, BRW_OBS_EXACT, BRW_N_POINTS_PRIMARY,
      BRW_SPLIT_PRIMARY, 0.0, BRW_H_BOUNDARY_THETA, BRW_B2_SIGMA, 1, 0.0, 0, 0.0, 0.0, 0, 0.0, 0.0 },
    CELL_H("H-affine",  BRW_OBS_AFFINE,     0.0),
    /* EXP-002C-INT (spec section 15, R3-24 U5; construction R3-36) */
    CELL_INT("INT-d0", 0.0), CELL_INT("INT-d1", 1.0), CELL_INT("INT-d2", 2.0), CELL_INT("INT-d5", 5.0), CELL_INT("INT-d8", 8.0),
    CELL_CTL("CTL-d0", 0.0), CELL_CTL("CTL-d1", 1.0), CELL_CTL("CTL-d2", 2.0), CELL_CTL("CTL-d5", 5.0), CELL_CTL("CTL-d8", 8.0),
    CELL_INT05("INT05-d0", 0.0), CELL_INT05("INT05-d1", 1.0), CELL_INT05("INT05-d2", 2.0), CELL_INT05("INT05-d5", 5.0), CELL_INT05("INT05-d8", 8.0),
    /* EXP-002B Occam sweep: 124 cells from BRW_OCC_LIST (brw_cells.h) */
#define OCC_CELL(nm, s, h) CELL_B1N(nm, s, BRW_SPLIT_PRIMARY + (h)),
    BRW_OCC_LIST(OCC_CELL)
#undef OCC_CELL
};

int brw_cell_lookup(const char *name, brw_cell_spec *out) {
    if (!name || !out) return BRW_E_ARG;
    for (size_t i = 0; i < sizeof k_cells / sizeof k_cells[0]; i++)
        if (strcmp(name, k_cells[i].name) == 0) { *out = k_cells[i]; return BRW_OK; }
    return BRW_E_ARG;
}

/* ---- exact transitions (plan §7, D5) ---- */

int brw_transition(brw_family f, const brw_params *p, double x, double h,
                   double *mean, double *var) {
    if (!p || !mean || !var) return BRW_E_ARG;
    if (!(h > 0.0) || !isfinite(h) || !isfinite(x)) return BRW_E_REFUSED;
    switch (f) {
    case BRW_FAM_D0:
        if (!(p->D > 0.0) || !isfinite(p->D)) return BRW_E_REFUSED;
        *mean = x;
        *var = 2.0 * p->D * h;
        return BRW_OK;
    case BRW_FAM_D1:
        if (!(p->D > 0.0) || !isfinite(p->D) || !isfinite(p->mu)) return BRW_E_REFUSED;
        *mean = x + p->mu * h;
        *var = 2.0 * p->D * h;
        return BRW_OK;
    case BRW_FAM_D2: {
        double u;
        if (!(p->theta > 0.0) || !(p->sigma > 0.0) || !isfinite(p->theta) ||
            !isfinite(p->sigma)) return BRW_E_REFUSED;
        u = 2.0 * p->theta * h;
        *mean = x * exp(-p->theta * h);
        *var = p->sigma * p->sigma * h * (-expm1(-u) / u);
        return BRW_OK;
    }
    }
    return BRW_E_ARG;
}

int brw_check_transition_kats(brw_transition_fn fn) {
    brw_params p;
    double m, v, m0, v0;
    if (!fn) return BRW_E_ARG;
    /* D2 mean: theta = 1, h = 1, x = 1 -> exp(-1) within 1e-12 */
    memset(&p, 0, sizeof p);
    p.theta = 1.0; p.sigma = 1.0;
    if (fn(BRW_FAM_D2, &p, 1.0, 1.0, &m, &v) != BRW_OK) return BRW_E_KAT;
    if (!(fabs(m - exp(-1.0)) <= 1e-12)) return BRW_E_KAT;
    /* OI-3 (a): theta*h = 1e-6 vs long-double sigma^2 (1-exp(-2 theta h))/(2 theta), 1e-12 rel */
    p.theta = 1e-6; p.sigma = 1.7;
    if (fn(BRW_FAM_D2, &p, 0.3, 1.0, &m, &v) != BRW_OK) return BRW_E_KAT;
    {
        long double s2 = (long double)p.sigma * (long double)p.sigma;
        long double ref = s2 * (1.0L - expl(-2.0L * (long double)p.theta)) /
                          (2.0L * (long double)p.theta);
        if (!(fabsl(((long double)v - ref) / ref) <= 1e-12L)) return BRW_E_KAT;
    }
    /* OI-3 (b): theta*h = 1e-9, ratio to D0 with 2D = sigma^2 within 3e-9 */
    p.theta = 1e-9; p.sigma = 1.7; p.D = p.sigma * p.sigma / 2.0;
    if (fn(BRW_FAM_D2, &p, 0.3, 1.0, &m, &v) != BRW_OK) return BRW_E_KAT;
    if (fn(BRW_FAM_D0, &p, 0.3, 1.0, &m0, &v0) != BRW_OK) return BRW_E_KAT;
    if (!(fabs(v / v0 - 1.0) <= 3e-9)) return BRW_E_KAT;
    /* known h != 1 transition on D0 (catches h^0 / h^2 scaling) */
    p.D = 0.7;
    if (fn(BRW_FAM_D0, &p, 2.0, 3.0, &m0, &v0) != BRW_OK) return BRW_E_KAT;
    if (!(m0 == 2.0 && fabs(v0 - 4.2) <= 1e-12)) return BRW_E_KAT;
    return BRW_OK;
}

/* ---- quantizer qint.v1 (plan §8) ---- */

int brw_quantize(double x, int64_t *k) {
    if (!k || !isfinite(x)) return BRW_E_ARG;
    if (fabs(x) >= BRW_RANGE_LIMIT) return BRW_E_RANGE;
    *k = (int64_t)floor(ldexp(x, BRW_DELTA_EXP));   /* scaling by 2^20 is exact */
    return BRW_OK;
}

double brw_symbol_value(int64_t k) {
    return ldexp((double)k + 0.5, -BRW_DELTA_EXP);
}

/* ---- world generation ---- */

void brw_traj_free(brw_traj *t) {
    if (!t) return;
    free(t->t); free(t->k);
    t->t = NULL; t->k = NULL; t->count = 0;
}

int brw_world_generate(const brw_cell_spec *cell, const uint8_t world_seed[32],
                       brw_traj *out, brw_params *hidden_out) {
    ClRng rp, rl, rm, rmiss, rout;
    brw_params par;
    double *x = NULL, *t = NULL, *h = NULL;
    double aff_c = 1.0, aff_b = 0.0;
    uint8_t *keep = NULL;
    uint32_t n, kept = 0;
    int rc;

    if (!cell || !world_seed || !out) return BRW_E_ARG;
    n = cell->n_points;
    if (n < 2 || cell->split >= n) return BRW_E_ARG;
    if (cell->set_state && (cell->split < 2 || cell->obs != BRW_OBS_EXACT)) return BRW_E_ARG;
    out->count = 0; out->t = NULL; out->k = NULL;
    memset(&par, 0, sizeof par);

    if ((rc = brw_stream_init(&rp, world_seed, "param")) != BRW_OK) return rc;
    if ((rc = brw_stream_init(&rl, world_seed, "latent")) != BRW_OK) return rc;
    if ((rc = brw_stream_init(&rm, world_seed, "meas")) != BRW_OK) return rc;
    if ((rc = brw_stream_init(&rmiss, world_seed, "missing")) != BRW_OK) return rc;
    if ((rc = brw_stream_init(&rout, world_seed, "outlier")) != BRW_OK) return rc;

    /* param stream: D first, then affine scale and offset (OI-5); D2 cells draw no D */
    if (cell->family == BRW_FAM_D2) {
        par.theta = cell->theta; par.sigma = cell->sigma;
    } else if (cell->d_fixed) {
        par.D = cell->d_value;
    } else {
        double lo = log(BRW_D_MIN), hi = log(BRW_D_MAX);
        par.D = exp(lo + brw_uniform(&rp) * (hi - lo));
    }
    if (cell->family == BRW_FAM_D1) par.mu = cell->snr_s * sqrt(2.0 * par.D / BRW_B1_TFULL);
    if (cell->obs == BRW_OBS_AFFINE) {
        double lo = log(BRW_H_AFFINE_C_MIN), hi = log(BRW_H_AFFINE_C_MAX);
        aff_c = exp(lo + brw_uniform(&rp) * (hi - lo));
        aff_b = BRW_H_AFFINE_B_MULT * brw_normal(&rp);
    }

    x = malloc(n * sizeof *x); t = malloc(n * sizeof *t); h = malloc(n * sizeof *h);
    keep = malloc(n);
    out->t = malloc(n * sizeof *out->t); out->k = malloc(n * sizeof *out->k);
    if (!x || !t || !h || !keep || !out->t || !out->k) { rc = BRW_E_IO; goto fail; }

    /* latent: X_0 first, always drawn (discarded when fixed) */
    {
        double z0 = brw_normal(&rl);
        x[0] = cell->x0_fixed ? cell->x0 : (cell->x0_sd > 0.0 ? cell->x0_sd * z0 : z0);   /* set-state cells: x_0 ~ N(0, x0_sd^2), the cell's stationary law */
    }
    t[0] = 0.0;
    h[0] = 0.0;
    if (cell->grid == BRW_GRID_IRREGULAR) {
        double lo = log(BRW_H_MIN), hi = log(BRW_H_MAX);
        for (uint32_t i = 1; i < n; i++) h[i] = exp(lo + brw_uniform(&rl) * (hi - lo));
    } else {
        for (uint32_t i = 1; i < n; i++) h[i] = 1.0;
    }
    for (uint32_t i = 1; i < n; i++) t[i] = (cell->grid == BRW_GRID_REGULAR) ? (double)i : t[i - 1] + h[i];

    for (uint32_t i = 1; i < n; i++) {
        double mean, var, z;
        if ((rc = brw_transition(cell->family, &par, x[i - 1], h[i], &mean, &var)) != BRW_OK) goto fail;
        if (cell->obs == BRW_OBS_T4_INNOV) {
            /* OI-9: innovation N0 / sqrt((N1^2+..+N4^2)/4), scaled to variance 2 D h */
            double n0 = brw_normal(&rl), ss = 0.0;
            for (int j = 0; j < 4; j++) { double q = brw_normal(&rl); ss += q * q; }
            z = n0 / sqrt(ss / 4.0);
            x[i] = mean + sqrt(par.D * h[i]) * z;
        } else {
            z = brw_normal(&rl);
            x[i] = mean + sqrt(var) * z;
        }
        /* EXP-002C-INT (R3-36 (i)): the state at index split - 1 = 128 is SET; the normal above is still drawn (stream position unchanged) and discarded */
        if (cell->set_state && i == cell->split - 1) x[i] = cell->set_x;
    }

    /* observation stage: measurement noise / outlier / affine, then quantization */
    for (uint32_t i = 0; i < n; i++) keep[i] = 1;
    if (cell->obs == BRW_OBS_MISSING)
        for (uint32_t i = 1; i + 1 < n; i++)
            if (brw_uniform(&rmiss) < cell->obs_p) keep[i] = 0;

    for (uint32_t i = 0; i < n; i++) {
        double y = x[i];
        int64_t k;
        if (cell->obs == BRW_OBS_MEAS_NOISE) {
            double eps = brw_normal(&rm);           /* one normal per index, drawn even if dropped */
            y = x[i] + sqrt(2.0 * par.D * 1.0) * eps;   /* tau^2 = 2 D h, h = 1 */
        } else if (cell->obs == BRW_OBS_OUTLIER) {
            if (brw_uniform(&rout) < cell->obs_p) {
                double sg = (brw_uniform(&rout) < 0.5) ? -1.0 : 1.0;
                y = x[i] + sg * BRW_H_OUTLIER_MULT * sqrt(2.0 * par.D * 1.0);
            }
        } else if (cell->obs == BRW_OBS_AFFINE) {
            y = aff_c * x[i] + aff_b;
        }
        if ((rc = brw_quantize(y, &k)) != BRW_OK) goto fail;
        if (keep[i]) { out->t[kept] = t[i]; out->k[kept] = k; kept++; }
    }
    out->count = kept;
    par.aff_c = aff_c; par.aff_b = aff_b;
    if (hidden_out) *hidden_out = par;
    free(x); free(t); free(h); free(keep);
    return BRW_OK;
fail:
    free(x); free(t); free(h); free(keep);
    brw_traj_free(out);
    return rc;
}

/* spec section 6, H-missing: the split is by ORIGINAL index (prefix [0, split), held-out [split, n)). The regular grid has t_i = i,
 * so the rows of a dropped world with original index < split are exactly the kept rows with t < split. Every other cell drops nothing. */
uint32_t brw_world_split(const brw_cell_spec *cs, const brw_traj *tr) {
    if (cs->obs != BRW_OBS_MISSING) return cs->split;
    uint32_t s = 0;
    while (s < tr->count && tr->t[s] < (double)cs->split) s++;
    return s;
}

/* fit prefix length: the set-state point (index split - 1) belongs to neither the fit prefix nor the scored rows (R3-36 (i)) */
uint32_t brw_world_fit_split(const brw_cell_spec *cs, const brw_traj *tr) {
    return brw_world_split(cs, tr) - (cs->set_state ? 1u : 0u);
}

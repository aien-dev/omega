/* brw_stats.c: Brownian evaluator statistics (Lane D). Pure statistics, libm only, no Python. */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "brw_stats.h"
#include "brw_normal.h"

/* ------------------------------------------------------------------ special functions */

/* norm_cdf copied from omega src/runtime/rx_costmodel.c:232 (pinned checkout, read-only):
 *   static double norm_cdf(double x) { return 0.5 * erfc(-x / sqrt(2.0)); }
 * Attribution: omega rx_costmodel.c; unchanged formula. */
double brw_norm_cdf(double x) { return 0.5 * erfc(-x / sqrt(2.0)); }

long double brw_gamma_p_ld(long double a, long double x) {
    if (x <= 0.0L) return 0.0L;
    long double gln = lgammal(a);
    if (x < a + 1.0L) {                       /* series */
        long double ap = a, sum = 1.0L / a, del = sum;
        for (int n = 0; n < 100000; n++) {
            ap += 1.0L; del *= x / ap; sum += del;
            if (fabsl(del) < fabsl(sum) * 1e-19L) break;
        }
        return sum * expl(-x + a * logl(x) - gln);
    }
    /* continued fraction (modified Lentz) for Q(a, x) */
    const long double tiny = 1e-300L;
    long double b = x + 1.0L - a, c = 1.0L / tiny, d = 1.0L / b, h = d;
    for (int i = 1; i < 100000; i++) {
        long double an = -(long double)i * ((long double)i - a);
        b += 2.0L; d = an * d + b; if (fabsl(d) < tiny) d = tiny;
        c = b + an / c; if (fabsl(c) < tiny) c = tiny;
        d = 1.0L / d;
        long double del = d * c; h *= del;
        if (fabsl(del - 1.0L) < 1e-19L) break;
    }
    return 1.0L - expl(-x + a * logl(x) - gln) * h;
}


int brw_chi2_quantile(uint32_t dof, double p, double *out) {
    if (!out || dof < 1 || !(p > 0.0 && p < 1.0)) return BRW_E_ARG;
    long double n = (long double)dof, a = n / 2.0L, target = (long double)p;
    long double lgam = lgammal(a);
    /* bracket [lo, hi] with P(lo) < p <= P(hi) */
    long double lo = 0.0L, hi = n + 60.0L * sqrtl(2.0L * n) + 200.0L;
    long double z = brw_acklam_inv(p), w = 2.0L / (9.0L * n);
    long double x = n * powl(1.0L - w + z * sqrtl(w), 3.0L);
    if (!(x > 0.0L) || x >= hi) x = n;
    for (int it = 0; it < 200; it++) {
        long double f = brw_gamma_p_ld(a, x / 2.0L) - target;
        if (f < 0.0L) lo = x; else hi = x;
        /* pdf of chi2: x^(a-1) e^(-x/2) / (2^a Gamma(a)) */
        long double logpdf = (a - 1.0L) * logl(x) - x / 2.0L - a * logl(2.0L) - lgam;
        long double pdf = expl(logpdf);
        long double nx = (pdf > 0.0L) ? x - f / pdf : -1.0L;
        if (!(nx > lo && nx < hi)) nx = 0.5L * (lo + hi);    /* guard: bisect when Newton leaves the bracket */
        long double step = fabsl(nx - x) / nx;
        x = nx;
        if (step < 1e-15L) break;
    }
    *out = (double)x;
    return BRW_OK;
}

/* ------------------------------------------------------------------ bootstrap */

int brw_boot_init(ClRng *boot, const uint8_t analysis_seed[32]) {
    if (!boot || !analysis_seed) return BRW_E_ARG;
    return brw_stream_init(boot, analysis_seed, "bootstrap");
}

__extension__ typedef __int128 i128;
static int cmp_i128(const void *a, const void *b) {
    i128 x = *(const i128 *)a, y = *(const i128 *)b;
    return (x > y) - (x < y);
}
static int64_t clamp64(i128 v) { return v > INT64_MAX ? INT64_MAX : v < INT64_MIN ? INT64_MIN : (int64_t)v; }
static int cmp_d(const void *a, const void *b) {
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

static int boot_check(size_t n, uint32_t B, ClRng *boot) {
    if (n == 0 || !boot || B < 400 || B % 10 != 0) return BRW_E_ARG;
    return BRW_OK;
}

int brw_bootstrap_interval(const int64_t *per_world_diff_ub, size_t n_worlds, int64_t cell_term_ub,
                           uint32_t B, ClRng *boot, int64_t *lo_ub, int64_t *hi_ub, double *mc_err_bits) {
    if (!per_world_diff_ub || !lo_ub || !hi_ub) return BRW_E_ARG;
    int rc = boot_check(n_worlds, B, boot);
    if (rc) return rc;
    i128 *st = malloc((size_t)B * sizeof *st);
    i128 *sorted = malloc((size_t)B * sizeof *sorted);
    if (!st || !sorted) { free(st); free(sorted); return BRW_E_IO; }
    for (uint32_t r = 0; r < B; r++) {
        i128 s = cell_term_ub;   /* R3-30d: 128-bit accumulator, cannot overflow for any n_worlds < 2^63 */
        for (size_t k = 0; k < n_worlds; k++) s += per_world_diff_ub[cl_rng_below(boot, (uint64_t)n_worlds)];
        st[r] = s;
    }
    if (mc_err_bits) {
        uint32_t bs = B / 10, bi = bs * 25 / 1000 - 1;
        double bound[10], m = 0, ss = 0;
        for (int b = 0; b < 10; b++) {
            memcpy(sorted, st + (size_t)b * bs, (size_t)bs * sizeof *sorted);
            qsort(sorted, bs, sizeof *sorted, cmp_i128);
            bound[b] = (double)sorted[bi]; m += bound[b];
        }
        m /= 10.0;
        for (int b = 0; b < 10; b++) ss += (bound[b] - m) * (bound[b] - m);
        *mc_err_bits = sqrt(ss / 9.0) / sqrt(10.0) / 1e6;
    }
    qsort(st, B, sizeof *st, cmp_i128);
    *lo_ub = clamp64(st[B * 25u / 1000u - 1u]);
    *hi_ub = clamp64(st[B * 975u / 1000u - 1u]);
    free(st); free(sorted);
    return BRW_OK;
}

int brw_bootstrap_interval_d(const double *v, size_t n, int mean, uint32_t B, ClRng *boot,
                             double *lo, double *hi, double *mc_err) {
    if (!v || !lo || !hi) return BRW_E_ARG;
    int rc = boot_check(n, B, boot);
    if (rc) return rc;
    double *st = malloc((size_t)B * sizeof *st), *sorted = malloc((size_t)B * sizeof *sorted);
    if (!st || !sorted) { free(st); free(sorted); return BRW_E_IO; }
    for (uint32_t r = 0; r < B; r++) {
        double s = 0;
        for (size_t k = 0; k < n; k++) s += v[cl_rng_below(boot, (uint64_t)n)];
        st[r] = mean ? s / (double)n : s;
    }
    if (mc_err) {
        uint32_t bs = B / 10, bi = bs * 25 / 1000 - 1;
        double bound[10], m = 0, ss = 0;
        for (int b = 0; b < 10; b++) {
            memcpy(sorted, st + (size_t)b * bs, (size_t)bs * sizeof *sorted);
            qsort(sorted, bs, sizeof *sorted, cmp_d);
            bound[b] = sorted[bi]; m += bound[b];
        }
        m /= 10.0;
        for (int b = 0; b < 10; b++) ss += (bound[b] - m) * (bound[b] - m);
        *mc_err = sqrt(ss / 9.0) / sqrt(10.0);
    }
    qsort(st, B, sizeof *st, cmp_d);
    *lo = st[B * 25u / 1000u - 1u];
    *hi = st[B * 975u / 1000u - 1u];
    free(st); free(sorted);
    return BRW_OK;
}

brw_class brw_classify(double lo, double hi) {
    if (hi < 0.0) return BRW_CLASS_NEG;
    if (lo > 0.0) return BRW_CLASS_POS;
    return BRW_CLASS_AMB;
}
brw_class brw_classify_ub(int64_t lo_ub, int64_t hi_ub) {
    if (hi_ub < 0) return BRW_CLASS_NEG;
    if (lo_ub > 0) return BRW_CLASS_POS;
    return BRW_CLASS_AMB;
}

/* ------------------------------------------------------------------ reference intervals */

static int prefix_ok(const double *t, const double *y, uint32_t split) {
    if (!t || !y || split < 2) return 0;
    for (uint32_t i = 1; i < split; i++) if (!(t[i] > t[i - 1])) return 0;
    return 1;
}

static int chi2_interval(uint32_t n, double d_hat, double *lo, double *hi) {
    double c_lo, c_hi;
    int rc = brw_chi2_quantile(n, 0.025, &c_lo);
    if (rc) return rc;
    rc = brw_chi2_quantile(n, 0.975, &c_hi);
    if (rc) return rc;
    *lo = (double)n * d_hat / c_hi;
    *hi = (double)n * d_hat / c_lo;
    return BRW_OK;
}

int brw_d_interval(const double *t, const double *y, uint32_t split, double *d_hat, double *lo, double *hi) {
    if (!d_hat || !lo || !hi || !prefix_ok(t, y, split)) return BRW_E_ARG;
    uint32_t n = split - 1;
    double s = 0;
    for (uint32_t i = 1; i < split; i++) { double d = y[i] - y[i - 1], h = t[i] - t[i - 1]; s += d * d / h; }
    *d_hat = s / (2.0 * (double)n);
    return chi2_interval(n, *d_hat, lo, hi);
}

static void drift_fit(const double *t, const double *y, uint32_t split, double *mu, double *v_rate, double *span) {
    uint32_t n = split - 1;
    *span = t[split - 1] - t[0];
    *mu = (y[split - 1] - y[0]) / *span;
    double s = 0;
    for (uint32_t i = 1; i < split; i++) {
        double h = t[i] - t[i - 1], r = (y[i] - y[i - 1]) - *mu * h;
        s += r * r / h;
    }
    *v_rate = s / (double)n;
}

int brw_d_interval_drift(const double *t, const double *y, uint32_t split, double *d_hat, double *lo, double *hi) {
    if (!d_hat || !lo || !hi || !prefix_ok(t, y, split)) return BRW_E_ARG;
    double mu, v, span;
    drift_fit(t, y, split, &mu, &v, &span);
    *d_hat = v / 2.0;
    return chi2_interval(split - 1, *d_hat, lo, hi);
}

int brw_mu_interval(const double *t, const double *y, uint32_t split, double *mu_hat, double *lo, double *hi) {
    if (!mu_hat || !lo || !hi || !prefix_ok(t, y, split)) return BRW_E_ARG;
    double v, span;
    drift_fit(t, y, split, mu_hat, &v, &span);
    double se = sqrt(v / span);
    *lo = *mu_hat - 1.959963984540054 * se;
    *hi = *mu_hat + 1.959963984540054 * se;
    return BRW_OK;
}

/* ------------------------------------------------------------------ binomial bands */

double brw_binom_pmf(uint32_t k, uint32_t n, double p) {
    if (k > n) return 0.0;
    if (p <= 0.0) return k == 0 ? 1.0 : 0.0;
    if (p >= 1.0) return k == n ? 1.0 : 0.0;
    long double lp = lgammal((long double)n + 1) - lgammal((long double)k + 1) - lgammal((long double)n - k + 1)
                   + (long double)k * logl((long double)p) + ((long double)n - k) * log1pl(-(long double)p);
    return (double)expl(lp);
}

double brw_binom_range(int lo, int hi, uint32_t n, double p) {
    if (lo < 0) lo = 0;
    if (hi > (int)n) hi = (int)n;
    long double s = 0;
    for (int k = lo; k <= hi; k++) s += (long double)brw_binom_pmf((uint32_t)k, n, p);
    return (double)s;
}

int brw_band_count_lo(double f, uint32_t n) { return (int)ceil(f * (double)n - 1e-9); }
int brw_band_count_hi(double f, uint32_t n) { return (int)floor(f * (double)n + 1e-9); }

double brw_band_pass_prob(uint32_t n, double p, double f_lo, double f_hi) {
    return brw_binom_range(brw_band_count_lo(f_lo, n), brw_band_count_hi(f_hi, n), n, p);
}

int brw_band_check(uint32_t count, uint32_t n, double f_lo, double f_hi, double stop_lo, double stop_hi) {
    int c = (int)count;
    if (c >= brw_band_count_lo(f_lo, n) && c <= brw_band_count_hi(f_hi, n)) return BRW_BAND_PASS;
    if (c < brw_band_count_lo(stop_lo, n) || c > brw_band_count_hi(stop_hi, n)) return BRW_BAND_STOP;
    return BRW_BAND_WARN;
}

uint32_t brw_count_cover(const double *lo, const double *hi, const double *truth, size_t n) {
    uint32_t c = 0;
    for (size_t i = 0; i < n; i++) if (lo[i] <= truth[i] && truth[i] <= hi[i]) c++;
    return c;
}
uint32_t brw_count_excludes(const double *lo, const double *hi, size_t n, double value) {
    uint32_t c = 0;
    for (size_t i = 0; i < n; i++) if (value < lo[i] || value > hi[i]) c++;
    return c;
}
uint32_t brw_count_below(const double *hi, size_t n, double value) {
    uint32_t c = 0;
    for (size_t i = 0; i < n; i++) if (hi[i] < value) c++;
    return c;
}

/* ------------------------------------------------------------------ diagnostics */

typedef struct { double v; size_t i; } vi_t;
static int cmp_vi(const void *a, const void *b) {
    double x = ((const vi_t *)a)->v, y = ((const vi_t *)b)->v;
    return (x > y) - (x < y);
}
/* average ranks (1-based), ties share the mean rank */
static int avg_ranks(const double *v, size_t n, double *rank) {
    vi_t *s = malloc(n * sizeof *s);
    if (!s) return BRW_E_IO;
    for (size_t i = 0; i < n; i++) { s[i].v = v[i]; s[i].i = i; }
    qsort(s, n, sizeof *s, cmp_vi);
    for (size_t a = 0; a < n;) {
        size_t b = a;
        while (b + 1 < n && s[b + 1].v == s[a].v) b++;
        double r = 0.5 * ((double)a + (double)b) + 1.0;
        for (size_t k = a; k <= b; k++) rank[s[k].i] = r;
        a = b + 1;
    }
    free(s);
    return BRW_OK;
}

int brw_diag_world(const double *z, const double *t, const double *y_prev, size_t n, brw_diag *out) {
    if (!z || !t || !y_prev || !out || n < 3) return BRW_E_ARG;
    double m = 0, m2 = 0;
    for (size_t i = 0; i < n; i++) { m += z[i]; m2 += z[i] * z[i]; }
    m /= (double)n; m2 /= (double)n;
    double c2 = 0, c4 = 0, ac = 0;
    for (size_t i = 0; i < n; i++) { double d = z[i] - m; c2 += d * d; c4 += d * d * d * d; }
    if (!(c2 > 0.0)) return BRW_E_RANGE;
    for (size_t i = 0; i + 1 < n; i++) ac += (z[i] - m) * (z[i + 1] - m);
    out->mean_z = m; out->mean_z2 = m2; out->lag1 = ac / c2;
    /* Spearman(z^2, t) */
    double *buf = malloc(3 * n * sizeof *buf);
    if (!buf) return BRW_E_IO;
    double *q = buf, *rz = buf + n, *rt = buf + 2 * n;
    for (size_t i = 0; i < n; i++) q[i] = z[i] * z[i];
    int rc = avg_ranks(q, n, rz);
    if (!rc) rc = avg_ranks(t, n, rt);
    if (rc) { free(buf); return rc; }
    double mr = (double)(n + 1) / 2.0, sab = 0, saa = 0, sbb = 0;
    for (size_t i = 0; i < n; i++) { double a = rz[i] - mr, b = rt[i] - mr; sab += a * b; saa += a * a; sbb += b * b; }
    out->spearman_z2_t = (saa > 0.0 && sbb > 0.0) ? sab / sqrt(saa * sbb) : 0.0;
    free(buf);
    double my = 0;
    for (size_t i = 0; i < n; i++) my += y_prev[i];
    my /= (double)n;
    double sxy = 0, sxx = 0;
    for (size_t i = 0; i < n; i++) { double d = y_prev[i] - my; sxy += d * (z[i] - m); sxx += d * d; }
    out->slope_prev_y = sxx > 0.0 ? sxy / sxx : 0.0;
    c2 /= (double)n; c4 /= (double)n;
    out->excess_kurt = c4 / (c2 * c2) - 3.0;
    return BRW_OK;
}

static double *diag_at(brw_diag *d, int i) { return &d->mean_z + i; }
static const double *diag_cat(const brw_diag *d, int i) { return &d->mean_z + i; }

int brw_diag_block_mean(const brw_diag *worlds, size_t n_worlds, brw_diag *mean) {
    if (!worlds || !mean || n_worlds == 0) return BRW_E_ARG;
    for (int d = 0; d < 6; d++) {
        double s = 0;
        for (size_t w = 0; w < n_worlds; w++) s += *diag_cat(&worlds[w], d);
        *diag_at(mean, d) = s / (double)n_worlds;
    }
    return BRW_OK;
}

int brw_holm6(const double p[6], double alpha, int reject[6]) {
    int ord[6] = {0, 1, 2, 3, 4, 5}, nrej = 0;
    for (int i = 0; i < 6; i++) reject[i] = 0;
    for (int i = 1; i < 6; i++) {              /* stable insertion sort by p ascending */
        int k = ord[i], j = i - 1;
        while (j >= 0 && p[ord[j]] > p[k]) { ord[j + 1] = ord[j]; j--; }
        ord[j + 1] = k;
    }
    for (int i = 0; i < 6; i++) {
        if (p[ord[i]] <= alpha / (double)(6 - i)) { reject[ord[i]] = 1; nrej++; }
        else break;
    }
    return nrej;
}

int brw_diag_boot_holm(const brw_diag *worlds, size_t n_worlds, const double null_center[6], uint32_t B,
                       ClRng *boot, double alpha, double p[6], int reject[6], int *n_reject) {
    if (!worlds || !null_center || !p || !reject || !n_reject) return BRW_E_ARG;
    int rc = boot_check(n_worlds, B, boot);
    if (rc) return rc;
    uint32_t le[6] = {0}, ge[6] = {0};
    for (uint32_t r = 0; r < B; r++) {
        double s[6] = {0};
        for (size_t k = 0; k < n_worlds; k++) {
            const brw_diag *w = &worlds[cl_rng_below(boot, (uint64_t)n_worlds)];
            for (int d = 0; d < 6; d++) s[d] += *diag_cat(w, d);
        }
        for (int d = 0; d < 6; d++) {
            double m = s[d] / (double)n_worlds;
            le[d] += m <= null_center[d];
            ge[d] += m >= null_center[d];
        }
    }
    for (int d = 0; d < 6; d++) {
        double a = (double)le[d] / B, b = (double)ge[d] / B, v = 2.0 * (a < b ? a : b);
        p[d] = v > 1.0 ? 1.0 : v;
    }
    *n_reject = brw_holm6(p, alpha, reject);
    return BRW_OK;
}

/* ------------------------------------------------------------------ null table */

int brw_null_calibrate(const brw_diag *block_means, size_t nb, double tail, brw_null_cell *out) {
    if (!block_means || !out || nb < 100 || !(tail > 0.0 && tail < 0.5)) return BRW_E_ARG;
    double *v = malloc(nb * sizeof *v);
    if (!v) return BRW_E_IO;
    size_t il = (size_t)(tail * (double)nb), ih = (size_t)((1.0 - tail) * (double)nb);
    if (ih >= nb) ih = nb - 1;
    for (int d = 0; d < 6; d++) {
        double s = 0;
        for (size_t b = 0; b < nb; b++) { v[b] = *diag_cat(&block_means[b], d); s += v[b]; }
        qsort(v, nb, sizeof *v, cmp_d);
        out->center[d] = s / (double)nb;
        out->lo[d] = v[il];
        out->hi[d] = v[ih];
    }
    free(v);
    return BRW_OK;
}

int brw_null_reject(const brw_diag *block_mean, const brw_null_cell *nc, int flags[6]) {
    int any = 0;
    for (int d = 0; d < 6; d++) {
        double m = *diag_cat(block_mean, d);
        flags[d] = (m < nc->lo[d] || m > nc->hi[d]);
        any |= flags[d];
    }
    return any;
}

int brw_stop13(uint32_t n_reject, uint32_t n_blocks, int *stop) {
    if (!stop || n_blocks != BRW_STOP13_BLOCKS || n_reject > n_blocks) return BRW_E_ARG;
    *stop = n_reject >= BRW_STOP13_LIMIT;
    return BRW_OK;
}

/* Frozen table: copied verbatim from brownian/design/DESIGN_CHECK_R2.md "Frozen values" (1fd3189), generated by
 * script from that file, six statistics per cell in order mean z, mean z^2, lag-1 ac, Spearman(z^2,t), slope
 * z~y_prev, excess kurt; three rows per cell: center, q0.42%, q99.58%. Matching reference: DIFFUSION in B0 and
 * B2-noise, DIFFUSION_DRIFT in B1, MEAN_REVERT in B2-weak/clear/fast/emerging. */
const brw_frozen_null BRW_FROZEN_NULLS[] = {
    { "B0-regular", 400, 128, "DIFFUSION", {
      {-0.000003, 1.016106, -0.007941, 0.000006, -0.041444, -0.047156},
      {-0.01247, 0.99252, -0.01943, -0.01225, -0.04855, -0.10432},
      {0.01243, 1.03957, 0.00308, 0.01127, -0.03492, 0.00650} } },
    { "B0-irregular", 400, 128, "DIFFUSION", {
      {0.000030, 1.016016, -0.007886, 0.000111, -0.033252, -0.046048},
      {-0.01193, 0.99328, -0.01955, -0.01141, -0.03958, -0.09683},
      {0.01217, 1.04010, 0.00318, 0.01237, -0.02761, 0.00970} } },
    { "B1-0", 400, 128, "DIFFUSION_DRIFT", {
      {-0.000004, 1.032034, -0.007774, 0.000108, -0.041577, -0.045930},
      {-0.01610, 1.00877, -0.01949, -0.01168, -0.04956, -0.09674},
      {0.01722, 1.05799, 0.00343, 0.01219, -0.03441, 0.00781} } },
    { "B1-1", 400, 128, "DIFFUSION_DRIFT", {
      {-0.000043, 1.032094, -0.007785, 0.000007, -0.036539, -0.046489},
      {-0.01669, 1.00929, -0.01962, -0.01132, -0.04368, -0.09941},
      {0.01672, 1.05749, 0.00301, 0.01155, -0.03001, 0.00877} } },
    { "B1-3", 400, 256, "DIFFUSION_DRIFT", {
      {0.000190, 1.032211, -0.003956, -0.000126, -0.001354, -0.024216},
      {-0.01410, 1.01162, -0.01285, -0.00854, -0.00198, -0.06221},
      {0.01415, 1.05435, 0.00464, 0.00809, -0.00076, 0.01783} } },
    { "B1-4n", 400, 256, "DIFFUSION_DRIFT", {
      {0.000042, 1.032336, -0.004001, -0.000026, -0.001069, -0.022737},
      {-0.01394, 1.01001, -0.01187, -0.00906, -0.00164, -0.06016},
      {0.01401, 1.05512, 0.00464, 0.00813, -0.00058, 0.01692} } },
    { "B2-noise", 400, 512, "DIFFUSION", {
      {-0.000070, 1.015938, -0.001987, 0.000014, -0.010517, -0.011802},
      {-0.00598, 0.99690, -0.00786, -0.00576, -0.01246, -0.04005},
      {0.00578, 1.03485, 0.00398, 0.00577, -0.00867, 0.01637} } },
    { "B2-weak", 200, 128, "MEAN_REVERT", {
      {-0.000257, 1.058483, 0.007922, 0.003848, -0.023742, -0.047772},
      {-0.03599, 1.01528, -0.00991, -0.01291, -0.03242, -0.12015},
      {0.03658, 1.11334, 0.02656, 0.02165, -0.01557, 0.02884} } },
    { "B2-clear", 200, 128, "MEAN_REVERT", {
      {0.000050, 1.032807, 0.005485, -0.000108, -0.015919, -0.047443},
      {-0.01728, 0.99854, -0.01577, -0.01739, -0.04090, -0.12129},
      {0.01822, 1.06831, 0.02708, 0.01640, 0.00900, 0.03399} } },
    { "B2-fast", 200, 256, "MEAN_REVERT", {
      {0.000030, 1.031100, -0.003420, 0.000077, -0.012522, -0.023492},
      {-0.01163, 1.00081, -0.02261, -0.01187, -0.05278, -0.07887},
      {0.01143, 1.06444, 0.01521, 0.01183, 0.02664, 0.03215} } },
    { "B2-emerging", 1600, 512, "MEAN_REVERT", {
      {-0.000081, 1.039859, 0.022832, 0.000195, 0.007210, -0.012865},
      {-0.00472, 1.02938, 0.01874, -0.00285, 0.00478, -0.02588},
      {0.00412, 1.05021, 0.02710, 0.00338, 0.00970, 0.00269} } },
};
const size_t BRW_FROZEN_NULLS_N = sizeof BRW_FROZEN_NULLS / sizeof BRW_FROZEN_NULLS[0];

const brw_frozen_null *brw_frozen_null_find(const char *cell) {
    for (size_t i = 0; i < BRW_FROZEN_NULLS_N; i++) if (!strcmp(BRW_FROZEN_NULLS[i].cell, cell)) return &BRW_FROZEN_NULLS[i];
    return NULL;
}

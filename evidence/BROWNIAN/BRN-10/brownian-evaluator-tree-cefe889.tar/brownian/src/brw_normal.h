#ifndef BRW_NORMAL_H
#define BRW_NORMAL_H
#include "crumbline/cl_common.h"
double brw_acklam_inv(double p);   /* coefficients copied with attribution from rx_costmodel.c */
double brw_normal(ClRng *r);       /* brw_acklam_inv(brw_uniform(r)); exactly one draw per call */
#endif

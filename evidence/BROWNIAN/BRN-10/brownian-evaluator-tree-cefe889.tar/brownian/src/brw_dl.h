/* brw_dl.h -- BRW-DL v0 interface (private, sealed) */
#ifndef BRW_DL_H
#define BRW_DL_H
#include <stddef.h>
#include <stdint.h>
#define BRW_MAXBYTES 4096
#define BRW_MAXSTACK 16
#define BRW_MAXPOINTS 4096
#define BRW_FITSTEPS 4194304L
#define BRW_PREDSTEPS 1024L
typedef struct { int bytes, k, nfuncs, fitoff, fitlen, predoff, predlen, fnoff[4], fnlen[4]; } BrwInfo;
int brwdl_assemble(const char *text, uint8_t *out, int *n, char *err, int errcap);
int brwdl_check(const uint8_t *code, int n, BrwInfo *info, char *err, int errcap);
int brwdl_run(const uint8_t *code, const BrwInfo *info, const double *t, const double *y, int N, int S,
              double *loc, double *scale, const char **why);
void brwdl_sha256(const uint8_t *m, size_t n, char hex[65]);
#endif

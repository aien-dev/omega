/* repro_fixture.c: builds one certification run (dummy digests, temp dir) and prints two lines on stdout: the temp
 * directory and the path of the resulting qgain. `make brownian-repro-c` rescores that qgain with six differently
 * compiled brownian_bench binaries (plan §24). The caller deletes the temp directory. Never touches evidence/. */
#include "harness_fx.h"
int main(int argc, char **argv) {
    fx_t fx; char gp[BRW_PATH] = "";
    if (argc < 3 || fx_init(&fx, argc, argv)) return 2;
    if (fx_cert(&fx) || fx_score_cert(&fx, "DIFFUSION", "IID_NORMAL", "score1", gp, sizeof gp)) { fprintf(stderr, "repro_fixture: %s\n", fx.why); return 1; }
    printf("%s\n%s\n", fx.tmp, gp);
    return 0;
}

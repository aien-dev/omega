/* test_brw_stats.c: known answers and property checks for brw_stats (Lane D).
 * usage: test_brw_stats [path/to/DESIGN_CHECK_R2.md]   (the md path enables the verbatim frozen-table cross-check) */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "brw_stats.h"
#include "brw_normal.h"

static int g_n, g_fail;
#define CHECK(c) do { g_n++; if (!(c)) { g_fail++; printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)
static int near_rel(double a, double b, double tol) { return fabs(a - b) <= tol * fabs(b); }
static int near_abs(double a, double b, double tol) { return fabs(a - b) <= tol; }

/* ---------- independent chi-square reference (documented) ----------
 * Reference inverse by 400-step bisection in long double on the CLOSED-FORM survival function, which shares no code
 * with the incomplete-gamma Newton solver:
 *   even n : SF(x) = e^{-x/2} sum_{j=0}^{n/2-1} (x/2)^j / j!
 *   odd  n : SF(x) = erfc(sqrt(x/2)) + 2 phi(sqrt x) sum_{k=1}^{(n-1)/2} x^{k-1/2} / (2k-1)!!,  phi = e^{-x/2}/sqrt(2 pi)
 * The solver is asked for the p-quantile, i.e. SF = 1-p. */
static long double ref_sf(unsigned n, long double x) {
    if (n % 2 == 0) {
        long double term = 1.0L, sum = 1.0L;
        for (unsigned j = 1; j < n / 2; j++) { term *= (x / 2.0L) / (long double)j; sum += term; }
        return expl(-x / 2.0L) * sum;
    }
    const long double pi = 3.141592653589793238462643383279502884L;
    long double t = sqrtl(x), sum = 0.0L;
    for (unsigned k = 1; k <= (n - 1) / 2; k++) { if (k > 1) t *= x / (long double)(2 * k - 1); sum += t; }
    return erfcl(sqrtl(x / 2.0L)) + 2.0L * (expl(-x / 2.0L) / sqrtl(2.0L * pi)) * sum;
}
static long double ref_quant(unsigned n, long double p) {
    long double lo = 0.0L, hi = 2000.0L;
    for (int i = 0; i < 400; i++) {
        long double m = 0.5L * (lo + hi);
        if (ref_sf(n, m) > 1.0L - p) lo = m; else hi = m;    /* SF decreasing */
    }
    return 0.5L * (lo + hi);
}

static void test_chi2(void) {
    static const unsigned ns[] = {1, 2, 3, 4, 7, 50, 127, 128, 255, 511};
    static const double ps[] = {0.025, 0.5, 0.975, 0.0041666666666666666, 0.99583333333333333};
    for (size_t i = 0; i < sizeof ns / sizeof ns[0]; i++)
        for (size_t j = 0; j < sizeof ps / sizeof ps[0]; j++) {
            double x; long double r = ref_quant(ns[i], (long double)ps[j]);
            CHECK(brw_chi2_quantile(ns[i], ps[j], &x) == BRW_OK);
            CHECK(near_rel(x, (double)r, 1e-12));
        }
    /* literal KATs, values from the long-double bisection above (printed by this test's derivation run) */
    struct { unsigned n; double p, x; } kat[] = {
        {3, 0.025, 0.2157952826}, {3, 0.975, 9.3484036044}, {127, 0.025, 97.6984854000598}, {127, 0.975, 160.085812374801},
    };
    for (size_t i = 0; i < 2; i++) { double x; CHECK(brw_chi2_quantile(kat[i].n, kat[i].p, &x) == BRW_OK); CHECK(near_rel(x, kat[i].x, 1e-9)); }
    /* n=127 literals: long-double bisection on the closed form, 15 significant digits */
    for (size_t i = 2; i < 4; i++) {
        double x; long double r = ref_quant(kat[i].n, (long double)kat[i].p);
        CHECK(brw_chi2_quantile(kat[i].n, kat[i].p, &x) == BRW_OK);
        CHECK(near_rel(x, (double)r, 1e-12));
        CHECK(near_rel(x, kat[i].x, 1e-12));   /* literal derived by the bisection */
        printf("  chi2 n=%u p=%.3f -> %.15g (bisection %.15Lg)\n", kat[i].n, kat[i].p, x, r);
    }
    /* well-known table values: chi2(1,0.95)=3.841458820694124, chi2(2,0.95)=2*ln 20 */
    double x; CHECK(brw_chi2_quantile(1, 0.95, &x) == BRW_OK); CHECK(near_rel(x, 3.841458820694124, 1e-12));
    CHECK(brw_chi2_quantile(2, 0.95, &x) == BRW_OK); CHECK(near_rel(x, 2.0 * log(20.0), 1e-12));
    CHECK(brw_chi2_quantile(0, 0.5, &x) == BRW_E_ARG); CHECK(brw_chi2_quantile(3, 0.0, &x) == BRW_E_ARG);
    CHECK(brw_chi2_quantile(3, 1.0, &x) == BRW_E_ARG);
    /* round trip */
    CHECK(brw_chi2_quantile(127, 0.3, &x) == BRW_OK);
    CHECK(near_abs((double)brw_gamma_p_ld(63.5L, (long double)x / 2.0L), 0.3, 1e-14));
    /* normal cdf */
    CHECK(brw_norm_cdf(0.0) == 0.5);
    CHECK(near_abs(brw_norm_cdf(1.959963984540054), 0.975, 1e-15));
    CHECK(near_abs(brw_norm_cdf(-1.0), 0.15865525393145707, 1e-15));
}

static void test_diag(void) {
    brw_diag d;
    /* alternating +-1: mean 0, mean z^2 1, lag1 -3/4, kurt -2, all z^2 tied -> Spearman 0, slope -0.4 */
    double z1[4] = {1, -1, 1, -1}, t4[4] = {0, 1, 2, 3}, yp4[4] = {0, 1, 2, 3};
    CHECK(brw_diag_world(z1, t4, yp4, 4, &d) == BRW_OK);
    CHECK(near_abs(d.mean_z, 0, 1e-15)); CHECK(near_abs(d.mean_z2, 1, 1e-15)); CHECK(near_abs(d.lag1, -0.75, 1e-15));
    CHECK(near_abs(d.excess_kurt, -2.0, 1e-15)); CHECK(d.spearman_z2_t == 0.0); CHECK(near_abs(d.slope_prev_y, -0.4, 1e-15));
    /* 1..5: mean 3, mean z^2 11, lag1 0.4, kurt 6.8/4-3 = -1.3, Spearman 1, slope on reversed y -1 */
    double z2[5] = {1, 2, 3, 4, 5}, t5[5] = {1, 2, 3, 4, 5}, y5[5] = {5, 4, 3, 2, 1};
    CHECK(brw_diag_world(z2, t5, y5, 5, &d) == BRW_OK);
    CHECK(near_abs(d.mean_z, 3, 1e-15)); CHECK(near_abs(d.mean_z2, 11, 1e-15)); CHECK(near_abs(d.lag1, 0.4, 1e-15));
    CHECK(near_abs(d.excess_kurt, -1.3, 1e-14)); CHECK(near_abs(d.spearman_z2_t, 1.0, 1e-15)); CHECK(near_abs(d.slope_prev_y, -1.0, 1e-15));
    /* Spearman with ties, average ranks: z^2 = 1,1,4,4,9 -> 9/sqrt(90); irregular t leaves ranks unchanged */
    double z3[5] = {1, -1, 2, -2, 3}, t5i[5] = {0, 0.5, 3, 3.1, 10};
    CHECK(brw_diag_world(z3, t5i, y5, 5, &d) == BRW_OK);
    CHECK(near_abs(d.spearman_z2_t, 9.0 / sqrt(90.0), 1e-14));
    double t5r[5] = {5, 4, 3, 2, 1};
    CHECK(brw_diag_world(z2, t5r, y5, 5, &d) == BRW_OK); CHECK(near_abs(d.spearman_z2_t, -1.0, 1e-15));
    /* refusals */
    double zc[4] = {2, 2, 2, 2};
    CHECK(brw_diag_world(zc, t4, yp4, 4, &d) == BRW_E_RANGE);
    CHECK(brw_diag_world(z1, t4, yp4, 2, &d) == BRW_E_ARG);
    /* constant y_prev -> slope 0 */
    double yc[4] = {7, 7, 7, 7};
    CHECK(brw_diag_world(z1, t4, yc, 4, &d) == BRW_OK); CHECK(d.slope_prev_y == 0.0);
    /* block mean */
    brw_diag ws[2] = {{1, 2, 3, 4, 5, 6}, {3, 4, 5, 6, 7, 8}}, m;
    CHECK(brw_diag_block_mean(ws, 2, &m) == BRW_OK);
    CHECK(m.mean_z == 2 && m.mean_z2 == 3 && m.lag1 == 4 && m.spearman_z2_t == 5 && m.slope_prev_y == 6 && m.excess_kurt == 7);
    /* Gaussian white noise from the brownian stream: kurtosis near 0, mean z^2 near 1, |lag1| small (n large) */
    uint8_t seed[32]; memset(seed, 7, sizeof seed);
    ClRng r; CHECK(brw_stream_init(&r, seed, "latent") == BRW_OK);
    enum { N = 20000 };
    double *z = malloc(N * sizeof *z), *t = malloc(N * sizeof *t), *y = malloc(N * sizeof *y);
    for (int i = 0; i < N; i++) { z[i] = brw_normal(&r); t[i] = i; y[i] = brw_normal(&r); }
    CHECK(brw_diag_world(z, t, y, N, &d) == BRW_OK);
    CHECK(fabs(d.mean_z) < 0.05 && fabs(d.mean_z2 - 1) < 0.05 && fabs(d.lag1) < 0.05 && fabs(d.spearman_z2_t) < 0.05 &&
          fabs(d.slope_prev_y) < 0.05 && fabs(d.excess_kurt) < 0.15);
    free(z); free(t); free(y);
}

static void test_holm(void) {
    int rej[6]; int n;
    double p1[6] = {0.9, 0.001, 0.04, 0.3, 0.02, 0.5};       /* sorted .001 (<=.00833) yes, .02 (<=.01) no -> stop */
    n = brw_holm6(p1, 0.05, rej); CHECK(n == 1 && rej[1] == 1 && rej[4] == 0 && rej[0] == 0);
    double p2[6] = {0.02, 0.005, 0.009, 0.001, 0.011, 0.3};  /* .001<=.00833, .005<=.01, .009<=.0125, .011<=.01667, .02<=.025, .3<=.05 no */
    n = brw_holm6(p2, 0.05, rej); CHECK(n == 5 && rej[5] == 0 && rej[0] == 1 && rej[1] && rej[2] && rej[3] && rej[4]);
    double p3[6] = {0.009, 0.5, 0.6, 0.7, 0.8, 0.9};         /* smallest .009 > .00833: nothing */
    n = brw_holm6(p3, 0.05, rej); CHECK(n == 0);
    double p4[6] = {0.0083, 0.5, 0.6, 0.7, 0.8, 0.9};        /* just under alpha/6 */
    n = brw_holm6(p4, 0.05, rej); CHECK(n == 1 && rej[0]);
    double p5[6] = {0.001, 0.001, 0.001, 0.001, 0.001, 0.001};   /* all six rejected */
    n = brw_holm6(p5, 0.05, rej); CHECK(n == 6);
}

static void test_bands(void) {
    CHECK(near_abs(brw_binom_pmf(2, 4, 0.5), 0.375, 1e-15));
    CHECK(near_abs(brw_binom_range(0, 200, 200, 0.37), 1.0, 1e-12));
    CHECK(near_abs(brw_binom_range(-5, 400, 10, 0.5), 1.0, 1e-13));
    CHECK(brw_band_count_lo(0.90, 200) == 180 && brw_band_count_hi(0.99, 200) == 198);
    CHECK(brw_band_count_lo(0.40, 400) == 160 && brw_band_count_hi(0.10, 400) == 40);
    CHECK(brw_band_count_lo(0.01, 400) == 4 && brw_band_count_hi(0.99, 400) == 396);
    CHECK(near_abs(brw_band_pass_prob(10, 0.5, 0.4, 0.6), (210.0 + 252.0 + 210.0) / 1024.0, 1e-14));
    CHECK(near_abs(brw_binom_pmf(5, 10, 0.5), 252.0 / 1024.0, 1e-14));
    CHECK(brw_band_pass_prob(200, 0.95, 0.90, 0.99) > 0.99);
    /* band decisions at n=200: coverage band [0.90,0.99], stop [0.88,0.995] */
    CHECK(brw_band_check(190, 200, 0.90, 0.99, 0.88, 0.995) == BRW_BAND_PASS);
    CHECK(brw_band_check(180, 200, 0.90, 0.99, 0.88, 0.995) == BRW_BAND_PASS);
    CHECK(brw_band_check(198, 200, 0.90, 0.99, 0.88, 0.995) == BRW_BAND_PASS);
    CHECK(brw_band_check(179, 200, 0.90, 0.99, 0.88, 0.995) == BRW_BAND_WARN);
    CHECK(brw_band_check(176, 200, 0.90, 0.99, 0.88, 0.995) == BRW_BAND_WARN);
    CHECK(brw_band_check(175, 200, 0.90, 0.99, 0.88, 0.995) == BRW_BAND_STOP);
    CHECK(brw_band_check(199, 200, 0.90, 0.99, 0.88, 0.995) == BRW_BAND_WARN);
    CHECK(brw_band_check(200, 200, 0.90, 0.99, 0.88, 0.995) == BRW_BAND_STOP);
    /* one-sided "at least 0.40" over 400 worlds */
    CHECK(brw_band_check(160, 400, 0.40, 1.0, 0.40, 1.0) == BRW_BAND_PASS);
    CHECK(brw_band_check(159, 400, 0.40, 1.0, 0.40, 1.0) == BRW_BAND_STOP);
    /* stop #13 arithmetic and rate from DESIGN_CHECK_R2: r = 0.058, P(>=5/20) about 0.0047 */
    double pst = 1.0 - brw_binom_range(0, 4, 20, 0.058);
    CHECK(near_abs(pst, 0.0047, 5e-4));
    int stop; CHECK(brw_stop13(4, 20, &stop) == BRW_OK && stop == 0);
    CHECK(brw_stop13(5, 20, &stop) == BRW_OK && stop == 1);
    CHECK(brw_stop13(5, 19, &stop) == BRW_E_ARG);
    /* counters */
    double lo[4] = {-1, 0.5, -2, 1}, hi[4] = {1, 2, -0.5, 3}, tr[4] = {0, 0, 0, 2};
    CHECK(brw_count_cover(lo, hi, tr, 4) == 2);
    CHECK(brw_count_excludes(lo, hi, 4, 0.0) == 3);      /* [0.5,2] excludes, [-2,-.5] excludes, [1,3] excludes */
    CHECK(brw_count_below(hi, 4, 0.0) == 1);
}

static void test_intervals(void) {
    /* hand array: t=0..4, y=0,1,3,4,8: increments 1,2,1,4 (h=1) */
    double t[5] = {0, 1, 2, 3, 4}, y[5] = {0, 1, 3, 4, 8};
    double dh, lo, hi, c_lo, c_hi;
    CHECK(brw_d_interval(t, y, 5, &dh, &lo, &hi) == BRW_OK);
    CHECK(near_abs(dh, 22.0 / 8.0, 1e-15));
    CHECK(brw_chi2_quantile(4, 0.025, &c_lo) == BRW_OK && brw_chi2_quantile(4, 0.975, &c_hi) == BRW_OK);
    CHECK(near_rel(lo, 4 * dh / c_hi, 1e-14) && near_rel(hi, 4 * dh / c_lo, 1e-14) && lo < dh && dh < hi);
    double mu;
    CHECK(brw_mu_interval(t, y, 5, &mu, &lo, &hi) == BRW_OK);
    CHECK(near_abs(mu, 2.0, 1e-15));                  /* v_rate = (1+0+1+4)/4 = 1.5, se = sqrt(1.5/4) */
    CHECK(near_abs(hi - mu, 1.959963984540054 * sqrt(1.5 / 4.0), 1e-14) && near_abs(mu - lo, hi - mu, 1e-14));
    CHECK(brw_d_interval_drift(t, y, 5, &dh, &lo, &hi) == BRW_OK);
    CHECK(near_abs(dh, 0.75, 1e-15));
    /* irregular gaps: increments scaled by h */
    double ti[3] = {0, 0.5, 2.5}, yi[3] = {0, 1, 3};
    CHECK(brw_d_interval(ti, yi, 3, &dh, &lo, &hi) == BRW_OK);
    CHECK(near_abs(dh, (1.0 / 0.5 + 4.0 / 2.0) / 4.0, 1e-15));
    double tb[3] = {0, 1, 1}; CHECK(brw_d_interval(tb, yi, 3, &dh, &lo, &hi) == BRW_E_ARG);
    CHECK(brw_d_interval(t, y, 1, &dh, &lo, &hi) == BRW_E_ARG);
    /* coverage of the D interval and the mu interval on simulated D0 worlds (deterministic streams) */
    uint8_t seed[32]; memset(seed, 3, sizeof seed);
    ClRng r; CHECK(brw_stream_init(&r, seed, "latent") == BRW_OK);
    enum { S = 128, W = 4000 };
    double tt[S], yy[S]; uint32_t cd = 0, cm = 0, cdd = 0;
    for (int w = 0; w < W; w++) {
        double D = exp(log(0.05) + (log(20.0) - log(0.05)) * brw_uniform(&r)), x = brw_normal(&r);
        for (int i = 0; i < S; i++) { tt[i] = i; yy[i] = x; x += sqrt(2.0 * D) * brw_normal(&r); }
        double dhat, l, h, m;
        CHECK(brw_d_interval(tt, yy, S, &dhat, &l, &h) == BRW_OK); cd += (l <= D && D <= h);
        CHECK(brw_d_interval_drift(tt, yy, S, &dhat, &l, &h) == BRW_OK); cdd += (l <= D && D <= h);
        CHECK(brw_mu_interval(tt, yy, S, &m, &l, &h) == BRW_OK); cm += (l <= 0.0 && 0.0 <= h);
    }
    double fd = (double)cd / W, fm = (double)cm / W, fdd = (double)cdd / W;
    CHECK(fd > 0.93 && fd < 0.97);      /* nominal 0.95, sd 0.0034 */
    CHECK(fm > 0.93 && fm < 0.97);
    CHECK(fdd > 0.93 && fdd < 0.97);
    printf("  coverage D0 %.4f, D drift-resid %.4f, mu(true 0) %.4f over %d worlds\n", fd, fdd, fm, W);
}

/* replay the documented bootstrap draw order independently */
static void test_bootstrap(void) {
    enum { N = 60 };
    int64_t v[N]; double vd[N];
    for (int i = 0; i < N; i++) { v[i] = (int64_t)((i * 37) % 23 - 8) * 1000000 + i; vd[i] = (double)v[i]; }
    uint8_t seed[32]; for (int i = 0; i < 32; i++) seed[i] = (uint8_t)(i * 5 + 1);
    ClRng a, b; int64_t lo1, hi1, lo2, hi2; double mc1, mc2;
    CHECK(brw_boot_init(&a, seed) == BRW_OK && brw_boot_init(&b, seed) == BRW_OK);
    CHECK(brw_bootstrap_interval(v, N, -128000000, 2000, &a, &lo1, &hi1, &mc1) == BRW_OK);
    CHECK(brw_bootstrap_interval(v, N, -128000000, 2000, &b, &lo2, &hi2, &mc2) == BRW_OK);
    CHECK(lo1 == lo2 && hi1 == hi2 && memcmp(&mc1, &mc2, sizeof mc1) == 0);        /* same seed -> same bits */
    CHECK(lo1 < hi1 && mc1 > 0.0);
    seed[0] ^= 1; CHECK(brw_boot_init(&b, seed) == BRW_OK);
    CHECK(brw_bootstrap_interval(v, N, -128000000, 2000, &b, &lo2, &hi2, NULL) == BRW_OK);
    CHECK(lo2 != lo1 || hi2 != hi1);                                                /* different seed differs */
    /* R3-30d: 128-bit accumulator: resample sums beyond int64 do not overflow; the reported bounds saturate */
    { int64_t big[4] = { INT64_MAX / 2, INT64_MAX / 2, INT64_MAX / 2, INT64_MAX / 2 }; int64_t bl, bh; ClRng c;
      CHECK(brw_boot_init(&c, seed) == BRW_OK && brw_bootstrap_interval(big, 4, 0, 2000, &c, &bl, &bh, NULL) == BRW_OK && bl == INT64_MAX && bh == INT64_MAX); }
    /* independent replay: same stream, own draws, own sort, indices B*25/1000-1 and B*975/1000-1 */
    seed[0] ^= 1; CHECK(brw_boot_init(&b, seed) == BRW_OK);
    int64_t st[2000];
    for (int r = 0; r < 2000; r++) { int64_t s = -128000000; for (int k = 0; k < N; k++) s += v[cl_rng_below(&b, N)]; st[r] = s; }
    for (int i = 1; i < 2000; i++) { int64_t x = st[i]; int j = i - 1; while (j >= 0 && st[j] > x) { st[j + 1] = st[j]; j--; } st[j + 1] = x; }
    CHECK(lo1 == st[49] && hi1 == st[1949]);                                        /* 2000*25/1000-1 = 49; 2000*975/1000-1 = 1949 */
    /* double variant is the same resampling: sum form equals the int64 form without a cell term */
    CHECK(brw_boot_init(&a, seed) == BRW_OK && brw_boot_init(&b, seed) == BRW_OK);
    CHECK(brw_bootstrap_interval(v, N, 0, 2000, &a, &lo1, &hi1, NULL) == BRW_OK);
    double dl, dhh, dm, dl2, dh2;
    CHECK(brw_bootstrap_interval_d(vd, N, 0, 2000, &b, &dl, &dhh, &dm) == BRW_OK);
    CHECK(dl == (double)lo1 && dhh == (double)hi1);
    CHECK(brw_boot_init(&b, seed) == BRW_OK);
    CHECK(brw_bootstrap_interval_d(vd, N, 1, 2000, &b, &dl2, &dh2, NULL) == BRW_OK);
    CHECK(near_abs(dl2, dl / N, 1e-6) && near_abs(dh2, dhh / N, 1e-6));
    /* B = 10000: index 249 / 9749; constant world values give a degenerate interval */
    int64_t c[10]; for (int i = 0; i < 10; i++) c[i] = 500000;
    CHECK(brw_boot_init(&a, seed) == BRW_OK);
    CHECK(brw_bootstrap_interval(c, 10, 0, BRW_BOOT_B, &a, &lo1, &hi1, &mc1) == BRW_OK);
    CHECK(lo1 == 5000000 && hi1 == 5000000 && mc1 == 0.0);
    /* classification */
    CHECK(brw_classify(0.1, 2.0) == BRW_CLASS_POS && brw_classify(-3, -0.1) == BRW_CLASS_NEG);
    CHECK(brw_classify(-1, 1) == BRW_CLASS_AMB && brw_classify(0.0, 1.0) == BRW_CLASS_AMB && brw_classify(-1, 0.0) == BRW_CLASS_AMB);
    CHECK(brw_classify_ub(1, 5) == BRW_CLASS_POS && brw_classify_ub(-5, -1) == BRW_CLASS_NEG && brw_classify_ub(-5, 5) == BRW_CLASS_AMB);
    /* clearly positive T worlds: lower > 0; zero-centered: covers 0 */
    int64_t pos[50], zc[50];
    for (int i = 0; i < 50; i++) { pos[i] = 3000000 + (i % 5) * 100000; zc[i] = (i % 2 ? 1 : -1) * 1000000; }
    CHECK(brw_boot_init(&a, seed) == BRW_OK);
    CHECK(brw_bootstrap_interval(pos, 50, 0, 2000, &a, &lo1, &hi1, NULL) == BRW_OK && brw_classify_ub(lo1, hi1) == BRW_CLASS_POS);
    CHECK(brw_boot_init(&a, seed) == BRW_OK);
    CHECK(brw_bootstrap_interval(zc, 50, 0, 2000, &a, &lo1, &hi1, NULL) == BRW_OK && brw_classify_ub(lo1, hi1) == BRW_CLASS_AMB);
    /* argument checks */
    CHECK(brw_bootstrap_interval(v, 0, 0, 2000, &a, &lo1, &hi1, NULL) == BRW_E_ARG);
    CHECK(brw_bootstrap_interval(v, N, 0, 2005, &a, &lo1, &hi1, NULL) == BRW_E_ARG);
    CHECK(brw_bootstrap_interval(v, N, 0, 100, &a, &lo1, &hi1, NULL) == BRW_E_ARG);
}

static void test_null_and_diag_boot(void) {
    /* calibration: block means with known order statistics */
    enum { NB = 1000 };
    brw_diag *bm = calloc(NB, sizeof *bm);
    for (int b = 0; b < NB; b++) {
        double u = ((b * 7919) % NB) / (double)NB;    /* permutation of 0..999 /1000 */
        bm[b].mean_z = u; bm[b].mean_z2 = 1 + u; bm[b].lag1 = -u; bm[b].spearman_z2_t = 2 * u; bm[b].slope_prev_y = 10 * u; bm[b].excess_kurt = u * u;
    }
    brw_null_cell nc; CHECK(brw_null_calibrate(bm, NB, BRW_NULL_TAIL, &nc) == BRW_OK);
    /* (int)(0.05/12*1000) = 4; (int)((1-0.05/12)*1000) = 995 */
    CHECK(near_abs(nc.center[0], 0.4995, 1e-12));
    CHECK(near_abs(nc.lo[0], 0.004, 1e-12) && near_abs(nc.hi[0], 0.995, 1e-12));
    CHECK(near_abs(nc.lo[1], 1.004, 1e-12) && near_abs(nc.hi[2], -0.004, 1e-12) && near_abs(nc.lo[2], -0.995, 1e-12));
    CHECK(brw_null_calibrate(bm, 50, BRW_NULL_TAIL, &nc) == BRW_E_ARG);
    CHECK(brw_null_calibrate(bm, NB, 0.6, &nc) == BRW_E_ARG);
    brw_null_cell c2; CHECK(brw_null_calibrate(bm, NB, BRW_NULL_TAIL, &c2) == BRW_OK);
    int fl[6];
    brw_diag inside = {0.5, 1.5, -0.5, 1.0, 5.0, 0.25};
    CHECK(brw_null_reject(&inside, &c2, fl) == 0);
    brw_diag out1 = inside; out1.lag1 = 0.1;               /* above the hi of lag1 (-0.004) */
    CHECK(brw_null_reject(&out1, &c2, fl) == 1 && fl[2] == 1 && fl[0] == 0);
    brw_diag out2 = inside; out2.mean_z = 0.001;           /* below lo 0.004 */
    CHECK(brw_null_reject(&out2, &c2, fl) == 1 && fl[0] == 1);
    free(bm);
    /* bootstrap + Holm on world-level statistics: null-like vs shifted mean z */
    uint8_t seed[32]; memset(seed, 9, sizeof seed);
    ClRng g; CHECK(brw_stream_init(&g, seed, "latent") == BRW_OK);
    enum { W = 200 };
    brw_diag ws[W], ws2[W]; double null6[6] = {0, 1, 0, 0, 0, 0};
    for (int w = 0; w < W; w++) {
        double u[6]; for (int d = 0; d < 6; d++) u[d] = brw_normal(&g);
        ws[w] = (brw_diag){u[0], 1 + 0.5 * u[1], u[2] * 0.1, u[3] * 0.1, u[4] * 0.1, u[5] * 0.3};
        ws2[w] = ws[w]; ws2[w].mean_z += 1.0;
    }
    ClRng b; double p[6]; int rej[6], n;
    CHECK(brw_boot_init(&b, seed) == BRW_OK);
    CHECK(brw_diag_boot_holm(ws2, W, null6, 2000, &b, 0.05, p, rej, &n) == BRW_OK);
    CHECK(n >= 1 && rej[0] == 1 && p[0] < 0.01);
    for (int d = 0; d < 6; d++) CHECK(p[d] >= 0.0 && p[d] <= 1.0);
    CHECK(brw_boot_init(&b, seed) == BRW_OK);
    CHECK(brw_diag_boot_holm(ws, W, null6, 2000, &b, 0.05, p, rej, &n) == BRW_OK);
    printf("  null-like worlds: p = %.3f %.3f %.3f %.3f %.3f %.3f, n_reject %d\n", p[0], p[1], p[2], p[3], p[4], p[5], n);
    CHECK(n == 0);
    /* determinism */
    double p2[6]; int rej2[6], n2;
    CHECK(brw_boot_init(&b, seed) == BRW_OK);
    CHECK(brw_diag_boot_holm(ws, W, null6, 2000, &b, 0.05, p2, rej2, &n2) == BRW_OK);
    CHECK(memcmp(p, p2, sizeof p) == 0 && n == n2);
}

/* ---------- frozen table ---------- */
static const char *trim(char *s) { while (*s == ' ') s++; char *e = s + strlen(s); while (e > s && (e[-1] == ' ' || e[-1] == '\n' || e[-1] == '|')) *--e = 0; return s; }

static void test_frozen(const char *md) {
    CHECK(BRW_FROZEN_NULLS_N == 11);
    CHECK(brw_frozen_null_find("B0-short") == NULL);              /* not run (N = 8): no row exists */
    CHECK(brw_frozen_null_find("nope") == NULL);
    /* spot values copied by hand from DESIGN_CHECK_R2 */
    const brw_frozen_null *f = brw_frozen_null_find("B0-regular");
    CHECK(f && f->W == 400 && f->H == 128 && !strcmp(f->matching_ref, "DIFFUSION"));
    CHECK(f->nc.center[0] == -0.000003 && f->nc.lo[0] == -0.01247 && f->nc.hi[0] == 0.01243);
    CHECK(f->nc.center[1] == 1.016106 && f->nc.hi[5] == 0.00650 && f->nc.lo[5] == -0.10432);
    f = brw_frozen_null_find("B2-emerging");
    CHECK(f && f->W == 1600 && f->H == 512 && !strcmp(f->matching_ref, "MEAN_REVERT"));
    CHECK(f->nc.center[2] == 0.022832 && f->nc.lo[2] == 0.01874 && f->nc.hi[2] == 0.02710 && f->nc.lo[4] == 0.00478);
    f = brw_frozen_null_find("B1-3"); CHECK(f && f->H == 256 && !strcmp(f->matching_ref, "DIFFUSION_DRIFT") && f->nc.hi[4] == -0.00076);
    f = brw_frozen_null_find("B2-weak"); CHECK(f && f->W == 200 && f->nc.center[1] == 1.058483);
    /* structure: every center inside its interval, lo < hi */
    for (size_t i = 0; i < BRW_FROZEN_NULLS_N; i++)
        for (int d = 0; d < 6; d++) {
            const brw_null_cell *c = &BRW_FROZEN_NULLS[i].nc;
            CHECK(c->lo[d] < c->hi[d]);
            CHECK(c->lo[d] <= c->center[d] && c->center[d] <= c->hi[d]);
        }
    if (!md) { printf("  (no md path given: verbatim cross-check skipped)\n"); return; }
    FILE *fp = fopen(md, "r"); CHECK(fp != NULL); if (!fp) return;
    char line[8192]; int in = 0, rows = 0, notrun = 0;
    while (fgets(line, sizeof line, fp)) {
        if (!strncmp(line, "## Frozen values", 16)) { in = 1; continue; }
        if (in && !strncmp(line, "## ", 3)) break;
        if (!in || strncmp(line, "| B", 3)) continue;
        char *save = NULL; char *tok = strtok_r(line, "|", &save); char *fld[16]; int nf = 0;
        while (tok && nf < 16) { fld[nf++] = tok; tok = strtok_r(NULL, "|", &save); }
        while (nf > 0 && !*trim(fld[nf - 1])) nf--;
        if (nf < 3) continue;
        char name[64]; snprintf(name, sizeof name, "%s", trim(fld[0]));
        const char *last = trim(fld[nf - 1]);
        if (strstr(last, "not run")) { notrun++; CHECK(brw_frozen_null_find(name) == NULL); continue; }
        const brw_frozen_null *t = brw_frozen_null_find(name); CHECK(t != NULL); if (!t) continue;
        CHECK((uint32_t)atoi(trim(fld[1])) == t->W && (uint32_t)atoi(trim(fld[2])) == t->H);
        char buf[4096]; snprintf(buf, sizeof buf, "%s", last);
        char *p = buf; int d = 0;
        while (d < 6) {
            char *br = strstr(p, "<br>"); if (br) *br = 0;
            double c, lo, hi;
            CHECK(sscanf(p, " %lf [%lf, %lf]", &c, &lo, &hi) == 3);
            CHECK(t->nc.center[d] == c && t->nc.lo[d] == lo && t->nc.hi[d] == hi);
            d++; if (!br) break; p = br + 4;
        }
        CHECK(d == 6); rows++;
    }
    fclose(fp);
    CHECK(rows == 11 && notrun == 1);
    printf("  frozen table: %d rows matched verbatim against %s (%d 'not run')\n", rows, md, notrun);
}

int main(int argc, char **argv) {
    test_chi2(); test_diag(); test_holm(); test_bands(); test_intervals(); test_bootstrap(); test_null_and_diag_boot();
    test_frozen(argc > 1 ? argv[1] : NULL);
    printf("test_brw_stats: %d checks, %d failed\n", g_n, g_fail);
    return g_fail ? 1 : 0;
}

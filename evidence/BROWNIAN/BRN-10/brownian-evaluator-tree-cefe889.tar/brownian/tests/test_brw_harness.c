/* Lane D3 tests: the blind lifecycle (plan §10 steps 1-9), the binding messages R3-26 (G2, G3, G6, G7, G9) and the
 * in-process versus interpreter equality. Hostile §18 cases live in the tests/hostile directory.
 * argv: <checkout root holding brownian/src> <pinned omega> <build/brw_interp>
 * All fixtures are temp directories with dummy digests. Sealed generation runs only on those dummy freezes. */
#include "harness_fx.h"
#include <sys/wait.h>

static int g_blocked;

static int file_has(const char *path, const char *needle) {
    brw_bytes b;
    if (brw_slurp(path, &b) != 0) return 0;
    char *z = malloc(b.n + 1); memcpy(z, b.b, b.n); z[b.n] = 0;
    int r = strstr(z, needle) != NULL;
    free(z); brw_bytes_free(&b);
    return r;
}

static void test_units(fx_t *fx) {
    /* G6: labels are disjoint and total */
    CHECK(!strcmp(brw_class_label(5, 1, 9), "POSITIVE"), "G6 lower>0 POSITIVE");
    CHECK(!strcmp(brw_class_label(-5, -9, -1), "NEGATIVE"), "G6 upper<0 NEGATIVE");
    CHECK(!strcmp(brw_class_label(5, -1, 9), "WEAK"), "G6 covers 0, point>0 WEAK");
    CHECK(!strcmp(brw_class_label(0, -1, 9), "AMBIGUOUS"), "G6 covers 0, point=0 AMBIGUOUS");
    CHECK(!strcmp(brw_class_label(-5, -9, 1), "AMBIGUOUS"), "G6 covers 0, point<0 AMBIGUOUS");
    CHECK(!strcmp(brw_class_label(3, 0, 9), "WEAK"), "G6 lower=0 covers 0 WEAK");
    CHECK(!strcmp(brw_class_label(-3, -9, 0), "AMBIGUOUS"), "G6 upper=0 covers 0 AMBIGUOUS");
    /* R3-30c: H=128 per world. The exact value is 173.28 ub (spec: about 1.73e-4 bit); rounded up per world it is 174 */
    CHECK(brw_numeric_bound_world_ub(128) == 174, "R3-30c numeric bound, H=128: ceil(173.28) = 174 ub");
    CHECK(brw_numeric_bound_world_ub(128) > 173 && brw_numeric_bound_world_ub(128) < 175, "R3-30c numeric bound near 1.73e-4 bit");
    /* frozen sandbox argv (U2) */
    const char *const *a = brw_sandbox_argv();
    CHECK(a[0] && !strcmp(a[0], "/usr/bin/bwrap"), "argv[0] is bwrap");
    int has_unshare = 0, has_clear = 0, has_die = 0;
    for (int i = 0; a[i]; i++) { has_unshare |= !strcmp(a[i], "--unshare-all"); has_clear |= !strcmp(a[i], "--clearenv"); has_die |= !strcmp(a[i], "--die-with-parent"); }
    CHECK(has_unshare && has_clear && has_die, "frozen argv has --unshare-all --clearenv --die-with-parent");
    /* calibration file is exactly its rendering */
    char *cal = malloc(16384); size_t cl = 0;
    CHECK(cal && brw_calib_render(cal, 16384, &cl) == 0 && cl > 20, "calib render");
    char p[BRW_PATH]; snprintf(p, sizeof p, "%s/calib_unit.txt", fx->tmp);
    cal[cl] = 0; fx_put(p, cal);
    ty_digest d;
    CHECK(brw_calib_check(p, &d, fx->why, sizeof fx->why) == 0, "calib check accepts the rendering");
    fx_put(p, "brw.calib.v1\nB0-short mean_z 0 0 0\n");
    REJECT(brw_calib_check(p, &d, fx->why, sizeof fx->why), TYQ_FAIL_PROFILE, "calib check refuses a different file");
    /* R3-28d: occ_cross lines after the null lines are accepted (H ascending, %.17g); anything else is refused */
    {
        static const char *const good[] = { "occ_cross 64 0.5\n", "occ_cross 64 0.5\nocc_cross 128 1.2345678901234567\n" };
        static const char *const bad[] = { "occ_cross 128 0.5\nocc_cross 128 0.6\n", "occ_cross 128 0.5\nocc_cross 64 0.6\n", "occ_cross 128\n",
            "occ_cross 128 0.5 x\n", "occ_cross 128 nan\n", "occ_cross 128 0.5", "extra 1 2\n", "occ_cross 0 0.5\n", "occ_cross 128 0.5\n\n" };
        char *big = malloc(16384 + 512);
        if (big) {
            for (size_t i = 0; i < sizeof good / sizeof *good; i++) {
                snprintf(big, 16384 + 512, "%s%s", cal, good[i]); fx_put(p, big);
                CHECK(brw_calib_check(p, &d, fx->why, sizeof fx->why) == 0, "calib check accepts occ_cross lines");
            }
            for (size_t i = 0; i < sizeof bad / sizeof *bad; i++) {
                snprintf(big, 16384 + 512, "%s%s", cal, bad[i]); fx_put(p, big);
                REJECT(brw_calib_check(p, &d, fx->why, sizeof fx->why), TYQ_FAIL_PROFILE, "calib check refuses a bad occ_cross tail");
            }
            free(big);
        }
    }
    free(cal);
    /* scanner known answers */
    CHECK(brw_scan_text("plain list of numbers", 21, NULL, 0) == 0, "scanner passes plain text");
    CHECK(brw_scan_text("a diffusion process", 19, NULL, 0) == TYQ_FAIL_PROTOCOL, "scanner refuses a label word");
    /* cell table: every reference cell has a size and H- cells are hostile */
    brw_cellinfo ci;
    CHECK(brw_cellinfo_get("B0-short", &ci) == 0 && ci.s.n_points == 8 && ci.s.split == 4 && !ci.hostile, "B0-short is 8 points, split 4");
    CHECK(brw_cellinfo_get("H-meas", &ci) == 0 && ci.hostile, "H-meas is hostile (development only)");
    CHECK(brw_cellinfo_get("INT-d8", &ci) == 0 && ci.W == 1600 && ci.H == 512 && !ci.hostile && ci.experiment && strcmp(ci.experiment, "EXP-002C-INT") == 0 && ci.s.set_state && ci.s.split == 129 && ci.s.n_points == 641 && !ci.descriptive, "INT-d8 is a sealable 1600 x 512 scored cell (set state at 128, scored from 129)");
    CHECK(brw_cellinfo_get("CTL-d5", &ci) == 0 && ci.W == 1600 && ci.H == 512 && !ci.hostile && !ci.descriptive && ci.s.set_state && ci.s.family == BRW_FAM_D0 && ci.experiment && strcmp(ci.experiment, "EXP-002C-INT") == 0, "CTL-d5 is a 1600 x 512 control cell in the same experiment");
    { size_t nocc = 0, nall = brw_cellinfo_count(); int okocc = 1;
      for (size_t i = 0; i < nall; i++) { brw_cellinfo x; brw_cellinfo_at(i, &x); if (strncmp(x.s.name, "OCC-", 4) == 0) { nocc++; okocc &= x.W == 400 && x.experiment && strcmp(x.experiment, "EXP-002B-OCC") == 0 && !x.hostile && !x.descriptive && x.s.n_points == x.s.split + x.H && x.s.split == 128 && (x.H == 128 || x.H == 256 || x.H == 512 || x.H == 1024); } }
      CHECK(nocc == 124 && okocc, "124 OCC cells, W = 400, tag EXP-002B-OCC, H in {128,256,512,1024}");
      CHECK(brw_cellinfo_get("OCC-s-3.25-H512", &ci) == 0 && ci.W == 400 && ci.H == 512 && ci.s.snr_s == -3.25 && ci.s.n_points == 640, "OCC-s-3.25-H512 lookup"); }
    CHECK(brw_cellinfo_get("INT05-d0", &ci) == 0 && ci.W == 200 && ci.H == 128 && ci.s.n_points == 257 && ci.descriptive && !ci.hostile && ci.experiment && strcmp(ci.experiment, "EXP-002C-INT") == 0, "INT05-d0 is a 200 x 128 descriptive cell");
    CHECK(brw_cellinfo_get("INT-d0", &ci) == 0 && !ci.descriptive && brw_cellinfo_get("B2-emerging", &ci) == 0 && !ci.descriptive && !ci.s.set_state, "gated and observational cells are not descriptive");
    CHECK(brw_cellinfo_get("INT-d0", &ci) == 0 && brw_cellinfo_get("INT-d1", &ci) == 0 && brw_cellinfo_get("INT-d2", &ci) == 0 && brw_cellinfo_get("INT-d5", &ci) == 0 && brw_cellinfo_get("CTL-d0", &ci) == 0 && brw_cellinfo_get("CTL-d8", &ci) == 0 && brw_cellinfo_get("INT05-d8", &ci) == 0, "INT, CTL and INT05 cells are listed");
}

/* R3-36 (i): INT/CTL/INT05 PRD1 files cover the scored rows only (indices 129 .. 128 + H); the model is fitted on the 128-point prefix and the
 * first scored prediction is anchored on the set-state point (index 128), which itself is not scored */
static void test_int_prd(void) {
    static const char *const cells[3] = { "INT-d2", "CTL-d1", "INT05-d8" };
    for (int c = 0; c < 3; c++) {
        brw_cell_spec cs; brw_traj tr; brw_prog dp; brw_bytes pb; char why[160], label[96]; uint8_t ws[32]; ty_prd prd;
        uint32_t H = c == 2 ? 128u : 512u;
        CHECK(brw_cell_lookup(cells[c], &cs) == BRW_OK && brw_ref_program(BRW_OP_DIFFUSION, &dp) == TYQ_OK, "INT PRD1 fixture");
        brw_world_label("dev", cells[c], 0, label, sizeof label);
        brw_world_seed(label, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), 0, ws);
        if (brw_world_generate(&cs, ws, &tr, NULL) != BRW_OK) { CHECK(0, "INT PRD1 world"); continue; }
        CHECK(brw_prd_for_program(&dp, &tr, &cs, &pb, why, sizeof why) == 0, "INT PRD1 built");
        memset(&prd, 0, sizeof prd);
        CHECK(ty_prd_parse(pb.b, pb.n, 129, H, &prd) == TYQ_OK, "PRD1 covers exactly the scored rows 129 .. 128 + H");
        CHECK(prd.rec && prd.rec[0].index == 129 && prd.rec[H - 1].index == 128 + H, "first scored index 129, last 128 + H");
        CHECK(prd.rec && prd.rec[0].loc == brw_symbol_value(tr.k[128]), "DIFFUSION at index 129 is centred on the SET state, not the prefix");
        ty_prd_free(&prd);
        CHECK(ty_prd_parse(pb.b, pb.n, 128, H + 1, &prd) != TYQ_OK, "a PRD1 that started at index 128 would be refused");
        ty_prd_free(&prd);
        brw_bytes_free(&pb); brw_traj_free(&tr);
    }
}

static void test_thresholds(fx_t *fx) {
    /* thresholds sidecar: read from a path, refused when its digest differs from the qprofile's (spec §25) */
    CHECK(brw_thr_file_check(&fx->prof, fx->thr, fx->why, sizeof fx->why) == 0, "thresholds sidecar matching the qprofile is accepted");
    char p[BRW_PATH]; snprintf(p, sizeof p, "%s/thr_other.txt", fx->tmp);
    fx_put(p, "T1 lower 0\nT2 lower 2\n");
    REJECT(brw_thr_file_check(&fx->prof, p, fx->why, sizeof fx->why), TYQ_FAIL_PROFILE, "thresholds sidecar with another digest refused");
    snprintf(p, sizeof p, "%s/thr_missing.txt", fx->tmp);
    CHECK(brw_thr_file_check(&fx->prof, p, fx->why, sizeof fx->why) != 0, "missing thresholds sidecar refused");
}

static void test_freeze_and_seal(fx_t *fx) {
    int rc = fx_prepare(fx, "certification");
    REJECT(rc, 0, "prepare qprofile, dev block, devman, calibration");
    if (rc) { printf("  why: %s\n", fx->why); return; }
    test_thresholds(fx);
    /* G7: producer-side devman */
    char p[BRW_PATH]; snprintf(p, sizeof p, "%s/devman.pub.txt", fx->work);
    brw_bytes pb;
    CHECK(brw_slurp(p, &pb) == 0 && pb.n > 0, "devman.pub.txt written");
    if (pb.n) {
        char *z = malloc(pb.n + 1); memcpy(z, pb.b, pb.n); z[pb.n] = 0;
        int ok = 1, lines = 0; char prev[9] = "";
        for (char *l = strtok(z, "\n"); l; l = strtok(NULL, "\n")) {
            lines++;
            if (strlen(l) != 73 || l[8] != ' ') { ok = 0; continue; }
            for (int i = 0; i < 73; i++) if (i != 8 && !((l[i] >= '0' && l[i] <= '9') || (l[i] >= 'a' && l[i] <= 'f'))) ok = 0;
            if (strncmp(prev, l, 8) > 0) ok = 0;
            snprintf(prev, sizeof prev, "%.8s", l);
        }
        CHECK(ok && lines > 0, "G7 devman.pub lines are `<sha8> <sha256>` sorted by sha8, nothing else");
        CHECK(!strstr((char *)pb.b, "B0") && !strstr((char *)pb.b, "POSITIVE"), "G7 devman.pub names no cell or label");
        free(z);
    }
    brw_bytes_free(&pb);
    CHECK(file_has(fx->devman, "B0-short"), "devman (evaluator only) keeps the cell names");
    /* freeze; a seal before the freeze is refused */
    brw_seal_ctx ctx;
    char nofz[BRW_PATH]; snprintf(nofz, sizeof nofz, "%s/turing.qfreeze.%064d.omg0", fx->tmp, 0);
    CHECK(brw_seal_check(nofz, fx->predict_src, "B0-short", &ctx, fx->why, sizeof fx->why) != 0, "sealed generation refused: no qfreeze");
    rc = fx_freeze(fx, fx->predict_src, NULL);
    REJECT(rc, 0, "freeze");
    if (rc) { printf("  why: %s\n", fx->why); return; }
    struct stat st;
    CHECK(stat(fx->qfreeze, &st) == 0 && (st.st_mode & 0777) == 0444, "qfreeze is write-once, mode 0444");
    /* G3 */
    char hex[65], want[BRW_PATH];
    ty_digest cd;
    CHECK(brw_calib_check(fx->calib, &cd, fx->why, sizeof fx->why) == 0, "calibration file valid");
    ty_hex(&cd, hex);
    snprintf(want, sizeof want, "calib=%s turing_profile=%s", hex, FX_T0);
    CHECK(!strcmp(fx->fr.calibration_extra, want), "G3 calibration_extra = calib=<sha256 of brw.calib.v1> turing_profile=<hex>");
    /* a freeze without a turing profile carries 64 zeros */
    {
        fx_t f2; char *av[3] = { "x", fx->root, fx->omega };
        if (fx_init(&f2, 3, av) == 0 && fx_prepare(&f2, "certification") == 0) {
            brw_freeze_args a; memset(&a, 0, sizeof a);
            a.artifact = f2.predict_src; a.qprofile = f2.qprofile; a.devman = f2.devman; a.calibration = f2.calib; a.meta = f2.meta; a.outdir = f2.fdir;
            tyqr_freeze f; ty_digest fd;
            CHECK(brw_freeze(&a, &f, &fd, f2.why, sizeof f2.why) == 0 && strstr(f.calibration_extra, "turing_profile=0000000000000000000000000000000000000000000000000000000000000000"),
                  "G3 turing_profile is 64 zeros until provided");
        }
        fx_done(&f2);
    }
    /* the artifact digest binds: another file is refused */
    char other[BRW_PATH]; snprintf(other, sizeof other, "%s/brownian/src/brw_dl.c", fx->root);
    REJECT(brw_seal_check(fx->qfreeze, other, "B0-short", &ctx, fx->why, sizeof fx->why), TYQ_FAIL_DIGEST, "sealed generation refused: artifact digest mismatch");
    /* the qprofile named by the qfreeze must be present and match */
    {
        char lone[BRW_PATH], q2[BRW_PATH];
        fx_dir(fx, lone, "lone");
        snprintf(q2, sizeof q2, "%s/%s", lone, strrchr(fx->qfreeze, '/') + 1);
        fx_cp(fx->qfreeze, q2);
        CHECK(brw_seal_check(q2, fx->predict_src, "B0-short", &ctx, fx->why, sizeof fx->why) != 0, "sealed generation refused: qprofile missing or mismatched");
    }
    /* a hostile cell is never sealed */
    CHECK(brw_seal_check(fx->qfreeze, fx->predict_src, "H-meas", &ctx, fx->why, sizeof fx->why) != 0, "sealed generation refused for a hostile cell");
    CHECK(brw_seal_check(fx->qfreeze, fx->predict_src, "B0-short", &ctx, fx->why, sizeof fx->why) == 0, "seal check passes for the good freeze");
    /* the seed is a function of the qfreeze digest (plan §10) */
    uint8_t parent[32]; char lab[80]; ty_digest sd;
    memcpy(lab, "brownian.seal.v1", 17);
    { uint8_t buf[17 + 32]; memcpy(buf, lab, 17); memcpy(buf + 17, fx->fd.b, 32); brw_sha256(buf, sizeof buf, &sd); }
    memcpy(parent, ctx.parent, 32);
    CHECK(!memcmp(parent, sd.b, 32), "sealed parent = SHA-256(\"brownian.seal.v1\" || 0x00 || qfreeze digest)");
    /* the seal, then the one-attempt rule */
    rc = fx_seal(fx, fx->predict_src);
    REJECT(rc, 0, "sealed generation");
    if (rc) { printf("  why: %s\n", fx->why); return; }
    char sdir2[BRW_PATH]; fx_dir(fx, sdir2, "sealed2");
    tyqr_world w; ty_digest wd;
    REJECT(brw_seal(&fx->env, fx->qfreeze, fx->predict_src, "B0-short", sdir2, NULL, &w, &wd, fx->why, sizeof fx->why), BRW_STOPPED, "#32 second sealed attempt is STOPPED");
    /* the trajectory files must not already exist: a fresh ledger dir but the same output dir */
    char led2[BRW_PATH]; fx_dir(fx, led2, "ledger2");
    rc = brw_seal(&fx->env, fx->qfreeze, fx->predict_src, "B0-short", fx->sdir, led2, &w, &wd, fx->why, sizeof fx->why);
    CHECK(rc != 0, "sealed generation refuses when the trajectory files already exist");
}

static void test_score_verify(fx_t *fx) {
    char gp[BRW_PATH] = "";
    int rc = fx_score_cert(fx, "DIFFUSION", "IID_NORMAL", "score1", gp, sizeof gp);
    REJECT(rc, 0, "score certification DIFFUSION vs IID");
    if (rc) { printf("  why: %s\n", fx->why); return; }
    tyqr_gain g; ty_digest gd;
    CHECK(brw_load_gain(gp, &g, &gd, fx->why, sizeof fx->why) == 0, "qgain loads and its digest matches its name");
    const char *cl = g.classification;
    CHECK(!strcmp(cl, "POSITIVE") || !strcmp(cl, "NEGATIVE") || !strcmp(cl, "WEAK") || !strcmp(cl, "AMBIGUOUS"), "G6 record carries one of the four labels");
    CHECK(!strcmp(cl, brw_class_label(g.t_ub, g.t_lo_ub, g.t_hi_ub)), "G6 label agrees with the interval");
    REJECT(brw_verify(gp, fx->thr, fx->predict_src, fx->why, sizeof fx->why), 0, "verify rebuilds the gain from stored files");
    REJECT(brw_replay(&fx->env, gp, 1, NULL, fx->why, sizeof fx->why), 0, "replay with regeneration");
    /* a baseline that is not the declared one needs a ladder item */
    brw_score_args a; memset(&a, 0, sizeof a);
    char out[BRW_PATH]; fx_dir(fx, out, "score2");
    char qf[BRW_PATH]; brw_record_path(qf, sizeof qf, fx->sdir, "turing.qfreeze", &fx->fd);
    a.mode = "certification"; a.qfreeze = qf; a.qworld = fx->qworld; a.candidate = "DIFFUSION"; a.baseline = "LINEAR_TREND";
    a.predict_src = fx->predict_src; a.outdir = out;
    REJECT(brw_score(&a, &g, &gd, NULL, 0, fx->why, sizeof fx->why), TYQ_FAIL_BASELINE, "#29 swapped baseline without a ladder item");
    /* mode mixing: certification qfreeze scored as discovery */
    a.mode = "discovery"; a.baseline = "IID_NORMAL"; a.candidate = fx->predict_src; a.candidate_cmd = "/nonexistent";
    REJECT(brw_score(&a, &g, &gd, NULL, 0, fx->why, sizeof fx->why), TYQ_FAIL_PROTOCOL, "#31 certification qfreeze scored as discovery");
    /* a thresholds sidecar with a different digest is refused at score time */
    char thr2[BRW_PATH]; snprintf(thr2, sizeof thr2, "%s/thr2.txt", fx->tmp); fx_put(thr2, "T1 lower 0\nT2 lower 3\n");
    a.mode = "certification"; a.candidate = "DIFFUSION"; a.candidate_cmd = NULL; a.thresholds = thr2; fx_dir(fx, out, "score3"); a.outdir = out;
    REJECT(brw_score(&a, &g, &gd, NULL, 0, fx->why, sizeof fx->why), TYQ_FAIL_PROFILE, "score refuses a thresholds sidecar with a different digest");
}

/* in-process PRD1 == interpreter PRD1, world by world (discovery runs the same fit-once computation) */
static void test_interp_equal(fx_t *fx, const char *interp) {
    fx_gain_t x;
    int rc = fx_gain_load(fx, &x, 1, BRW_OP_DIFFUSION);
    REJECT(rc, 0, "load the sealed world");
    if (rc) { printf("  why: %s\n", fx->why); fx_gain_free(&x); return; }
    char art[BRW_PATH]; snprintf(art, sizeof art, "%s/diffusion.brwdl", fx->tmp);
    FILE *f = fopen(art, "wb"); fwrite(x.pm.bytes, 1, (size_t)x.pm.n, f); fclose(f);
    brw_bytes *prd = calloc(x.W, sizeof *prd);
    char note[4096] = "";
    rc = brw_run_discovery(interp, art, x.tr, x.W, &x.in.ci.s, prd, note, sizeof note, fx->why, sizeof fx->why);
    if (rc == BRW_BLOCKED) { printf("BLOCKED: %s\n", fx->why); g_blocked++; }
    else {
        REJECT(rc, 0, "interpreter run under bwrap");
        if (rc == 0) {
            size_t same = 0;
            for (size_t w = 0; w < x.W; w++) same += prd[w].n == x.prd_m[w].n && !memcmp(prd[w].b, x.prd_m[w].b, prd[w].n);
            CHECK(same == x.W, "interpreter PRD1 is byte-identical to the in-process PRD1 for every world");
            printf("  interpreter vs in-process identical worlds: %zu of %zu\n", same, x.W);
        } else printf("  why: %s\n", fx->why);
        for (size_t w = 0; w < x.W; w++) brw_bytes_free(&prd[w]);
    }
    free(prd);
    fx_gain_free(&x);
}

static void test_discovery(fx_t *fx, const char *interp) {
    fx_t d; char *av[3] = { "x", fx->root, fx->omega };
    if (fx_init(&d, 3, av)) { CHECK(0, "discovery fixture"); return; }
    REJECT(fx_prepare(&d, "discovery"), 0, "discovery prepare");
    brw_prog dp; brw_ref_program(BRW_OP_DIFFUSION, &dp);
    char art[BRW_PATH]; snprintf(art, sizeof art, "%s/art.brwdl", d.tmp);
    FILE *f = fopen(art, "wb"); fwrite(dp.bytes, 1, (size_t)dp.n, f); fclose(f);
    fx_meta(&d, "discovery", "producer_tool=testtool\nproducer_model=testmodel\n"
        "prompt_digest=1111111111111111111111111111111111111111111111111111111111111111\n"
        "transcript_digest=2222222222222222222222222222222222222222222222222222222222222222\n");
    int rc = fx_freeze(&d, art, interp);
    REJECT(rc, 0, "discovery freeze (artifact_bin = SHA-256 of the interpreter, U3)");
    if (rc) { printf("  why: %s\n", d.why); fx_done(&d); return; }
    ty_digest ad, id; brw_bytes b;
    brw_sha256(dp.bytes, (size_t)dp.n, &ad);
    CHECK(ty_digest_eq(&ad, &d.fr.artifact), "U4 artifact digest = SHA-256 of the canonical BRW-DL bytes");
    brw_slurp(interp, &b); brw_sha256(b.b, b.n, &id); brw_bytes_free(&b);
    CHECK(ty_digest_eq(&id, &d.fr.artifact_bin), "U3 artifact_bin = SHA-256 of the static interpreter");
    CHECK(!strcmp(d.prof.lm_rule, BRW_LM_RULE), "U1 lm_rule is brw.lm.brwdl.v0.fitonce");
    REJECT(fx_seal(&d, art), 0, "discovery seal");
    if (access("/usr/bin/bwrap", X_OK) != 0) { printf("BLOCKED: /usr/bin/bwrap is not executable\n"); g_blocked++; fx_done(&d); return; }
    /* a clean packet directory, then G9 with a stray file */
    char pk[BRW_PATH], p[BRW_PATH];
    fx_dir(&d, pk, "pk"); snprintf(p, sizeof p, "%s/packet.txt", pk); fx_put(p, "a list of numbers\n");
    brw_score_args a; memset(&a, 0, sizeof a);
    char qf[BRW_PATH]; brw_record_path(qf, sizeof qf, d.sdir, "turing.qfreeze", &d.fd);
    a.mode = "discovery"; a.qfreeze = qf; a.qworld = d.qworld; a.candidate = art; a.baseline = "IID_NORMAL"; a.candidate_cmd = interp;
    a.packet = pk; a.ladder_item = "LADDER-TEST"; a.thresholds = d.thr;
    char out[BRW_PATH], gp[BRW_PATH] = ""; fx_dir(&d, out, "score");
    a.outdir = out;
    tyqr_gain g; ty_digest gd;
    rc = brw_score(&a, &g, &gd, gp, sizeof gp, d.why, sizeof d.why);
    REJECT(rc, 0, "discovery score under bwrap");
    if (rc) printf("  why: %s\n", d.why);
    else {
        REJECT(brw_verify(gp, d.thr, NULL, d.why, sizeof d.why), 0, "discovery verify");
        CHECK(!strcmp(g.classification, brw_class_label(g.t_ub, g.t_lo_ub, g.t_hi_ub)), "discovery G6 label agrees");
        CHECK(!strcmp(g.leak_flag, "0"), "#6 the leak oracle is evaluated on an honest discovery run (leak_flag 0)");
    }
    /* G9: a packet-scanner hit is FAIL_PROTOCOL, lane STOPPED, and is recorded */
    char stray[BRW_PATH]; snprintf(stray, sizeof stray, "%s/params.txt", pk); fx_put(stray, "D=0.5\n");
    char out2[BRW_PATH]; fx_dir(&d, out2, "score_g9"); a.outdir = out2;
    gp[0] = 0;
    REJECT(brw_score(&a, &g, &gd, gp, sizeof gp, d.why, sizeof d.why), TYQ_FAIL_PROTOCOL, "G9 packet-scanner hit refuses the run");
    tyqr_gain r;
    if (gp[0] && brw_load_gain(gp, &r, &gd, d.why, sizeof d.why) == 0) {
        CHECK(!strcmp(r.status, "FAIL_PROTOCOL"), "G9 run record verdict FAIL_PROTOCOL");
        CHECK(!strcmp(r.classification, "STOPPED"), "G9 lane status STOPPED");
    } else CHECK(0, "G9 run record was written and loads");
    /* a leaking word in packet.txt is the same */
    unlink(stray); fx_put(p, "this is a diffusion process\n");
    char out3[BRW_PATH]; fx_dir(&d, out3, "score_g9b"); a.outdir = out3;
    REJECT(brw_score(&a, &g, &gd, NULL, 0, d.why, sizeof d.why), TYQ_FAIL_PROTOCOL, "#3 hidden process label in the packet is refused");
    /* #5 the sealed seed pasted into the packet is refused (seed scan), as hex and as a 0x state word; the leak flag of the
     * honest discovery run above was evaluated (0), not INCONCLUSIVE */
    {
        uint8_t sp[32]; char hx[65], t[256]; brw_sealed_parent(d.fd.b, sp);
        for (int i = 0; i < 32; i++) snprintf(hx + 2 * i, 3, "%02x", sp[i]);
        snprintf(t, sizeof t, "a list of numbers %s\n", hx); fx_put(p, t);
        char out4[BRW_PATH]; fx_dir(&d, out4, "score_seed"); a.outdir = out4;
        REJECT(brw_score(&a, &g, &gd, NULL, 0, d.why, sizeof d.why), TYQ_FAIL_PROTOCOL, "#5 the sealed parent seed in the packet is refused");
        unsigned long long v = 0; for (int i = 7; i >= 0; i--) v = (v << 8) | sp[i];
        snprintf(t, sizeof t, "a list of numbers 0x%016llX\n", v); fx_put(p, t);
        char out5[BRW_PATH]; fx_dir(&d, out5, "score_seed2"); a.outdir = out5;
        REJECT(brw_score(&a, &g, &gd, NULL, 0, d.why, sizeof d.why), TYQ_FAIL_PROTOCOL, "#5 a sealed seed state word in the packet is refused");
    }
    fx_done(&d);
}

int main(int argc, char **argv) {
    fx_t fx;
    if (argc < 4) { fprintf(stderr, "usage: %s <checkout root> <pinned omega> <brw_interp>\n", argv[0]); return 2; }
    if (fx_init(&fx, argc, argv)) return 2;
    test_units(&fx);
    test_int_prd();
    test_freeze_and_seal(&fx);
    test_score_verify(&fx);
    test_interp_equal(&fx, argv[3]);
    test_discovery(&fx, argv[3]);
    fx_done(&fx);
    printf("test_brw_harness: %d passed, %d failed, %d blocked\n", g_pass, g_fail, g_blocked);
    return g_fail ? 1 : g_blocked ? 3 : 0;
}

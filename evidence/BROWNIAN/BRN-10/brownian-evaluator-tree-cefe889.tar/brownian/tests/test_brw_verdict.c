/* test_brw_verdict: Lane D5. Synthetic record fixtures for `brownian_bench verdict` (brw_verdict.c): PASS, FAIL at each band edge,
 * NOT_COMPUTABLE, the sidecar digest mismatch refusal, and the agreement of the tool with brw_band_check (the single band function
 * that the stats tests, test_brw_stats.c, pin at every edge). NOTE: test_brw_xcheck.c does NOT encode the spec 13-15 bands (it compares
 * calibrate against brownian_calib stop-13 counts), so the cross-check here is against brw_band_check and the sidecar.
 * argv: <checkout root> <pinned omega>. Private, sealed. C only. */
#include "harness_fx.h"
#include <math.h>
#include "brw_predict.h"
#include "brw_stats.h"
#include "brw_occam.h"
#include "brw_verdict.h"
#include "brw_cells.h"
#include "brw_rng.h"
#include "brw_world.h"

#define IID BRW_OP_IID
#define LIN BRW_OP_LINEAR_TREND
#define CUB BRW_OP_CUBIC_TREND
#define DIF BRW_OP_DIFFUSION
#define DRF BRW_OP_DIFF_DRIFT
#define MR BRW_OP_MEAN_REVERT
#define LK BRW_OP_LOOKUP_FLOOR

typedef struct { tyqr_gain g[256]; ty_digest d[256]; size_t n; tyqr_freeze fr; tyqr_profile pr; ty_digest fd; brw_vd_cellstats cs[16]; size_t ncs; brw_bytes thr; } world_t;

static void sethex(ty_digest *d, size_t k) { memset(d, 0, sizeof *d); d->b[0] = (uint8_t)(k + 1); d->b[1] = (uint8_t)((k + 1) >> 8); }
/* a gain with an interval in micro-bits: classification derived as the tool derives it */
static void gain(world_t *w, const char *cell, int cand, int base, long long t, long long lo, long long hi) {
    size_t at = w->n;
    for (size_t k = 0; k < w->n; k++) if (!strcmp(w->g[k].cell, cell) && (int)w->g[k].candidate_opcode == cand && (int)w->g[k].baseline_opcode == base) at = k;
    if (at >= sizeof w->g / sizeof w->g[0]) { printf("FAIL: test world full\n"); exit(1); }
    tyqr_gain *g = &w->g[at];
    memset(g, 0, sizeof *g);
    snprintf(g->mode, sizeof g->mode, "certification"); snprintf(g->cell, sizeof g->cell, "%s", cell);
    g->candidate_opcode = (uint64_t)cand; g->baseline_opcode = (uint64_t)base;
    g->t_ub = t; g->t_lo_ub = lo; g->t_hi_ub = hi;
    g->counts[0] = 100; g->counts[1] = 10; g->counts[2] = 10; g->counts[3] = 1000;
    snprintf(g->leak_flag, sizeof g->leak_flag, "0"); snprintf(g->status, sizeof g->status, "PASS");
    snprintf(g->classification, sizeof g->classification, "%s", brw_class_label(t, lo, hi));
    sethex(&w->d[at], at); if (at == w->n) w->n++;
}
#define POS(w, c, a, b) gain(w, c, a, b, 500000, 100000, 900000)
#define NEG(w, c, a, b) gain(w, c, a, b, -500000, -900000, -100000)
#define AMB(w, c, a, b) gain(w, c, a, b, 1000, -100000, 100000)
static void stats(world_t *w, const char *cell, uint32_t n, uint32_t cd, uint32_t cm, uint32_t ex, uint32_t bl) {
    size_t at = w->ncs;
    for (size_t k = 0; k < w->ncs; k++) if (!strcmp(w->cs[k].cell, cell)) at = k;
    snprintf(w->cs[at].cell, sizeof w->cs[at].cell, "%s", cell);
    brw_vd_wstats *s = &w->cs[at].s; if (at == w->ncs) w->ncs++;
    memset(s, 0, sizeof *s); s->have = 1; s->n = n; s->cov_d = cd; s->cov_mu = cm; s->excl0 = ex; s->below0 = bl;
}
static void reset(world_t *w, const char *thr_path) {
    if (w->thr.b) brw_bytes_free(&w->thr);
    memset(w, 0, sizeof *w);
    if (brw_slurp(thr_path, &w->thr) != 0) { printf("cannot read sidecar\n"); exit(2); }
    snprintf(w->fr.b2_emerging_label, sizeof w->fr.b2_emerging_label, "AMBIGUOUS");
    snprintf(w->fr.bayes_plugin_check, sizeof w->fr.bayes_plugin_check, "AGREE");
    snprintf(w->fr.diag_fw_rate_ppm, sizeof w->fr.diag_fw_rate_ppm, "-");
    snprintf(w->fr.lengthening_test, sizeof w->fr.lengthening_test, "PASS");
    snprintf(w->fr.stability_test, sizeof w->fr.stability_test, "PASS");
    snprintf(w->pr.lm_rule, sizeof w->pr.lm_rule, "%s", BRW_LM_RULE);
}
static int eval(world_t *w, const char *exp, brw_vd_report *r) {
    brw_vd_in in; memset(&in, 0, sizeof in);
    in.g = w->g; in.gd = w->d; in.ng = w->n; in.fr = &w->fr; in.fd = &w->fd; in.pr = &w->pr; in.cs = w->cs; in.ncs = w->ncs;
    in.thr = (const char *)w->thr.b; in.thrlen = w->thr.n;
    return brw_vd_evaluate(&in, exp, r);
}
static const brw_vd_item *item(const brw_vd_report *r, const char *id, const char *cell) {
    for (size_t k = 0; k < r->n; k++) if (!strcmp(r->it[k].id, id) && !strcmp(r->it[k].cell, cell)) return &r->it[k];
    return NULL;
}
static int res_of(const brw_vd_report *r, const char *id, const char *cell) { const brw_vd_item *i = item(r, id, cell); return i ? (int)i->res : -1; }
static int stop_state(const brw_vd_report *r, int no) { for (size_t k = 0; k < r->nst; k++) if (r->st[k].no == no) return r->st[k].state; return -1; }

static void fill_a(world_t *w) {
    POS(w, "B0-regular", DIF, IID); NEG(w, "B0-regular", LIN, DIF); NEG(w, "B0-regular", CUB, DIF); NEG(w, "B0-regular", DRF, DIF);
    NEG(w, "B0-regular", MR, DIF); NEG(w, "B0-regular", LK, DIF);
    POS(w, "B0-irregular", DIF, IID); NEG(w, "B0-irregular", MR, DIF);
    NEG(w, "B0-short", DRF, DIF); NEG(w, "B0-short", MR, DIF);
    stats(w, "B0-regular", 100, 95, 95, 0, 0); stats(w, "B0-irregular", 100, 95, 95, 0, 0);
}
static void fill_b(world_t *w) {
    NEG(w, "B1-0", DRF, DIF); NEG(w, "B1-0", MR, DIF);
    NEG(w, "B1-1", DRF, DIF);
    POS(w, "B1-3", DRF, DIF); NEG(w, "B1-3", MR, DRF);
    POS(w, "B1-4n", DRF, DIF); NEG(w, "B1-4n", MR, DRF);
    stats(w, "B1-0", 100, 0, 95, 5, 0); stats(w, "B1-1", 100, 0, 95, 10, 0); stats(w, "B1-3", 100, 0, 95, 50, 0); stats(w, "B1-4n", 100, 0, 95, 80, 80);
}
static void fill_c(world_t *w) {
    NEG(w, "B2-noise", MR, DIF); POS(w, "B2-noise", DIF, IID);
    AMB(w, "B2-weak", MR, DRF);
    POS(w, "B2-clear", MR, DRF); NEG(w, "B2-clear", CUB, MR);
    POS(w, "B2-fast", MR, DRF); NEG(w, "B2-fast", CUB, MR); AMB(w, "B2-fast", IID, MR);
    AMB(w, "B2-emerging", MR, DRF);
}

/* ---- the whole-table tests ---- */
static void test_a(world_t *w, const char *thr) {
    brw_vd_report r;
    reset(w, thr); fill_a(w);
    CHECK(eval(w, "EXP-002A", &r) == 0, "A evaluates");
    CHECK(res_of(&r, "s13.1", "B0-regular") == BRW_VD_PASS && res_of(&r, "s13.1", "B0-irregular") == BRW_VD_PASS, "A row 1 PASS");
    CHECK(res_of(&r, "s13.2", "B0-regular") == BRW_VD_PASS && res_of(&r, "s13.3", "B0-regular") == BRW_VD_PASS, "A rows 2, 3 PASS");
    CHECK(res_of(&r, "s13.4", "B0-short") == BRW_VD_PASS && res_of(&r, "s13.5", "B0-short") == BRW_VD_PASS && res_of(&r, "s13.6", "B0-regular") == BRW_VD_PASS, "A rows 4, 5, 6 PASS");
    CHECK(res_of(&r, "s13.7", "B0-regular") == BRW_VD_PASS && res_of(&r, "s13.7", "B0-irregular") == BRW_VD_PASS, "A row 7 PASS from recomputed coverage");
    CHECK(res_of(&r, "s13.8", "B0-regular") == BRW_VD_PASS, "A row 8 flags PASS");
    const brw_vd_item *i9 = item(&r, "s13.9", "B0-irregular");
    CHECK(i9 && i9->res == BRW_VD_NC && strstr(i9->why, "variant qgain not computed"), "A row 9 NOT_COMPUTABLE with a reason when no variant qgain exists");
    CHECK(r.verdict == BRW_VD_V_INCOMPLETE, "A verdict INCOMPLETE while row 9 is not computable");
    /* every other required item passed: no FAIL anywhere */
    int nfail = 0; for (size_t k = 0; k < r.n; k++) if (r.it[k].res == BRW_VD_FAIL) nfail++;
    CHECK(nfail == 0, "A no FAIL items");
    /* sign edges: lower end exactly 0 is not above 0; upper end exactly 0 is not below 0 */
    reset(w, thr); fill_a(w); w->g[0].t_lo_ub = 0; snprintf(w->g[0].classification, 16, "%s", brw_class_label(w->g[0].t_ub, 0, w->g[0].t_hi_ub));
    eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.1", "B0-regular") == BRW_VD_FAIL && r.verdict == BRW_VD_V_FAIL, "A lower end 0 FAILs a POS item, verdict FAIL");
    reset(w, thr); fill_a(w); w->g[0].t_lo_ub = 1; eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.1", "B0-regular") == BRW_VD_PASS, "A lower end 1 micro-bit PASSes a POS item");
    reset(w, thr); fill_a(w); w->g[1].t_hi_ub = 0; snprintf(w->g[1].classification, 16, "%s", brw_class_label(w->g[1].t_ub, w->g[1].t_lo_ub, 0));
    eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.2", "B0-regular") == BRW_VD_FAIL, "A upper end 0 FAILs a NEG item");
    reset(w, thr); fill_a(w); w->g[1].t_hi_ub = -1; eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.2", "B0-regular") == BRW_VD_PASS, "A upper end -1 PASSes a NEG item");
    /* stored classification that contradicts the stored interval is not silently trusted */
    reset(w, thr); fill_a(w); snprintf(w->g[0].classification, 16, "NEGATIVE"); eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.1", "B0-regular") == BRW_VD_NC, "A contradictory stored classification is NOT_COMPUTABLE");
    /* missing gain, missing world stats */
    reset(w, thr); fill_a(w); w->n--; eval(w, "EXP-002A", &r);   /* drops B0-short MR vs DIFFUSION */
    CHECK(res_of(&r, "s13.5", "B0-short") == BRW_VD_NC && r.verdict == BRW_VD_V_INCOMPLETE, "A missing qgain is NOT_COMPUTABLE");
    reset(w, thr); fill_a(w); w->ncs = 0; eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.7", "B0-regular") == BRW_VD_NC && strstr(item(&r, "s13.7", "B0-regular")->why, "not recomputed"), "A missing qworld makes coverage NOT_COMPUTABLE, says what is needed");
    /* fail flags */
    reset(w, thr); fill_a(w); snprintf(w->g[3].status, 16, "FAIL_LEAK"); eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.8", "B0-regular") == BRW_VD_FAIL, "A a FAIL_LEAK gain fails row 8");
    reset(w, thr); fill_a(w); snprintf(w->g[3].status, 16, "FAIL_PROTOCOL"); eval(w, "EXP-002A", &r);
    CHECK(stop_state(&r, 5) == 1 && r.verdict == BRW_VD_V_STOPPED, "A FAIL_PROTOCOL is stop 5, verdict STOPPED");
    reset(w, thr); fill_a(w); snprintf(w->g[3].status, 16, "FAIL_FLOOR"); eval(w, "EXP-002A", &r);
    CHECK(stop_state(&r, 7) == 1 && r.verdict == BRW_VD_V_STOPPED, "A FAIL_FLOOR is stop 7, verdict STOPPED");
    /* development-side stops written in the qfreeze */
    reset(w, thr); fill_a(w); snprintf(w->fr.stability_test, 8, "FAIL"); eval(w, "EXP-002A", &r);
    CHECK(stop_state(&r, 6) == 1 && r.verdict == BRW_VD_V_STOPPED, "A stability FAIL is stop 6");
    reset(w, thr); fill_a(w); snprintf(w->fr.lengthening_test, 8, "FAIL"); eval(w, "EXP-002A", &r);
    CHECK(stop_state(&r, 8) == 1, "A lengthening FAIL is stop 8");
    reset(w, thr); fill_a(w); snprintf(w->fr.diag_fw_rate_ppm, sizeof w->fr.diag_fw_rate_ppm, "B0-regular:250000 B0-short:0"); eval(w, "EXP-002A", &r);
    CHECK(stop_state(&r, 13) == 1, "A 5 of 20 blocks rejected (250000 ppm) is stop 13");
    reset(w, thr); fill_a(w); snprintf(w->fr.diag_fw_rate_ppm, sizeof w->fr.diag_fw_rate_ppm, "B0-regular:249999 B0-short:0"); eval(w, "EXP-002A", &r);
    CHECK(stop_state(&r, 13) == 0, "A 249999 ppm is below stop 13");
    /* stop 11: cubic or lookup floor beats a structure reference */
    reset(w, thr); fill_a(w); w->g[2].t_lo_ub = 1; w->g[2].t_hi_ub = 900000; w->g[2].t_ub = 500000; snprintf(w->g[2].classification, 16, "POSITIVE"); eval(w, "EXP-002A", &r);
    CHECK(stop_state(&r, 11) == 1, "A CUBIC_TREND beating DIFFUSION is stop 11");
    /* stop 9: coverage in its band while the true family T upper end is below 0 */
    reset(w, thr); fill_a(w); NEG(w, "B0-regular", DIF, IID); eval(w, "EXP-002A", &r);
    CHECK(stop_state(&r, 9) == 1, "A coverage in band with true-family T below 0 is stop 9");
    CHECK(stop_state(&r, 14) == 2 && stop_state(&r, 10) == 2, "A stops that no record can answer are reported not evaluated");
    /* stop 27 (TPS1 adapter gate failure): per-gain sidecar results are supplied through in.tps */
    { static brw_tps_gain_res tp[512]; brw_vd_in in; brw_vd_report r2;
      reset(w, thr); fill_a(w);
      memset(&in, 0, sizeof in); in.g = w->g; in.gd = w->d; in.ng = w->n; in.fr = &w->fr; in.fd = &w->fd; in.pr = &w->pr; in.cs = w->cs; in.ncs = w->ncs; in.thr = (const char *)w->thr.b; in.thrlen = w->thr.n;
      eval(w, "EXP-002A", &r);
      CHECK(stop_state(&r, 27) == 2, "A stop 27 is not evaluated when no sidecar result is supplied");
      memset(tp, 0, sizeof tp); in.tps = tp; in.ntps = w->n;
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 2, "A stop 27 stays not evaluated when a record has no usable sidecar (never counted as a pass)");
      for (size_t k = 0; k < w->n; k++) tp[k].state = BRW_TPS_PASS;
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 0, "A stop 27 passes when every qgain record has a passing TPS1 result");
      tp[3].state = BRW_TPS_GATE_FAIL; tp[3].arm[1].state = BRW_TPS_GATE_FAIL; tp[3].arm[1].bad_world = 7; tp[3].arm[1].bad_index = 11;
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 1 && r2.verdict == BRW_VD_V_STOPPED, "A a TPS1 gate failure on one qgain is stop 27, verdict STOPPED");
      for (size_t k = 0; k < r2.nst; k++) if (r2.st[k].no == 27) CHECK(strstr(r2.st[k].why, "arm M world 7 obs 11") != NULL, "A stop 27 names the arm, world and observation");
    }
    /* the sidecar round trip: a real gate failure must survive render -> file -> read (else it would silently read as "not evaluated") */
    { char dir[] = "/tmp/brw_tps_rt_XXXXXX"; char gp[BRW_PATH], sp[BRW_PATH]; tyqr_gain g; ty_digest gd; brw_tps_gain_res a, b; memset(&g, 0, sizeof g); memset(&gd, 7, sizeof gd); memset(&g.prd_b, 1, sizeof g.prd_b); memset(&g.prd_m, 2, sizeof g.prd_m);
      if (mkdtemp(dir)) {
          snprintf(gp, sizeof gp, "%s/turing.qgain.x.omg0", dir);
          memset(&a, 0, sizeof a); a.state = BRW_TPS_PASS;
          for (int m = 0; m < 2; m++) { a.arm[m].state = BRW_TPS_PASS; a.arm[m].n_obs = 819200; a.arm[m].n_steps = 32877762; a.arm[m].ideal_ub = 18052391938972LL; a.arm[m].range_bytes = 2263034 + (unsigned)m; a.arm[m].rans_bytes = 2262149; a.arm[m].max_dev_exact = 1.23e-32; }
          CHECK(brw_tps_sidecar_write(gp, &g, &gd, &a, sp, sizeof sp) == 0 && brw_tps_sidecar_write(gp, &g, &gd, &a, NULL, 0) == 0, "tps sidecar: write, and an identical rewrite is accepted");
          memset(&b, 0, sizeof b); brw_tps_sidecar_read(gp, &g, &gd, &b);
          CHECK(b.state == BRW_TPS_PASS && b.arm[1].range_bytes == 2263035 && b.arm[0].ideal_ub == 18052391938972LL && b.arm[0].n_steps == 32877762 && b.arm[0].max_dev_exact == 1.23e-32, "tps sidecar: PASS round trip keeps every field");
          unlink(sp);
          memset(&a, 0, sizeof a); a.state = BRW_TPS_GATE_FAIL; a.arm[0].state = BRW_TPS_PASS; a.arm[1].state = BRW_TPS_GATE_FAIL; a.arm[1].code = BRW_TPS_E_PROOF; a.arm[1].bad_world = 1234; a.arm[1].bad_index = 511;
          CHECK(brw_tps_sidecar_write(gp, &g, &gd, &a, sp, sizeof sp) == 0, "tps sidecar: write a gate failure");
          memset(&b, 0, sizeof b); brw_tps_sidecar_read(gp, &g, &gd, &b);
          CHECK(b.state == BRW_TPS_GATE_FAIL && b.arm[1].state == BRW_TPS_GATE_FAIL && b.arm[1].bad_world == 1234 && b.arm[1].bad_index == 511 && b.arm[1].code == BRW_TPS_E_PROOF && b.arm[0].state == BRW_TPS_PASS, "tps sidecar: GATE_FAIL round trip keeps state, arm, world, observation and code");
          { tyqr_gain g2 = g; memset(&g2.prd_b, 9, sizeof g2.prd_b); memset(&b, 0, sizeof b); brw_tps_sidecar_read(gp, &g2, &gd, &b);
            CHECK(b.state == BRW_TPS_NOT_EVALUATED, "tps sidecar: bound to other PRD1 digests is refused"); }
          { brw_bytes sb; FILE *f; CHECK(brw_slurp(sp, &sb) == 0, "tps sidecar readable"); unlink(sp);
            f = fopen(sp, "wb"); if (f) { fwrite(sb.b, 1, sb.n - 3, f); fclose(f); } brw_bytes_free(&sb);
            memset(&b, 0, sizeof b); brw_tps_sidecar_read(gp, &g, &gd, &b); CHECK(b.state == BRW_TPS_NOT_EVALUATED, "tps sidecar: a truncated file is not evaluated"); unlink(sp); }
          rmdir(dir);
      } else CHECK(0, "mkdtemp for the sidecar round trip");
    }
    /* TPS1 verified range (v1.3 A3.6, R3-48): fold precedence, stream skip, sidecar state 3, and stop 27 admissibility */
    { brw_tps_arm a, o, f, p; memset(&a, 0, sizeof a); memset(&o, 0, sizeof o); memset(&f, 0, sizeof f); memset(&p, 0, sizeof p);
      o.state = BRW_TPS_OUT_OF_RANGE; o.bad_index = 4; f.state = BRW_TPS_GATE_FAIL; f.code = BRW_TPS_E_PROOF; f.bad_index = 9; p.n_obs = 10;
      brw_tps_fold(&a, &p, 0); brw_tps_fold(&a, &o, 1);
      CHECK(a.state == BRW_TPS_OUT_OF_RANGE && a.bad_world == 1 && a.bad_index == 4 && a.n_obs == 10, "tps fold: PASS then OUT_OF_RANGE is OUT_OF_RANGE, the skipped world adds nothing");
      brw_tps_fold(&a, &p, 2); CHECK(a.state == BRW_TPS_OUT_OF_RANGE && a.n_obs == 20, "tps fold: a later in-range world still counts and keeps OUT_OF_RANGE");
      brw_tps_fold(&a, &f, 3); CHECK(a.state == BRW_TPS_GATE_FAIL && a.bad_world == 3 && a.bad_index == 9, "tps fold: OUT_OF_RANGE then GATE_FAIL is GATE_FAIL");
      brw_tps_fold(&a, &o, 4); CHECK(a.state == BRW_TPS_GATE_FAIL && a.bad_world == 3, "tps fold: GATE_FAIL then OUT_OF_RANGE stays GATE_FAIL");
    }
    { tyq_pred rec[3]; int64_t k[3]; brw_tps_arm a; memset(rec, 0, sizeof rec); memset(&a, 0, sizeof a);
      for (int i = 0; i < 3; i++) { rec[i].index = (uint32_t)i; rec[i].loc = 0; rec[i].scale = 1; }
      k[0] = 0; k[1] = 5; k[2] = -7;
      CHECK(brw_tps_stream(rec, k, 3, 0, NULL, NULL, &a) == 0 && a.state == BRW_TPS_PASS && a.n_obs == 3, "tps stream: a normal world passes");
      memset(&a, 0, sizeof a); k[1] = llround(2000.0 / 0x1p-20);
      CHECK(brw_tps_stream(rec, k, 3, 6, NULL, NULL, &a) == 0 && a.state == BRW_TPS_OUT_OF_RANGE && a.bad_world == 6 && a.bad_index == 1 && a.n_obs == 0 && a.n_steps == 0 && a.range_bytes == 0, "tps stream: an observation above 2^20 bits skips the world (OUT_OF_RANGE, returns 0, adds nothing)");
    }
    { char dir[] = "/tmp/brw_tps_oor_XXXXXX"; char gp[BRW_PATH], sp[BRW_PATH]; tyqr_gain g; ty_digest gd; brw_tps_gain_res a, b; memset(&g, 0, sizeof g); memset(&gd, 7, sizeof gd); memset(&g.prd_b, 1, sizeof g.prd_b); memset(&g.prd_m, 2, sizeof g.prd_m);
      if (mkdtemp(dir)) {
          snprintf(gp, sizeof gp, "%s/gain.bin", dir);
          memset(&a, 0, sizeof a); a.state = BRW_TPS_OUT_OF_RANGE; a.arm[0].state = BRW_TPS_PASS; a.arm[0].n_obs = 5; a.arm[1].state = BRW_TPS_OUT_OF_RANGE; a.arm[1].bad_world = 17; a.arm[1].bad_index = 3;
          CHECK(brw_tps_sidecar_write(gp, &g, &gd, &a, sp, sizeof sp) == 0, "tps sidecar: write an OUT_OF_RANGE result");
          memset(&b, 0, sizeof b); brw_tps_sidecar_read(gp, &g, &gd, &b);
          CHECK(b.state == BRW_TPS_OUT_OF_RANGE && b.arm[1].state == BRW_TPS_OUT_OF_RANGE && b.arm[1].bad_world == 17 && b.arm[1].bad_index == 3 && b.arm[0].state == BRW_TPS_PASS && b.arm[0].n_obs == 5, "tps sidecar: state 3 round trip keeps gain and arm states");
          unlink(sp); rmdir(dir);
      } else CHECK(0, "mkdtemp for the state 3 round trip");
    }
    { static brw_tps_gain_res tp[512]; brw_vd_in in; brw_vd_report r2;
      reset(w, thr); fill_a(w);
      memset(&in, 0, sizeof in); in.g = w->g; in.gd = w->d; in.ng = w->n; in.fr = &w->fr; in.fd = &w->fd; in.pr = &w->pr; in.cs = w->cs; in.ncs = w->ncs; in.thr = (const char *)w->thr.b; in.thrlen = w->thr.n;
      memset(tp, 0, sizeof tp); in.tps = tp; in.ntps = w->n;
      for (size_t k = 0; k < w->n; k++) { tp[k].state = BRW_TPS_PASS; tp[k].arm[0].state = tp[k].arm[1].state = BRW_TPS_PASS; }
      w->g[3].t_lo_ub = -900000; w->g[3].t_ub = -500000; w->g[3].t_hi_ub = -1; snprintf(w->g[3].classification, 16, "NEGATIVE");
      tp[3].state = BRW_TPS_OUT_OF_RANGE; tp[3].arm[1].state = BRW_TPS_OUT_OF_RANGE;
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 0, "A stop 27 is clear when the candidate arm is out of range on a NEGATIVE qgain and the baseline passed");
      { int seen = 0; for (size_t k = 0; k < r2.nst; k++) if (r2.st[k].no == 27) seen = strstr(r2.st[k].why, "arm M outside TPS1 verified range (admissible, losing arm)") != NULL; CHECK(seen, "A stop 27 lists the admissible out-of-range qgain by name"); }
      w->g[3].t_lo_ub = 1; w->g[3].t_ub = 500000; w->g[3].t_hi_ub = 900000; snprintf(w->g[3].classification, 16, "POSITIVE");
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 1, "A stop 27 is a hit when the winning (candidate) arm of a POSITIVE qgain is out of range");
      { int seen = 0; for (size_t k = 0; k < r2.nst; k++) if (r2.st[k].no == 27) seen = strstr(r2.st[k].why, "outside TPS1 verified range on the winning arm") != NULL; CHECK(seen, "A stop 27 hit names the winning-arm out-of-range case"); }
      tp[3].arm[0].state = BRW_TPS_OUT_OF_RANGE;
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 1, "A stop 27 is a hit when both arms are out of range");
      w->g[3].t_lo_ub = -900000; w->g[3].t_ub = -500000; w->g[3].t_hi_ub = -1; snprintf(w->g[3].classification, 16, "NEGATIVE");
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 1, "A stop 27 is a hit when both arms are out of range, even on a NEGATIVE qgain");
      tp[3].arm[0].state = BRW_TPS_PASS; tp[3].arm[1].state = BRW_TPS_OUT_OF_RANGE; w->g[3].t_lo_ub = -1; w->g[3].t_ub = 0; w->g[3].t_hi_ub = 5; snprintf(w->g[3].classification, 16, "AMBIGUOUS");
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 1, "A stop 27 is a hit when the class is AMBIGUOUS");
      tp[3].arm[0].state = BRW_TPS_OUT_OF_RANGE; tp[3].arm[1].state = BRW_TPS_PASS; w->g[3].t_lo_ub = 1; w->g[3].t_ub = 500000; w->g[3].t_hi_ub = 900000;
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      CHECK(stop_state(&r2, 27) == 0, "A stop 27 is clear when the baseline arm is out of range on a POSITIVE qgain and the candidate passed");
      for (size_t k = 0; k < w->n; k++) {   /* every qgain admissible: the clear-stop text must name all of them, none cut off */
          w->g[k].t_lo_ub = -900000; w->g[k].t_ub = -500000; w->g[k].t_hi_ub = -1; snprintf(w->g[k].classification, 16, "NEGATIVE");
          tp[k].state = BRW_TPS_OUT_OF_RANGE; tp[k].arm[0].state = BRW_TPS_PASS; tp[k].arm[1].state = BRW_TPS_OUT_OF_RANGE; }
      brw_vd_evaluate(&in, "EXP-002A", &r2);
      { size_t cnt = 0; for (size_t k = 0; k < r2.nst; k++) if (r2.st[k].no == 27) for (const char *p = r2.st[k].why; (p = strstr(p, "(admissible, losing arm)")) != NULL; p++) cnt++;
        CHECK(stop_state(&r2, 27) == 0 && w->n > 3 && cnt == w->n, "A stop 27 names every admissible out-of-range qgain, none cut off"); }
    }
}
static void test_b(world_t *w, const char *thr) {
    brw_vd_report r;
    reset(w, thr); fill_b(w);
    CHECK(eval(w, "EXP-002B", &r) == 0, "B evaluates");
    int nfail = 0, nnc = 0; for (size_t k = 0; k < r.n; k++) { if (r.it[k].res == BRW_VD_FAIL) nfail++; if (r.it[k].res == BRW_VD_NC && r.it[k].required) nnc++; }
    CHECK(nfail == 0 && nnc == 0 && r.verdict == BRW_VD_V_PASS, "B all required items PASS, verdict PASS");
    /* B1-1.3: more than half fails; exactly half passes */
    reset(w, thr); fill_b(w); stats(w, "B1-1", 100, 0, 95, 50, 0);
    eval(w, "EXP-002B", &r);
    CHECK(res_of(&r, "s14.B1-1.3", "B1-1") == BRW_VD_PASS, "B1-1.3: exactly half excluded PASSes");
    reset(w, thr); fill_b(w); stats(w, "B1-1", 100, 0, 95, 51, 0);
    eval(w, "EXP-002B", &r);
    CHECK(res_of(&r, "s14.B1-1.3", "B1-1") == BRW_VD_FAIL, "B1-1.3: more than half excluded FAILs");
    /* B1-3.3 one-sided min 0.40; B1-4n.3 below-0 min 0.70 */
    static const struct { uint32_t c; int want; } E3[] = { { 39, BRW_VD_FAIL }, { 40, BRW_VD_PASS }, { 100, BRW_VD_PASS } };
    for (size_t k = 0; k < 3; k++) {
        reset(w, thr); fill_b(w); w->cs[2].s.excl0 = E3[k].c; eval(w, "EXP-002B", &r);
        CHECK(res_of(&r, "s14.B1-3.3", "B1-3") == E3[k].want, "B1-3.3 edge at 0.40");
    }
    static const struct { uint32_t c; int want; } E4[] = { { 69, BRW_VD_FAIL }, { 70, BRW_VD_PASS } };
    for (size_t k = 0; k < 2; k++) {
        reset(w, thr); fill_b(w); w->cs[3].s.below0 = E4[k].c; eval(w, "EXP-002B", &r);
        CHECK(res_of(&r, "s14.B1-4n.3", "B1-4n") == E4[k].want, "B1-4n.3 edge at 0.70");
    }
    /* B1-0.4 exclusion band 0.01..0.10, also the stop band */
    static const struct { uint32_t c; int want; int stop; } E0[] = { { 0, BRW_VD_FAIL, 1 }, { 1, BRW_VD_PASS, 0 }, { 10, BRW_VD_PASS, 0 }, { 11, BRW_VD_FAIL, 1 } };
    for (size_t k = 0; k < 4; k++) {
        reset(w, thr); fill_b(w); w->cs[0].s.excl0 = E0[k].c; eval(w, "EXP-002B", &r);
        CHECK(res_of(&r, "s14.B1-0.4", "B1-0") == E0[k].want, "B1-0.4 edge");
        CHECK((stop_state(&r, 15) == 1) == (E0[k].stop == 1), "B1-0.4 outside the band trips stop 15");
        if (E0[k].stop) CHECK(r.verdict == BRW_VD_V_STOPPED, "B1-0.4 stop makes the verdict STOPPED");
    }
    /* sign rows */
    reset(w, thr); fill_b(w); POS(w, "B1-0", DRF, DIF); eval(w, "EXP-002B", &r);
    CHECK(res_of(&r, "s14.B1-0.1", "B1-0") == BRW_VD_FAIL, "B1-0.1 drift beating diffusion at drift 0 FAILs");
    reset(w, thr); fill_b(w); w->ncs = 0; eval(w, "EXP-002B", &r);
    CHECK(res_of(&r, "s14.B1-4n.3", "B1-4n") == BRW_VD_NC && r.verdict == BRW_VD_V_INCOMPLETE, "B without the sealed worlds is INCOMPLETE, never guessed");
    const brw_vd_item *oc = item(&r, "s14.occam", "OCC-*");
    CHECK(oc && !oc->required && r.verdict == BRW_VD_V_INCOMPLETE, "B Occam curve is reported and never gates");
    /* a sidecar with a non-`half` token refuses that row rather than guessing */
    { char *bad = malloc(w->thr.n + 1); memcpy(bad, w->thr.b, w->thr.n); bad[w->thr.n] = 0;
      char *p = strstr(bad, "excl_frac_gt half"); if (p) memcpy(p + 12, "0.50", 4);
      brw_bytes save = w->thr; reset(w, thr); fill_b(w); free(w->thr.b); w->thr.b = (uint8_t *)bad; w->thr.n = save.n; (void)save;
      eval(w, "EXP-002B", &r);
      CHECK(res_of(&r, "s14.B1-1.3", "B1-1") == BRW_VD_NC, "B1-1.3 with a non-`half` sidecar token is NOT_COMPUTABLE"); }
}
static void test_c(world_t *w, const char *thr) {
    brw_vd_report r;
    reset(w, thr); fill_c(w);
    CHECK(eval(w, "EXP-002C", &r) == 0, "C evaluates");
    int nfail = 0, nnc = 0; for (size_t k = 0; k < r.n; k++) { if (strncmp(r.it[k].id, "s15.I-", 6) == 0) continue; if (r.it[k].res == BRW_VD_FAIL) nfail++; if (r.it[k].res == BRW_VD_NC && r.it[k].required) nnc++; }
    CHECK(nfail == 0 && nnc == 0 && r.verdict == BRW_VD_V_PASS, "C observational rows PASS");
    CHECK(r.has_int == 0 && r.int_verdict == BRW_VD_V_INCOMPLETE, "C INT phase INCOMPLETE without INT qgains");
    static const char *const INTIDS[] = { "s15.I-far", "s15.I-near", "s15.I-drift", "s15.I-control" };
    for (size_t k = 0; k < 4; k++) CHECK(res_of(&r, INTIDS[k], item(&r, INTIDS[k], "INT-d8") ? "INT-d8" : item(&r, INTIDS[k], "INT-d2") ? "INT-d2" : item(&r, INTIDS[k], "INT-d*") ? "INT-d*" : "CTL-d*") == BRW_VD_NC, "C INT item NOT_COMPUTABLE without records");
    CHECK(r.verdict == BRW_VD_V_PASS, "C INT NOT_COMPUTABLE never changes the observational verdict");
    /* row 5 label check */
    reset(w, thr); fill_c(w); snprintf(w->fr.b2_emerging_label, 16, "POSITIVE"); NEG(w, "B2-emerging", MR, DRF);
    eval(w, "EXP-002C", &r);
    CHECK(res_of(&r, "s15.5", "B2-emerging") == BRW_VD_FAIL && r.verdict == BRW_VD_V_FAIL, "C POSITIVE label with NEGATIVE class FAILs");
    reset(w, thr); fill_c(w); snprintf(w->fr.b2_emerging_label, 16, "NEGATIVE"); eval(w, "EXP-002C", &r);
    CHECK(res_of(&r, "s15.5", "B2-emerging") == BRW_VD_PASS, "C AMBIGUOUS class never opposes a label");
    /* row 4: IID beating MEAN_REVERT on B2-fast fails and stops */
    reset(w, thr); fill_c(w); POS(w, "B2-fast", IID, MR); eval(w, "EXP-002C", &r);
    CHECK(res_of(&r, "s15.4", "B2-fast") == BRW_VD_FAIL && stop_state(&r, 15) == 1 && r.verdict == BRW_VD_V_STOPPED, "C B2-fast IID beats MEAN_REVERT: FAIL and stop 15");
    /* row 2 edge: lower end 0 passes, 1 fails */
    reset(w, thr); fill_c(w); gain(w, "B2-weak", MR, DRF, 1, 0, 100000); eval(w, "EXP-002C", &r);
    CHECK(res_of(&r, "s15.2", "B2-weak") == BRW_VD_PASS, "C s15.2 lower end 0 PASSes");
    reset(w, thr); fill_c(w); gain(w, "B2-weak", MR, DRF, 1, 1, 100000); eval(w, "EXP-002C", &r);
    CHECK(res_of(&r, "s15.2", "B2-weak") == BRW_VD_FAIL, "C s15.2 lower end 1 FAILs");
    /* row 6: held-out points */
    reset(w, thr); fill_c(w); w->g[0].counts[2] = 0; eval(w, "EXP-002C", &r);
    CHECK(res_of(&r, "s15.6", "all") == BRW_VD_FAIL, "C row 6 needs held-out scored points");
    /* INT phase present: far, near, drift pass; control passes when it earns no both-beat credit */
    reset(w, thr); fill_c(w);
    POS(w, "INT-d8", MR, DRF); POS(w, "INT-d8", MR, DIF); AMB(w, "INT-d2", MR, DIF);
    static const char *const D[] = { "0", "1", "2", "5", "8" };
    for (size_t k = 0; k < 5; k++) { char c[16], t[16]; snprintf(c, sizeof c, "INT-d%s", D[k]); snprintf(t, sizeof t, "CTL-d%s", D[k]);
        if (k != 4) { POS(w, c, MR, DRF); }
        AMB(w, t, MR, DIF); AMB(w, t, MR, DRF); }
    eval(w, "EXP-002C", &r);
    CHECK(r.has_int == 1 && res_of(&r, "s15.I-far", "INT-d8") == BRW_VD_PASS && res_of(&r, "s15.I-near", "INT-d2") == BRW_VD_PASS && res_of(&r, "s15.I-drift", "INT-d*") == BRW_VD_PASS, "C INT far, near, drift PASS from records");
    CHECK(res_of(&r, "s15.I-control", "CTL-d*") == BRW_VD_PASS && r.int_verdict == BRW_VD_V_PASS, "C INT control PASS, INT verdict PASS");
    /* explicit control failure fixture */
    reset(w, thr); fill_c(w);
    for (size_t k = 0; k < 5; k++) { char t[16]; snprintf(t, sizeof t, "CTL-d%s", D[k]); if (k == 3) { POS(w, t, MR, DIF); POS(w, t, MR, DRF); } else { AMB(w, t, MR, DIF); AMB(w, t, MR, DRF); } }
    eval(w, "EXP-002C", &r);
    CHECK(res_of(&r, "s15.I-control", "CTL-d*") == BRW_VD_FAIL && r.int_verdict == BRW_VD_V_FAIL && r.verdict == BRW_VD_V_PASS, "C INT control earning credit FAILs the INT rung only");
}

/* ---- agreement of the tool with brw_band_check over every count ---- */
static void test_agree(world_t *w, const char *thr) {
    brw_vd_report r; int bad = 0, n = 0;
    for (uint32_t c = 0; c <= 100; c++) {
        reset(w, thr); fill_a(w); w->cs[0].s.cov_d = c; eval(w, "EXP-002A", &r);
        int want = brw_band_check(c, 100, 0.90, 0.99, 0.88, 0.995);   /* the sidecar values of s13.7, checked equal below */
        const brw_vd_item *i = item(&r, "s13.7", "B0-regular");
        n++; if (!i || (i->res == BRW_VD_PASS) != (want == BRW_BAND_PASS) || (i->stop_no == 15) != (want == BRW_BAND_STOP)) bad++;
    }
    CHECK(bad == 0, "verdict s13.7 agrees with brw_band_check for every count 0..100");
    (void)n;
    char v[64]; double lo = 0, hi = 0, slo = 0, shi = 0;
    reset(w, thr);
    CHECK(brw_vd_thr_get((const char *)w->thr.b, w->thr.n, "s13.7", "d_cov_lo", v, sizeof v) == 0 && (lo = atof(v)) == 0.90, "sidecar d_cov_lo is the value the agreement test uses");
    CHECK(brw_vd_thr_get((const char *)w->thr.b, w->thr.n, "s13.7", "d_cov_hi", v, sizeof v) == 0 && (hi = atof(v)) == 0.99, "sidecar d_cov_hi");
    CHECK(brw_vd_thr_get((const char *)w->thr.b, w->thr.n, "s13.7", "d_cov_stop_lo", v, sizeof v) == 0 && (slo = atof(v)) == 0.88, "sidecar d_cov_stop_lo");
    CHECK(brw_vd_thr_get((const char *)w->thr.b, w->thr.n, "s13.7", "d_cov_stop_hi", v, sizeof v) == 0 && (shi = atof(v)) == 0.995, "sidecar d_cov_stop_hi");
    CHECK(brw_vd_thr_get((const char *)w->thr.b, w->thr.n, "no.such", "item", v, sizeof v) == -1, "an absent sidecar line is reported absent");
    /* pinned edges (spec 13 row 7: 0.90 to 0.99; stop outside 0.88 to 0.995) */
    static const struct { uint32_t c; int res; int stop; } E[] = { { 90, BRW_VD_PASS, 0 }, { 89, BRW_VD_FAIL, 0 }, { 88, BRW_VD_FAIL, 0 }, { 87, BRW_VD_FAIL, 1 }, { 99, BRW_VD_PASS, 0 }, { 100, BRW_VD_FAIL, 1 } };
    for (size_t k = 0; k < sizeof E / sizeof E[0]; k++) {
        reset(w, thr); fill_a(w); w->cs[0].s.cov_d = E[k].c; eval(w, "EXP-002A", &r);
        const brw_vd_item *i = item(&r, "s13.7", "B0-regular");
        CHECK(i && (int)i->res == E[k].res && (i->stop_no == 15) == (E[k].stop == 1), "s13.7 pinned band edge");
        (void)lo; (void)hi; (void)slo; (void)shi;
    }
}

/* ---- render determinism ---- */
static void test_render(world_t *w, const char *thr) {
    brw_vd_report r; char a[65536], b[65536]; size_t la = 0, lb = 0; ty_digest z; memset(&z, 0, sizeof z);
    reset(w, thr); fill_a(w); eval(w, "EXP-002A", &r);
    CHECK(brw_vd_render(&r, &w->pr, &z, &z, a, sizeof a, &la) == 0 && brw_vd_render(&r, &w->pr, &z, &z, b, sizeof b, &lb) == 0 && la == lb && memcmp(a, b, la) == 0, "render is deterministic");
    CHECK(strstr(a, "PASS s13.1 B0-regular") && strstr(a, "NOT_COMPUTABLE s13.9 B0-irregular") && strstr(a, "verdict EXP-002A INCOMPLETE") && strstr(a, "line 806") && strstr(a, "line 620"), "render carries items, verdict and the cited rule");
    char tiny[64];
    CHECK(brw_vd_render(&r, &w->pr, &z, &z, tiny, sizeof tiny, &la) != 0, "render refuses a too-small buffer");
}

/* ---- add-on: item 9 wired to brw_variant_h1, cell names, INT05 descriptive ---- */
static void test_addon(world_t *w, const char *thr) {
    brw_vd_report r; const int V = BRW_OP_VARIANT_H1;
    static const char *const D[] = { "0", "1", "2", "5", "8" };
    /* (1) row 9 computes from a variant qgain: upper below 0 passes, upper at 0 or above fails, missing stays NOT_COMPUTABLE */
    reset(w, thr); fill_a(w); NEG(w, "B0-irregular", V, DIF); eval(w, "EXP-002A", &r);
    const brw_vd_item *i9 = item(&r, "s13.9", "B0-irregular");
    CHECK(i9 && i9->required && i9->res == BRW_VD_PASS && i9->gains[0], "s13.9 PASSes when the variant upper end is below 0");
    CHECK(r.verdict == BRW_VD_V_PASS, "A verdict PASS once row 9 computes and passes");
    reset(w, thr); fill_a(w); gain(w, "B0-irregular", V, DIF, -1000, -100000, 0); eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.9", "B0-irregular") == BRW_VD_FAIL && r.verdict == BRW_VD_V_FAIL, "s13.9 upper end exactly 0 FAILs");
    reset(w, thr); fill_a(w); POS(w, "B0-irregular", V, DIF); eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.9", "B0-irregular") == BRW_VD_FAIL, "s13.9 a positive variant FAILs");
    reset(w, thr); fill_a(w); eval(w, "EXP-002A", &r);
    i9 = item(&r, "s13.9", "B0-irregular");
    CHECK(i9 && i9->res == BRW_VD_NC && strstr(i9->why, "variant qgain not computed"), "s13.9 without the variant qgain is NOT_COMPUTABLE with a reason");
    reset(w, thr); fill_a(w); NEG(w, "B0-irregular", V, DIF); snprintf(w->g[w->n - 1].status, 16, "STOPPED"); snprintf(w->g[w->n - 1].classification, 16, "STOPPED"); eval(w, "EXP-002A", &r);
    CHECK(res_of(&r, "s13.9", "B0-irregular") == BRW_VD_NC, "s13.9 with a STOPPED variant gain is NOT_COMPUTABLE");
    {   const brw_variant *v = brw_variant_h1(); brw_prog p; char err[128];
        CHECK(v->nbytes == 17 && v->charged_bytes == 22 && v->k == 1 && V != DIF && brw_prog_from_bytes(v->bytes, v->nbytes, &p, err, sizeof err) == 0 && p.info.k == 1,
              "the variant program wired to row 9 is 17 bytes measured, charged 22, k = 1"); }
    /* (1b) the real scorer: brw_vd_variant_gain on freshly generated B0-irregular worlds fills a certification gain named VARIANT_H1 vs DIFFUSION, with the 22-byte charge */
    {   brw_cellinfo ci; static tyqr_profile pr; static tyqr_freeze fr; tyqr_world wo; ty_digest z, fd; char why[256] = ""; tyqr_gain g;
        CHECK(brw_cellinfo_get("B0-irregular", &ci) == 0, "B0-irregular is in the table");
        memset(&pr, 0, sizeof pr); memset(&fr, 0, sizeof fr); memset(&wo, 0, sizeof wo); memset(&z, 0, sizeof z); memset(&fd, 0, sizeof fd); fd.b[0] = 7;
        pr.bootstrap_b = BRW_BOOT_B; snprintf(pr.unit, sizeof pr.unit, "micro-bit"); snprintf(pr.baselines, sizeof pr.baselines, "EXP-002A:IID_NORMAL");
        snprintf(wo.mode, sizeof wo.mode, "certification"); wo.block = 0;
        size_t W = ci.W; brw_traj *tr = calloc(W, sizeof *tr); uint8_t parent[32]; char label[128]; int okg = tr != NULL;
        brw_sealed_parent(fd.b, parent);
        okg = okg && brw_world_label("seal", "B0-irregular", 0, label, sizeof label) == BRW_OK;
        for (size_t k = 0; okg && k < W; k++) { uint8_t seed[32]; brw_params par; okg = brw_world_seed(label, parent, 32, k, seed) == BRW_OK && brw_world_generate(&ci.s, seed, &tr[k], &par) == BRW_OK; }
        CHECK(okg, "worlds generated");
        if (okg) {
            int rc = brw_vd_variant_gain(&ci, tr, W, &pr, &z, &fr, &fd, &wo, &z, &g, why, sizeof why);
            CHECK(rc == 0 || rc == TYQ_FAIL_LEAK || rc == TYQ_FAIL_FLOOR, "variant gain computes"); if (rc) printf("  rc %d why %s\n", rc, why);
            CHECK(g.candidate_opcode == (uint64_t)V && g.baseline_opcode == (uint64_t)DIF && !strcmp(g.cell, "B0-irregular") && !g.official && !strcmp(g.ladder_item, "s13.9"), "variant gain names VARIANT_H1 vs DIFFUSION on B0-irregular, unofficial");
            { int64_t l22 = 0, lp = 0; CHECK(brw_ref_get(DIF)->nbytes + 1 == 22 && ty_qcont_bytes_ub(22, &l22) == 0 && ty_qcont_bytes_ub((uint32_t)brw_ref_get(DIF)->nbytes, &lp) == 0 && g.lengths[2] - g.lengths[0] == l22 - lp, "variant is charged 22 bytes, DIFFUSION its own bytes"); }
            printf("  variant gain T=%lld [%lld, %lld] micro-bits, status %s, class %s\n", (long long)g.t_ub, (long long)g.t_lo_ub, (long long)g.t_hi_ub, g.status, g.classification);
        }
        if (tr) { for (size_t k = 0; k < W; k++) brw_traj_free(&tr[k]); free(tr); }
    }
    /* (2) cell names: every INT/CTL/INT05 name the verdict uses is a cell of the table, and far = d8, near = d2 */
    for (size_t k = 0; k < 5; k++) {
        char c[24]; brw_cellinfo ci;
        snprintf(c, sizeof c, "INT-d%s", D[k]);   CHECK(brw_cellinfo_get(c, &ci) == 0 && !ci.descriptive, "cell table has INT-d<d>, gating");
        snprintf(c, sizeof c, "CTL-d%s", D[k]);   CHECK(brw_cellinfo_get(c, &ci) == 0 && !ci.descriptive, "cell table has CTL-d<d>, gating");
        snprintf(c, sizeof c, "INT05-d%s", D[k]); CHECK(brw_cellinfo_get(c, &ci) == 0 && ci.descriptive, "cell table has INT05-d<d>, descriptive");
    }
    reset(w, thr); fill_c(w); POS(w, "INT-d8", MR, BRW_OP_DIFF_DRIFT); POS(w, "INT-d8", MR, DIF); POS(w, "INT-d2", MR, DIF); eval(w, "EXP-002C", &r);
    CHECK(res_of(&r, "s15.I-far", "INT-d8") == BRW_VD_PASS && res_of(&r, "s15.I-near", "INT-d2") == BRW_VD_PASS, "I-far reads INT-d8 and I-near reads INT-d2 by the cell table names");
    /* (3) INT05 rows are descriptive, never gating, and never make has_int or change any verdict */
    reset(w, thr); fill_c(w); eval(w, "EXP-002C", &r);
    brw_vd_verdict base_v = r.verdict, base_i = r.int_verdict;
    for (size_t k = 0; k < 5; k++) { char c[24]; snprintf(c, sizeof c, "INT05-d%s", D[k]); NEG(w, c, MR, DIF); }
    eval(w, "EXP-002C", &r);
    int nrows = 0, allok = 1;
    for (size_t k = 0; k < 5; k++) { char c[24], id[24]; snprintf(c, sizeof c, "INT05-d%s", D[k]); snprintf(id, sizeof id, "s15.I05-d%s", D[k]);
        const brw_vd_item *it = item(&r, id, c); nrows++;
        if (!it || it->required || it->res != BRW_VD_DESC || !it->measured[0]) allok = 0; }
    CHECK(nrows == 5 && allok, "five INT05 rows, each descriptive (required 0, result DESC) with a measured class");
    CHECK(r.has_int == 0 && r.verdict == base_v && r.int_verdict == base_i, "INT05 gains alone leave has_int, the verdict and the INT verdict unchanged");
    for (size_t k = 0; k < r.n; k++) if (!strncmp(r.it[k].cell, "INT05-d", 7)) CHECK(!r.it[k].required && r.it[k].stop_no == 0, "no INT05 item is required or trips a stop");
    reset(w, thr); fill_c(w); for (size_t k = 0; k < 5; k++) { char c[24]; snprintf(c, sizeof c, "INT05-d%s", D[k]); POS(w, c, MR, DIF); snprintf(w->g[w->n - 1].status, 16, "STOPPED"); snprintf(w->g[w->n - 1].classification, 16, "STOPPED"); }
    eval(w, "EXP-002C", &r);
    CHECK(r.verdict == base_v && r.int_verdict == base_i, "STOPPED INT05 gains never gate or stop");
    reset(w, thr); fill_c(w); eval(w, "EXP-002C", &r);
    { const brw_vd_item *it = item(&r, "s15.I05-d0", "INT05-d0"); CHECK(it && !it->required && it->res == BRW_VD_NC, "INT05 row without a gain is reported NOT_COMPUTABLE but stays non-gating"); }
    CHECK(r.verdict == base_v && r.int_verdict == base_i, "missing INT05 gains do not change any verdict");
}

/* ---- file based: real records from the harness fixture ---- */
static int mode_of(const char *p) { struct stat st; return stat(p, &st) ? -1 : (int)(st.st_mode & 07777); }
static void test_files(fx_t *fx) {
    char gp[BRW_PATH], out[BRW_PATH], why[BRW_WHY * 2] = "", rp[BRW_PATH], rp2[BRW_PATH]; brw_vd_verdict v;
    if (fx_cert(fx) || fx_score_cert(fx, "DIFFUSION", "IID_NORMAL", "score1", gp, sizeof gp)) { printf("FAIL: fixture: %s\n", fx->why); g_fail++; return; }
    char sc[BRW_PATH]; snprintf(sc, sizeof sc, "%s/score1", fx->tmp);
    fx_dir(fx, out, "vout");
    brw_vd_args a; memset(&a, 0, sizeof a);
    a.experiment = "EXP-002A"; a.thresholds = fx->thr; a.outdir = out; a.dirs[0] = fx->sdir; a.dirs[1] = sc; a.ndirs = 2;
    int rc = brw_verdict_run(&a, &v, rp, sizeof rp, why, sizeof why);
    CHECK(rc == 0, "file run produces a verdict");
    if (rc) printf("  why: %s\n", why);
    CHECK(v == BRW_VD_V_INCOMPLETE, "one-cell records give INCOMPLETE, never PASS");
    CHECK(mode_of(rp) == 0444, "verdict record is mode 0444");
    rc = brw_verdict_run(&a, &v, rp2, sizeof rp2, why, sizeof why);
    CHECK(rc == 0 && !strcmp(rp, rp2), "rerun names the same digest and tolerates the existing 0444 record");
    /* wrong experiment / no records */
    a.experiment = "EXP-002Z"; REJECT(brw_verdict_run(&a, &v, NULL, 0, why, sizeof why), TYQ_E_ARG, "unknown experiment refused");
    /* sidecar digest mismatch: one changed byte in the sidecar */
    char bad[BRW_PATH]; snprintf(bad, sizeof bad, "%s/thr_bad.txt", fx->work);
    { brw_bytes b; brw_slurp(fx->thr, &b); FILE *f = fopen(bad, "wb"); fwrite(b.b, 1, b.n, f); fputs("s19.99 zzz 1\n", f); fclose(f); brw_bytes_free(&b); }
    a.experiment = "EXP-002A"; a.thresholds = bad;
    REJECT(brw_verdict_run(&a, &v, NULL, 0, why, sizeof why), TYQ_FAIL_PROFILE, "sidecar digest mismatch refused (FAIL_PROFILE)");
    CHECK(strstr(why, "digest"), "digest refusal says why");
    /* qprofile missing from the given directories */
    char go[BRW_PATH]; { char q[BRW_PATH], d2[BRW_PATH]; fx_dir(fx, go, "gonly"); if (fx_find(sc, "turing.qgain.", q, sizeof q)) { snprintf(d2, sizeof d2, "%s/%s", go, strrchr(q, 47) + 1); fx_cp(q, d2); } a.dirs[0] = go; }
    a.thresholds = fx->thr; a.ndirs = 1;
    CHECK(brw_verdict_run(&a, &v, NULL, 0, why, sizeof why) != 0, "qprofile absent: refused");
    /* world stats on the real sealed world regenerate cleanly and refuse a tampered trajectory */
    { brw_traj *tr = NULL; size_t W = 0; brw_cellinfo ci; brw_vd_wstats s; char w2[BRW_WHY] = "";
      if (brw_world_load(fx->sdir, &fx->wo, &tr, &W, w2, sizeof w2) == 0 && brw_cellinfo_get(fx->cell, &ci) == 0) {
          int r2 = brw_vd_world_stats(&ci, tr, W, &fx->fd, &s, w2, sizeof w2);
          CHECK(r2 == 0 && s.have && s.n == W && s.cov_d <= s.n && s.cov_mu <= s.n && s.excl0 <= s.n, "regenerated hidden parameters give counts for the sealed world");
          if (r2) printf("  why: %s\n", w2);
          if (tr[0].count) { tr[0].k[0] ^= 1; REJECT(brw_vd_world_stats(&ci, tr, W, &fx->fd, &s, w2, sizeof w2), TYQ_FAIL_DIGEST, "tampered trajectory is not the sealed world"); }
          brw_world_free(tr, W);
      } else { g_fail++; printf("FAIL: cannot load sealed world\n"); } }
}

/* ---- EXP-002B-OCC: s14.occ0 (spec v1.3 A3.3) and the Occam crossing rules (A3.4) ---- */
static void occ_fill(world_t *w) {
    static const char *const Z[4] = { "OCC-s+0.00-H128", "OCC-s+0.00-H256", "OCC-s+0.00-H512", "OCC-s+0.00-H1024" };
    for (size_t k = 0; k < 4; k++) AMB(w, Z[k], DRF, DIF);
    POS(w, "OCC-s+3.00-H128", DRF, DIF);      /* a non-zero cell may earn credit; that is the curve, not a verdict item */
    /* R3-48: every OCC cell carries its DIFFUSION_DRIFT vs DIFFUSION qgain, else s14.occ0 is NOT_COMPUTABLE */
#define OCC_FILL(nm, s, h) if (strcmp(nm, "OCC-s+3.00-H128")) AMB(w, nm, DRF, DIF);
    BRW_OCC_LIST(OCC_FILL)
#undef OCC_FILL
}
static void set_pt(brw_occ_curve *c, size_t i, double s, long long t, long long lo, long long hi) {
    memset(&c->pt[i], 0, sizeof c->pt[i]); c->pt[i].s = s; c->pt[i].ratio = fabs(s) / sqrt(255.0); c->pt[i].t = t; c->pt[i].lo = lo; c->pt[i].hi = hi;
    if (i + 1 > c->n) c->n = i + 1;
}
static void test_occ(world_t *w, const char *thr) {
    brw_vd_report r;
    reset(w, thr); occ_fill(w);
    CHECK(eval(w, "EXP-002B-OCC", &r) == 0, "OCC evaluates");
    CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_PASS && r.verdict == BRW_VD_V_PASS, "s14.occ0 PASS: s = 0 not POSITIVE at all four H");
    { const brw_vd_item *i = item(&r, "s14.occ0", "OCC-s+0.00"); CHECK(i && i->required && strstr(i->band, "OCC qgains"), "s14.occ0 is required and counts the OCC qgains"); }
    /* WEAK and NEGATIVE are not POSITIVE; lower end exactly 0 is not POSITIVE */
    reset(w, thr); occ_fill(w); NEG(w, "OCC-s+0.00-H256", DRF, DIF); gain(w, "OCC-s+0.00-H512", DRF, DIF, 1000, 0, 100000); eval(w, "EXP-002B-OCC", &r);
    CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_PASS, "s14.occ0: NEGATIVE and lower end exactly 0 are not POSITIVE");
    /* POSITIVE at any one H fails */
    for (size_t k = 0; k < 4; k++) {
        static const char *const Z[4] = { "OCC-s+0.00-H128", "OCC-s+0.00-H256", "OCC-s+0.00-H512", "OCC-s+0.00-H1024" };
        reset(w, thr); occ_fill(w); POS(w, Z[k], DRF, DIF); eval(w, "EXP-002B-OCC", &r);
        CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_FAIL && r.verdict == BRW_VD_V_FAIL, "s14.occ0 FAIL when drift earns credit at one H");
    }
    /* missing qgain: INCOMPLETE, never PASS */
    reset(w, thr); occ_fill(w); w->n--; w->n--;   /* drops the s = +3.00 gain and the H = 1024 s = 0 gain */
    eval(w, "EXP-002B-OCC", &r);
    CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_NC && r.verdict == BRW_VD_V_INCOMPLETE, "s14.occ0 with a missing s = 0 qgain is INCOMPLETE");
    reset(w, thr); eval(w, "EXP-002B-OCC", &r);
    CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_NC && r.verdict == BRW_VD_V_INCOMPLETE, "s14.occ0 with no OCC qgain is INCOMPLETE");
    /* FAIL_LEAK / FAIL_FLOOR / FAIL_PROTOCOL on any OCC cell, also a non-zero one, fails; FAIL wins over a missing qgain */
    static const char *const ST[3] = { "FAIL_LEAK", "FAIL_FLOOR", "FAIL_PROTOCOL" };
    for (size_t k = 0; k < 3; k++) {
        reset(w, thr); occ_fill(w); snprintf(w->g[4].status, sizeof w->g[4].status, "%s", ST[k]); eval(w, "EXP-002B-OCC", &r);
        CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_FAIL, "s14.occ0 FAILs on a FAIL_* status on a non-zero OCC cell");
    }
    reset(w, thr); occ_fill(w); w->g[4].protocol_failures = 1; eval(w, "EXP-002B-OCC", &r);
    CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_FAIL, "s14.occ0 FAILs on protocol_failures");
    reset(w, thr); occ_fill(w); w->n -= 1; eval(w, "EXP-002B-OCC", &r);   /* last OCC cell has no qgain: a scoring abort writes none */
    { const brw_vd_item *i = item(&r, "s14.occ0", "OCC-s+0.00"); CHECK(i && i->res == BRW_VD_NC && strstr(i->why, "missing OCC qgain on 1 of 124") && r.verdict == BRW_VD_V_INCOMPLETE, "s14.occ0: one OCC cell without its qgain is INCOMPLETE, never PASS"); }
    reset(w, thr); occ_fill(w); w->n -= 1; POS(w, "OCC-s+0.00-H512", DRF, DIF); eval(w, "EXP-002B-OCC", &r);
    CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_FAIL, "s14.occ0: drift credit at s = 0 FAILs even with a missing OCC cell");
    reset(w, thr); occ_fill(w); w->n -= 2; snprintf(w->g[0].status, sizeof w->g[0].status, "FAIL_LEAK"); eval(w, "EXP-002B-OCC", &r);
    CHECK(res_of(&r, "s14.occ0", "OCC-s+0.00") == BRW_VD_FAIL, "s14.occ0: FAIL_LEAK wins over a missing qgain");
    /* gains of B cells are not read by the OCC experiment, and the old experiments do not read OCC cells */
    reset(w, thr); fill_b(w); occ_fill(w); eval(w, "EXP-002B", &r);
    CHECK(item(&r, "s14.occ0", "OCC-s+0.00") == NULL && item(&r, "s14.occam", "OCC-*") != NULL, "EXP-002B output carries no s14.occ0 and keeps its descriptive s14.occam row");

    /* --- crossing rules on synthetic points (micro-bits) --- */
    brw_occ_curve c;
    /* simple crossing: dT -2, -1, +1, +2 bits at s 0, 1, 2, 3; the line between (1, -1) and (2, +1) is 0 at 1.5 */
    memset(&c, 0, sizeof c);
    set_pt(&c, 0, 0.0, -2000000, -3000000, -1000000); set_pt(&c, 1, 1.0, -1000000, -2000000, 500000);
    set_pt(&c, 2, 2.0, 1000000, 500000, 1500000); set_pt(&c, 3, 3.0, 2000000, 1500000, 2500000);
    c.have_cross_ref = 1; c.cross_ref = 1.75; brw_occ_analyze(&c);
    CHECK(c.has_cross && c.cross_s == 1.5 && !c.nonmono && c.changes == 1, "simple crossing at |s| = 1.5, monotone");
    CHECK(c.has_lo_end && c.lo_end == 1.0 && c.has_hi_end && c.hi_end == 2.0, "interval from the first upper end >= 0 (s = 1) to the first lower end > 0 (s = 2)");
    CHECK(c.inside == 1, "occ_cross 1.75 inside [1, 2]");
    c.cross_ref = 2.5; brw_occ_analyze(&c); CHECK(c.inside == 0, "occ_cross 2.5 outside [1, 2]");
    c.cross_ref = 1.0; brw_occ_analyze(&c); CHECK(c.inside == 1, "interval ends are inclusive");
    /* dT(s_i) exactly 0 followed by a positive point: the crossing is s_i */
    memset(&c, 0, sizeof c); set_pt(&c, 0, 0.0, -1000000, -2000000, 0); set_pt(&c, 1, 0.5, 0, -100000, 100000); set_pt(&c, 2, 1.0, 1000000, 500000, 1500000); brw_occ_analyze(&c);
    CHECK(c.has_cross && c.cross_s == 0.5, "dT = 0 followed by dT > 0 crosses at that |s|");
    /* no crossing: never positive; the ends beyond the grid */
    memset(&c, 0, sizeof c); set_pt(&c, 0, 0.0, -2000000, -3000000, -1500000); set_pt(&c, 1, 1.0, -1000000, -2000000, -500000); set_pt(&c, 2, 2.0, -500000, -1000000, -100000);
    c.have_cross_ref = 1; c.cross_ref = 2.0; brw_occ_analyze(&c);
    CHECK(!c.has_cross && c.changes == 0 && !c.nonmono && !c.has_lo_end && !c.has_hi_end && c.inside == 0, "no crossing in grid; both interval ends beyond grid; occ_cross outside");
    /* missing upper end only: the lower end exists, the upper is beyond grid; occ_cross at or above the lower end is inside */
    memset(&c, 0, sizeof c); set_pt(&c, 0, 0.0, -2000000, -3000000, -1500000); set_pt(&c, 1, 1.0, -100000, -1000000, 200000); set_pt(&c, 2, 2.0, 100000, -200000, 900000);
    c.have_cross_ref = 1; c.cross_ref = 1.5; brw_occ_analyze(&c);
    CHECK(c.has_cross && c.has_lo_end && c.lo_end == 1.0 && !c.has_hi_end && c.inside == 1, "upper end beyond grid: interval [1, beyond grid], occ_cross 1.5 inside");
    c.cross_ref = 0.5; brw_occ_analyze(&c); CHECK(c.inside == 0, "occ_cross below the lower end is outside");
    /* non-monotone: the first crossing is reported, the curve is flagged */
    memset(&c, 0, sizeof c); set_pt(&c, 0, 0.0, -1000000, -2000000, 0); set_pt(&c, 1, 1.0, 1000000, 200000, 1800000); set_pt(&c, 2, 2.0, -1000000, -1800000, -200000);
    set_pt(&c, 3, 3.0, 1000000, 200000, 1800000); brw_occ_analyze(&c);
    CHECK(c.has_cross && c.cross_s == 0.5 && c.nonmono && c.changes == 3, "non-monotone: first crossing reported (|s| = 0.5), flagged, 3 sign changes");
    /* one downward change only: no upward crossing and not non-monotone */
    memset(&c, 0, sizeof c); set_pt(&c, 0, 0.0, 1000000, 200000, 1800000); set_pt(&c, 1, 1.0, -1000000, -1800000, -200000); brw_occ_analyze(&c);
    CHECK(!c.has_cross && c.changes == 1 && !c.nonmono, "a single downward change is neither a crossing nor non-monotone");
    /* fewer than two points */
    memset(&c, 0, sizeof c); brw_occ_analyze(&c); CHECK(!c.has_cross && !c.has_lo_end && !c.has_hi_end, "no points: nothing reported");
    memset(&c, 0, sizeof c); set_pt(&c, 0, 0.0, 1000000, 500000, 1500000); brw_occ_analyze(&c);
    CHECK(!c.has_cross && c.has_lo_end && c.lo_end == 0.0 && c.has_hi_end && c.hi_end == 0.0, "one point: no crossing; ends taken from that point");

    /* --- build and render from gains: ratio, sign split, s = 0 shared, calibration parse --- */
    { brw_occ_curve cv[8]; char why[200] = ""; double cr[4]; int hv[4]; ty_digest gd[8]; tyqr_gain g[8]; size_t n = 0;
      static const char *const NM[5] = { "OCC-s+0.00-H128", "OCC-s+1.00-H128", "OCC-s-1.00-H128", "OCC-s+2.00-H128", "OCC-s+1.00-H256" };
      static const long long T[5] = { -1000000, -500000, -400000, 500000, 700000 };
      for (size_t k = 0; k < 5; k++) {
          memset(&g[n], 0, sizeof g[n]); snprintf(g[n].cell, sizeof g[n].cell, "%s", NM[k]); g[n].candidate_opcode = DRF; g[n].baseline_opcode = DIF;
          g[n].t_ub = T[k]; g[n].t_lo_ub = T[k] - 100000; g[n].t_hi_ub = T[k] + 100000; snprintf(g[n].status, sizeof g[n].status, "PASS"); snprintf(g[n].classification, sizeof g[n].classification, "AMBIGUOUS");
          sethex(&gd[n], k); n++;
      }
      memset(&g[n], 0, sizeof g[n]); snprintf(g[n].cell, sizeof g[n].cell, "B1-3"); g[n].candidate_opcode = DRF; g[n].baseline_opcode = DIF; sethex(&gd[n], 50); n++;   /* ignored: not an OCC cell */
      CHECK(brw_occ_parse_calib("brw.calib.v1\nB2-noise x 1 2 3\nocc_cross 128 3.5\nocc_cross 256 2.5\nocc_cross 512 2.25\nocc_cross 1024 1.75\n", cr, hv, why, sizeof why) == 0 && hv[0] && hv[3] && cr[0] == 3.5 && cr[3] == 1.75, "calibration occ_cross parsed");
      CHECK(brw_occ_parse_calib("brw.calib.v1\nocc_cross 128 3.5\nocc_cross 128 3.6\n", cr, hv, why, sizeof why) != 0 && brw_occ_parse_calib("x\n", cr, hv, why, sizeof why) != 0 && brw_occ_parse_calib("brw.calib.v1\nocc_cross 100 3.5\n", cr, hv, why, sizeof why) != 0, "calibration: duplicate H, bad header, foreign H refused");
      brw_occ_parse_calib("brw.calib.v1\nocc_cross 128 3.5\nocc_cross 256 2.5\nocc_cross 512 2.25\nocc_cross 1024 1.75\n", cr, hv, why, sizeof why);
      int used = brw_occ_build(g, gd, n, cr, hv, cv, why, sizeof why);
      CHECK(used == 5, "five OCC points used, the B1-3 gain ignored");
      CHECK(cv[0].H == 128 && cv[0].sign == 1 && cv[0].n == 3 && cv[0].pt[0].s == 0.0 && cv[0].pt[1].s == 1.0 && cv[0].pt[2].s == 2.0, "H128 + curve: s = 0, 1, 2 by |s|");
      CHECK(cv[1].H == 128 && cv[1].sign == -1 && cv[1].n == 2 && cv[1].pt[0].s == 0.0 && cv[1].pt[1].s == -1.0, "H128 - curve: shared s = 0, then s = -1");
      CHECK(cv[0].pt[2].ratio == 2.0 / sqrt(255.0) && cv[1].pt[1].ratio == 1.0 / sqrt(255.0), "ratio = |s| / sqrt(255) (|mu| / sqrt(2D), D cancels)");
      CHECK(cv[0].has_cross && cv[0].cross_s > 1.0 && cv[0].cross_s < 2.0 && cv[0].have_cross_ref && cv[0].cross_ref == 3.5 && cv[0].inside == 0, "H128 + crossing between 1 and 2; occ_cross 3.5 outside");
      CHECK(cv[2].H == 256 && cv[2].n == 1 && cv[3].n == 0 && !cv[2].has_cross, "H256: one non-zero point on + only, none on -, no crossing");
      char txt[8192]; int tl = brw_occ_render(cv, "certification", txt, sizeof txt);
      char txt2[8192]; int tl2 = brw_occ_render(cv, "certification", txt2, sizeof txt2);
      CHECK(tl > 0 && tl == tl2 && !memcmp(txt, txt2, (size_t)tl) && strstr(txt, "crossing_point no crossing in grid") && strstr(txt, "crossing_interval") && strstr(txt, "occ_cross 3.5 outside") && strstr(txt, "beyond grid"), "render is deterministic and carries the crossing rows");
      CHECK(strstr(txt, "point s 2 ratio 0.1252448") != NULL, "render prints reals with %.17g");
      gd[4] = gd[0]; g[4] = g[0]; snprintf(g[4].cell, sizeof g[4].cell, "OCC-s+0.00-H128"); g[4].t_ub = 5; sethex(&gd[4], 99);
      CHECK(brw_occ_build(g, gd, n, NULL, NULL, cv, why, sizeof why) == -1 && strstr(why, "two different qgains"), "two different qgains for one cell refuse the curve"); }
}
int main(int argc, char **argv) {
    fx_t fx; static world_t w;
    if (fx_init(&fx, argc, argv)) return 2;
    test_a(&w, fx.thr); test_b(&w, fx.thr); test_c(&w, fx.thr); test_agree(&w, fx.thr); test_render(&w, fx.thr); test_addon(&w, fx.thr); test_occ(&w, fx.thr);
    test_files(&fx);
    brw_bytes_free(&w.thr);
    fx_done(&fx);
    printf("test_brw_verdict: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

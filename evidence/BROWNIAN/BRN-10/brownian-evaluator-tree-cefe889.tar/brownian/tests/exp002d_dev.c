/* exp002d_dev: EXP-002D (BRN-9) hostile-cell table of spec section 18, DEVELOPMENT blocks 0, 1, 2 only.
 * Generates the same worlds `brownian_bench dev` writes (parent brownian.dev.v1, mode "dev"), in memory only: no file is written,
 * nothing is sealed, no qfreeze is read. Scores with the shipped reference programs and the shipped scorer (brw_score_world,
 * brw_cell_dl_*, brw_bootstrap_interval) using the same bootstrap recipe as brw_calib.c (dev_analysis_seed). Adds no scoring code.
 * Output: one line per check `ID | expected | observed | MATCH/MISMATCH | detail`, then a per-block detail on stderr-free stdout.
 * Worlds per block of an H- cell: 400 (brw_protocol.c "UNDECIDED: 400 assumed"). Usage: exp002d_dev  (no arguments) */
#include "brw_calib.h"
#include "brw_cells.h"
#include "brw_predict.h"
#include "sha256.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NBLK 3
#define OPI BRW_OP_IID
#define OPL BRW_OP_LINEAR_TREND
#define OPC BRW_OP_CUBIC_TREND
#define OPD BRW_OP_DIFFUSION
#define OPF BRW_OP_DIFF_DRIFT
#define OPM BRW_OP_MEAN_REVERT
#define OPK BRW_OP_LOOKUP_FLOOR
#define OPH BRW_OP_VARIANT_H1

static int g_match, g_mismatch;

static uint32_t cell_w(const char *cell) {
    uint32_t w = brw_calib_cell_w(cell);
    return w ? w : 400u;                       /* H- cells: 400 assumed (brw_protocol.c) */
}

/* a program by opcode; OPH = the h = 1 variant charged parent + 1 = 22 bytes exactly as brw_vd_variant_gain does */
static int get_prog(int op, brw_prog *p) {
    char err[128];
    if (op == OPH) {
        const brw_variant *v = brw_variant_h1();
        if (brw_prog_from_bytes(v->bytes, v->nbytes, p, err, sizeof err) != TYQ_OK) return -1;
        p->n = v->charged_bytes;
        return 0;
    }
    return brw_ref_program(op, p) == TYQ_OK ? 0 : -1;
}
static const char *op_name(int op) {
    if (op == OPH) return "DIFFUSION_H1";
    const brw_ref *r = brw_ref_get(op);
    return r ? r->name : "?";
}

/* same recipe as brw_calib.c dev_analysis_seed */
static void dev_analysis_seed(const char *cell, uint64_t block, uint8_t out[32]) {
    uint8_t parent[32], z = 0; char s[256]; sha256_ctx c;
    sha256_init(&c); sha256_update(&c, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT)); sha256_final(&c, parent);
    int n = snprintf(s, sizeof s, "brownian.v1|analysis|dev|%s|%llu", cell, (unsigned long long)block);
    sha256_init(&c); sha256_update(&c, (const uint8_t *)s, (size_t)n); sha256_update(&c, &z, 1); sha256_update(&c, parent, 32);
    sha256_final(&c, out);
}

typedef struct { brw_traj *tr; uint32_t *split; uint32_t W; brw_cell_spec cs; char cell[40]; } blockw;

static int load_block(const char *cell, uint32_t blk, blockw *b) {
    memset(b, 0, sizeof *b);
    snprintf(b->cell, sizeof b->cell, "%s", cell);
    if (brw_cell_lookup(cell, &b->cs) != BRW_OK) { printf("cannot look up cell %s\n", cell); return -1; }
    b->W = cell_w(cell);
    b->tr = calloc(b->W, sizeof *b->tr); b->split = calloc(b->W, sizeof *b->split);
    if (!b->tr || !b->split) return -1;
    for (uint32_t w = 0; w < b->W; w++) {
        uint8_t ws[32];
        if (brw_calib_world_seed(BRW_DEV_PARENT, cell, blk, w, ws) != BRW_OK) return -1;
        if (brw_world_generate(&b->cs, ws, &b->tr[w], NULL) != BRW_OK) { printf("generate failed %s b%u w%u\n", cell, blk, w); return -1; }
        b->split[w] = brw_world_split(&b->cs, &b->tr[w]);   /* the H-missing prefix count differs per world */
    }
    return 0;
}
static void free_block(blockw *b) {
    for (uint32_t w = 0; w < b->W; w++) brw_traj_free(&b->tr[w]);
    free(b->tr); free(b->split);
}

typedef struct { int64_t t[NBLK], lo[NBLK], hi[NBLK]; } trow;

static int score_rows(const char *cell, int opm, int opb, trow *r) {
    for (uint32_t blk = 0; blk < NBLK; blk++) {
        blockw b; brw_prog pm, pb; brw_cell_dl dm, db; ClRng boot; double mc; uint8_t seed[32];
        if (load_block(cell, blk, &b)) return -1;
        int64_t *diff = malloc((size_t)b.W * sizeof *diff);
        int rc = (diff && !get_prog(opm, &pm) && !get_prog(opb, &pb)) ? TYQ_OK : -1;
        if (rc == TYQ_OK) rc = brw_cell_dl_init(&dm, &pm);
        if (rc == TYQ_OK) rc = brw_cell_dl_init(&db, &pb);
        for (uint32_t w = 0; w < b.W && rc == TYQ_OK; w++) {
            brw_world_score sm, sb;
            rc = brw_score_world(&pm, &b.tr[w], b.split[w], BRW_MODE_FIT_ONCE, &sm);
            if (rc == TYQ_OK) rc = brw_score_world(&pb, &b.tr[w], b.split[w], BRW_MODE_FIT_ONCE, &sb);
            if (rc != TYQ_OK) break;
            rc = brw_cell_dl_add(&dm, &sm);
            if (rc == TYQ_OK) rc = brw_cell_dl_add(&db, &sb);
            diff[w] = (sb.data_ub + sb.rider_ub) - (sm.data_ub + sm.rider_ub);
        }
        int64_t t = 0, lo = 0, hi = 0;
        if (rc == TYQ_OK) rc = brw_cell_gain(&db, &dm, &t);
        dev_analysis_seed(cell, blk, seed);
        if (rc == TYQ_OK) rc = brw_boot_init(&boot, seed);
        if (rc == TYQ_OK) rc = brw_bootstrap_interval(diff, b.W, db.bytes_ub - dm.bytes_ub, BRW_BOOT_B, &boot, &lo, &hi, &mc);
        free(diff); free_block(&b);
        if (rc != TYQ_OK && rc != BRW_OK) { printf("scoring failed %s %s vs %s b%u rc=%d\n", cell, op_name(opm), op_name(opb), blk, rc); return -1; }
        r->t[blk] = t; r->lo[blk] = lo; r->hi[blk] = hi;
    }
    return 0;
}

static int crit_ok(char crit, int64_t lo, int64_t hi) {
    switch (crit) { case 'L': return lo > 0; case 'U': return hi < 0; case 'N': return !(lo > 0); default: return 1; }
}
static const char *crit_txt(char c) { return c == 'L' ? "lower>0" : c == 'U' ? "upper<0" : c == 'N' ? "lower not above 0" : "record only"; }

static void report(const char *id, const char *expected, int ok, const char *observed, const char *detail) {
    printf("%s | %s | %s | %s | %s\n", id, expected, observed, ok ? "MATCH" : "MISMATCH", detail);
    if (ok) g_match++; else g_mismatch++;
}

/* one T comparison, all three blocks must meet the criterion */
static void t_row(const char *id, const char *cell, int opm, int opb, char crit) {
    trow r; char exp[160], obs[512], det[160]; int ok = 1;
    snprintf(exp, sizeof exp, "%s: T(%s vs %s) %s on blocks 0,1,2", cell, op_name(opm), op_name(opb), crit_txt(crit));
    if (score_rows(cell, opm, opb, &r)) { report(id, exp, 0, "not evaluated (scoring error)", "exp002d_dev"); return; }
    obs[0] = 0;
    for (int b = 0; b < NBLK; b++) {
        char one[128];
        snprintf(one, sizeof one, "%sb%d T=%.4f [%.4f,%.4f] bits", b ? "; " : "", b, (double)r.t[b] / 1e6, (double)r.lo[b] / 1e6, (double)r.hi[b] / 1e6);
        strncat(obs, one, sizeof obs - strlen(obs) - 1);
        if (!crit_ok(crit, r.lo[b], r.hi[b])) ok = 0;
    }
    snprintf(det, sizeof det, "exp002d_dev t_row %s W=%u", cell, cell_w(cell));
    report(id, exp, crit == '-' ? 1 : ok, obs, det);
}

/* diagnostics of a program on a cell block: per-world statistics, block mean, vs the frozen null interval of null_cell */
static int diag_block(const blockw *b, int op, brw_diag *mean) {
    brw_prog p; brw_diag *dw = malloc((size_t)b->W * sizeof *dw);
    if (!dw || get_prog(op, &p)) { free(dw); return -1; }
    for (uint32_t w = 0; w < b->W; w++) {
        const brw_traj *tr = &b->tr[w]; uint32_t N = (uint32_t)tr->count, S = b->split[w], H = N - S;
        double y[BRW_MAXPOINTS], z[BRW_MAXPOINTS]; tyq_pred pr[BRW_MAXPOINTS]; const char *why = "";
        for (uint32_t i = 0; i < N; i++) y[i] = brw_symbol_value(tr->k[i]);
        if (brw_predict_fit_once(&p, tr->t, y, N, S, pr, &why) != TYQ_OK) { free(dw); return -1; }
        for (uint32_t i = 0; i < H; i++) { double sd = pr[i].scale; if (sd < TYQ_SD_MIN) sd = TYQ_SD_MIN; z[i] = (y[S + i] - pr[i].loc) / sd; }
        if (brw_diag_world(z, tr->t + S, y + S - 1, H, &dw[w]) != BRW_OK) { free(dw); return -1; }
    }
    int rc = brw_diag_block_mean(dw, b->W, mean);
    free(dw);
    return rc == BRW_OK ? 0 : -1;
}
static double stat_of(const brw_diag *d, int i) { const double v[6] = { d->mean_z, d->mean_z2, d->lag1, d->spearman_z2_t, d->slope_prev_y, d->excess_kurt }; return v[i]; }

/* expect_out = 1: the block mean of stat lies outside the frozen null interval of null_cell on every block; 0: inside on every block (control) */
static void d_row(const char *id, const char *cell, int op, int stat, const char *null_cell, int expect_out) {
    const brw_frozen_null *fz = brw_frozen_null_find(null_cell);
    char exp[200], obs[512], det[200]; int ok = 1;
    snprintf(exp, sizeof exp, "%s: %s of %s %s frozen %s null interval on blocks 0,1,2", cell, BRW_CALIB_STAT_NAMES[stat], op_name(op), expect_out ? "outside" : "inside", null_cell);
    if (!fz) { report(id, exp, 0, "not evaluated (no frozen null row)", "exp002d_dev"); return; }
    obs[0] = 0;
    for (uint32_t blk = 0; blk < NBLK; blk++) {
        blockw b; brw_diag m; char one[160];
        if (load_block(cell, blk, &b) || diag_block(&b, op, &m)) { report(id, exp, 0, "not evaluated (scoring error)", "exp002d_dev"); return; }
        free_block(&b);
        double v = stat_of(&m, stat), lo = fz->nc.lo[stat], hi = fz->nc.hi[stat]; int out = v < lo || v > hi;
        snprintf(one, sizeof one, "%sb%u %.5f (null [%.5f,%.5f]) %s", blk ? "; " : "", blk, v, lo, hi, out ? "OUT" : "in");
        strncat(obs, one, sizeof obs - strlen(obs) - 1);
        if (out != expect_out) ok = 0;
    }
    snprintf(det, sizeof det, "exp002d_dev d_row %s W=%u", cell, cell_w(cell));
    report(id, exp, ok, obs, det);
}

/* B1-1: reference mu interval excludes 0 on a minority of worlds ("intervals cover 0 most of the time") */
static void mu_row(const char *id, const char *cell) {
    char exp[160], obs[300], det[120]; int ok = 1;
    snprintf(exp, sizeof exp, "%s: fraction of reference mu intervals excluding 0 below 0.5 on blocks 0,1,2", cell);
    obs[0] = 0;
    for (uint32_t blk = 0; blk < NBLK; blk++) {
        blockw b; char one[80]; uint32_t ex = 0;
        if (load_block(cell, blk, &b)) { report(id, exp, 0, "not evaluated (scoring error)", "exp002d_dev"); return; }
        for (uint32_t w = 0; w < b.W; w++) {
            double y[BRW_MAXPOINTS], mh, lo, hi; const brw_traj *tr = &b.tr[w];
            for (uint32_t i = 0; i < tr->count; i++) y[i] = brw_symbol_value(tr->k[i]);
            if (brw_mu_interval(tr->t, y, b.split[w], &mh, &lo, &hi) != BRW_OK) { report(id, exp, 0, "not evaluated (mu interval error)", "exp002d_dev"); free_block(&b); return; }
            if (lo > 0 || hi < 0) ex++;
        }
        snprintf(one, sizeof one, "%sb%u %u/%u = %.4f", blk ? "; " : "", blk, ex, b.W, (double)ex / b.W);
        strncat(obs, one, sizeof obs - strlen(obs) - 1);
        if ((double)ex / b.W >= 0.5) ok = 0;
        free_block(&b);
    }
    snprintf(det, sizeof det, "exp002d_dev mu_row %s (band item B1-1.2 is [0.05,0.20])", cell);
    report(id, exp, ok, obs, det);
}

/* H-meas: informational D coverage of the naive diffusion reference (no gate) */
static void dcov_info(const char *id, const char *cell) {
    char obs[300]; obs[0] = 0;
    for (uint32_t blk = 0; blk < NBLK; blk++) {
        blockw b; char one[80]; uint32_t cov = 0;
        if (load_block(cell, blk, &b)) { report(id, "no coverage gate on naive D", 0, "not evaluated", "exp002d_dev"); return; }
        for (uint32_t w = 0; w < b.W; w++) {
            double y[BRW_MAXPOINTS], dh, lo, hi; brw_params hp; brw_traj tr2 = { 0, NULL, NULL }; uint8_t ws[32];
            brw_calib_world_seed(BRW_DEV_PARENT, cell, blk, w, ws);
            if (brw_world_generate(&b.cs, ws, &tr2, &hp) != BRW_OK) continue;
            for (uint32_t i = 0; i < tr2.count; i++) y[i] = brw_symbol_value(tr2.k[i]);
            if (brw_d_interval(tr2.t, y, b.split[w], &dh, &lo, &hi) == BRW_OK && lo <= hp.D && hp.D <= hi) cov++;
            brw_traj_free(&tr2);
        }
        snprintf(one, sizeof one, "%sb%u coverage %u/%u = %.3f", blk ? "; " : "", blk, cov, b.W, (double)cov / b.W);
        strncat(obs, one, sizeof obs - strlen(obs) - 1);
        free_block(&b);
    }
    report(id, "H-meas: naive D coverage recorded, NOT gated (B0 band [0.88,0.995] does not apply)", 1, obs, "exp002d_dev dcov_info");
}

int main(void) {
    printf("EXP-002D dev-only hostile cell table (spec section 18, hostile cells). Parent %s, blocks 0,1,2. Nothing written, nothing sealed.\n", BRW_DEV_PARENT);
    /* very short path: items 4 and 5 (13.4, 13.5) */
    t_row("HC-short-13.4", "B0-short", OPF, OPD, 'U');
    t_row("HC-short-13.5", "B0-short", OPM, OPD, 'U');
    /* irregular h: h = 1 variant, charged 22 bytes */
    t_row("HC-irregular-h1", "B0-irregular", OPH, OPD, 'U');
    /* tiny drift */
    t_row("HC-tinydrift-T", "B1-1", OPF, OPD, 'U');
    mu_row("HC-tinydrift-cover0", "B1-1");
    /* large measurement noise */
    d_row("HC-meas-lag1", "H-meas", OPD, 2, "B0-regular", 1);
    d_row("HC-meas-lag1-control", "B0-regular", OPD, 2, "B0-regular", 0);
    dcov_info("HC-meas-Dcov", "H-meas");
    /* wrong noise family */
    d_row("HC-t4-kurt", "H-t4", OPD, 5, "B0-regular", 1);
    d_row("HC-t4-kurt-control", "B0-regular", OPD, 5, "B0-regular", 0);
    t_row("HC-t4-smooth-linear", "H-t4", OPL, OPD, 'U');
    t_row("HC-t4-smooth-cubic", "H-t4", OPC, OPD, 'U');
    /* outliers */
    d_row("HC-outlier-kurt", "H-outlier", OPD, 5, "B0-regular", 1);
    t_row("HC-outlier-lookup", "H-outlier", OPK, OPD, 'U');
    /* missing rows: gap-ignoring model */
    t_row("HC-missing-h1", "H-missing", OPH, OPD, 'U');
    /* boundary parameters: as B0 (13.1-13.6) and as B2-weak (15.2) */
    t_row("HC-boundD-13.1", "H-boundary-D", OPD, OPI, 'L');
    t_row("HC-boundD-13.2", "H-boundary-D", OPL, OPD, 'U');
    t_row("HC-boundD-13.3", "H-boundary-D", OPC, OPD, 'U');
    t_row("HC-boundD-13.4", "H-boundary-D", OPF, OPD, 'U');
    t_row("HC-boundD-13.5", "H-boundary-D", OPM, OPD, 'U');
    t_row("HC-boundD-13.6", "H-boundary-D", OPK, OPD, 'U');
    t_row("HC-boundtheta-15.2", "H-boundary-theta", OPM, OPF, 'N');
    /* fast reversion: 15.3a, 15.3b, 15.4 */
    t_row("HC-fast-15.3a", "B2-fast", OPM, OPF, 'L');
    t_row("HC-fast-15.3b", "B2-fast", OPC, OPM, 'U');
    t_row("HC-fast-15.4", "B2-fast", OPI, OPM, 'N');
    /* overparameterized / memorization / false deterministic structure: B0-regular and B2-clear */
    t_row("HC-overfit-B0-linear", "B0-regular", OPL, OPD, 'U');
    t_row("HC-overfit-B0-cubic", "B0-regular", OPC, OPD, 'U');
    t_row("HC-memo-B0-lookup", "B0-regular", OPK, OPD, 'U');
    d_row("HC-overfit-B0-linear-lag1", "B0-regular", OPL, 2, "B0-regular", 1);
    d_row("HC-overfit-B0-cubic-lag1", "B0-regular", OPC, 2, "B0-regular", 1);
    t_row("HC-overfit-B2c-linear", "B2-clear", OPL, OPM, 'U');
    t_row("HC-overfit-B2c-cubic", "B2-clear", OPC, OPM, 'U');
    t_row("HC-memo-B2c-lookup", "B2-clear", OPK, OPM, 'U');
    d_row("HC-overfit-B2c-linear-lag1", "B2-clear", OPL, 2, "B2-clear", 1);
    d_row("HC-overfit-B2c-cubic-lag1", "B2-clear", OPC, 2, "B2-clear", 1);
    /* section 10 gate: mean reversion omitted on B2-clear: slope on previous y excludes 0 */
    d_row("HC-omit-MR-B2c-slope", "B2-clear", OPD, 4, "B2-clear", 1);
    /* affine disguise: development record only, T only */
    t_row("HC-affine-record-DvsIID", "H-affine", OPD, OPI, '-');
    printf("EXP-002D runner: %d match %d mismatch\n", g_match, g_mismatch);
    return g_mismatch ? 1 : 0;
}

/* test_brw_results.c: `brownian_bench results` on a small certification fixture (DUMMY digests, temp dir; never touches evidence/).
 * Checks: two runs are byte-identical, the printed sha256 is the file's, the JSON is compact with every object's keys in byte
 * order, fields with no source are null, the manifest arrays come through, and bad manifests (verdict word, unknown line,
 * bad sha) are refused with a nonzero exit and no output file. argv: <root> <omega> <bench> <sample manifest>. */
#include "harness_fx.h"
#include <sys/wait.h>

static int run(const char *fmt, ...) {
    char c[4096]; va_list ap; va_start(ap, fmt); vsnprintf(c, sizeof c, fmt, ap); va_end(ap);
    int s = system(c);
    return s == -1 ? -1 : WIFEXITED(s) ? WEXITSTATUS(s) : -1;
}
/* compact-JSON walker: no whitespace outside strings, object keys strictly ascending. Returns 0 on success. */
static int jval(const char **pp);
static int jstr(const char **pp, char *out, size_t cap) {
    const char *p = *pp; size_t n = 0;
    if (*p++ != '"') return -1;
    while (*p && *p != '"') { if (*p == '\\') { p++; if (!*p) return -1; if (*p == 'u') p += 4; } if (n + 1 < cap) out[n++] = *p; p++; }
    if (*p != '"') return -1;
    out[n] = 0; *pp = p + 1; return 0;
}
static int jval(const char **pp) {
    const char *p = *pp;
    if (*p == '{') {
        char prev[256] = "", k[256]; int first = 1; p++;
        if (*p == '}') { *pp = p + 1; return 0; }
        for (;;) {
            if (jstr(&p, k, sizeof k)) return -1;
            if (!first && strcmp(prev, k) >= 0) return -2;
            snprintf(prev, sizeof prev, "%s", k); first = 0;
            if (*p++ != ':') return -1;
            int r = jval(&p); if (r) return r;
            if (*p == ',') { p++; continue; }
            if (*p == '}') { *pp = p + 1; return 0; }
            return -1;
        }
    }
    if (*p == '[') {
        p++;
        if (*p == ']') { *pp = p + 1; return 0; }
        for (;;) { int r = jval(&p); if (r) return r; if (*p == ',') { p++; continue; } if (*p == ']') { *pp = p + 1; return 0; } return -1; }
    }
    if (*p == '"') { char k[4096]; if (jstr(&p, k, sizeof k)) return -1; *pp = p; return 0; }
    if (!strncmp(p, "null", 4)) { *pp = p + 4; return 0; }
    if (!strncmp(p, "true", 4)) { *pp = p + 4; return 0; }
    if (!strncmp(p, "false", 5)) { *pp = p + 5; return 0; }
    if (*p == '-' || (*p >= '0' && *p <= '9')) { if (*p == '-') p++; while (*p >= '0' && *p <= '9') p++; *pp = p; return 0; }   /* integers only: no '.', no exponent */
    return -1;
}
static int has(const brw_bytes *b, const char *s) { return b->n && memmem(b->b, b->n, s, strlen(s)) != NULL; }

int main(int argc, char **argv) {
    fx_t fx; char gp[BRW_PATH] = "";
    if (argc < 5 || fx_init(&fx, argc, argv)) { fprintf(stderr, "usage: %s <root> <omega> <bench> <sample manifest>\n", argv[0]); return 2; }
    const char *bench = argv[3], *man = argv[4];
    if (fx_cert(&fx) || fx_score_cert(&fx, "DIFFUSION", "IID_NORMAL", "score1", gp, sizeof gp)) { fprintf(stderr, "fixture: %s\n", fx.why); return 1; }
    char sc[BRW_PATH]; snprintf(sc, sizeof sc, "%s/score1", fx.tmp);
    char o1[BRW_PATH], o2[BRW_PATH], lg[BRW_PATH], bad[BRW_PATH], ob[BRW_PATH];
    snprintf(o1, sizeof o1, "%s/r1.json", fx.tmp); snprintf(o2, sizeof o2, "%s/r2.json", fx.tmp); snprintf(lg, sizeof lg, "%s/log1.txt", fx.tmp);
    snprintf(bad, sizeof bad, "%s/bad.tsv", fx.tmp); snprintf(ob, sizeof ob, "%s/rbad.json", fx.tmp);
    const char *cmd = "'%s' results --qprofile '%s' --dir '%s' --dir '%s' --manifest '%s' --out '%s' > '%s' 2>&1";
    CHECK(run(cmd, bench, fx.qprofile, fx.sdir, sc, man, o1, lg) == 0, "results run 1 exits 0");
    CHECK(run(cmd, bench, fx.qprofile, sc, fx.sdir, man, o2, "/dev/null") == 0, "results run 2 exits 0 (directories in the other order)");
    brw_bytes a, b, l;
    CHECK(brw_slurp(o1, &a) == 0 && brw_slurp(o2, &b) == 0 && a.n > 100 && a.n == b.n && memcmp(a.b, b.b, a.n) == 0, "two runs are byte-identical");
    if (a.b) {
        ty_digest d; char h[65], want[200]; brw_sha256(a.b, a.n, &d); ty_hex(&d, h);
        snprintf(want, sizeof want, "sha256 %s %s", h, o1);
        CHECK(brw_slurp(lg, &l) == 0 && has(&l, want) && has(&l, "PASS results.json written"), "stdout prints the file's sha256 and PASS");
        brw_bytes_free(&l);
        char *t = malloc(a.n + 1); memcpy(t, a.b, a.n); t[a.n] = 0;
        const char *p = t; int r = jval(&p);
        CHECK(r == 0 && *p == 0, "compact JSON, integers only, no trailing bytes");
        CHECK(r != -2, "every object's keys are in byte order");
        free(t);
        CHECK(has(&a, "{\"calibration\":{\"fw_rate_20block\":null,\"pit_bins\":null,\"rows\":null},\"ceiling_matrix\":["), "calibration is null-valued and sorts first, ceiling_matrix next");
        CHECK(has(&a, "\"occam_curve\":null") && has(&a, "\"intervention\":null") && has(&a, "\"chance_trend_worlds\":null"), "fields with no source are null");
        CHECK(has(&a, "\"coded_lengths\":null") && has(&a, "\"diagnostics\":null") && has(&a, "\"dev_parent\":null"), "per-cell fields with no source are null");
        CHECK(has(&a, "\"name\":\"B0-short\"") && has(&a, "\"candidate\":\"DIFFUSION\"") && has(&a, "\"baseline\":\"IID_NORMAL\"") && has(&a, "\"ladder_item\":\"-\""), "cell and qgain fields (declared-baseline pair is official, ladder item cleared by the scorer)");
        CHECK(has(&a, "\"mode\":\"certification\"") && has(&a, "\"official\":1"), "gain mode and official flag");
        CHECK(has(&a, "\"omega\":\"0123456789abcdef0123456789abcdef01234567\"") && has(&a, "\"dirty\":false") && has(&a, "\"name\":\"omega-pin-brn\""), "commits from the manifest");
        CHECK(has(&a, "\"kat1\":\"PASS\"") && has(&a, "\"rung\":\"EXP-002D\"") && has(&a, "\"verdict\":\"INCOMPLETE\""), "rng kat and ceiling matrix from the manifest");
        CHECK(has(&a, "\\\"quoted\\\"") && has(&a, "\"known_limitations\":[\"Bit-exactness") && has(&a, "\"replay\":[\"build/brownian_bench replay"), "manifest strings are escaped and kept in file order");
        CHECK(has(&a, "\"cflags\":null"), "cflags null without --cflags");
        brw_bytes_free(&a); brw_bytes_free(&b);
    }
    /* refusals: nothing is written */
    static const char *const BAD[] = {
        "rung\tCAL-0\tMAYBE\tx\ty\n", "failed_run\tg\tp\tq\tr\tpass\n", "negative_test\t1\tn\te\tOK\n",
        "surprise\tx\n", "commit\tname\tnothex\n", "rung\tCAL-0\tPASS\tonly-three-fields\n", "dirty\t2\n", "omega\t0123456789abcdef0123456789abcdef01234567\nomega\t0123456789abcdef0123456789abcdef01234567\n" };
    for (size_t i = 0; i < sizeof BAD / sizeof BAD[0]; i++) {
        fx_put(bad, BAD[i]); unlink(ob);
        char nm[80]; snprintf(nm, sizeof nm, "bad manifest %zu is refused and writes nothing", i);
        CHECK(run(cmd, bench, fx.qprofile, fx.sdir, sc, bad, ob, "/dev/null") != 0 && access(ob, F_OK) != 0, nm);
    }
    fx_put(bad, "# only a comment\n\n"); unlink(ob);
    CHECK(run(cmd, bench, fx.qprofile, fx.sdir, sc, bad, ob, "/dev/null") == 0, "an empty manifest is accepted (arrays empty, values null)");
    { brw_bytes e; CHECK(brw_slurp(ob, &e) == 0 && has(&e, "\"ceiling_matrix\":[]") && has(&e, "\"omega\":null") && has(&e, "\"dirty\":null"), "empty manifest gives [] and null"); brw_bytes_free(&e); }
    CHECK(run("'%s' results --qprofile '%s' --manifest '%s' --out '%s' > /dev/null 2>&1", bench, fx.qprofile, man, ob) != 0, "no --dir is a usage error");
    CHECK(run("'%s' results --qprofile '%s' --dir '%s' --manifest '%s' --out '%s' > /dev/null 2>&1", bench, fx.qprofile, fx.fdir, man, ob) != 0, "no qgain in the directories is refused");
    /* coded_lengths: from the TPS1 sidecar written by `tps --write`; the qgain bytes are untouched, results without the sidecar stay null */
    { char o3[BRW_PATH]; brw_bytes c3, q0, q1; snprintf(o3, sizeof o3, "%s/r3.json", fx.tmp);
      CHECK(brw_slurp(gp, &q0) == 0, "qgain readable before the sidecar");
      CHECK(run("'%s' tps --qgain '%s' --write > '%s' 2>&1", bench, gp, lg) == 0, "tps --write exits 0 on the fixture qgain");
      CHECK(brw_slurp(gp, &q1) == 0 && q0.n == q1.n && memcmp(q0.b, q1.b, q0.n) == 0, "the qgain is byte-identical after the sidecar is written");
      CHECK(run("'%s' tps --qgain '%s' --write > /dev/null 2>&1", bench, gp) == 0, "a second tps --write is idempotent");
      CHECK(run(cmd, bench, fx.qprofile, fx.sdir, sc, man, o3, "/dev/null") == 0, "results with a sidecar exits 0");
      CHECK(brw_slurp(o3, &c3) == 0 && has(&c3, "\"coded_lengths\":{\"B\":{\"ideal_ub\":") && has(&c3, "\"gate\":\"PASS\"") && has(&c3, "\"range_bytes\":") && has(&c3, "\"rans_bytes\":") && !has(&c3, "\"coded_lengths\":null"), "coded_lengths carries ideal, range and rANS lengths for both arms");
      if (c3.b) { char *t = malloc(c3.n + 1); memcpy(t, c3.b, c3.n); t[c3.n] = 0; const char *p = t; int r = jval(&p); CHECK(r == 0 && *p == 0, "results with coded_lengths is still compact JSON with sorted keys"); free(t); }
      brw_bytes_free(&c3); brw_bytes_free(&q0); brw_bytes_free(&q1); }
    fx_done(&fx);
    printf("results tests: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

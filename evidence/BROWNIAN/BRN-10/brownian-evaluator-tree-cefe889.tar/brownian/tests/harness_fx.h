/* harness_fx.h: shared fixture for the harness and hostile tests (Lane D3). Private, sealed. C only.
 * Every fixture lives in a fresh mkdtemp directory under $TMPDIR (or /tmp) and uses DUMMY digests: the run
 * commit, base commits and the turing profile are made-up hex strings. Nothing here touches brownian/evidence/
 * or any real sealed seed. The thresholds sidecar is the real brownian/spec/brw_thr_v1.txt (R3-30e; the
 * harness never compiles a band in). argv: <checkout root holding brownian/src> <pinned omega checkout>. */
#ifndef HARNESS_FX_H
#define HARNESS_FX_H
#pragma GCC diagnostic ignored "-Wformat-truncation"   /* fixture paths are short temp paths */
#include "brw_protocol.h"
#include <dirent.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static __attribute__((unused)) int g_pass, g_fail;
#define CHECK(cond, name) do { if (cond) { g_pass++; } else { g_fail++; printf("FAIL: %s (line %d)\n", name, __LINE__); } } while (0)
/* a refusal test: the call must return exactly `code` */
#define REJECT(rc, code, name) do { int r_ = (rc); if (r_ == (code)) { g_pass++; } else { g_fail++; printf("FAIL: %s: got %d (%s), want %s (line %d)\n", name, r_, brw_verdict_name(r_), brw_verdict_name(code), __LINE__); } } while (0)

typedef struct {
    char root[BRW_PATH], omega[BRW_PATH], tmp[BRW_PATH];
    brw_env env;
    char work[BRW_PATH];      /* profile, dev worlds, devman, calibration, meta, thresholds */
    char fdir[BRW_PATH];      /* qfreeze (and the ledger) */
    char sdir[BRW_PATH];      /* sealed run directory */
    char predict_src[BRW_PATH];
    char thr[BRW_PATH], meta[BRW_PATH], calib[BRW_PATH], devman[BRW_PATH];
    char qprofile[BRW_PATH], qfreeze[BRW_PATH], qworld[BRW_PATH];
    tyqr_profile prof; ty_digest pd;
    tyqr_freeze fr; ty_digest fd;
    tyqr_world wo; ty_digest wd;
    char cell[32];            /* cell used by prepare, seal and gain_load; default B0-short */
    const char *thr_text, *spec_text;   /* NULL = defaults; set BEFORE prepare to build a different qprofile */
    char why[BRW_WHY * 2];
} fx_t;

static const char FX_C0[] = "0123456789abcdef0123456789abcdef01234567";
static const char FX_T0[] = "00000000000000000000000000000000000000000000000000000000000000ff";

static __attribute__((unused)) int fx_put(const char *path, const char *s) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    fputs(s, f);
    return fclose(f);
}
static __attribute__((unused)) int fx_cp(const char *src, const char *dst) {
    brw_bytes b;
    if (brw_slurp(src, &b) != 0) return -1;
    FILE *f = fopen(dst, "wb");
    if (!f) { brw_bytes_free(&b); return -1; }
    size_t w = fwrite(b.b, 1, b.n, f);
    int rc = fclose(f) || w != b.n;
    brw_bytes_free(&b);
    return rc;
}
static void fx_dir(fx_t *fx, char *out, const char *name) {
    snprintf(out, BRW_PATH, "%s/%s", fx->tmp, name);
    mkdir(out, 0755);
}
/* flip one byte of a (possibly read-only) file in place */
static __attribute__((unused)) int fx_flip(const char *path, size_t off) {
    chmod(path, 0644);
    FILE *f = fopen(path, "r+b");
    if (!f) return -1;
    int c;
    if (fseek(f, (long)off, SEEK_SET) || (c = fgetc(f)) == EOF || fseek(f, (long)off, SEEK_SET) || fputc(c ^ 1, f) == EOF) { fclose(f); return -1; }
    return fclose(f);
}
/* first file in dir whose name starts with prefix; 0 if none */
static __attribute__((unused)) int fx_find(const char *dir, const char *prefix, char *out, size_t cap) {
    DIR *d = opendir(dir);
    if (!d) return 0;
    struct dirent *e; int n = 0;
    while ((e = readdir(d)) != NULL) if (strncmp(e->d_name, prefix, strlen(prefix)) == 0) { snprintf(out, cap, "%s/%s", dir, e->d_name); n++; break; }
    closedir(d);
    return n;
}
static void fx_meta(fx_t *fx, const char *mode, const char *extra) {
    char m[2048];
    snprintf(m, sizeof m, "mode=%s\nb2_emerging_label=AMBIGUOUS\nbayes_plugin_check=AGREE\ndiag_fw_rate_ppm=0\n"
        "lengthening_test=PASS\nstability_test=PASS\nrun_commit=%s\ntree_dirty=0\nbase_commits=%s\n%s", mode, FX_C0, FX_C0, extra ? extra : "");
    fx_put(fx->meta, m);
}
static __attribute__((unused)) int fx_init(fx_t *fx, int argc, char **argv) {
    memset(fx, 0, sizeof *fx);
    if (argc < 3) { fprintf(stderr, "usage: %s <checkout root> <pinned omega>\n", argv[0]); return -1; }
    snprintf(fx->root, sizeof fx->root, "%s", argv[1]);
    snprintf(fx->omega, sizeof fx->omega, "%s", argv[2]);
    const char *t = getenv("TMPDIR");
    snprintf(fx->tmp, sizeof fx->tmp, "%s/brwfx.XXXXXX", t && *t ? t : "/tmp");
    if (!mkdtemp(fx->tmp)) return -1;
    snprintf(fx->cell, sizeof fx->cell, "B0-short");
    brw_env_default(&fx->env);
    snprintf(fx->env.root, sizeof fx->env.root, "%s", fx->root);
    snprintf(fx->env.omega, sizeof fx->env.omega, "%s", fx->omega);
    snprintf(fx->predict_src, sizeof fx->predict_src, "%s/brownian/src/brw_predict.c", fx->root);
    fx_dir(fx, fx->work, "work"); fx_dir(fx, fx->fdir, "freeze"); fx_dir(fx, fx->sdir, "sealed");
    snprintf(fx->thr, sizeof fx->thr, "%s/brownian/spec/brw_thr_v1.txt", fx->root);   /* R3-30e: the real frozen sidecar */
    snprintf(fx->meta, sizeof fx->meta, "%s/meta.txt", fx->work);
    snprintf(fx->calib, sizeof fx->calib, "%s/calib.txt", fx->work);
    snprintf(fx->devman, sizeof fx->devman, "%s/devman.txt", fx->work);
    return 0;
}
static __attribute__((unused)) void fx_done(fx_t *fx) {
    char c[BRW_PATH * 2 + 16];
    if (strncmp(fx->tmp, "/", 1) == 0 && strstr(fx->tmp, "brwfx.")) { snprintf(c, sizeof c, "rm -rf '%s'", fx->tmp); if (system(c)) {} }
}
/* steps 1-4: qprofile, one development block of B0-short, devman, calibration file, meta */
static __attribute__((unused)) int fx_prepare(fx_t *fx, const char *mode) {
    char p[BRW_PATH];
    char *why = fx->why; size_t cap = sizeof fx->why;
    brw_profile_in in; memset(&in, 0, sizeof in);
    if (fx->thr_text) { snprintf(fx->thr, sizeof fx->thr, "%s/thr.txt", fx->work); fx_put(fx->thr, fx->thr_text); }   /* tests that need a different qprofile only */
    snprintf(p, sizeof p, "%s/spec.txt", fx->work); fx_put(p, fx->spec_text ? fx->spec_text : "spec\n");
    brw_bytes b;
    brw_slurp(p, &b); brw_sha256(b.b, b.n, &in.spec); brw_bytes_free(&b);
    snprintf(p, sizeof p, "%s/packet.txt", fx->work); fx_put(p, "packet\n");
    brw_slurp(p, &b); brw_sha256(b.b, b.n, &in.packet); brw_bytes_free(&b);
    brw_slurp(fx->thr, &b); tyqr_sidecar_digest((const char *)b.b, b.n, &in.thresholds); brw_bytes_free(&b);
    int rc = brw_profile_make(&in, &fx->prof, why, cap);
    if (rc) return rc;
    if (tyqr_profile_write(fx->work, &fx->prof, &fx->pd, fx->qprofile, sizeof fx->qprofile) != TY_OK) return TYQ_FAIL_PROFILE;
    if ((rc = brw_dev_block(&fx->env, fx->work, fx->cell, 0, &fx->pd, NULL, NULL, why, cap)) != 0) return rc;
    ty_digest md;
    if ((rc = brw_devman_refresh(fx->work, &md, why, cap)) != 0) return rc;
    char *cal = malloc(16384); size_t cl = 0;
    if (!cal || brw_calib_render(cal, 16384, &cl) != 0) { free(cal); return TYQ_E_IO; }
    cal[cl] = 0; fx_put(fx->calib, cal); free(cal);
    fx_meta(fx, mode, NULL);
    return 0;
}
static __attribute__((unused)) int fx_freeze(fx_t *fx, const char *artifact, const char *interp) {
    brw_freeze_args a; memset(&a, 0, sizeof a);
    a.artifact = artifact; a.qprofile = fx->qprofile; a.devman = fx->devman; a.calibration = fx->calib; a.meta = fx->meta;
    a.interp = interp; a.turing_profile = FX_T0; a.outdir = fx->fdir;
    int rc = brw_freeze(&a, &fx->fr, &fx->fd, fx->why, sizeof fx->why);
    if (rc) return rc;
    brw_record_path(fx->qfreeze, sizeof fx->qfreeze, fx->fdir, "turing.qfreeze", &fx->fd);
    char q[BRW_PATH]; snprintf(q, sizeof q, "%s", fx->qprofile);
    const char *s = strrchr(q, '/'); char d[BRW_PATH]; snprintf(d, sizeof d, "%s/%s", fx->fdir, s + 1);
    fx_cp(fx->qprofile, d);     /* the qprofile beside the qfreeze, as brw_seal_check expects */
    return 0;
}
/* seal into sdir; the run directory gets the qfreeze and qprofile copies, as `brownian_bench seal` does */
static __attribute__((unused)) int fx_seal(fx_t *fx, const char *artifact) {
    int rc = brw_seal(&fx->env, fx->qfreeze, artifact, fx->cell, fx->sdir, NULL, &fx->wo, &fx->wd, fx->why, sizeof fx->why);
    if (rc) return rc;
    char p[BRW_PATH], q[BRW_PATH];
    brw_record_path(p, sizeof p, fx->fdir, "turing.qfreeze", &fx->fd);
    brw_record_path(q, sizeof q, fx->sdir, "turing.qfreeze", &fx->fd); fx_cp(p, q);
    brw_record_path(p, sizeof p, fx->fdir, "turing.qprofile", &fx->pd);
    brw_record_path(q, sizeof q, fx->sdir, "turing.qprofile", &fx->pd); fx_cp(p, q);
    brw_record_path(fx->qworld, sizeof fx->qworld, fx->sdir, "turing.qworld", &fx->wd);
    return 0;
}
/* the whole certification lifecycle up to a sealed world */
static __attribute__((unused)) int fx_cert(fx_t *fx) {
    int rc = fx_prepare(fx, "certification");
    if (!rc) rc = fx_freeze(fx, fx->predict_src, NULL);
    if (!rc) rc = fx_seal(fx, fx->predict_src);
    return rc;
}
static __attribute__((unused)) int fx_score_cert(fx_t *fx, const char *cand, const char *base, const char *outname, char *gp, size_t gpc) {
    brw_score_args a; memset(&a, 0, sizeof a);
    char out[BRW_PATH]; fx_dir(fx, out, outname);
    a.mode = "certification"; a.qfreeze = fx->qfreeze; a.qworld = fx->qworld; a.candidate = cand; a.baseline = base;
    a.predict_src = fx->predict_src; a.thresholds = fx->thr; a.outdir = out;
    a.ladder_item = "LADDER-TEST";
    /* qfreeze must sit beside the qworld: use the copy in the run directory */
    char qf[BRW_PATH]; brw_record_path(qf, sizeof qf, fx->sdir, "turing.qfreeze", &fx->fd); a.qfreeze = qf;
    tyqr_gain g; ty_digest gd;
    return brw_score(&a, &g, &gd, gp, gpc, fx->why, sizeof fx->why);
}
/* score input rebuilt from the stored files, with the candidate PRD1 of world 0 replaceable (hostile PRD1 tests) */
typedef struct {
    brw_traj *tr; size_t W;
    brw_prog pb, pm; brw_bytes *prd_b, *prd_m;
    brw_gain_in in;
    tyqr_profile pr; tyqr_freeze fr; tyqr_world wo; ty_digest pd, fd, wd;
    ty_digest bman, mman;
} fx_gain_t;
static __attribute__((unused)) int fx_gain_load(fx_t *fx, fx_gain_t *x, int base_op, int cand_op) {
    memset(x, 0, sizeof *x);
    char p[BRW_PATH]; char *why = fx->why; size_t cap = sizeof fx->why;
    int rc;
    brw_record_path(p, sizeof p, fx->sdir, "turing.qfreeze", &fx->fd);
    if ((rc = brw_load_freeze(p, &x->fr, &x->fd, why, cap))) return rc;
    if ((rc = brw_load_world(fx->qworld, &x->wo, &x->wd, why, cap))) return rc;
    brw_record_path(p, sizeof p, fx->sdir, "turing.qprofile", &fx->pd);
    if ((rc = brw_load_profile(p, &x->pr, &x->pd, why, cap))) return rc;
    if ((rc = brw_world_load(fx->sdir, &x->wo, &x->tr, &x->W, why, cap))) return rc;
    if (brw_ref_program(base_op, &x->pb) || brw_ref_program(cand_op, &x->pm)) return TYQ_E_ARG;
    x->prd_b = calloc(x->W, sizeof *x->prd_b); x->prd_m = calloc(x->W, sizeof *x->prd_m);
    brw_cellinfo ci;
    if (brw_cellinfo_get(fx->cell, &ci)) return TYQ_E_ARG;
    for (size_t w = 0; w < x->W; w++) {
        if ((rc = brw_prd_for_program(&x->pb, &x->tr[w], &ci.s, &x->prd_b[w], why, cap))) return rc;
        if ((rc = brw_prd_for_program(&x->pm, &x->tr[w], &ci.s, &x->prd_m[w], why, cap))) return rc;
    }
    { brw_bytes bm, mm;
      if (brw_prd_manifest(x->prd_b, x->W, &bm, &x->bman) || brw_prd_manifest(x->prd_m, x->W, &mm, &x->mman)) return TYQ_E_IO;
      brw_bytes_free(&bm); brw_bytes_free(&mm); }
    brw_gain_in *in = &x->in;
    in->profile = &x->pr; in->profile_d = x->pd; in->freeze = &x->fr; in->freeze_d = x->fd; in->world = &x->wo; in->world_d = x->wd;
    in->ci = ci; in->tr = x->tr; in->W = x->W; in->pb = &x->pb; in->pm = &x->pm; in->base_op = base_op; in->cand_op = cand_op;
    brw_sha256(x->pb.bytes, (size_t)x->pb.n, &in->baseline_artifact); in->candidate = x->fr.artifact;
    in->prdman_b = x->bman; in->prdman_m = x->mman; in->prd_b = x->prd_b; in->prd_m = x->prd_m; in->ladder_item = "LADDER-TEST";
    return 0;
}
static __attribute__((unused)) void fx_gain_free(fx_gain_t *x) {
    if (x->prd_b) for (size_t w = 0; w < x->W; w++) brw_bytes_free(&x->prd_b[w]);
    if (x->prd_m) for (size_t w = 0; w < x->W; w++) brw_bytes_free(&x->prd_m[w]);
    free(x->prd_b); free(x->prd_m); brw_world_free(x->tr, x->W);
}
/* replace world 0 candidate PRD1 with crafted bytes and compute the gain */
static __attribute__((unused)) int fx_gain_with(fx_t *fx, fx_gain_t *x, const uint8_t *b, size_t n, char *why, size_t cap) {
    brw_bytes save = x->prd_m[0];
    brw_bytes mine; mine.b = malloc(n ? n : 1); memcpy(mine.b, b, n); mine.n = n;
    x->prd_m[0] = mine;
    tyqr_gain g;
    int rc = brw_gain_compute(&x->in, &g, why, cap);
    free(mine.b);
    x->prd_m[0] = save;
    (void)fx;
    return rc;
}
#endif

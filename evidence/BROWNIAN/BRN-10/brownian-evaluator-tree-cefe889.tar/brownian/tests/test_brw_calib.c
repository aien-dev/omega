/* test_brw_calib: BRN-5 calibration tool tests. argv: <path to brownian_calib> <scratch dir>.
 * Runs the CLI through the shell (its stdout is the product) and calls the library directly for unit checks. */
#include "brw_calib.h"
#include "brw_cells.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_pass, g_fail;
#define CHECK(cond, name) do { if (cond) { g_pass++; } else { g_fail++; printf("FAIL: %s (line %d)\n", name, __LINE__); } } while (0)

static const char *g_bin, *g_dir;

static char *slurp(const char *path) {
    FILE *f = fopen(path, "rb"); char *b = NULL; long z;
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); z = ftell(f); fseek(f, 0, SEEK_SET);
    b = malloc((size_t)z + 1);
    if (b && fread(b, 1, (size_t)z, f) != (size_t)z) { free(b); b = NULL; }
    if (b) b[z] = 0;
    fclose(f);
    return b;
}
/* run "<bin> <args>" with stdout to <dir>/<tag>.out (stderr discarded); returns the exit status; *text = output */
static int run(const char *tag, const char *args, char **text) {
    char cmd[1024], path[512];
    snprintf(path, sizeof path, "%s/%s.out", g_dir, tag);
    snprintf(cmd, sizeof cmd, "%s %s > %s 2>/dev/null", g_bin, args, path);
    int st = system(cmd);
    if (text) *text = slurp(path);
    return st;
}

static void test_quantiles(void) {
    /* 1000 blocks of W=1: statistic i of block b is a permutation of 0..999 scaled by 1e-3 */
    enum { NB = 1000 };
    brw_diag *w = calloc(NB, sizeof *w);
    brw_null_cell nc; char err[128];
    for (int b = 0; b < NB; b++) { double v = (double)((b * 373) % NB) / 1000.0; double *p = &w[b].mean_z; for (int d = 0; d < 6; d++) p[d] = v + d; }
    int rc = brw_calib_null_from_worlds(w, NB, 1, &nc, err, sizeof err);
    CHECK(rc == BRW_OK, "null_from_worlds ok");
    /* tail 0.05/12: lo index (int)(0.05/12*1000) = 4, hi index (int)((1-0.05/12)*1000) = 995 */
    for (int d = 0; d < 6; d++) {
        CHECK(fabs(nc.lo[d] - (0.004 + d)) < 1e-12, "quantile lo = sorted element 4");
        CHECK(fabs(nc.hi[d] - (0.995 + d)) < 1e-12, "quantile hi = sorted element 995");
        CHECK(fabs(nc.center[d] - (0.4995 + d)) < 1e-12, "center = mean of block means");
    }
    /* W=10 blocks: block means of 10 consecutive worlds */
    for (int b = 0; b < NB; b++) { double *p = &w[b].mean_z; for (int d = 0; d < 6; d++) p[d] = (double)b; }
    rc = brw_calib_null_from_worlds(w, NB, 10, &nc, err, sizeof err);
    CHECK(rc == BRW_OK, "W=10 ok");   /* 100 blocks; block b mean = 10b + 4.5 */
    CHECK(fabs(nc.lo[0] - (10 * 0 + 4.5)) < 1e-9, "W=10: index (int)(0.05/12*100) = 0");
    CHECK(fabs(nc.hi[0] - (10 * 99 + 4.5)) < 1e-9, "W=10: index min(99, 99)");
    CHECK(brw_calib_null_from_worlds(w, NB, 10, &nc, err, sizeof err) == BRW_OK, "repeat");
    CHECK(brw_calib_null_from_worlds(w, 990, 10, &nc, err, sizeof err) != BRW_OK, "99 blocks refused");
    CHECK(brw_calib_null_from_worlds(w, 1000, 7, &nc, err, sizeof err) != BRW_OK, "n not multiple of W refused");
    free(w);
    /* zero crossing */
    double s[4] = { 0, 1, 2, 3 }, t[4] = { -4, -2, 2, 6 }, x;
    CHECK(brw_calib_cross(s, t, 4, &x) == BRW_OK && fabs(x - 1.5) < 1e-15, "cross linear");
    double t2[4] = { -4, -2, -1, -0.5 };
    CHECK(brw_calib_cross(s, t2, 4, &x) != BRW_OK, "cross none");
}

static void test_seed_and_cells(void) {
    uint8_t a[32], b[32], c[32];
    CHECK(brw_calib_world_seed(BRW_CALIB_NULL_PARENT, "B0-regular", 0, 0, a) == BRW_OK, "seed");
    CHECK(brw_calib_world_seed(BRW_CALIB_NULL_PARENT, "B0-regular", 0, 0, b) == BRW_OK && !memcmp(a, b, 32), "seed repeatable");
    CHECK(brw_calib_world_seed(BRW_DEV_PARENT, "B0-regular", 0, 0, c) == BRW_OK && memcmp(a, c, 32), "nullcal differs from dev");
    CHECK(brw_calib_world_seed(BRW_CALIB_NULL_PARENT, "B0-regular", 0, 1, c) == BRW_OK && memcmp(a, c, 32), "rep matters");
    CHECK(brw_calib_cell_w("B0-regular") == 400 && brw_calib_cell_w("B2-weak") == 200 && brw_calib_cell_w("B2-emerging") == 1600, "W table");
    CHECK(brw_calib_cell_w("nope") == 0, "unknown cell");
    brw_cell_spec cs; char nm[64];
    CHECK(brw_calib_occ_spec(0.0, 128, &cs, nm, sizeof nm) == BRW_OK && !strcmp(nm, "OCC-s+0.00-H128") && cs.n_points == 256 && cs.split == 128, "occ name +0.00");
    CHECK(brw_calib_occ_spec(-3.25, 1024, &cs, nm, sizeof nm) == BRW_OK && !strcmp(nm, "OCC-s-3.25-H1024") && cs.n_points == 1152, "occ name -3.25");
}

static void test_nullcal(void) {
    char *a = NULL, *b = NULL, *c = NULL, *d = NULL;
    CHECK(run("nc_a", "nullcal B0-regular 40000", &a) == 0, "nullcal runs");
    CHECK(run("nc_b", "nullcal B0-regular 40000", &b) == 0 && a && b && !strcmp(a, b), "same output twice");
    CHECK(run("nc_j4", "-j 4 nullcal B0-regular 40000", &c) == 0 && c && !strcmp(a, c), "-j 4 identical to -j 1");
    CHECK(run("nc_j7", "-j 7 nullcal B0-regular 40000", &d) == 0 && d && !strcmp(a, d), "-j 7 identical");
    if (a) {
        int lines = 0; for (const char *p = a; *p; p++) lines += *p == '\n';
        CHECK(lines == 6, "six lines");
        double ctr, lo, hi; char cell[32], stat[32];
        CHECK(sscanf(a, "%31s %31s %lf %lf %lf", cell, stat, &ctr, &lo, &hi) == 5 && !strcmp(cell, "B0-regular") && !strcmp(stat, "mean_z") && lo < ctr && ctr < hi, "first line shape");
        const char *l2 = strchr(a, '\n') + 1;
        CHECK(sscanf(l2, "%31s %31s %lf %lf %lf", cell, stat, &ctr, &lo, &hi) == 5 && !strcmp(stat, "mean_z2"), "second stat is mean_z2");
        /* frozen design-check row for B0-regular mean z^2: 1.016106 [0.99252, 1.03957] (different seeds and only 100 blocks) */
        CHECK(fabs(ctr - 1.016106) < 0.005 && lo > 0.98 && lo < 1.005 && hi > 1.03 && hi < 1.06, "mean_z2 near the frozen design value");
    }
    free(a); free(b); free(c); free(d);
    a = NULL; b = NULL;
    CHECK(run("nc_w1", "nullcal B2-weak 20000", &a) == 0, "B2-weak runs (W=200)");
    CHECK(run("nc_w4", "-j 4 nullcal B2-weak 20000", &b) == 0 && a && b && !strcmp(a, b), "B2-weak -j 4 identical");
    free(a); free(b);
    CHECK(run("nc_bad", "nullcal B0-regular 2000", NULL) != 0, "n=2000 refused (5 blocks)");
    CHECK(run("nc_bad2", "nullcal B0-regular 40001", NULL) != 0, "n not multiple of W refused");
    CHECK(run("nc_bad3", "nullcal H-nope 40000", NULL) != 0, "unknown cell refused");
}

static void test_preq(void) {
    char *a = NULL, *b = NULL;
    CHECK(run("pq_a", "preqcheck B1-3 0", &a) == 0, "preqcheck B1-3 block 0 exits 0");
    CHECK(run("pq_b", "-j 4 preqcheck B1-3 0", &b) == 0 && a && b && !strcmp(a, b), "preqcheck -j identical");
    CHECK(a && strstr(a, "structural_KAT PASS") && strstr(a, "AGREE"), "structural KAT and AGREE");
    if (a) {
        double gap = 0; const char *p = strstr(a, "|data_ub gap| ");
        CHECK(p && sscanf(p, "|data_ub gap| %lf", &gap) == 1 && gap > 1.0, "data_ub arms differ by more than 1 ub");
        double tf = 0, tp = 0, rg = 0;
        CHECK((p = strstr(a, "T_fit_once_bits_per_block")) && sscanf(p, "T_fit_once_bits_per_block %lf", &tf) == 1, "T fit-once printed");
        CHECK((p = strstr(a, "T_prequential_bits_per_block")) && sscanf(p, "T_prequential_bits_per_block %lf", &tp) == 1, "T prequential printed");
        CHECK((p = strstr(a, "relative_gap")) && sscanf(p, "relative_gap %lf", &rg) == 1, "gap printed");
        CHECK(tf > 0 && tp > 0 && fabs(rg - fabs(tf - tp) / fmax(fabs(tf), fabs(tp))) < 1e-6, "B1-3 T positive in both arms; gap definition");
    }
    free(a); free(b);
    CHECK(run("pq_bad", "preqcheck B2-fast 0", NULL) != 0, "non-listed cell refused");
    char *s = NULL;
    CHECK(run("pq_short", "-j 4 preqcheck B0-short 0", &s) == 0 && s && strstr(s, "AGREE"), "B0-short runs and agrees");
    free(s);
}

static void test_occ_and_assemble(void) {
    char *o1 = NULL, *o4 = NULL;
    CHECK(run("oc_1", "occcross 128 1", &o1) == 0 && run("oc_4", "-j 4 occcross 128 1", &o4) == 0 && o1 && o4 && !strcmp(o1, o4), "occcross -j identical");
    unsigned h = 0; double sx = 0;
    CHECK(o1 && sscanf(o1, "occ_cross %u %lf", &h, &sx) == 2 && h == 128 && sx > 3.2 && sx < 4.0, "occ_cross 128 in the expected region");
    free(o1); free(o4);

    /* parts: every primary cell at 100 blocks, occ for four H at one block */
    char args[256], tag[64], path[600]; char *parts[16]; int np = 0;
    static const int order[11] = { 10, 3, 7, 0, 5, 9, 1, 8, 2, 6, 4 };   /* scrambled */
    for (int k = 0; k < 11; k++) {
        const char *cell = BRW_CALIB_PRIMARY[order[k]];
        unsigned W = brw_calib_cell_w(cell);
        snprintf(args, sizeof args, "-j 4 nullcal %s %u", cell, 100 * W);
        snprintf(tag, sizeof tag, "part_%d", k);
        CHECK(run(tag, args, &parts[np]) == 0 && parts[np], "part nullcal");
        np++;
    }
    for (int i = 3; i >= 0; i--) {
        snprintf(args, sizeof args, "-j 4 occcross %u 1", BRW_CALIB_OCC_H[i]);
        snprintf(tag, sizeof tag, "occ_%d", i);
        CHECK(run(tag, args, &parts[np]) == 0 && parts[np], "part occ");
        np++;
    }
    char list[4096] = "";
    for (int i = 0; i < np; i++) { snprintf(tag, sizeof tag, i < 11 ? "part_%d" : "occ_%d", i < 11 ? i : 14 - i); snprintf(path, sizeof path, " %s/%s.out", g_dir, tag); strcat(list, path); }
    char cmd[8192]; char *full = NULL, *full2 = NULL;
    snprintf(cmd, sizeof cmd, "assemble%s", list);
    CHECK(run("asm", cmd, &full) == 0 && full, "assemble ok");
    CHECK(run("asm2", cmd, &full2) == 0 && full && full2 && !strcmp(full, full2), "assemble deterministic");
    char err[128];
    CHECK(full && brw_calib_check_text(full, 0, err, sizeof err) == BRW_OK, "assembled file passes grammar and completeness");
    if (full) {
        CHECK(!strncmp(full, "brw.calib.v1\n", 13), "header line");
        int nl = 0, occ = 0; for (const char *p = full; *p; p++) nl += *p == '\n';
        CHECK(nl == 1 + 66 + 4, "line count 1 + 11*6 + 4");
        const char *p = strstr(full, "occ_cross ");
        for (; p; p = strstr(p + 1, "occ_cross ")) occ++;
        CHECK(occ == 4, "four occ_cross lines");
        CHECK(strstr(full, "B0-irregular mean_z ") == full + 13, "first null line is B0-irregular mean_z (byte order)");
        const char *e = strstr(full, "occ_cross 128 "), *e2 = strstr(full, "occ_cross 256 "), *e3 = strstr(full, "occ_cross 512 "), *e4 = strstr(full, "occ_cross 1024 ");
        CHECK(e && e2 && e3 && e4 && e < e2 && e2 < e3 && e3 < e4, "occ_cross H ascending");
        CHECK(strstr(full, "B2-weak exkurt ") && strstr(full, "B2-weak exkurt ") > strstr(full, "B2-noise exkurt "), "byte order at the end");
        /* every numeric field parses and lo <= center <= hi is NOT required; lo < hi is */
        int okrows = 1;
        for (const char *q = full + 13; strncmp(q, "occ_cross", 9) != 0; q = strchr(q, '\n') + 1) {
            char c1[32], st[32]; double ce, lo, hi;
            if (sscanf(q, "%31s %31s %lf %lf %lf", c1, st, &ce, &lo, &hi) != 5 || !(lo < hi)) okrows = 0;
        }
        CHECK(okrows, "all 66 null rows parse with lo < hi");
        /* negative grammar cases */
        char *bad = malloc(strlen(full) + 64);
        strcpy(bad, "brw.calib.v2\n"); strcat(bad, full + 13);
        CHECK(brw_calib_check_text(bad, 0, err, sizeof err) != BRW_OK, "wrong header refused");
        strcpy(bad, full); strcat(bad, "extra line\n");
        CHECK(brw_calib_check_text(bad, 0, err, sizeof err) != BRW_OK, "extra line refused");
        strcpy(bad, full); bad[strlen(bad) - 1] = 0;
        CHECK(brw_calib_check_text(bad, 0, err, sizeof err) != BRW_OK, "missing final LF refused");
        strcpy(bad, full); { char *x = strstr(bad, "B0-regular ac1"); memcpy(x, "B0-regular exk", 14); }
        CHECK(brw_calib_check_text(bad, 0, err, sizeof err) != BRW_OK, "unknown stat token refused");
        free(bad);
    }
    /* assemble refusals: missing cell, missing occ, duplicate */
    snprintf(cmd, sizeof cmd, "assemble %s/part_0.out", g_dir);
    CHECK(run("asm_inc", cmd, NULL) != 0, "incomplete set refused");
    snprintf(cmd, sizeof cmd, "assemble --partial %s/part_0.out %s/occ_0.out", g_dir, g_dir);
    CHECK(run("asm_part", cmd, NULL) == 0, "--partial accepts a subset");
    snprintf(cmd, sizeof cmd, "assemble --partial %s/part_0.out %s/part_0.out", g_dir, g_dir);
    CHECK(run("asm_dup", cmd, NULL) != 0, "duplicate lines refused");
    for (int i = 0; i < np; i++) free(parts[i]);
    free(full); free(full2);
}

/* ---- qfreeze keys 11/12 and the nullcal cross-check (R3-30 i and addendum) ---- */
static void test_keys(void) {
    CHECK(brw_calib_label4(5, 1, 9) == BRW_LAB_POSITIVE, "label POSITIVE: lower > 0");
    CHECK(brw_calib_label4(-5, -9, -1) == BRW_LAB_NEGATIVE, "label NEGATIVE: upper < 0");
    CHECK(brw_calib_label4(5, -1, 9) == BRW_LAB_WEAK, "label WEAK: covers 0, point > 0");
    CHECK(brw_calib_label4(0, -1, 9) == BRW_LAB_AMBIGUOUS && brw_calib_label4(-5, -9, 1) == BRW_LAB_AMBIGUOUS, "label AMBIGUOUS: covers 0, point <= 0");
    CHECK(brw_calib_label4(5, 0, 9) == BRW_LAB_WEAK, "lower exactly 0 is not POSITIVE");
    /* every key cell has a comparison; every comparison names a key cell */
    for (int c = 0; c < 12; c++) {
        int n = 0; for (size_t i = 0; i < BRW_CALIB_CMPS_N; i++) n += !strcmp(BRW_CALIB_CMPS[i].cell, BRW_CALIB_KEY_CELLS[c]);
        CHECK(n > 0 && brw_calib_cell_w(BRW_CALIB_KEY_CELLS[c]) > 0, "key cell has comparisons");
    }
    for (size_t i = 0; i < BRW_CALIB_CMPS_N; i++) {
        int f = 0; for (int c = 0; c < 12; c++) f |= !strcmp(BRW_CALIB_CMPS[i].cell, BRW_CALIB_KEY_CELLS[c]);
        CHECK(f, "comparison cell is a key cell");
    }
    /* verdict logic on hand-built items */
    brw_calib_item it[2]; memset(it, 0, sizeof it);
    for (int b = 0; b < BRW_CALIB_NBLOCKS; b++) for (int k = 0; k < 2; k++) { it[k].t[b] = 5; it[k].label[b] = it[k].llabel[b] = BRW_LAB_POSITIVE; }
    it[0].stable = it[1].stable = it[0].unchanged = it[1].unchanged = 1;
    CHECK(brw_calib_keys_verdict(it, 2, 0) == 1 && brw_calib_keys_verdict(it, 2, 1) == 1, "verdict PASS when all items ok");
    it[1].stable = 0;
    CHECK(brw_calib_keys_verdict(it, 2, 0) == 0 && brw_calib_keys_verdict(it, 2, 1) == 1, "one unstable item fails stability only");
    it[1].unchanged = 0;
    CHECK(brw_calib_keys_verdict(it, 2, 1) == 0 && brw_calib_keys_verdict(it, 0, 1) == 0, "one changed item (or no items) fails lengthening");
    /* the real path: B1-3 on dev blocks 0..2 */
    brw_calib_item *items = calloc(BRW_CALIB_CMPS_N, sizeof *items); size_t n = 0; char err[128] = "";
    CHECK(items && brw_calib_keys_cell("B1-3", 2, items, &n, err, sizeof err) == BRW_OK && n == 2, "keys_cell B1-3 ok, 2 comparisons");
    if (items && n == 2) {
        CHECK(items[0].label[0] == BRW_LAB_POSITIVE && items[1].label[0] == BRW_LAB_NEGATIVE, "B1-3: drift beats diffusion, mean-revert loses to drift");
        CHECK(items[0].stable && items[1].stable && items[0].unchanged && items[1].unchanged, "B1-3 stable and unchanged");
        for (int b = 0; b < BRW_CALIB_NBLOCKS; b++) {
            CHECK(items[0].lt[b] == items[0].t[b] - 8000000, "lengthened T = T - 8e6 ub (one byte on the candidate side)");
            CHECK(items[0].llo[b] == items[0].lo[b] - 8000000 && items[0].lhi[b] == items[0].hi[b] - 8000000, "lengthened interval shifts by exactly 8e6 ub (same stream)");
            CHECK(items[0].crit_ok[b] && items[1].crit_ok[b], "B1-3 item criteria met");
        }
        brw_calib_item again[8]; size_t n2 = 0;
        CHECK(brw_calib_keys_cell("B1-3", 1, again, &n2, err, sizeof err) == BRW_OK && n2 == 2 && again[0].t[1] == items[0].t[1] && again[0].lo[2] == items[0].lo[2], "deterministic in thread count");
    }
    free(items);
    CHECK(brw_calib_keys_cell("no-such-cell", 1, NULL, &n, err, sizeof err) != BRW_OK, "unknown cell refused");
}

static void test_null_compare(void) {
    const brw_frozen_null *fz = brw_frozen_null_find("B1-3");
    int ag[6][3]; double gp[6][3];
    CHECK(fz != NULL, "frozen B1-3 row");
    if (!fz) return;
    CHECK(brw_calib_null_compare("B1-3", &fz->nc, ag, gp) == 0 && ag[5][2] == 1 && gp[0][0] == 0.0, "frozen table agrees with itself");
    brw_null_cell p = fz->nc;
    p.lo[3] += 1e-9;
    CHECK(brw_calib_null_compare("B1-3", &p, ag, gp) == 1 && ag[3][1] == 0 && ag[3][0] == 1 && gp[3][1] > 0.0, "one perturbed field disagrees, and only that statistic");
    CHECK(brw_calib_null_compare("B0-short", &p, ag, gp) == BRW_E_ARG, "B0-short has no frozen row");
}

static void test_keys_cli(void) {
    char *t = NULL; int st;
    st = run("stab", "-j 2 stability B1-3 B0-short", &t);
    CHECK(st == 0 && t && strstr(t, "stability B1-3 PASS") && strstr(t, "stability B0-short PASS") && strstr(t, "stability_test PASS"), "CLI stability PASS");
    free(t);
    st = run("leng", "-j 2 lengthening B1-3", &t);
    CHECK(st == 0 && t && strstr(t, "B1-3.1 | b0 POSITIVE->POSITIVE") && strstr(t, "lengthening_test PASS"), "CLI lengthening PASS");
    free(t);
    st = run("badcell", "stability Nope", &t);
    CHECK(st != 0, "CLI stability unknown cell exits nonzero");
    free(t);
    /* R3-31(b) coverage on a small fresh sample: prints the per-cell rate, band, P(stop 13) and diagnostics, and a verdict line */
    st = run("cov", "-j 2 coverage B1-3 40000", &t);
    CHECK(t && strstr(t, "coverage B1-3 blocks") && strstr(t, "P_stop13 fresh") && strstr(t, "frozen_disclosed 0.0079") && strstr(t, "diag") && (strstr(t, "coverage B1-3 PASS") || strstr(t, "coverage B1-3 FAIL")), "CLI coverage reports rate, band, P(stop 13), diagnostics and a verdict");
    CHECK(((st >> 8) == 0 && strstr(t, "coverage B1-3 PASS")) || ((st >> 8) == 4 && strstr(t, "coverage B1-3 FAIL")), "CLI coverage exit code matches the verdict (0 PASS, 4 FAIL)");
    free(t);
    st = run("cov2", "coverage B0-short 40000", &t);
    CHECK(st != 0, "CLI coverage B0-short (no frozen row) refused");
    free(t);
}

int main(int argc, char **argv) {
    if (argc != 3) { fprintf(stderr, "usage: test_brw_calib <brownian_calib> <scratch dir>\n"); return 64; }
    g_bin = argv[1]; g_dir = argv[2];
    test_quantiles();
    test_seed_and_cells();
    test_nullcal();
    test_preq();
    test_occ_and_assemble();
    test_keys();
    test_null_compare();
    test_keys_cli();
    printf("brw_calib tests: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

#!/bin/sh
# Checks brw.thr.v1 against the frozen spec. Run from anywhere.
d=$(cd "$(dirname "$0")/.." && pwd)
spec=$d/spec/brownian-profile-v1.md
thr=$d/spec/brw_thr_v1.txt
rc=0
LC_ALL=C sort -c "$thr" || { echo "FAIL: not sorted"; rc=1; }
dups=$(awk '{print $1" "$2}' "$thr" | LC_ALL=C sort | uniq -d)
[ -z "$dups" ] || { echo "FAIL: duplicate item_id+field: $dups"; rc=1; }
[ "$(tail -c1 "$thr" | od -An -c | tr -d ' ')" = '\n' ] || { echo "FAIL: no final newline"; rc=1; }
grep -q ' $' "$thr" && { echo "FAIL: trailing space"; rc=1; }
while read -r id field val extra; do
  [ -z "$extra" ] || { echo "FAIL: extra fields: $id $field"; rc=1; }
  sec=${id%%.*}; row=${id#*.}
  case $sec in
    s13) h='## 13[.]' ;; s14) h='## 14\.' ;; s15) h='## 15\.' ;; s19) h='## 19\.' ;;
    *) echo "FAIL: bad section $id"; rc=1; continue ;;
  esac
  line=$(awk -v h="$h" -v row="$row" '
    $0 ~ "^## " {insec = ($0 ~ "^" h)}
    insec && index($0, "| " row " |") == 1 {print; exit}
    insec && index($0, "| " row " ") == 1 {print; exit}' "$spec")
  [ -n "$line" ] || { echo "FAIL: no spec row for $id"; rc=1; continue; }
  printf '%s\n' "$line" | grep -qF -- "$val" || { echo "FAIL: value $val not in row of $id"; rc=1; }
done < "$thr"
[ $rc -eq 0 ] && echo "PASS brw.thr.v1 ($(wc -l < "$thr") lines)"
exit $rc

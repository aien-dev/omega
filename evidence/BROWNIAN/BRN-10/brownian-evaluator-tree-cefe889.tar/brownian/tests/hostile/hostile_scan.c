/* §18 #3 hidden process label in the packet, #4 hidden parameters in the packet, #5 hidden seed in the packet.
 * The packet scanner (word list) and the packet allow-list (only packet.txt, brw_dl_spec.txt and world_<sha8>.qbw
 * whose sha8 is the first 8 hex of the file's SHA-256 and which decode as QBW1) must refuse every case.
 * argv: <checkout root> <pinned omega> */
#include "../harness_fx.h"

static int put_scan(fx_t *fx, const char *dir, const char *name, const char *text) {
    char p[BRW_PATH]; snprintf(p, sizeof p, "%s/%s", dir, name);
    fx_put(p, text);
    char why[BRW_WHY];
    int rc = brw_packet_scan(dir, why, sizeof why);
    unlink(p);
    (void)fx;
    return rc;
}

int main(int argc, char **argv) {
    fx_t fx;
    if (fx_init(&fx, argc, argv)) return 2;
    char why[BRW_WHY], pk[BRW_PATH];
    fx_dir(&fx, pk, "pk");
    /* #3 label words, in many spellings, inside packet.txt and brw_dl_spec.txt */
    static const char *bad[] = { "diffusion", "Diffusion process", "a DIFFUSION.", "Ornstein-Uhlenbeck", "ornstein uhlenbeck", "ORNSTEIN",
        "brownian motion", "Wiener process", "Langevin equation", "mean reversion", "mean-reverting", "mean_reverting", "white noise",
        "drift coefficient", "gaussian increment", "the force on it", "energy", "a mass", "temperature", "k_B", "epsilon_0", "h-bar", "the constant G" };
    for (size_t i = 0; i < sizeof bad / sizeof *bad; i++) {
        char t[128]; snprintf(t, sizeof t, "a list of numbers, %s, more numbers\n", bad[i]);
        char lab[160]; snprintf(lab, sizeof lab, "#3 packet.txt containing \"%s\" is refused", bad[i]);
        REJECT(put_scan(&fx, pk, "packet.txt", t), TYQ_FAIL_PROTOCOL, lab);
        snprintf(lab, sizeof lab, "#3 brw_dl_spec.txt containing \"%s\" is refused", bad[i]);
        REJECT(put_scan(&fx, pk, "brw_dl_spec.txt", t), TYQ_FAIL_PROTOCOL, lab);
    }
    CHECK(put_scan(&fx, pk, "packet.txt", "a list of numbers with a time and a value\n") == 0, "control: a plain packet.txt is accepted");
    /* #4 parameter files and evaluator paths in the packet */
    static const char *files[] = { "params.json", "hidden_params.txt", "parameters.txt", "seed.txt", "seed", "devman.txt", "truth.txt", "world.qbw",
        "traj.0000.man", "turing.qfreeze.00.omg0", "world_zzzzzzzz.qbw", "world_0123456.qbw", "world_01234567.qbw.bak", ".hidden" };
    for (size_t i = 0; i < sizeof files / sizeof *files; i++) {
        char lab[160]; snprintf(lab, sizeof lab, "#4/#5 stray packet file %s is refused by the allow-list", files[i]);
        REJECT(put_scan(&fx, pk, files[i], "D=0.5\n"), TYQ_FAIL_PROTOCOL, lab);
    }
    /* a subdirectory is not on the allow-list either */
    { char sub[BRW_PATH]; snprintf(sub, sizeof sub, "%s/sub", pk); mkdir(sub, 0755);
      REJECT(brw_packet_scan(pk, why, sizeof why), TYQ_FAIL_PROTOCOL, "#4 a subdirectory in the packet is refused"); rmdir(sub); }
    /* world files: a real QBW1 under its own sha8 name is allowed; the same bytes under another name, or garbage, are not */
    REJECT(fx_prepare(&fx, "certification"), 0, "prepare dev worlds");
    char q[BRW_PATH];
    {
        DIR *d = opendir(fx.work); struct dirent *e; q[0] = 0;
        while ((e = readdir(d)) != NULL) { size_t l = strlen(e->d_name); if (l > 4 && !strcmp(e->d_name + l - 4, ".qbw")) { snprintf(q, sizeof q, "%s/%s", fx.work, e->d_name); break; } }
        closedir(d);
    }
    CHECK(q[0], "found a development QBW1 file");
    if (q[0]) {
        brw_bytes b; brw_slurp(q, &b);
        ty_digest dg; brw_sha256(b.b, b.n, &dg); char h[65]; ty_hex(&dg, h);
        char w[BRW_PATH]; snprintf(w, sizeof w, "%s/world_%.8s.qbw", pk, h);
        fx_put(w, ""); unlink(w);
        FILE *f = fopen(w, "wb"); fwrite(b.b, 1, b.n, f); fclose(f);
        CHECK(brw_packet_scan(pk, why, sizeof why) == 0, "control: world_<sha8>.qbw with the right name and valid QBW1 is accepted");
        unlink(w);
        snprintf(w, sizeof w, "%s/world_%08x.qbw", pk, 0xdeadbeefu);
        f = fopen(w, "wb"); fwrite(b.b, 1, b.n, f); fclose(f);
        REJECT(brw_packet_scan(pk, why, sizeof why), TYQ_FAIL_PROTOCOL, "#4 a world file whose name is not its own sha8 is refused");
        unlink(w);
        snprintf(w, sizeof w, "%s/world_%.8s.qbw", pk, h);
        f = fopen(w, "wb"); fwrite(b.b, 1, b.n - 3, f); fclose(f);   /* truncated: name no longer matches either */
        REJECT(brw_packet_scan(pk, why, sizeof why), TYQ_FAIL_PROTOCOL, "#4 a corrupted world file is refused");
        unlink(w);
        brw_bytes_free(&b);
    }
    fx_done(&fx);
    printf("hostile_scan: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

/* Lane A broken-generator hostile rows, R2_INTEGRATOR_DECISIONS R3-30 (i); spec section 18 rows 1, 2, 24, 27.
 *  #1  wrong diffusion factor of 2: development D coverage outside [0.88, 0.995]  (the D2 small-step KAT half is in test_brw_world.c)
 *  #2  wrong dt scaling (h = 1): irregular-grid coverage out of band              (the known h != 1 KAT half is in test_brw_world.c)
 *  #24 wrong quantizer: symbol KAT, Simpson KAT (this file), profile digest binding (hostile_records #25 / FAIL_PROFILE)
 *  #27 Euler generator: D2 mean KAT (re-asserted here); the TPS1 adapter gate (stop 27) with a broken-adapter hook, via brw_tps_stream (pin 008c5eb).
 * Coverage emulation: the generator is not re-implemented broken. The real development block is generated and the D reference
 * interval of section 13 is compared against a truth that a broken generator would have produced (2D, D/2), or is computed with
 * the broken dt (h = 1). By the interval's construction those are the same numbers the analyzer would see against a broken generator.
 * argv: <checkout root> <pinned omega> (a third argument is ignored). The D coverage band is read from brw_thr_v1.txt. */
#include "../harness_fx.h"
#include "brw_stats.h"
#include "brw_tps.h"
#include <math.h>

static int gen(const char *cell, brw_traj **tr, brw_params **par, size_t *W) {
    brw_cellinfo ci;
    if (brw_cellinfo_get(cell, &ci)) return -1;
    char label[128];
    if (brw_world_label("dev", cell, 0, label, sizeof label) != BRW_OK) return -1;
    *W = ci.W; *tr = calloc(*W, sizeof **tr); *par = calloc(*W, sizeof **par);
    for (size_t w = 0; w < *W; w++) {
        uint8_t seed[32];
        if (brw_world_seed(label, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), w, seed) != BRW_OK ||
            brw_world_generate(&ci.s, seed, &(*tr)[w], &(*par)[w]) != BRW_OK) return -1;
    }
    return 0;
}
/* coverage count of `mult * D_true` by the section 13 interval; hone = 1: the interval is computed with t replaced by the index (h = 1) */
static uint32_t coverage(const char *cell, double mult, int hone, size_t *Wout) {
    brw_traj *tr; brw_params *par; size_t W;
    brw_cellinfo ci; brw_cellinfo_get(cell, &ci);
    if (gen(cell, &tr, &par, &W)) { *Wout = 0; return 0; }
    double *lo = calloc(W, sizeof *lo), *hi = calloc(W, sizeof *hi), *tv = calloc(W, sizeof *tv);
    for (size_t w = 0; w < W; w++) {
        size_t n = tr[w].count;
        double *t = malloc(n * sizeof *t), *y = malloc(n * sizeof *y), dh;
        for (size_t i = 0; i < n; i++) { t[i] = hone ? (double)i : tr[w].t[i]; y[i] = brw_symbol_value(tr[w].k[i]); }
        if (brw_d_interval(t, y, ci.s.split, &dh, &lo[w], &hi[w]) != 0) { lo[w] = 1; hi[w] = 0; }
        tv[w] = mult * par[w].D;
        free(t); free(y);
    }
    uint32_t c = brw_count_cover(lo, hi, tv, W);
    for (size_t w = 0; w < W; w++) brw_traj_free(&tr[w]);
    free(tr); free(par); free(lo); free(hi); free(tv);
    *Wout = W;
    return c;
}
/* the band comes from the frozen sidecar brw_thr_v1.txt (s13.7 d_cov_lo/hi PASS, d_cov_stop_lo/hi STOP; spec lines 429, 471, 561), never hard-coded */
static double g_cov_lo, g_cov_hi, g_stop_lo, g_stop_hi;
static int thr_load(const char *root) {
    char p[BRW_PATH]; snprintf(p, sizeof p, "%s/brownian/spec/brw_thr_v1.txt", root);
    FILE *fp = fopen(p, "r"); if (!fp) return -1;
    char k[64], n[64]; double v; int got = 0;
    while (fscanf(fp, "%63s %63s %lf", k, n, &v) == 3) if (!strcmp(k, "s13.7")) {
        if (!strcmp(n, "d_cov_lo")) { g_cov_lo = v; got++; } else if (!strcmp(n, "d_cov_hi")) { g_cov_hi = v; got++; }
        else if (!strcmp(n, "d_cov_stop_lo")) { g_stop_lo = v; got++; } else if (!strcmp(n, "d_cov_stop_hi")) { g_stop_hi = v; got++; } }
    fclose(fp); return got == 4 ? 0 : -1;
}
static int band(uint32_t c, size_t W) { return brw_band_check(c, (uint32_t)W, g_cov_lo, g_cov_hi, g_stop_lo, g_stop_hi); }

/* ---- #24: independent long-double composite Simpson of the bin mass, spec section 2 ---- */
static double simpson_bits(double zc, double b) {
    const int N = 4096;
    long double lo = -(long double)b / 2, hi = (long double)b / 2, hh = (hi - lo) / N, s = 0;
    for (int i = 0; i <= N; i++) {
        long double u = lo + hh * i, f = expl(-u * (2.0L * zc + u) / 2.0L);
        s += f * (i == 0 || i == N ? 1.0L : (i & 1) ? 4.0L : 2.0L);
    }
    long double I = s * hh / 3.0L;
    long double nats = (long double)zc * zc / 2.0L + 0.5L * logl(2.0L * 3.14159265358979323846264338327950288L) - logl(I);
    return (double)(nats / logl(2.0L));
}
typedef double (*scorer)(double zc, double b);
static double sc_midpoint(double zc, double b) { return (double)((long double)zc * zc / 2.0L / logl(2.0L) + log2l(sqrtl(2.0L * 3.14159265358979323846264338327950288L) / b)); }
static double sc_delta19(double zc, double b) { return simpson_bits(zc, 2.0 * b) ; }  /* bin twice as wide: a different delta */
static double sc_real(double zc, double b) { (void)b; (void)zc; return 0; }
/* run the KAT table against a scorer: returns the number of rows outside the section 2 tolerance (2e-7 + 1e-12 bits) */
static int kat_rows_failing(scorer sc, int use_real) {
    static const double S[] = { 0x1p-10, 1.0, 1e3 }, Z[] = { 0, 1, 5, 30, 2048, 4096 };
    int bad = 0;
    for (size_t a = 0; a < 3; a++) for (size_t z = 0; z < 6; z++) {
        double s = S[a], b_nom = 0x1p-20 / s;
        int64_t k = (int64_t)llround(Z[z] * s / 0x1p-20 - 0.5);
        double zc = (((double)k + 0.5) * 0x1p-20) / s;
        double ref = simpson_bits(zc, b_nom), got;
        if (use_real) {
            tyq_pred p; memset(&p, 0, sizeof p); p.family = TYQ_FAM_GAUSS; p.loc = 0; p.scale = s;
            int fh; if (ty_qcont_bits(&p, k, &got, &fh) != TYQ_OK) { bad++; continue; }
        } else got = sc(zc, b_nom);
        if (fabs(got - ref) > 2e-7 + 1e-12 * ref) bad++;
    }
    return bad;
}
static int euler_bad(brw_family f, const brw_params *p, double x, double h, double *m, double *v) {
    int rc = brw_transition(f, p, x, h, m, v);
    if (f == BRW_FAM_D2 && rc == BRW_OK) *m = x * (1.0 - p->theta * h);
    return rc;
}

/* a broken adapter plays a wrong mass on one observation (as omega tests/brownian/test_brw_tps.c does) */
typedef struct { size_t at; double rel; int mode; } tps_tamper;
static void tps_tamper_hook(void *ctx, size_t obs, brw_tps_step *st, size_t n) {
    const tps_tamper *t = ctx;
    if (obs != t->at || n == 0) return;
    long double pt = exp2l(st[0].log2p_taken);
    if (t->mode == 0) { pt *= (1.0L - (long double)t->rel); st[0].log2p_taken = log2l(pt); st[0].log2p_other = log2l(1.0L - pt); st[0].p1 = (double)(st[0].bit ? pt : 1.0L - pt); }
    else st[0].p1 = st[0].p1 * (1.0 - t->rel);
}

int main(int argc, char **argv) {
    if (argc < 2 || thr_load(argv[1])) { printf("cannot read the D coverage band from brw_thr_v1.txt\n"); return 2; }

    size_t W;
    /* ---- #1: development D coverage ---- */
    uint32_t c = coverage("B0-regular", 1.0, 0, &W);
    CHECK(W == 400, "B0-regular has 400 worlds");
    CHECK(band(c, W) == BRW_BAND_PASS, "#1 control: the real generator's D coverage is inside the frozen PASS band");
    printf("  B0-regular D coverage %u/%zu\n", c, W);
    c = coverage("B0-regular", 2.0, 0, &W);
    CHECK(band(c, W) == BRW_BAND_STOP, "#1 a generator that doubles the diffusion factor: coverage out of band, STOP");
    c = coverage("B0-regular", 0.5, 0, &W);
    CHECK(band(c, W) == BRW_BAND_STOP, "#1 a generator that halves the diffusion factor: coverage out of band, STOP");
    /* ---- #2: irregular grid, wrong dt ---- */
    c = coverage("B0-irregular", 1.0, 0, &W);
    CHECK(band(c, W) == BRW_BAND_PASS, "#2 control: irregular-grid D coverage is inside the band");
    printf("  B0-irregular D coverage %u/%zu\n", c, W);
    c = coverage("B0-irregular", 1.0, 1, &W);
    CHECK(band(c, W) == BRW_BAND_STOP, "#2 wrong dt scaling (h = 1): irregular-grid coverage out of band, STOP");
    /* the regular grid has h = 1, so h = 1 cannot be told from h: it must NOT stop (documents why the irregular cell carries the test) */
    c = coverage("B0-regular", 1.0, 1, &W);
    CHECK(band(c, W) == BRW_BAND_PASS, "#2 note: h = 1 is invisible on the regular grid, only the irregular cell catches it");

    /* ---- H-missing split by ORIGINAL index (spec line 261): prefix [0,128), held-out [128,256), only kept held-out rows scored ---- */
    {
        brw_cellinfo hm; brw_cellinfo_get("H-missing", &hm);
        double tt[] = { 0, 1, 2, 4, 5, 6, 8 }; int64_t kk[7] = { 0, 1, 2, 3, 4, 5, 6 };
        brw_traj hand = { 7, tt, kk };
        brw_cell_spec cs = hm.s; cs.split = 5;
        CHECK(brw_world_split(&cs, &hand) == 4, "H-missing split: kept rows with original index < 5 are t = 0,1,2,4, so the prefix has 4 rows (a kept-index split would give 5)");
        cs.split = 4; CHECK(brw_world_split(&cs, &hand) == 3, "H-missing split: original index 3 was dropped, so a split of 4 puts 3 rows in the prefix");
        CHECK(brw_world_split(&hm.s, &hand) == 7, "H-missing split: a split beyond every kept time leaves no held-out rows");
        brw_cell_spec ex = hm.s; ex.obs = BRW_OBS_EXACT; ex.split = 5;
        CHECK(brw_world_split(&ex, &hand) == 5, "every other cell splits at the cell's split");
        brw_traj *tr; brw_params *par; size_t Wm; int shifted = 0, agree = 1, idx_ok = 1, hcheck = 1;
        brw_prog prog; brw_ref_program(BRW_OP_DIFFUSION, &prog);
        if (gen("H-missing", &tr, &par, &Wm)) { CHECK(0, "generate H-missing"); return 1; }
        for (size_t w = 0; w < Wm; w++) {
            uint32_t sw = brw_world_split(&hm.s, &tr[w]), ref = 0;
            /* an independent count of kept rows below the original split index 128 (t_i = i on the regular grid) */
            for (uint64_t i = 0; i < tr[w].count; i++) if ((uint64_t)tr[w].t[i] < hm.s.split) ref++;
            if (sw != ref) agree = 0;
            if (sw != hm.s.split) shifted++;
            for (uint32_t i = 0; i < sw; i++) if (tr[w].t[i] >= hm.s.split) agree = 0;
            if (sw < tr[w].count && tr[w].t[sw] < hm.s.split) agree = 0;
            if (w < 40) {
                brw_bytes pb; char why[BRW_WHY];
                if (brw_prd_for_program(&prog, &tr[w], &hm.s, &pb, why, sizeof why) != 0) { idx_ok = 0; continue; }
                ty_prd prd; memset(&prd, 0, sizeof prd);
                if (ty_prd_parse(pb.b, pb.n, sw, (uint32_t)(tr[w].count - sw), &prd) != TYQ_OK) idx_ok = 0;
                else {
                    /* the first held-out point is predicted with h = difference of kept times: DIFFUSION sd scales with sqrt(h) */
                    if (sw >= 2 && tr[w].count > sw + 1) {
                        double h1 = tr[w].t[sw] - tr[w].t[sw - 1], h2 = tr[w].t[sw + 1] - tr[w].t[sw];
                        double r = prd.rec[1].scale / prd.rec[0].scale;
                        if (fabs(r - sqrt(h2 / h1)) > 1e-9 * r) hcheck = 0;
                    }
                    ty_prd_free(&prd);
                }
                brw_bytes_free(&pb);
            }
        }
        CHECK(agree, "H-missing: prefix membership is by original index in all 400 development worlds");
        CHECK(shifted > 0, "H-missing: some worlds drop rows before index 128, so the kept-index and original-index splits really differ");
        CHECK(idx_ok, "H-missing: PRD1 held-out records start at the original-index split (per-world first index)");
        CHECK(hcheck, "H-missing: the prediction step uses the difference of kept times");
        for (size_t w = 0; w < Wm; w++) brw_traj_free(&tr[w]);
        free(tr); free(par);
    }

    /* ---- #24: quantizer ---- */
    int64_t k;
    CHECK(brw_quantize(-0.5 * 0x1p-20, &k) == BRW_OK && k == -1, "#24 symbol KAT: x = -0.5 delta gives k = -1 (floor)");
    CHECK((int64_t)(-0.5) == 0, "#24 the truncating quantizer would give 0 for the same x: a KAT failure");
    CHECK(kat_rows_failing(NULL, 1) == 0, "#24 control: ty_qcont_bits agrees with the long-double Simpson KAT on all 18 rows");
    CHECK(kat_rows_failing(sc_midpoint, 0) > 0, "#24 a midpoint scorer fails the Simpson KAT");
    CHECK(kat_rows_failing(sc_delta19, 0) > 0, "#24 a scorer with delta = 2^-19 fails the Simpson KAT");
    (void)sc_real;
    /* the profile digest binding half (a different delta or scorer changes the qprofile) is hostile_records row 25: FAIL_PROFILE */

    /* ---- #27: Euler generator ---- */
    CHECK(brw_check_transition_kats(brw_transition) == BRW_OK, "#27 control: the exact D2 transition passes the KATs");
    CHECK(brw_check_transition_kats(euler_bad) == BRW_E_KAT, "#27 an Euler generator (D2 mean factor 1 - theta h) fails the D2 mean KAT");
    /* ---- #27: TPS1 adapter gate (omega tools/brownian/brw_tps_adapter, via brw_tps_stream): broken adapters must fail the gate ---- */
    { enum { NO = 200 }; static tyq_pred rec[NO]; static int64_t kk[NO]; static brw_tps_arm arm; unsigned long long sst = 88172645463325252ULL;
      for (int i = 0; i < NO; i++) {
          sst ^= sst << 13; sst ^= sst >> 7; sst ^= sst << 17; double u1 = (double)(sst >> 11) / 9007199254740992.0;
          sst ^= sst << 13; sst ^= sst >> 7; sst ^= sst << 17; double u2 = (double)(sst >> 11) / 9007199254740992.0;
          memset(&rec[i], 0, sizeof rec[i]); rec[i].index = (uint32_t)i; rec[i].loc = 5.0 * (u1 - 0.5); rec[i].scale = 0.05 + 2.0 * u2;
          kk[i] = (int64_t)llround((rec[i].loc + (u2 - 0.5) * 3.0 * rec[i].scale) / 0x1p-20);
      }
      memset(&arm, 0, sizeof arm);
      CHECK(brw_tps_stream(rec, kk, NO, 0, NULL, NULL, &arm) == 0 && arm.state == BRW_TPS_PASS, "#27 control: the real adapter passes both gates on a synthetic stream");
      CHECK(arm.n_obs == NO && arm.range_bytes > 0 && arm.rans_bytes > 0 && arm.ideal_ub > 0 && arm.max_dev_exact <= BRW_TPS_EXACT_TOL, "#27 control: real coded lengths and the ideal are produced");
      static const double rels[] = { 1e-3, 1e-5, 1e-7 };
      for (int mode = 0; mode < 2; mode++) for (int r = 0; r < 3; r++) {
          tps_tamper t = { 37, rels[r], mode };
          memset(&arm, 0, sizeof arm);
          int rc = brw_tps_stream(rec, kk, NO, 4, tps_tamper_hook, &t, &arm);
          CHECK(rc == BRW_TPS_E_PROOF && arm.state == BRW_TPS_GATE_FAIL && arm.bad_index == 37 && arm.bad_world == 4 && arm.range_bytes == 0, "#27 a broken adapter (wrong step mass, 1e-3 to 1e-7) fails the gate: STOP, nothing coded");
      } }
    printf("hostile_lane_a: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

/* hostile_sandbox.c: §18 #33 (sandbox escape), #34 (nondeterministic candidate) and R3-26 G2 (rlimits).
 * argv: <checkout root> <pinned omega> <sandbox_probe> <nondet_interp> <brw_interp>. Every test that needs bwrap is
 * BLOCKED, not skipped silently, when /usr/bin/bwrap is missing. */
#include "../harness_fx.h"

static int g_blocked;
static int has(const char *note, const char *needle) { return strstr(note, needle) != NULL; }

static void run_mode(fx_t *fx, fx_gain_t *x, const char *probe, const char *mode, int expect_ok, const char *label) {
    char prog[BRW_PATH], note[8192] = "";
    snprintf(prog, sizeof prog, "%s/prog_%s", fx->tmp, mode);
    char body[64]; snprintf(body, sizeof body, "%s\n", mode); fx_put(prog, body);
    brw_bytes *prd = calloc(x->W, sizeof *prd);
    int rc = brw_run_in_sandbox(probe, prog, x->tr, 3, &x->in.ci.s, prd, note, sizeof note, fx->why, sizeof fx->why);
    if (expect_ok) REJECT(rc, 0, label);
    else REJECT(rc, TYQ_FAIL_PROTOCOL, label);
    for (size_t w = 0; w < x->W; w++) brw_bytes_free(&prd[w]);
    free(prd);
}

int main(int argc, char **argv) {
    fx_t fx;
    if (argc < 6) { fprintf(stderr, "usage: %s <root> <omega> <sandbox_probe> <nondet_interp> <brw_interp>\n", argv[0]); return 2; }
    char *av[3] = { argv[0], argv[1], argv[2] };
    if (fx_init(&fx, 3, av)) return 2;
    const char *probe = argv[3], *nondet = argv[4];
    if (access("/usr/bin/bwrap", X_OK) != 0) {
        printf("BLOCKED #33/G2/#34: /usr/bin/bwrap is not executable\n"); g_blocked++;
        printf("hostile_sandbox: %d passed, %d failed, %d blocked\n", g_pass, g_fail, g_blocked);
        fx_done(&fx); return 0;
    }
    if (fx_cert(&fx)) { CHECK(0, "fixture"); printf("  why: %s\n", fx.why); fx_done(&fx); return 1; }
    fx_gain_t x;
    if (fx_gain_load(&fx, &x, 1, BRW_OP_DIFFUSION)) { CHECK(0, "load sealed world"); printf("  why: %s\n", fx.why); fx_done(&fx); return 1; }

    /* #33 and G2: W = 0 run, read what the probe saw from inside */
    char prog[BRW_PATH], note[16384] = "";
    snprintf(prog, sizeof prog, "%s/prog_ok", fx.tmp); fx_put(prog, "ok\n");
    int rc = brw_run_in_sandbox(probe, prog, x.tr, 0, &x.in.ci.s, NULL, note, sizeof note, fx.why, sizeof fx.why);
    REJECT(rc, 0, "#33 escape probe session completes (W = 0)");
    if (rc) printf("  why: %s\n", fx.why);
    CHECK(has(note, "PROBE open_etc_passwd=fail"), "#33 /etc/passwd is not readable");
    CHECK(has(note, "PROBE open_home=fail"), "#33 /home is not visible");
    CHECK(has(note, "PROBE open_root=fail"), "#33 /root is not visible");
    CHECK(has(note, "PROBE write_tmp=fail"), "#33 no /tmp to write into");
    CHECK(!has(note, "PROBE write_root=WROTE"), "#33 no file can be written at /");
    CHECK(has(note, "PROBE connect=fail"), "#33 no network");
    CHECK(has(note, "PROBE exec_sh=fail"), "#33 no /bin/sh to execute");
    CHECK(has(note, "PROBE env=0"), "#33 environment is empty");
    CHECK(has(note, "PROBE rlimit_cpu=10\n"), "G2 RLIMIT_CPU = 10 s at W = 0");
    CHECK(has(note, "PROBE rlimit_as=1073741824\n"), "G2 RLIMIT_AS = 1 GiB");
    CHECK(has(note, "PROBE rlimit_fsize=0\n"), "G2 RLIMIT_FSIZE = 0");
    CHECK(has(note, "PROBE rlimit_nofile=16\n"), "G2 RLIMIT_NOFILE = 16");
    CHECK(has(note, "PROBE rlimit_core=0\n"), "G2 RLIMIT_CORE = 0");
    CHECK(has(note, "PROBE nnp=1"), "G2 NO_NEW_PRIVS is set");
    {
      char h[BRW_PATH]; snprintf(h, sizeof h, "%s/probe_out", fx.tmp); CHECK(access(h, F_OK) != 0, "#33 nothing appeared in the run directory"); }

    /* a candidate that breaks the line protocol is FAIL_PROTOCOL and is not retried */
    run_mode(&fx, &x, probe, "ok", 1, "valid hostile-probe session with W = 3 is accepted (escapes change nothing)");
    run_mode(&fx, &x, probe, "badreply", 0, "malformed reply is FAIL_PROTOCOL");
    run_mode(&fx, &x, probe, "nan", 0, "NaN loc is FAIL_PROTOCOL");
    run_mode(&fx, &x, probe, "negscale", 0, "negative scale is FAIL_PROTOCOL");
    run_mode(&fx, &x, probe, "wrongindex", 0, "reply for a different index is FAIL_PROTOCOL");
    run_mode(&fx, &x, probe, "longline", 0, "over-long reply line is FAIL_PROTOCOL");
    run_mode(&fx, &x, probe, "extra", 0, "output after X is FAIL_PROTOCOL");
    run_mode(&fx, &x, probe, "earlyexit", 0, "candidate that quits early is FAIL_PROTOCOL");
    fx_gain_free(&x);
    fx_done(&fx);

    /* #34: a nondeterministic candidate must be caught by replay */
    fx_t d; char *av2[3] = { argv[0], argv[1], argv[2] };
    if (fx_init(&d, 3, av2)) { CHECK(0, "discovery fixture"); return 1; }
    REJECT(fx_prepare(&d, "discovery"), 0, "#34 prepare");
    brw_prog dp; brw_ref_program(BRW_OP_IID, &dp);
    char art[BRW_PATH]; snprintf(art, sizeof art, "%s/art.brwdl", d.tmp);
    FILE *f = fopen(art, "wb"); fwrite(dp.bytes, 1, (size_t)dp.n, f); fclose(f);
    fx_meta(&d, "discovery", "producer_tool=testtool\nproducer_model=testmodel\n"
        "prompt_digest=1111111111111111111111111111111111111111111111111111111111111111\n"
        "transcript_digest=2222222222222222222222222222222222222222222222222222222222222222\n");
    rc = fx_freeze(&d, art, nondet);
    if (!rc) rc = fx_seal(&d, art);
    REJECT(rc, 0, "#34 freeze and seal with the nondeterministic interpreter");
    if (rc) { printf("  why: %s\n", d.why); fx_done(&d); goto done; }
    char pk[BRW_PATH], p[BRW_PATH]; fx_dir(&d, pk, "pk"); snprintf(p, sizeof p, "%s/packet.txt", pk); fx_put(p, "a list of numbers\n");
    brw_score_args a; memset(&a, 0, sizeof a);
    char qf[BRW_PATH]; brw_record_path(qf, sizeof qf, d.sdir, "turing.qfreeze", &d.fd);
    a.mode = "discovery"; a.qfreeze = qf; a.qworld = d.qworld; a.candidate = art; a.baseline = "IID_NORMAL"; a.candidate_cmd = nondet;
    a.packet = pk; a.ladder_item = "LADDER-TEST"; a.thresholds = d.thr;
    char out[BRW_PATH], gp[BRW_PATH] = ""; fx_dir(&d, out, "score"); a.outdir = out;
    tyqr_gain g; ty_digest gd;
    rc = brw_score(&a, &g, &gd, gp, sizeof gp, d.why, sizeof d.why);
    REJECT(rc, 0, "#34 the nondeterministic candidate scores once");
    if (rc) printf("  why: %s\n", d.why);
    else {
        REJECT(brw_replay(&d.env, gp, 0, nondet, d.why, sizeof d.why), TYQ_FAIL_DIGEST, "#34 replay of a nondeterministic candidate is FAIL_DIGEST");
    }
    fx_done(&d);
done:
    printf("hostile_sandbox: %d passed, %d failed, %d blocked\n", g_pass, g_fail, g_blocked);
    return g_fail ? 1 : 0;
}

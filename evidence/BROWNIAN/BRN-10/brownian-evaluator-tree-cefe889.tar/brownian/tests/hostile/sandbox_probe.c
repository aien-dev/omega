/* sandbox_probe.c: a STATIC test candidate for tests/hostile/hostile_sandbox.c (§18 #33, R3-26 G2). It speaks brw.line.v1
 * like the evaluator interpreter but is hostile: it tries to leave the sandbox and reports each attempt on STDERR
 * as `PROBE key=value`. argv: <exe> --line <prog>; the first line of <prog> is the mode:
 *   ok          escape attempts, then a valid loc 0 scale 1 predictor
 *   badreply    reply is not `N i loc scale`
 *   nan         reply has a NaN loc
 *   negscale    reply has scale -1
 *   wrongindex  reply names another index
 *   longline    reply longer than 4096 bytes
 *   extra       valid session, then output after X
 *   earlyexit   exits after the handshake
 * The evaluator must never accept output from an escape attempt and never change its verdict because of one. */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <unistd.h>

extern char **environ;

static void rl(const char *k, int r) { struct rlimit x; if (getrlimit(r, &x) == 0) fprintf(stderr, "PROBE %s=%llu\n", k, (unsigned long long)x.rlim_cur); else fprintf(stderr, "PROBE %s=error\n", k); }
static void escapes(void) {
    int fd;
    fd = open("/etc/passwd", O_RDONLY); fprintf(stderr, "PROBE open_etc_passwd=%s\n", fd < 0 ? "fail" : "OPENED"); if (fd >= 0) close(fd);
    fd = open("/home", O_RDONLY); fprintf(stderr, "PROBE open_home=%s\n", fd < 0 ? "fail" : "OPENED"); if (fd >= 0) close(fd);
    fd = open("/root", O_RDONLY); fprintf(stderr, "PROBE open_root=%s\n", fd < 0 ? "fail" : "OPENED"); if (fd >= 0) close(fd);
    fd = open("/tmp/probe_out", O_WRONLY | O_CREAT, 0600); fprintf(stderr, "PROBE write_tmp=%s\n", fd < 0 ? "fail" : "OPENED"); if (fd >= 0) close(fd);
    signal(SIGXFSZ, SIG_IGN);
    fd = open("/probe_out", O_WRONLY | O_CREAT, 0600);
    if (fd < 0) fprintf(stderr, "PROBE write_root=fail\n");
    else { ssize_t w = write(fd, "x", 1); fprintf(stderr, "PROBE write_root=%s\n", w < 0 ? "fail" : "WROTE"); close(fd); }
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) fprintf(stderr, "PROBE connect=fail\n");
    else {
        struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_port = htons(80); inet_pton(AF_INET, "93.184.216.34", &a.sin_addr);
        int c = connect(s, (struct sockaddr *)&a, sizeof a); fprintf(stderr, "PROBE connect=%s\n", c < 0 ? "fail" : "CONNECTED"); close(s);
    }
    char *av[] = { "/bin/sh", "-c", "true", NULL };
    execve("/bin/sh", av, NULL);
    fprintf(stderr, "PROBE exec_sh=fail\n");
    int extra = 0; for (char **e = environ; e && *e; e++) if (strcmp(*e, "PWD=/") != 0) extra++; /* bwrap itself sets PWD=/ after --clearenv */ fprintf(stderr, "PROBE env=%d\n", extra);
    rl("rlimit_cpu", RLIMIT_CPU); rl("rlimit_as", RLIMIT_AS); rl("rlimit_fsize", RLIMIT_FSIZE); rl("rlimit_nofile", RLIMIT_NOFILE); rl("rlimit_core", RLIMIT_CORE);
    fprintf(stderr, "PROBE nnp=%d\n", prctl(PR_GET_NO_NEW_PRIVS, 0, 0, 0, 0));
    fflush(stderr);
}
int main(int argc, char **argv) {
    char mode[32] = "ok", line[8192];
    if (argc == 3) { FILE *f = fopen(argv[2], "r"); if (f) { if (fgets(mode, sizeof mode, f)) mode[strcspn(mode, "\r\n")] = 0; fclose(f); } }
    long n = 0, s = 0;
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] == 'B') { printf("R 1\n"); fflush(stdout); escapes(); if (!strcmp(mode, "earlyexit")) return 0; }
        else if (line[0] == 'W') sscanf(line, "W %ld %ld", &n, &s);
        else if (line[0] == 'Q') {
            long i = 0; sscanf(line, "Q %ld", &i);
            if (!strcmp(mode, "badreply")) printf("hello\n");
            else if (!strcmp(mode, "nan")) printf("N %ld nan 1\n", i);
            else if (!strcmp(mode, "negscale")) printf("N %ld 0 -1\n", i);
            else if (!strcmp(mode, "wrongindex")) printf("N %ld 0 1\n", i + 1);
            else if (!strcmp(mode, "longline")) { printf("N %ld 0 ", i); for (int k = 0; k < 5000; k++) putchar('1'); printf("\n"); }
            else printf("N %ld 0 1\n", i);
            fflush(stdout);
        } else if (line[0] == 'X') { if (!strcmp(mode, "extra")) { printf("extra\n"); fflush(stdout); } return 0; }
    }
    return 2;
}

/* nondet_interp.c: a STATIC test "interpreter" for §18 #34. It speaks brw.line.v1 correctly but predicts loc from
 * /dev/urandom, so its PRD1 differs on every run. brw_replay must catch that as FAIL_DIGEST. */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    char line[4200];
    FILE *u = fopen("/dev/urandom", "rb");
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] == 'B') { printf("R 1\n"); fflush(stdout); }
        else if (line[0] == 'Q') {
            long i = 0; sscanf(line, "Q %ld", &i);
            int c = u ? fgetc(u) : 7;
            printf("N %ld %d 1\n", i, c & 3);
            fflush(stdout);
        } else if (line[0] == 'X') return 0;
    }
    return 2;
}

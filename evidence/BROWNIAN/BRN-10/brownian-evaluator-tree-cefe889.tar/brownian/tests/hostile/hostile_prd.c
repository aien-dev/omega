/* §18 hostile cases that arrive as prediction bytes or as wrong predictors, on a real sealed B0-short certification
 * world in a temp directory (dummy freeze digests). Every case must be REJECTED or detected.
 *   #7 NaN, #8 Inf, #9 scale <= 0, #10 huge z, #11 floor gaming, #12 zero variance, #13 huge sd,
 *   #14 variance x4 and /4, #15 mean shift, #16 polynomial overfit, #17 memorization; the #28 mixture-weight row is PENDING (see hostile_leak.c)
 *   defects (PRD1 has no weights: wrong length/index/family stand in), #30 family 1.
 * argv: <checkout root> <pinned omega> */
#include "../harness_fx.h"
#include <math.h>

#define HDR 8
#define REC 24
static void put_u32(uint8_t *p, uint32_t v) { for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static void put_f64(uint8_t *p, double d) { uint64_t u; memcpy(&u, &d, 8); for (int i = 0; i < 8; i++) p[i] = (uint8_t)(u >> (8 * i)); }
static double get_f64(const uint8_t *p) { uint64_t u = 0; for (int i = 7; i >= 0; i--) u = (u << 8) | p[i]; double d; memcpy(&d, &u, 8); return d; }

/* replace the candidate PRD1 of EVERY world with fn(bytes) and compute the gain */
typedef void (*mut_fn)(uint8_t *b, size_t n, void *arg);
static int gain_all(fx_gain_t *x, mut_fn fn, void *arg, tyqr_gain *g, char *why, size_t cap) {
    brw_bytes *save = malloc(x->W * sizeof *save);
    for (size_t w = 0; w < x->W; w++) {
        save[w] = x->prd_m[w];
        brw_bytes m; m.n = save[w].n; m.b = malloc(m.n); memcpy(m.b, save[w].b, m.n);
        fn(m.b, m.n, arg);
        x->prd_m[w] = m;
    }
    int rc = brw_gain_compute(&x->in, g, why, cap);
    for (size_t w = 0; w < x->W; w++) { free(x->prd_m[w].b); x->prd_m[w] = save[w]; }
    free(save);
    return rc;
}
/* one world (0) only */
static int gain_one(fx_gain_t *x, mut_fn fn, void *arg, char *why, size_t cap) {
    brw_bytes save = x->prd_m[0], m;
    m.n = save.n; m.b = malloc(m.n); memcpy(m.b, save.b, m.n);
    fn(m.b, m.n, arg);
    x->prd_m[0] = m;
    tyqr_gain g;
    int rc = brw_gain_compute(&x->in, &g, why, cap);
    free(m.b); x->prd_m[0] = save;
    return rc;
}
typedef struct { int rec; int field; double v; } setf;      /* field 0 = loc, 1 = scale */
static void m_set(uint8_t *b, size_t n, void *a) { setf *s = a; (void)n; put_f64(b + HDR + (size_t)s->rec * REC + 8 + (size_t)s->field * 8, s->v); }
static void m_family(uint8_t *b, size_t n, void *a) { (void)n; (void)a; put_u32(b + HDR + 4, 1); }
static void m_index(uint8_t *b, size_t n, void *a) { (void)n; (void)a; put_u32(b + HDR + REC, 99); }
static void m_swap_index(uint8_t *b, size_t n, void *a) { (void)n; (void)a; put_u32(b + HDR, 5); put_u32(b + HDR + REC, 4); }
static void m_all_scale(uint8_t *b, size_t n, void *a) { double f = *(double *)a; for (size_t o = HDR; o + REC <= n; o += REC) put_f64(b + o + 16, get_f64(b + o + 16) * f); }
static void m_all_loc_shift(uint8_t *b, size_t n, void *a) { (void)a; for (size_t o = HDR; o + REC <= n; o += REC) put_f64(b + o + 8, get_f64(b + o + 8) + get_f64(b + o + 16)); }
static void m_all_scale_to(uint8_t *b, size_t n, void *a) { double v = *(double *)a; for (size_t o = HDR; o + REC <= n; o += REC) put_f64(b + o + 16, v); }
static void m_floor(uint8_t *b, size_t n, void *a) { (void)a; for (size_t o = HDR; o + REC <= n; o += REC) put_f64(b + o + 16, 1e-4); }
static int gain_trunc(fx_gain_t *x, size_t drop, char *why, size_t cap) {
    brw_bytes save = x->prd_m[0];
    brw_bytes m = save; m.n = save.n - drop;
    x->prd_m[0] = m;
    tyqr_gain g; int rc = brw_gain_compute(&x->in, &g, why, cap);
    x->prd_m[0] = save;
    return rc;
}

int main(int argc, char **argv) {
    fx_t fx;
    if (fx_init(&fx, argc, argv)) return 2;
    snprintf(fx.cell, sizeof fx.cell, "B0-regular");   /* 256 points: the reference variance is right here, unlike B0-short */
    int rc = fx_cert(&fx);
    if (rc) { printf("fixture failed: %d %s\n", rc, fx.why); return 2; }
    fx_gain_t x;
    REJECT(fx_gain_load(&fx, &x, BRW_OP_DIFFUSION, BRW_OP_DIFFUSION), 0, "load sealed world (DIFFUSION vs DIFFUSION)");
    char why[BRW_WHY]; tyqr_gain g;
    CHECK(brw_gain_compute(&x.in, &g, why, sizeof why) == 0, "control: unmodified predictions score");
    double nan = NAN, inf = INFINITY;
    setf s;
    s = (setf){ 0, 0, nan };  REJECT(gain_one(&x, m_set, &s, why, sizeof why), TYQ_FAIL_PROTOCOL, "#7 NaN loc");
    s = (setf){ 1, 1, nan };  REJECT(gain_one(&x, m_set, &s, why, sizeof why), TYQ_FAIL_PROTOCOL, "#7 NaN scale");
    s = (setf){ 0, 0, inf };  REJECT(gain_one(&x, m_set, &s, why, sizeof why), TYQ_FAIL_PROTOCOL, "#8 +Inf loc");
    s = (setf){ 0, 0, -inf }; REJECT(gain_one(&x, m_set, &s, why, sizeof why), TYQ_FAIL_PROTOCOL, "#8 -Inf loc");
    s = (setf){ 2, 1, inf };  REJECT(gain_one(&x, m_set, &s, why, sizeof why), TYQ_FAIL_PROTOCOL, "#8 +Inf scale / #13 sd = Inf");
    s = (setf){ 0, 1, 0.0 };  REJECT(gain_one(&x, m_set, &s, why, sizeof why), TYQ_FAIL_PROTOCOL, "#9 scale = 0 / #12 sd = 0");
    s = (setf){ 3, 1, -1.0 }; REJECT(gain_one(&x, m_set, &s, why, sizeof why), TYQ_FAIL_PROTOCOL, "#9 negative scale");
    REJECT(gain_one(&x, m_family, NULL, why, sizeof why), TYQ_FAIL_PROTOCOL, "#30 family 1 (Student-t)");
    REJECT(gain_one(&x, m_index, NULL, why, sizeof why), TYQ_FAIL_PROTOCOL, "PRD1 structure (not #28) wrong index in a record");
    REJECT(gain_one(&x, m_swap_index, NULL, why, sizeof why), TYQ_FAIL_PROTOCOL, "PRD1 structure (not #28) records out of order");
    REJECT(gain_trunc(&x, REC, why, sizeof why), TYQ_FAIL_PROTOCOL, "PRD1 structure (not #28) one record short");
    REJECT(gain_trunc(&x, 5, why, sizeof why), TYQ_FAIL_PROTOCOL, "PRD1 truncated mid-record");
    /* #10: z_c = 1e6 is finite (scored or overflow-bounded); z_c = 1e150 is FAIL_PROTOCOL, never capped */
    s = (setf){ 0, 0, 1e6 };
    rc = gain_one(&x, m_set, &s, why, sizeof why);
    /* R3-30d: the bootstrap accumulator is 128-bit, so a 1e6 sd (~1e17 ub per point) is scored again */
    CHECK(rc == 0, "#10 z_c = 1e6 is scored (no overflow stopgap)");
    s = (setf){ 0, 0, 1e150 };
    REJECT(gain_one(&x, m_set, &s, why, sizeof why), TYQ_FAIL_PROTOCOL, "#10 z_c = 1e150 is FAIL_PROTOCOL (never capped)");
    /* #11 floor gaming: mass far from the data with a tiny sd */
    rc = gain_all(&x, m_floor, NULL, &g, why, sizeof why);
    REJECT(rc, TYQ_FAIL_FLOOR, "#11 probability-floor gaming is FAIL_FLOOR");
    /* #12 a tiny but positive sd is raised and counted, not accepted silently */
    { double v = 1e-300; rc = gain_all(&x, m_all_scale_to, &v, &g, why, sizeof why);
      CHECK(rc == TYQ_FAIL_FLOOR || (rc == 0 && g.t_hi_ub < 0), "#12 sd below sd_min is raised and counted (FAIL_FLOOR or lost T)"); }
    /* #13 huge sd on every point loses T */
    { double v = 1e7; rc = gain_all(&x, m_all_scale_to, &v, &g, why, sizeof why);
      CHECK(rc == 0 && g.t_hi_ub < 0, "#13 sd > 1e6 on all points: T upper < 0"); }
    /* #14 right mean, wrong variance (x4 and /4) */
    { double f = 2.0; rc = gain_all(&x, m_all_scale, &f, &g, why, sizeof why);
      printf("  x4: rc=%d t=%lld [%lld,%lld] units=%s\n", rc, (long long)g.t_ub, (long long)g.t_lo_ub, (long long)g.t_hi_ub, g.unit); CHECK(rc == 0 && g.t_hi_ub < 0, "#14 variance x4: T upper < 0 vs the true-variance model");
      f = 0.5; rc = gain_all(&x, m_all_scale, &f, &g, why, sizeof why);
      CHECK(rc == 0 && g.t_hi_ub < 0, "#14 variance /4: T upper < 0 vs the true-variance model"); }
    /* #15 wrong mean, right variance: shifted by one predictive sd */
    rc = gain_all(&x, m_all_loc_shift, NULL, &g, why, sizeof why);
    CHECK(rc == 0 && g.t_hi_ub < 0, "#15 mean shifted by one sd: T upper < 0");
    fx_gain_free(&x);
    /* #16 polynomial overfit and #17 memorization: real wrong programs vs the DIFFUSION baseline */
    struct { int op; const char *name; } wrong[] = { { BRW_OP_LINEAR_TREND, "#16 LINEAR_TREND" }, { BRW_OP_CUBIC_TREND, "#16 CUBIC_TREND" }, { BRW_OP_LOOKUP_FLOOR, "#17 LOOKUP_FLOOR" } };
    for (int i = 0; i < 3; i++) {
        fx_gain_t y;
        if (fx_gain_load(&fx, &y, BRW_OP_DIFFUSION, wrong[i].op)) { CHECK(0, wrong[i].name); continue; }
        rc = brw_gain_compute(&y.in, &g, why, sizeof why);
        int ok = rc == TYQ_FAIL_FLOOR || (rc == 0 && g.t_hi_ub < 0);
        printf("  %s rc=%d t=%lld [%lld,%lld]\n", wrong[i].name, rc, (long long)g.t_ub, (long long)g.t_lo_ub, (long long)g.t_hi_ub); CHECK(ok, wrong[i].name);
        printf("  %s -> %s%s\n", wrong[i].name, brw_verdict_name(rc), rc == 0 ? (g.t_hi_ub < 0 ? " (T upper < 0)" : " (T upper >= 0)") : "");
        fx_gain_free(&y);
    }
    CHECK(brw_memorizer_charged_bits(10) == 10u * 144u, "#17 stored pairs are charged 144 bits each");
    fx_done(&fx);
    printf("hostile_prd: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

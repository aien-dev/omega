/* §18 #6 held-out leakage (leak oracle, FAIL_LEAK), #5 candidate embeds a guessed seed, and the #28 wire-format check.
 * Spec: §7 "Oracle and leak ceiling" (oracle = true family and parameters, conditioned on the revealed y = (k+0.5) delta,
 * never the latent x; diff_w = L(oracle) - L(M), predictive bits only; FAIL_LEAK iff the world-bootstrap 2.5% bound of the
 * summed diff_w is above 0; INCONCLUSIVE on H-t4, H-meas, H-outlier), §18 rows 5 and 6, §16 (no seed reaches the candidate).
 * Conservative choices: (1) leakage is reported before the floor check; (2) the regenerated worlds must equal the stored
 * ones or the check refuses with FAIL_DIGEST; (3) H-affine is evaluated in the transformed coordinate (loc = c*mean + b,
 * scale = |c| sd) with the true c and b.
 * argv: <checkout root> <pinned omega> <brw_interp> (the third is unused here) */
#include "../harness_fx.h"
#include "turing/ty_prd2.h"
#include <math.h>
#include <ctype.h>

/* PRD1 files for a world set from a per-point rule */
typedef void (*rule_fn)(const brw_traj *tr, size_t i, size_t w, double *loc, double *scale, void *arg);
static int make_prds(const brw_cellinfo *ci, const brw_traj *tr, size_t W, rule_fn fn, void *arg, brw_bytes *out) {

    for (size_t w = 0; w < W; w++) {
        size_t S = brw_world_split(&ci->s, &tr[w]), H = tr[w].count - S;
        tyq_pred *p = calloc(H, sizeof *p);
        for (size_t j = 0; j < H; j++) {
            p[j].index = (uint32_t)(S + j); p[j].family = TYQ_FAM_GAUSS;
            fn(&tr[w], S + j, w, &p[j].loc, &p[j].scale, arg);
        }
        ty_prd prd = { (uint32_t)H, (uint32_t)S, p };
        int rc = ty_prd_encode(&prd, &out[w].b, &out[w].n);
        free(p);
        if (rc != TYQ_OK) return rc;
    }
    return 0;
}
static void free_prds(brw_bytes *b, size_t W) { for (size_t w = 0; w < W; w++) brw_bytes_free(&b[w]); }

/* a candidate that has seen the held-out y_i: loc = the true y_i, scale 2^-9 (above sd_min = 2^-10, so no floor raise) */
static void rule_leak(const brw_traj *tr, size_t i, size_t w, double *loc, double *scale, void *arg) {
    (void)w; (void)arg; *loc = brw_symbol_value(tr->k[i]); *scale = 0x1p-9;
}
/* a candidate that has seen only y_{i-1} and a coarse guess: honest random-walk rule with the true-looking scale 1 */
static void rule_honest(const brw_traj *tr, size_t i, size_t w, double *loc, double *scale, void *arg) {
    (void)w; (void)arg; *loc = brw_symbol_value(tr->k[i - 1]); *scale = 1.0;
}
/* a noisy leaker: the true y_i plus an error of 2^-8, scale 2^-8 */
static void rule_halfleak(const brw_traj *tr, size_t i, size_t w, double *loc, double *scale, void *arg) {
    (void)w; (void)arg; *loc = brw_symbol_value(tr->k[i]) + 0x1p-8; *scale = 0x1p-8;
}
/* the guessed-seed candidate: the held-out symbols of worlds regenerated from a guessed parent (arg = brw_traj *guess) */
static void rule_guess(const brw_traj *tr, size_t i, size_t w, double *loc, double *scale, void *arg) {
    (void)tr; const brw_traj *g = arg; *loc = brw_symbol_value(g[w].k[i]); *scale = fmax(0x1p-9, fabs(brw_symbol_value(g[w].k[i]) - brw_symbol_value(g[w].k[i - 1])));
}

static int gen_worlds(const brw_cellinfo *ci, const char *mode, const uint8_t *parent, size_t plen, brw_traj *out, brw_params *par) {
    char label[128];
    if (brw_world_label(mode, ci->s.name, 0, label, sizeof label) != BRW_OK) return -1;
    for (size_t w = 0; w < ci->W; w++) {
        uint8_t seed[32];
        if (brw_world_seed(label, parent, plen, w, seed) != BRW_OK || brw_world_generate(&ci->s, seed, &out[w], par ? &par[w] : NULL) != BRW_OK) return -1;
    }
    return 0;
}
static void free_worlds(brw_traj *t, size_t W) { for (size_t w = 0; w < W; w++) brw_traj_free(&t[w]); }

/* the oracle, written again here from the hidden parameters (independent of brw_leak_check); H-affine included */
static void rule_oracle(const brw_traj *tr, size_t i, size_t w, double *loc, double *scale, void *arg) {
    struct { const brw_cellinfo *ci; const brw_params *par; } *o = (void *)arg;
    const brw_params *p = &o->par[w];
    double h = tr->t[i] - tr->t[i - 1], yp = brw_symbol_value(tr->k[i - 1]);
    double c = o->ci->s.obs == BRW_OBS_AFFINE ? p->aff_c : 1.0, b = o->ci->s.obs == BRW_OBS_AFFINE ? p->aff_b : 0.0;
    double xp = (yp - b) / c, m, v;
    if (o->ci->s.family == BRW_FAM_D0) { m = xp; v = 2.0 * p->D * h; }
    else if (o->ci->s.family == BRW_FAM_D1) { m = xp + p->mu * h; v = 2.0 * p->D * h; }
    else { double u = 2.0 * p->theta * h; m = xp * exp(-p->theta * h); v = p->sigma * p->sigma * h * (-expm1(-u) / u); }
    *loc = c * m + b; *scale = fabs(c) * sqrt(v);
}

static void leak_cells(fx_t *fx) {
    static const char *const cells[] = { "B0-regular", "B0-irregular", "B0-short", "B1-1", "B2-fast", "H-missing", "H-boundary-D", "H-boundary-theta", "H-affine",
                                         "H-t4", "H-meas", "H-outlier" };
    for (size_t c = 0; c < sizeof cells / sizeof *cells; c++) {
        brw_cellinfo ci;
        if (brw_cellinfo_get(cells[c], &ci)) { CHECK(0, cells[c]); continue; }
        size_t W = ci.W;
        brw_traj *tr = calloc(W, sizeof *tr); brw_params *par = calloc(W, sizeof *par); brw_bytes *pl = calloc(W, sizeof *pl), *ph = calloc(W, sizeof *ph), *po = calloc(W, sizeof *po);
        char lab[160], flag[16], why[BRW_WHY];
        if (gen_worlds(&ci, "dev", (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), tr, par)) { CHECK(0, "generate worlds"); goto next; }
        uint8_t as[32], parent[32]; memset(parent, 7, 32);
        brw_analysis_seed("leak-test", ci.s.name, 0, parent, as);
        int inconclusive = ci.s.obs == BRW_OBS_MEAS_NOISE || ci.s.obs == BRW_OBS_T4_INNOV || ci.s.obs == BRW_OBS_OUTLIER;
        const uint8_t *dp = (const uint8_t *)BRW_DEV_PARENT; size_t dl = strlen(BRW_DEV_PARENT);
        int64_t lo, hi;
        /* the leaker: FAIL_LEAK on every evaluable cell, INCONCLUSIVE (FAIL_LEAK not evaluated) on the three noisy cells */
        make_prds(&ci, tr, W, rule_leak, NULL, pl);
        int rc = brw_leak_check(&ci, "dev", 0, dp, dl, tr, W, pl, as, 2000, flag, &lo, &hi, why, sizeof why);
        snprintf(lab, sizeof lab, "#6 %s: a candidate that saw y_i is %s", ci.s.name, inconclusive ? "INCONCLUSIVE (not evaluated)" : "FAIL_LEAK");
        if (rc == -101) printf("  %s why=%s\n", ci.s.name, why);
        if (inconclusive) { REJECT(rc, 0, lab); CHECK(!strcmp(flag, "INCONCLUSIVE"), lab); }
        else { REJECT(rc, TYQ_FAIL_LEAK, lab); CHECK(!strcmp(flag, "1") && lo > 0, "leak flag 1 with a positive bound"); }
        /* an honest random-walk candidate never beats the oracle */
        make_prds(&ci, tr, W, rule_honest, NULL, ph);
        rc = brw_leak_check(&ci, "dev", 0, dp, dl, tr, W, ph, as, 2000, flag, &lo, &hi, why, sizeof why);
        snprintf(lab, sizeof lab, "#6 control %s: an honest candidate is not a leak", ci.s.name);
        REJECT(rc, 0, lab);
        CHECK(!strcmp(flag, inconclusive ? "INCONCLUSIVE" : "0"), lab);
        if (!inconclusive) {
            /* the oracle correctness check: a candidate that IS the oracle (written independently here) ties it exactly */
            struct { const brw_cellinfo *ci; const brw_params *par; } o = { &ci, par };
            make_prds(&ci, tr, W, rule_oracle, &o, po);
            rc = brw_leak_check(&ci, "dev", 0, dp, dl, tr, W, po, as, 2000, flag, &lo, &hi, why, sizeof why);
            snprintf(lab, sizeof lab, "#6 %s: the independently written oracle ties the harness oracle (interval within 5 micro-bits of 0)", ci.s.name);
            CHECK(rc == 0 && llabs(lo) <= 5 && llabs(hi) <= 5 && !strcmp(flag, "0"), lab);
            if (!(rc == 0 && llabs(lo) <= 5 && llabs(hi) <= 5)) printf("  rc=%d lo=%lld hi=%lld why=%s\n", rc, (long long)lo, (long long)hi, why);
        }
next:;
        free_worlds(tr, W); free_prds(pl, W); free_prds(ph, W); free_prds(po, W);
        free(tr); free(par); free(pl); free(ph); free(po);
    }
    (void)fx;
}

int main(int argc, char **argv) {
    fx_t fx;
    if (fx_init(&fx, argc, argv)) return 2;
    char why[BRW_WHY * 2];
    /* ---- #6 on the sealed B0-regular certification world, through the real gain path ---- */
    snprintf(fx.cell, sizeof fx.cell, "B0-regular");
    int rc = fx_cert(&fx);
    if (rc) { printf("fixture failed: %d %s\n", rc, fx.why); return 2; }
    fx_gain_t x;
    REJECT(fx_gain_load(&fx, &x, BRW_OP_DIFFUSION, BRW_OP_DIFFUSION), 0, "load sealed world");
    tyqr_gain g;
    rc = brw_gain_compute(&x.in, &g, why, sizeof why);
    CHECK(rc == 0 && !strcmp(g.leak_flag, "0"), "#6 control: the honest DIFFUSION run has leak_flag 0 (the oracle was evaluated)");
    {
        size_t W = x.W;
        brw_bytes *leak = calloc(W, sizeof *leak), *half = calloc(W, sizeof *half);
        make_prds(&x.in.ci, x.tr, W, rule_leak, NULL, leak);
        make_prds(&x.in.ci, x.tr, W, rule_halfleak, NULL, half);
        const brw_bytes *save = x.in.prd_m;
        x.in.prd_m = leak;
        rc = brw_gain_compute(&x.in, &g, why, sizeof why);
        REJECT(rc, TYQ_FAIL_LEAK, "#6 a candidate that saw the held-out y_i is FAIL_LEAK");
        CHECK(!strcmp(g.status, "FAIL_LEAK") && !strcmp(g.classification, "STOPPED") && !strcmp(g.leak_flag, "1"), "#6 the record says FAIL_LEAK, STOPPED, leak_flag 1");
        x.in.prd_m = half;
        REJECT(brw_gain_compute(&x.in, &g, why, sizeof why), TYQ_FAIL_LEAK, "#6 a noisy leaker is FAIL_LEAK");
        /* a wrong-scale honest-mean candidate stays FAIL-free */
        x.in.prd_m = save;
        /* the world set must be the world the seed generates: a shifted symbol is refused, never scored */
        int64_t k0 = x.tr[0].k[100];
        x.tr[0].k[100] = k0 + 1;
        REJECT(brw_gain_compute(&x.in, &g, why, sizeof why), TYQ_FAIL_DIGEST, "#6 trajectories that differ from the seed's worlds are refused (FAIL_DIGEST)");
        x.tr[0].k[100] = k0;
        free_prds(leak, W); free_prds(half, W); free(leak); free(half);

        /* ---- #5 guessed seeds ---- */
        brw_cellinfo ci = x.in.ci;
        brw_traj *guess = calloc(W, sizeof *guess);
        uint8_t sp[32];
        brw_sealed_parent(fx.fd.b, sp);
        brw_bytes *pg = calloc(W, sizeof *pg);
        /* (a) a candidate that embeds the DEVELOPMENT parent guess and regenerates worlds from it: no advantage on the sealed worlds */
        CHECK(gen_worlds(&ci, "seal", (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), guess, NULL) == 0, "regenerate worlds from a guessed parent");
        make_prds(&ci, x.tr, W, rule_guess, guess, pg);
        x.in.prd_m = pg;
        rc = brw_gain_compute(&x.in, &g, why, sizeof why);
        CHECK(rc != TYQ_FAIL_LEAK && strcmp(g.leak_flag, "1"), "#5 a wrong guessed seed gives no advantage: no FAIL_LEAK on the sealed worlds"); if (rc == TYQ_FAIL_LEAK || strcmp(g.leak_flag, "0")) printf("  rc=%d flag=%s why=%s\n", rc, g.leak_flag, why);
        free_worlds(guess, W); free_prds(pg, W);
        /* (b) the guess is right (the harness is handed the guessed parent as if sealed): the same candidate beats the oracle */
        CHECK(gen_worlds(&ci, "seal", sp, 32, guess, NULL) == 0, "regenerate worlds from the real sealed parent");
        make_prds(&ci, x.tr, W, rule_guess, guess, pg);
        x.in.prd_m = pg;
        REJECT(brw_gain_compute(&x.in, &g, why, sizeof why), TYQ_FAIL_LEAK, "#5 a candidate holding the true sealed seed beats the oracle: FAIL_LEAK");
        free_worlds(guess, W); free_prds(pg, W); free(guess); free(pg);
        x.in.prd_m = save;
        /* (c) the sealed seed is a function of the qfreeze digest: one flipped bit gives a different parent and other worlds */
        uint8_t d2[32], sp2[32], s1[32], s2[32];
        memcpy(d2, fx.fd.b, 32); d2[31] ^= 1;
        brw_sealed_parent(d2, sp2);
        CHECK(memcmp(sp, sp2, 32) != 0, "#5 sealed parent depends on every bit of the qfreeze digest");
        brw_world_seed("brownian.v1|seal|B0-regular|0", sp, 32, 0, s1); brw_world_seed("brownian.v1|seal|B0-regular|0", sp2, 32, 0, s2);
        CHECK(memcmp(s1, s2, 32) != 0, "#5 world seeds differ under the neighbouring qfreeze digest");
        CHECK(memcmp(sp, BRW_DEV_PARENT, 15) != 0, "#5 the sealed parent is not the development parent");
    }
    fx_gain_free(&x);

    /* ---- #6 on every evaluable and every inconclusive cell (development worlds, direct oracle calls) ---- */
    leak_cells(&fx);

    /* ---- #5 seed scan on text ---- */
    {
        uint8_t seeds[2][32];
        for (int i = 0; i < 32; i++) { seeds[0][i] = (uint8_t)(i * 7 + 3); seeds[1][i] = (uint8_t)(255 - i * 5); }
        char hx[65], t[512];
        for (int i = 0; i < 32; i++) snprintf(hx + 2 * i, 3, "%02x", seeds[1][i]);
        unsigned long long v = 0; for (int i = 7; i >= 0; i--) v = (v << 8) | seeds[1][8 + i];
        snprintf(t, sizeof t, "a list of numbers\nspec hash %s\n", "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef");
        CHECK(brw_seed_scan(t, strlen(t), (const uint8_t (*)[32])seeds, 2, why, sizeof why) == 0, "#5 control: a 64-hex spec hash that is not a seed is accepted");
        snprintf(t, sizeof t, "note %s end", hx);
        REJECT(brw_seed_scan(t, strlen(t), (const uint8_t (*)[32])seeds, 2, why, sizeof why), TYQ_FAIL_PROTOCOL, "#5 a seed as 64 lower-case hex digits");
        for (int i = 0; hx[i]; i++) hx[i] = (char)toupper((unsigned char)hx[i]);
        snprintf(t, sizeof t, "note %s end", hx);
        REJECT(brw_seed_scan(t, strlen(t), (const uint8_t (*)[32])seeds, 2, why, sizeof why), TYQ_FAIL_PROTOCOL, "#5 a seed as 64 upper-case hex digits");
        hx[16] = 0;
        snprintf(t, sizeof t, "note %s end", hx);
        REJECT(brw_seed_scan(t, strlen(t), (const uint8_t (*)[32])seeds, 2, why, sizeof why), TYQ_FAIL_PROTOCOL, "#5 the first 8 bytes of a seed as hex");
        snprintf(t, sizeof t, "s=0x%016llx", v);
        REJECT(brw_seed_scan(t, strlen(t), (const uint8_t (*)[32])seeds, 2, why, sizeof why), TYQ_FAIL_PROTOCOL, "#5 a state word as 0x%016llx");
        snprintf(t, sizeof t, "s=%llu;", v);
        REJECT(brw_seed_scan(t, strlen(t), (const uint8_t (*)[32])seeds, 2, why, sizeof why), TYQ_FAIL_PROTOCOL, "#5 a state word as a decimal number");
        snprintf(t, sizeof t, "s=1%llu;", v);
        CHECK(brw_seed_scan(t, strlen(t), (const uint8_t (*)[32])seeds, 2, why, sizeof why) == 0, "#5 a decimal that merely contains the word digits is not a hit");
        /* every seed label is already refused by the word list (each contains "brownian") */
        static const char *const labels[] = { "brownian.dev.v1", "brownian.seal.v1", "brownian.nullcal.v1", "brownian.eval.v1", "brownian.v1|analysis|certification|B0|0" };
        for (size_t i = 0; i < sizeof labels / sizeof *labels; i++) {
            char lab[160]; snprintf(lab, sizeof lab, "#5 seed label %s is refused by the packet scanner", labels[i]);
            REJECT(brw_scan_text(labels[i], strlen(labels[i]), why, sizeof why), TYQ_FAIL_PROTOCOL, lab);
        }
    }

    /* ---- #28 (mixture weights), PRD2 (omega 2564f57, docs/turing/PRD2_PREDICTION_FORMAT.md), preregistered rule R28-v2:
     * weights summing to 0.9 and 1.1 are refused by WEIGHT_SUM, a negative weight by WEIGHT_RANGE, a well-formed mixture is
     * accepted and scored, and the scorer refuses an unnormalized record instead of renormalizing. The old PRD1 check (every
     * mixture refused by family) is kept as the v1 record. ---- */
    {
        tyq_pred p; memset(&p, 0, sizeof p);
        p.family = TYQ_FAM_MIX; p.K = 2; p.comp[0].pi = 0.5; p.comp[0].loc = 0; p.comp[0].scale = 1;
        p.comp[1].pi = 0.4; p.comp[1].loc = 0; p.comp[1].scale = 1;                    /* weights sum 0.9 */
        REJECT(ty_prd_validate(&p), TYQ_FAIL_PROTOCOL, "#28 PRD1 (v1 record): mixture refused by family");
        int why28 = 0; double bits28 = 0;
        REJECT(ty_prd2_validate(&p, &why28), TYQ_FAIL_PROTOCOL, "#28 PRD2 weights sum 0.9: refused");
        CHECK(why28 == PRD2_R_WEIGHT_SUM, "#28 PRD2 weights sum 0.9: reason is WEIGHT_SUM, not FAMILY");
        REJECT(ty_qcont2_bits(&p, 0, &bits28, NULL), TYQ_FAIL_PROTOCOL, "#28 PRD2 scorer refuses an unnormalized mixture (no renormalization)");
        p.comp[1].pi = 0.6;                                                            /* sum 1.1 */
        REJECT(ty_prd2_validate(&p, &why28), TYQ_FAIL_PROTOCOL, "#28 PRD2 weights sum 1.1: refused");
        CHECK(why28 == PRD2_R_WEIGHT_SUM, "#28 PRD2 weights sum 1.1: reason is WEIGHT_SUM");
        p.comp[1].pi = -0.5; p.comp[0].pi = 1.5;                                       /* sum 1, a negative weight */
        REJECT(ty_prd2_validate(&p, &why28), TYQ_FAIL_PROTOCOL, "#28 PRD2 a negative weight: refused");
        CHECK(why28 == PRD2_R_WEIGHT_RANGE, "#28 PRD2 a negative weight: reason is WEIGHT_RANGE");
        p.comp[0].pi = 0.5; p.comp[1].pi = 0.5;                                        /* well formed */
        CHECK(ty_prd2_validate(&p, &why28) == TYQ_OK && why28 == PRD2_R_NONE, "#28 PRD2 a well-formed mixture is accepted");
        CHECK(ty_qcont2_bits(&p, 123, &bits28, NULL) == TYQ_OK && isfinite(bits28), "#28 PRD2 a well-formed mixture is scored");
        printf("ROW28 PRD2 R28-v2: evaluated (no PENDING)\n");
    }
    fx_done(&fx);
    printf("hostile_leak: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

/* §18 hostile cases on records, data and the run chain, on temp B0-short certification runs with dummy digests.
 *   #18 single seed / unstable claim refused at freeze, #19 tampered candidate, #20 tampered profile,
 *   #21 tampered data (QBW1, PRD1), #22 tampered receipt (qgain, qfreeze, qworld), #23 replay mismatch,
 *   #25 quantizer/profile changed after preregistration, #26 model-description cost omitted.
 * argv: <checkout root> <pinned omega> */
#include "../harness_fx.h"

static int in_set(int rc, int a, int b) { return rc == a || rc == b; }

/* a fresh scored copy of the run: returns the qgain path and the out dir */
static int scored(fx_t *fx, const char *name, char *gp, size_t gpc, char *dir, size_t dc) {
    int rc = fx_score_cert(fx, "DIFFUSION", "IID_NORMAL", name, gp, gpc);
    snprintf(dir, dc, "%s/%s", fx->tmp, name);
    return rc;
}
static void flip_first(const char *dir, const char *prefix, const char *suffix, size_t off) {
    DIR *d = opendir(dir); struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        size_t l = strlen(e->d_name), sl = strlen(suffix);
        if (strncmp(e->d_name, prefix, strlen(prefix)) == 0 && l >= sl && strcmp(e->d_name + l - sl, suffix) == 0) {
            char p[BRW_PATH]; snprintf(p, sizeof p, "%s/%s", dir, e->d_name);
            fx_flip(p, off); break;
        }
    }
    closedir(d);
}
static int count_suffix(const char *dir, const char *suffix) {
    DIR *d = opendir(dir); struct dirent *e; int n = 0;
    if (!d) return 0;
    while ((e = readdir(d)) != NULL) { size_t l = strlen(e->d_name), sl = strlen(suffix); if (l >= sl && !strcmp(e->d_name + l - sl, suffix)) n++; }
    closedir(d);
    return n;
}

int main(int argc, char **argv) {
    fx_t fx;
    if (fx_init(&fx, argc, argv)) return 2;
    char why[BRW_WHY * 2];
    /* ---- #18 refusals at freeze: an unstable or unlengthened claim, a dirty tree, a plug-in disagreement ---- */
    REJECT(fx_prepare(&fx, "certification"), 0, "prepare");
    {
        static const char *bad[][2] = { { "stability_test=FAIL", "stability_test=PASS" }, { "lengthening_test=FAIL", "lengthening_test=PASS" },
            { "tree_dirty=1", "tree_dirty=0" }, { "bayes_plugin_check=STOP", "bayes_plugin_check=AGREE" } };
        brw_bytes mb; brw_slurp(fx.meta, &mb); size_t mbn = mb.n;
        char *orig = malloc(mbn + 1); memcpy(orig, mb.b, mbn); orig[mbn] = 0; brw_bytes_free(&mb);
        for (int i = 0; i < 4; i++) {
            char *m = malloc(mbn + 64); char *at = strstr(orig, bad[i][1]);
            size_t pre = (size_t)(at - orig);
            memcpy(m, orig, pre); strcpy(m + pre, bad[i][0]); strcpy(m + pre + strlen(bad[i][0]), at + strlen(bad[i][1]));
            fx_put(fx.meta, m); free(m);
            fx_t f2 = fx; snprintf(f2.fdir, sizeof f2.fdir, "%s/frz_bad%d", fx.tmp, i); mkdir(f2.fdir, 0755);
            int rc = fx_freeze(&f2, fx.predict_src, NULL);
            REJECT(rc, 0, "a failed pre-seal confirmation is still RECORDED by freeze");
            brw_seal_ctx ctx;
            rc = brw_seal_check(f2.qfreeze, fx.predict_src, fx.cell, &ctx, why, sizeof why);
            REJECT(rc, i == 2 ? TYQ_FAIL_PROTOCOL : BRW_STOPPED, bad[i][0]);
        }
        fx_put(fx.meta, orig); free(orig);
    }
    /* ---- #19 tampered candidate: one byte of the frozen artifact flips; sealed generation refused, nothing written ---- */
    REJECT(fx_freeze(&fx, fx.predict_src, NULL), 0, "freeze");
    {
        char t[BRW_PATH]; snprintf(t, sizeof t, "%s/brw_predict_tampered.c", fx.tmp);
        fx_cp(fx.predict_src, t); fx_flip(t, 100);
        char od[BRW_PATH]; fx_dir(&fx, od, "seal_tampered");
        tyqr_world w; ty_digest wd;
        REJECT(brw_seal(&fx.env, fx.qfreeze, t, fx.cell, od, NULL, &w, &wd, why, sizeof why), TYQ_FAIL_DIGEST, "#19 tampered candidate: sealed generation refused with FAIL_DIGEST");
        CHECK(count_suffix(od, ".qbw") == 0, "#19 no trajectory was written");
        char led[BRW_PATH]; fx_find(fx.fdir, "attempt.", led, sizeof led);
        CHECK(!fx_find(fx.fdir, "attempt.", led, sizeof led), "#19 the refused attempt did not use up the one sealed attempt");
    }
    REJECT(fx_seal(&fx, fx.predict_src), 0, "seal after the refused tampered attempt");
    /* scoring with a tampered predictor source is refused too */
    {
        char t[BRW_PATH], gp[BRW_PATH]; snprintf(t, sizeof t, "%s/brw_predict_tampered.c", fx.tmp);
        char saved[BRW_PATH]; snprintf(saved, sizeof saved, "%s", fx.predict_src);
        snprintf(fx.predict_src, sizeof fx.predict_src, "%s", t);
        REJECT(fx_score_cert(&fx, "DIFFUSION", "IID_NORMAL", "s_t19", gp, sizeof gp), TYQ_FAIL_DIGEST, "#19 score with a tampered predictor source is FAIL_DIGEST");
        snprintf(fx.predict_src, sizeof fx.predict_src, "%s", saved);
    }
    /* ---- #20 tampered profile (a byte of the qprofile in the run) ---- */
    char gp[BRW_PATH], dir[BRW_PATH];
    REJECT(scored(&fx, "s20", gp, sizeof gp, dir, sizeof dir), 0, "score for tamper tests");
    REJECT(brw_verify(gp, fx.thr, fx.predict_src, why, sizeof why), 0, "control: verify passes on the untouched run");
    flip_first(dir, "turing.qprofile.", ".omg0", 30);
    { int rc = brw_verify(gp, fx.thr, fx.predict_src, why, sizeof why);
      CHECK(in_set(rc, TYQ_FAIL_DIGEST, TYQ_FAIL_PROFILE), "#20 tampered qprofile: FAIL_DIGEST or FAIL_PROFILE"); printf("  #20 -> %s\n", brw_verdict_name(rc)); }
    /* ---- #21 tampered data ---- */
    REJECT(scored(&fx, "s21a", gp, sizeof gp, dir, sizeof dir), 0, "score");
    flip_first(dir, "", ".qbw", 20);
    REJECT(brw_verify(gp, fx.thr, fx.predict_src, why, sizeof why), TYQ_FAIL_DIGEST, "#21 tampered QBW1 file: FAIL_DIGEST");
    REJECT(scored(&fx, "s21b", gp, sizeof gp, dir, sizeof dir), 0, "score");
    flip_first(dir, "", ".prd", 12);
    REJECT(brw_verify(gp, fx.thr, fx.predict_src, why, sizeof why), TYQ_FAIL_DIGEST, "#21 tampered PRD1 file: FAIL_DIGEST");
    /* ---- #22 tampered receipts ---- */
    static const char *rec[] = { "turing.qgain.", "turing.qfreeze.", "turing.qworld." };
    for (int i = 0; i < 3; i++) {
        char nm[32]; snprintf(nm, sizeof nm, "s22_%d", i);
        REJECT(scored(&fx, nm, gp, sizeof gp, dir, sizeof dir), 0, "score");
        flip_first(dir, rec[i], ".omg0", 40);
        char lab[64]; snprintf(lab, sizeof lab, "#22 tampered %s: FAIL_DIGEST", rec[i]);
        int rc = brw_verify(gp, fx.thr, fx.predict_src, why, sizeof why);
        CHECK(rc == TYQ_FAIL_DIGEST, lab);
        if (rc != TYQ_FAIL_DIGEST) printf("  got %s\n", brw_verdict_name(rc));
    }
    /* ---- #23 replay mismatch: two stored PRD1 files swapped; then a regenerated world that differs ---- */
    REJECT(scored(&fx, "s23a", gp, sizeof gp, dir, sizeof dir), 0, "score");
    {
        DIR *d = opendir(dir); struct dirent *e; char a[BRW_PATH] = "", b[BRW_PATH] = "";
        while ((e = readdir(d)) != NULL) {
            size_t l = strlen(e->d_name);
            if (l > 4 && !strcmp(e->d_name + l - 4, ".prd")) { if (!a[0]) snprintf(a, sizeof a, "%s/%s", dir, e->d_name); else if (!b[0]) { snprintf(b, sizeof b, "%s/%s", dir, e->d_name); } }
        }
        closedir(d);
        char t[BRW_PATH]; snprintf(t, sizeof t, "%s/swap.tmp", fx.tmp);
        chmod(a, 0644); chmod(b, 0644);
        fx_cp(a, t); fx_cp(b, a); fx_cp(t, b);
        CHECK(a[0] && b[0], "found two stored PRD1 files");
        REJECT(brw_verify(gp, fx.thr, fx.predict_src, why, sizeof why), TYQ_FAIL_DIGEST, "#23 verify: swapped stored PRD1 files differ from the recorded digests");
        REJECT(brw_replay(&fx.env, gp, 1, NULL, why, sizeof why), TYQ_FAIL_DIGEST, "#23 replay: the swapped run does not replay");
    }
    REJECT(scored(&fx, "s23b", gp, sizeof gp, dir, sizeof dir), 0, "score");
    REJECT(brw_replay(&fx.env, gp, 1, NULL, why, sizeof why), 0, "control: replay with regeneration passes on an untouched run");
    /* replay regenerates from the sealed seed: a run whose recorded generator digest differs cannot replay */
    {
        brw_env e2 = fx.env; strncat(e2.cflags, " -DDIFFERENT", sizeof e2.cflags - strlen(e2.cflags) - 1);
        REJECT(brw_replay(&e2, gp, 1, NULL, why, sizeof why), TYQ_FAIL_DIGEST, "#23 replay: a different build (generator digest) does not regenerate the same worlds");
    }
    /* ---- #25 the quantizer/profile changed after preregistration ---- */
    {
        fx_t f2; char *av[3] = { "x", fx.root, fx.omega };
        if (fx_init(&f2, 3, av) == 0) {
            /* a rebuilt profile: same spec, but different thresholds sidecar bytes, so a different qprofile digest */
            f2.thr_text = "T1 lower 0\nT2 lower 7\n";
            char p[BRW_PATH]; snprintf(p, sizeof p, "%s/spec.txt", f2.work);
            REJECT(fx_prepare(&f2, "certification"), 0, "second profile");
            CHECK(!ty_digest_eq(&f2.pd, &fx.pd), "the rebuilt profile has a different digest");
            /* put the rebuilt qprofile bytes under the name the qfreeze expects */
            char name[BRW_PATH], dst[BRW_PATH];
            brw_record_path(name, sizeof name, fx.fdir, "turing.qprofile", &fx.pd);
            fx_cp(f2.qprofile, name);
            (void)dst;
            brw_seal_ctx ctx;
            int rc = brw_seal_check(fx.qfreeze, fx.predict_src, fx.cell, &ctx, why, sizeof why);
            CHECK(in_set(rc, TYQ_FAIL_DIGEST, TYQ_FAIL_PROFILE), "#25 qprofile rebuilt after freeze: FAIL_PROFILE (or FAIL_DIGEST)");
            printf("  #25 -> %s\n", brw_verdict_name(rc));
        }
        fx_done(&f2);
    }
    /* ---- #26 model-description cost omitted: a qgain with L(M) = 0 is refused by verify ---- */
    {
        REJECT(scored(&fx, "s26", gp, sizeof gp, dir, sizeof dir), 0, "score");
        tyqr_gain g; ty_digest gd;
        REJECT(brw_load_gain(gp, &g, &gd, why, sizeof why), 0, "load gain");
        char d2[BRW_PATH]; snprintf(d2, sizeof d2, "%s/s26_omit", fx.tmp);
        char cmd[2 * BRW_PATH + 32]; snprintf(cmd, sizeof cmd, "cp -R '%s' '%s' && chmod -R u+w '%s'", dir, d2, d2);
        CHECK(system(cmd) == 0, "copy the run");
        char oldp[BRW_PATH]; snprintf(oldp, sizeof oldp, "%s/%s", d2, strrchr(gp, '/') + 1);
        unlink(oldp);
        g.lengths[2] = 0;       /* L(M) omitted */
        char np[BRW_PATH];
        int wr = tyqr_gain_write(d2, &g, &gd, np, sizeof np);
        CHECK(wr == TY_OK, "write the doctored qgain");
        REJECT(brw_verify(np, fx.thr, fx.predict_src, why, sizeof why), TYQ_FAIL_DIGEST, "#26 L(M) = 0 in the receipt: verify recomputes L(M) from the canonical bytes and refuses");
        /* the rider dropped the same way: DL(M,D) = DL(M,D) - rider is a different number than the recomputation */
        REJECT(brw_load_gain(gp, &g, &gd, why, sizeof why), 0, "reload");
        g.lengths[2] -= 1000000; g.lengths[5] -= 1000000; g.t_ub += 1000000;   /* rider dropped, kept self-consistent (T = DL(B,D) - DL(M,D)) so the writer accepts it */
        unlink(np);
        wr = tyqr_gain_write(d2, &g, &gd, np, sizeof np);
        CHECK(wr == TY_OK, "write the second doctored qgain");
        REJECT(brw_verify(np, fx.thr, fx.predict_src, why, sizeof why), TYQ_FAIL_DIGEST, "#26 rider dropped from DL(M,D): verify refuses");
    }
    fx_done(&fx);
    printf("hostile_records: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

/* Lane A tests: RNG KATs, streams, uniform, Acklam, D2 KATs, QBW1, symbols, hostile determinism.
 * argv: <sealed repo root> <omega dir> <cflags> <cc> <cc version line> */
#include "brw_cells.h"
#include "brw_normal.h"
#include "brw_qbw.h"
#include "brw_rng.h"
#include "brw_world.h"
#include "sha256.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

static int g_pass, g_fail;
#define CHECK(cond, name) do { if (cond) { g_pass++; } else { g_fail++; printf("FAIL: %s (line %d)\n", name, __LINE__); } } while (0)

/* splitmix64: attributed copy of the static splitmix64 in omega src/algebra/phase_twin.c
 * (test-only; that file is never included or linked). */
static uint64_t splitmix64(uint64_t *x) {
    uint64_t z = (*x += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

static void hex(const uint8_t *d, size_t n, char *o) {
    for (size_t i = 0; i < n; i++) sprintf(o + 2 * i, "%02x", d[i]);
}

/* KAT 1 (plan §9 as amended by R3-17: z row under -ffp-contract=off); a mismatch is a STOP, never edit these values */
static int kat1(void) {
    static const char *const st[4] = { "161922c645ce50e8", "ad760cafa1697b60",
                                       "3501ff44902ca50d", "417cb9a826d831df" };
    static const char *const uh[4] = { "e01d6fafc557f1b9", "bd627ebe4406b404",
                                       "2c23132b578b57db", "2e8b319d4d1f276a" };
    static const double zv[4] = { 1.152534074247803, 0.642680143178051,
                                  -0.94468366251373759, -0.90848344208339182 };
    ClRng r;
    uint64_t x = 0x123456789abcdef0ull;
    int ok = 1;
    char b[32];
    for (int i = 0; i < 4; i++) r.s[i] = splitmix64(&x);
    printf("KAT1 state ");
    for (int i = 0; i < 4; i++) {
        snprintf(b, sizeof b, "%016llx", (unsigned long long)r.s[i]);
        printf("%s ", b);
        if (strcmp(b, st[i]) != 0) ok = 0;
    }
    printf("\n");
    for (int i = 0; i < 4; i++) {
        uint64_t u = cl_rng_next(&r);
        double z = brw_acklam_inv(((double)(u >> 11) + 0.5) / 9007199254740992.0);
        snprintf(b, sizeof b, "%016llx", (unsigned long long)u);
        printf("KAT1 u%d %s z%d %.17g\n", i, b, i, z);
        if (strcmp(b, uh[i]) != 0 || z != zv[i]) ok = 0;
    }
    printf("KAT1 match: %s\n", ok ? "yes" : "NO");
    return ok;
}

static int kat2(void) {
    uint8_t d[32];
    char h[65];
    ClRng r;
    static const char *const exp_d = "6154810633d05c068bf31387e76dc5734f450f966690d53f557cdc67d9672b8b";
    static const uint64_t words[4] = { 0x065cd03306815461ull, 0x73c56de78713f38bull,
                                       0x3fd59066960f454full, 0x8b2b67d967dc7c55ull };
    int ok;
    brw_stream_digest((const uint8_t *)"brownian.eval.v1", 16, "param", d);
    hex(d, 32, h);
    brw_rng_from_digest(&r, d);
    ok = strcmp(h, exp_d) == 0;
    for (int i = 0; i < 4; i++) if (r.s[i] != words[i]) ok = 0;
    printf("KAT2 digest %s\nKAT2 words %016llx %016llx %016llx %016llx\nKAT2 match: %s\n", h,
           (unsigned long long)r.s[0], (unsigned long long)r.s[1],
           (unsigned long long)r.s[2], (unsigned long long)r.s[3], ok ? "yes" : "NO");
    return ok;
}

static void test_streams(void) {
    uint8_t ws[32], ws2[32], a[32], b[32], parent[32];
    ClRng r, r2;
    static const char *const names[] = { "param", "latent", "meas", "missing", "outlier",
        "policy-random", "eig-mc", "bootstrap", "search" };
    char label[96];
    sha256_ctx c;
    uint8_t ref[32], rep8[8] = { 5, 0, 0, 0, 0, 0, 0, 0 };
    memset(parent, 7, 32);
    CHECK(brw_world_label("dev", "B1-3", 12, label, sizeof label) == BRW_OK &&
          strcmp(label, "brownian.v1|dev|B1-3|12") == 0, "label format");
    CHECK(brw_world_label("bad", "B1-3", 0, label, sizeof label) == BRW_E_ARG, "label mode refused");
    CHECK(brw_world_seed(label, parent, 32, 5, ws) == BRW_OK, "world seed");
    sha256_init(&c);
    sha256_update(&c, (const uint8_t *)label, strlen(label));
    sha256_update(&c, (const uint8_t *)"\0", 1);
    sha256_update(&c, parent, 32);
    sha256_update(&c, rep8, 8);
    sha256_final(&c, ref);
    CHECK(memcmp(ws, ref, 32) == 0, "world seed = SHA-256(label||0||parent||rep_le)");
    brw_world_seed(label, parent, 32, 6, ws2);
    CHECK(memcmp(ws, ws2, 32) != 0, "rep changes world seed");
    /* dev parent is the 15 ASCII bytes */
    CHECK(strlen(BRW_DEV_PARENT) == 15, "dev parent 15 bytes");
    /* 9 streams distinct and none a subsequence-copy of another (first 64 outputs differ) */
    for (size_t i = 0; i < 9; i++) {
        CHECK(brw_stream_init(&r, ws, names[i]) == BRW_OK, "stream init");
        for (size_t j = i + 1; j < 9; j++) {
            int same = 0;
            brw_stream_init(&r, ws, names[i]);
            brw_stream_init(&r2, ws, names[j]);
            for (int q = 0; q < 64; q++) if (cl_rng_next(&r) == cl_rng_next(&r2)) same++;
            CHECK(same == 0, "streams independent");
        }
    }
    CHECK(brw_stream_init(&r, ws, "bogus") == BRW_E_ARG, "unknown stream refused");
    brw_stream_digest(ws, 32, "latent", a);
    brw_stream_init(&r, ws, "latent");
    brw_rng_from_digest(&r2, a);
    CHECK(memcmp(r.s, r2.s, sizeof r.s) == 0, "stream init = digest words");
    /* all-zero digest -> s[0] = 1 */
    memset(b, 0, 32);
    brw_rng_from_digest(&r, b);
    CHECK(r.s[0] == 1 && !r.s[1] && !r.s[2] && !r.s[3], "zero state fixup");
    brw_sealed_parent(a, b);
    sha256_init(&c);
    sha256_update(&c, (const uint8_t *)"brownian.seal.v1\0", 17);
    sha256_update(&c, a, 32);
    sha256_final(&c, ref);
    CHECK(memcmp(b, ref, 32) == 0, "sealed parent");
}

static void test_uniform_normal(void) {
    ClRng r;
    double mn = 1.0, mx = 0.0;
    /* extreme raw words: build states so first output is 0 or max is hard; test formula directly */
    double lo = brw_uniform_from_word(0), hi = brw_uniform_from_word(UINT64_MAX);
    CHECK(lo > 0.0 && hi < 1.0, "uniform endpoints strictly inside (0,1)");
    CHECK(brw_uniform_from_word(0x1234567890abcdefull) == ((double)(0x1234567890abcdefull >> 11) + 0.5) / 9007199254740992.0, "uniform formula");
    memset(&r, 0, sizeof r); r.s[0] = 1;
    for (int i = 0; i < 100000; i++) {
        double u = brw_uniform(&r);
        if (u < mn) mn = u;
        if (u > mx) mx = u;
    }
    CHECK(mn > 0.0 && mx < 1.0, "uniform range over 1e5 draws");
    /* Acklam branches */
    CHECK(fabs(brw_acklam_inv(0.5)) < 1e-15, "acklam central 0.5");
    CHECK(fabs(brw_acklam_inv(0.975) - 1.959963984540054) < 1e-8, "acklam central 0.975");
    CHECK(fabs(brw_acklam_inv(0.001) + 3.090232306167813) < 1e-7, "acklam lower tail");
    CHECK(fabs(brw_acklam_inv(0.999) - 3.090232306167813) < 1e-7, "acklam upper tail");
    CHECK(fabs(brw_acklam_inv(0.02425) + brw_acklam_inv(1 - 0.02425)) < 1e-9, "acklam boundary symmetry");
    CHECK(brw_acklam_inv(0.02424) < -1.9 && brw_acklam_inv(0.97576) > 1.9, "acklam tails beyond boundary");
    CHECK(isfinite(brw_acklam_inv(lo)) && isfinite(brw_acklam_inv(hi)), "acklam finite at extreme u");
    /* brw_normal: exactly one draw per call */
    {
        ClRng a, b;
        memset(&a, 0, sizeof a); a.s[0] = 9; a.s[1] = 3; b = a;
        (void)brw_normal(&a);
        (void)cl_rng_next(&b);
        CHECK(memcmp(a.s, b.s, sizeof a.s) == 0, "brw_normal one draw");
    }
}

/* broken transitions for BI tests */
static int broken_euler(brw_family f, const brw_params *p, double x, double h, double *m, double *v) {
    int rc = brw_transition(f, p, x, h, m, v);
    if (rc == BRW_OK && f == BRW_FAM_D2) *m = x * (1.0 - p->theta * h);
    return rc;
}
static int broken_factor2(brw_family f, const brw_params *p, double x, double h, double *m, double *v) {
    int rc = brw_transition(f, p, x, h, m, v);
    if (rc == BRW_OK && f == BRW_FAM_D0) *v = p->D * h;
    return rc;
}
static int broken_dt(brw_family f, const brw_params *p, double x, double h, double *m, double *v) {
    (void)h;
    return brw_transition(f, p, x, 1.0, m, v);
}

static void test_transitions(void) {
    brw_params p = { 1.0, 0.5, 0.0, 0.0, 1.0, 0.0 };
    double m, v;
    CHECK(brw_check_transition_kats(brw_transition) == BRW_OK, "D2 KATs on real transition");
    CHECK(brw_check_transition_kats(broken_euler) == BRW_E_KAT, "BI euler rejected");
    CHECK(brw_check_transition_kats(broken_factor2) == BRW_E_KAT, "BI factor-2 rejected");
    CHECK(brw_check_transition_kats(broken_dt) == BRW_E_KAT, "BI dt rejected");
    CHECK(brw_transition(BRW_FAM_D1, &p, 1.0, 2.0, &m, &v) == BRW_OK && m == 2.0 && v == 4.0, "D1 law");
    CHECK(brw_transition(BRW_FAM_D0, &p, 1.0, 0.0, &m, &v) == BRW_E_REFUSED, "h=0 refused");
    CHECK(brw_transition(BRW_FAM_D0, &p, 1.0, -1.0, &m, &v) == BRW_E_REFUSED, "h<0 refused");
    p.theta = 0.0; p.sigma = 1.0;
    CHECK(brw_transition(BRW_FAM_D2, &p, 1.0, 1.0, &m, &v) == BRW_E_REFUSED, "theta=0 refused");
    p.theta = -1.0;
    CHECK(brw_transition(BRW_FAM_D2, &p, 1.0, 1.0, &m, &v) == BRW_E_REFUSED, "theta<0 refused");
    p.D = 0.0;
    CHECK(brw_transition(BRW_FAM_D0, &p, 1.0, 1.0, &m, &v) == BRW_E_REFUSED, "D=0 refused");
}

static void test_symbols(void) {
    int64_t k;
    const double delta = ldexp(1.0, -20);
    CHECK(brw_quantize(-0.5 * delta, &k) == BRW_OK && k == -1, "symbol KAT x=-0.5 delta -> k=-1");
    CHECK(brw_quantize(0.0, &k) == BRW_OK && k == 0, "x=0 -> k=0");
    CHECK(brw_quantize(delta, &k) == BRW_OK && k == 1, "lower edge inclusive");
    CHECK(brw_quantize(delta * (1.0 - 0x1p-53), &k) == BRW_OK && k == 0, "just below edge");
    CHECK(brw_quantize(-delta, &k) == BRW_OK && k == -1, "negative edge inclusive");
    CHECK(brw_quantize(1.5, &k) == BRW_OK && k == 1572864, "1.5 -> 1572864");
    CHECK(brw_quantize(2147483647.0, &k) == BRW_OK && k == (int64_t)2147483647 << 20, "range max ok");
    CHECK(brw_quantize(2147483648.0, &k) == BRW_E_RANGE, "x = 2^31 refused");
    CHECK(brw_quantize(-2147483648.0, &k) == BRW_E_RANGE, "x = -2^31 refused");
    CHECK(brw_symbol_value(0) == 0.5 * delta && brw_symbol_value(-1) == -0.5 * delta, "symbol value");
    CHECK(brw_symbol_value(1572864) == 1.5 + 0.5 * delta, "symbol value 1.5");
}

static void test_qbw(const uint8_t *seed) {
    brw_cell_spec c;
    brw_traj t, u;
    uint8_t *buf, *bad;
    size_t len;
    char path[] = "/tmp/brw_qbw_test_XXXXXX";
    int fd;
    brw_cell_lookup("B0-irregular", &c);
    CHECK(brw_world_generate(&c, seed, &t, NULL) == BRW_OK && t.count == 256, "generate irregular");
    CHECK(brw_qbw_encode(&t, &buf, &len) == BRW_OK && len == 16 + 16 * 256, "encode size");
    CHECK(memcmp(buf, "QBW1", 4) == 0 && buf[4] == 1 && buf[5] == 0 && buf[8] == 0 && buf[9] == 1, "header LE");
    CHECK(brw_qbw_decode(buf, len, &u) == BRW_OK && u.count == t.count &&
          memcmp(u.t, t.t, 256 * sizeof(double)) == 0 && memcmp(u.k, t.k, 256 * sizeof(int64_t)) == 0,
          "round trip");
    brw_traj_free(&u);
    bad = malloc(len + 1);
    memcpy(bad, buf, len);
    bad[0] = 'X';
    CHECK(brw_qbw_decode(bad, len, &u) == BRW_E_PROTOCOL, "wrong magic refused");
    memcpy(bad, buf, len); bad[4] = 2;
    CHECK(brw_qbw_decode(bad, len, &u) == BRW_E_PROTOCOL, "version 2 refused");
    memcpy(bad, buf, len);
    CHECK(brw_qbw_decode(bad, len - 1, &u) == BRW_E_PROTOCOL, "short size refused");
    bad[len] = 0;
    CHECK(brw_qbw_decode(bad, len + 1, &u) == BRW_E_PROTOCOL, "long size refused");
    CHECK(brw_qbw_decode(bad, 8, &u) == BRW_E_PROTOCOL, "truncated header refused");
    memcpy(bad, buf, len);
    { double nan_ = NAN; memcpy(bad + 16 + 16 * 3, &nan_, 8); }
    CHECK(brw_qbw_decode(bad, len, &u) == BRW_E_PROTOCOL, "NaN t refused");
    memcpy(bad, buf, len);
    memcpy(bad + 16 + 16 * 5, bad + 16 + 16 * 4, 8);
    CHECK(brw_qbw_decode(bad, len, &u) == BRW_E_PROTOCOL, "equal t refused");
    memcpy(bad, buf, len);
    { double inf = INFINITY; memcpy(bad + 16 + 16 * 255, &inf, 8); }
    CHECK(brw_qbw_decode(bad, len, &u) == BRW_E_PROTOCOL, "Inf t refused");
    memcpy(bad, buf, len);
    bad[8] = (uint8_t)(bad[8] + 1);    /* count mismatch */
    CHECK(brw_qbw_decode(bad, len, &u) == BRW_E_PROTOCOL, "count mismatch refused");
    free(bad); free(buf);
    /* file round trip, O_EXCL, mode 0444 */
    fd = mkstemp(path);
    if (fd >= 0) { close(fd); remove(path); }
    CHECK(brw_qbw_write_excl(path, &t) == BRW_OK, "write_excl");
    CHECK(brw_qbw_write_excl(path, &t) == BRW_E_IO, "write_excl refuses existing");
    CHECK(brw_qbw_read(path, &u) == BRW_OK && u.count == 256 && memcmp(u.k, t.k, 256 * 8) == 0, "file round trip");
    brw_traj_free(&u);
    remove(path);
    brw_traj_free(&t);
}

static uint64_t traj_hash(const brw_traj *t) {
    uint64_t h = 1469598103934665603ull;
    for (uint64_t i = 0; i < t->count; i++) {
        uint64_t b;
        memcpy(&b, &t->t[i], 8);
        h = (h ^ b) * 1099511628211ull;
        h = (h ^ (uint64_t)t->k[i]) * 1099511628211ull;
    }
    return h;
}

static void test_cells(void) {
    static const char *const names[] = { "B0-regular", "B0-irregular", "B0-short", "B1-0", "B1-1",
        "B1-3", "B1-4n", "B2-noise", "B2-weak", "B2-clear", "B2-fast", "B2-emerging", "H-meas",
        "H-t4", "H-outlier", "H-missing", "H-boundary-D", "H-boundary-theta", "H-affine",
        "INT-d0", "INT-d1", "INT-d2", "INT-d5", "INT-d8", "CTL-d0", "CTL-d1", "CTL-d2", "CTL-d5", "CTL-d8",
        "INT05-d0", "INT05-d1", "INT05-d2", "INT05-d5", "INT05-d8" };
    uint8_t parent[16], ws[32], ws2[32];
    memcpy(parent, BRW_DEV_PARENT, 15);
    for (size_t i = 0; i < sizeof names / sizeof names[0]; i++) {
        brw_cell_spec c;
        brw_traj a, b, d;
        brw_params pa, pb;
        char label[96];
        int rc;
        CHECK(brw_cell_lookup(names[i], &c) == BRW_OK && strcmp(c.name, names[i]) == 0, "cell lookup");
        brw_world_label("dev", names[i], 0, label, sizeof label);
        brw_world_seed(label, parent, 15, 0, ws);
        brw_world_seed(label, parent, 15, 1, ws2);
        rc = brw_world_generate(&c, ws, &a, &pa);
        CHECK(rc == BRW_OK, "generate");
        if (rc != BRW_OK) continue;
        CHECK(brw_world_generate(&c, ws, &b, &pb) == BRW_OK && a.count == b.count &&
              traj_hash(&a) == traj_hash(&b) && memcmp(&pa, &pb, sizeof pa) == 0, "deterministic");
        CHECK(brw_world_generate(&c, ws2, &d, NULL) == BRW_OK && traj_hash(&a) != traj_hash(&d), "rep differs");
        if (c.obs == BRW_OBS_MISSING) CHECK(a.count < c.n_points && a.count > c.n_points / 2, "rows dropped");
        else CHECK(a.count == c.n_points, "count");
        {
            int inc = 1;
            for (uint64_t j = 1; j < a.count; j++) if (!(a.t[j] > a.t[j - 1])) inc = 0;
            CHECK(inc, "t strictly increasing");
        }
        if (c.grid == BRW_GRID_REGULAR && c.obs != BRW_OBS_MISSING) CHECK(a.t[a.count - 1] == (double)(c.n_points - 1), "regular t");
        if (c.family == BRW_FAM_D1) {
            double want = c.snr_s * sqrt(2.0 * pa.D / BRW_B1_TFULL);
            CHECK(pa.mu == want && pa.D >= BRW_D_MIN && pa.D <= BRW_D_MAX, "B1 mu formula");
        }
        if (c.family == BRW_FAM_D2) CHECK(pa.theta == c.theta && pa.sigma == c.sigma, "D2 params");
        if (c.d_fixed) CHECK(pa.D == c.d_value, "fixed D");
        brw_traj_free(&a); brw_traj_free(&b); brw_traj_free(&d);
    }
    {
        brw_cell_spec c;
        CHECK(brw_cell_lookup("nope", &c) == BRW_E_ARG, "unknown cell refused");
    }
    /* stream-position independence: x0 draw is made even when fixed, so B2-weak's first
       latent innovation equals the one an unfixed twin would see (same seed, same stream) */
    {
        brw_cell_spec c;
        brw_traj a, b;
        brw_cell_lookup("B2-clear", &c);
        brw_world_seed("brownian.v1|dev|B2-clear|0", parent, 15, 0, ws);
        brw_world_generate(&c, ws, &a, NULL);
        c.x0_fixed = 0;
        brw_world_generate(&c, ws, &b, NULL);
        CHECK(a.count == b.count && a.k[0] != b.k[0], "x0 fixed differs from drawn");
        brw_traj_free(&a); brw_traj_free(&b);
    }
}


/* EXP-002C-INT / CTL-d* / INT05-d* cells (spec section 15, R3-36): 128-point stationary prefix, state SET at index 128 to d * sd_stat,
 * H scored rows at indices 129 .. 128 + H; the set-state point and the score of index 128 are not counted */
static void test_int_cells(void) {
    static const double DS[5] = { 0.0, 1.0, 2.0, 5.0, 8.0 };
    static const char *const INT_N[5] = { "INT-d0", "INT-d1", "INT-d2", "INT-d5", "INT-d8" };
    static const char *const CTL_N[5] = { "CTL-d0", "CTL-d1", "CTL-d2", "CTL-d5", "CTL-d8" };
    static const char *const I05_N[5] = { "INT05-d0", "INT05-d1", "INT05-d2", "INT05-d5", "INT05-d8" };
    double sd_stat = sqrt(BRW_B2_SIGMA * BRW_B2_SIGMA / (2.0 * BRW_THETA_EMERGING));
    double sd05 = sqrt(BRW_B2_SIGMA * BRW_B2_SIGMA / (2.0 * BRW_INT05_THETA));
    CHECK(BRW_INT_SD_STAT == sd_stat, "sd_stat constant == sqrt(sigma^2 / (2 theta))");
    CHECK(BRW_INT05_SD_STAT == sd05 && sd05 == 1.0, "theta = 0.5 sd_stat == 1");
    for (int g = 0; g < 3; g++) {
        for (int i = 0; i < 5; i++) {
            const char *nm = g == 0 ? INT_N[i] : g == 1 ? CTL_N[i] : I05_N[i];
            uint32_t H = g == 2 ? 128u : 512u;
            double sd0 = g == 2 ? sd05 : g == 1 ? 1.0 : sd_stat;       /* the prefix x_0 law */
            double setx = DS[i] * (g == 2 ? sd05 : sd_stat);           /* CTL: the absolute displacement d * sqrt(10) */
            brw_cell_spec c; brw_traj a; brw_params pa; char label[96]; uint8_t ws[32]; int64_t kq; ClRng rl;
            CHECK(brw_cell_lookup(nm, &c) == BRW_OK, "INT/CTL/INT05 lookup");
            CHECK(c.grid == BRW_GRID_REGULAR && c.obs == BRW_OBS_EXACT && c.n_points == 128u + 1u + H && c.split == 129u &&
                  c.n_points - c.split == H, "128 prefix + set-state point + H scored rows");
            CHECK(c.set_state == 1 && c.set_x == setx && c.x0_sd == sd0 && !c.x0_fixed, "set-state fields");
            if (g == 0) CHECK(c.family == BRW_FAM_D2 && c.theta == BRW_THETA_EMERGING && c.sigma == 1.0 && !c.d_fixed, "INT law = B2-emerging");
            if (g == 1) CHECK(c.family == BRW_FAM_D0 && c.d_fixed == 1 && c.d_value == 0.5, "CTL law = pure diffusion, D = 0.5");
            if (g == 2) CHECK(c.family == BRW_FAM_D2 && c.theta == 0.5 && c.sigma == 1.0, "INT05 law = theta 0.5, sigma 1");
            brw_world_label("dev", nm, 0, label, sizeof label);
            CHECK(strstr(label, nm) != NULL, "cell name enters the label");
            brw_world_seed(label, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), 0, ws);
            CHECK(brw_world_generate(&c, ws, &a, &pa) == BRW_OK && a.count == c.n_points, "INT generate");
            if (g == 1) CHECK(pa.D == 0.5, "CTL hidden D = 0.5 (2D = sigma^2 = 1)");
            CHECK(brw_quantize(setx, &kq) == BRW_OK && a.k[128] == kq, "index 128 is the quantized set state");
            CHECK(brw_stream_init(&rl, ws, "latent") == BRW_OK && brw_quantize(sd0 * brw_normal(&rl), &kq) == BRW_OK && a.k[0] == kq,
                  "x_0 = sd * z_0 from the latent stream (stationary prefix law)");
            {   /* a = prefix, set state, continuation: the world is not the un-set world (index 129 continues FROM the set state) */
                brw_cell_spec u = c; brw_traj b; u.set_state = 0;
                CHECK(brw_world_generate(&u, ws, &b, NULL) == BRW_OK && b.count == a.count, "un-set twin");
                int same_prefix = 1; for (int j = 0; j < 128; j++) if (a.k[j] != b.k[j]) same_prefix = 0;
                CHECK(same_prefix, "prefix (indices 0..127) is unchanged by the set state (same stream positions)");
                CHECK(setx == 0.0 || a.k[129] != b.k[129], "continuation after the set state differs from the un-set world");
                brw_traj_free(&b);
            }
            brw_traj_free(&a);
        }
    }
    {   /* prefix x_0 has the right spread: mean of (x_0 / sd)^2 over 2000 dev worlds within 10% of 1 */
        for (int g = 0; g < 3; g++) {
            const char *nm = g == 0 ? "INT-d0" : g == 1 ? "CTL-d0" : "INT05-d0";
            brw_cell_spec c; double acc = 0.0; const int NW = 2000;
            brw_cell_lookup(nm, &c);
            for (int w = 0; w < NW; w++) {
                uint8_t ws[32]; char label[96]; ClRng rl;
                brw_world_label("dev", nm, 0, label, sizeof label);
                brw_world_seed(label, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), (uint64_t)w, ws);
                brw_stream_init(&rl, ws, "latent");
                double z = brw_normal(&rl); acc += z * z;
            }
            CHECK(fabs(acc / NW - 1.0) < 0.1, "latent z_0 second moment near 1");
        }
    }
    {   /* d = 8: the first scored transition starts from the set state, mean = set_x * exp(-theta) */
        brw_cell_spec c; brw_traj a; uint8_t ws[32]; char label[96];
        brw_cell_lookup("INT-d8", &c);
        brw_world_label("dev", "INT-d8", 0, label, sizeof label);
        brw_world_seed(label, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), 0, ws);
        brw_world_generate(&c, ws, &a, NULL);
        CHECK(a.k[128] == (int64_t)floor(ldexp(8.0 * sd_stat, 20)), "INT-d8 world 0 k[128] == floor(8 sqrt(10) 2^20)");
        CHECK(brw_world_fit_split(&c, &a) == 128u && brw_world_split(&c, &a) == 129u, "fit split 128, first scored index 129");
        brw_traj_free(&a);
    }
}

static void test_digest(const char *root, const char *omega, const char *cflags, const char *cc,
                        const char *ccv) {
    static const char *const rels[] = {
        "brownian/src/brw_rng.h", "brownian/src/brw_rng.c", "brownian/src/brw_normal.h",
        "brownian/src/brw_normal.c", "brownian/src/brw_world.h", "brownian/src/brw_world.c",
        "brownian/src/brw_qbw.h", "brownian/src/brw_qbw.c", "brownian/src/brw_cells.h",
        "src/crumbline/cl_common.h", "src/crumbline/cl_common.c", "src/sha256.h", "src/sha256.c" };
    const char *roots[13];
    const char *rev[13], *rroots[13];
    uint8_t d1[32], d2[32], d3[32];
    char line[1024], h[65];
    for (int i = 0; i < 13; i++) { roots[i] = (i < 9) ? root : omega; }
    for (int i = 0; i < 13; i++) { rev[i] = rels[12 - i]; rroots[i] = roots[12 - i]; }
    snprintf(line, sizeof line, "%s\n%s", cc, ccv);
    CHECK(brw_generator_digest_rooted(roots, rels, 13, cflags, line, d1) == BRW_OK, "digest");
    CHECK(brw_generator_digest_rooted(rroots, rev, 13, cflags, line, d2) == BRW_OK &&
          memcmp(d1, d2, 32) == 0, "digest independent of list order");
    CHECK(brw_generator_digest_rooted(roots, rels, 13, "-O3", line, d3) == BRW_OK &&
          memcmp(d1, d3, 32) != 0, "digest depends on cflags");
    CHECK(brw_generator_digest_rooted(roots, rels, 13, cflags, "other\ncc", d3) == BRW_OK &&
          memcmp(d1, d3, 32) != 0, "digest depends on compiler");
    hex(d1, 32, h);
    printf("GENERATOR_DIGEST %s (BRW_GEN_VERSION %s)\n", h, BRW_GEN_VERSION);
    CHECK(brw_generator_digest_rooted(roots, rels, 0, cflags, line, d3) == BRW_E_ARG, "digest empty refused");
}


/* EXP-002B Occam sweep cells (spec 14, U10): 124 cells OCC-s<+x.xx>-H<h>, D1 family, mu = s * sqrt(2D/255) */
static int occ_seen, occ_bad_name, occ_bad_shape, occ_bad_mu0, occ_bad_sym;
static void occ_check(const char *nm, double s, unsigned h) {
    char want[48];
    brw_cell_spec c, cn;
    uint8_t ws[32];
    brw_traj a, b;
    brw_params pa, pb;
    occ_seen++;
    snprintf(want, sizeof want, "OCC-s%+.2f-H%u", s, h);
    if (strcmp(want, nm) != 0) occ_bad_name++;
    if (brw_cell_lookup(nm, &c) != BRW_OK || c.family != BRW_FAM_D1 || c.grid != BRW_GRID_REGULAR || c.obs != BRW_OBS_EXACT ||
        c.split != 128 || c.n_points != 128 + h || c.snr_s != s) { occ_bad_shape++; return; }
    brw_world_seed(nm, (const uint8_t *)BRW_DEV_PARENT, 15, 0, ws);
    if (brw_world_generate(&c, ws, &a, &pa) != BRW_OK) { occ_bad_shape++; return; }
    if (s == 0.0 && pa.mu != 0.0) occ_bad_mu0++;
    if (s != 0.0 && fabs(pa.mu - s * sqrt(2.0 * pa.D / 255.0)) > 1e-15 * fabs(pa.mu)) occ_bad_mu0++;
    /* sign symmetry: the same seed with -s gives the same D and the exactly negated mu */
    cn = c; cn.snr_s = -s;
    if (brw_world_generate(&cn, ws, &b, &pb) != BRW_OK || pb.D != pa.D || pb.mu != -pa.mu) occ_bad_sym++;
    else brw_traj_free(&b);
    brw_traj_free(&a);
}
#define OCC_CHECK(nm, s, h) occ_check(nm, s, h);
static void test_occ_cells(void) {
    brw_cell_spec c;
    brw_traj t;
    brw_params p;
    uint8_t ws[32];
    BRW_OCC_LIST(OCC_CHECK)
    CHECK(occ_seen == 124 && BRW_OCC_COUNT == 124, "124 OCC cells in the list");
    CHECK(occ_bad_name == 0, "OCC names are OCC-s<+x.xx>-H<h> with the sign always shown");
    CHECK(occ_bad_shape == 0, "OCC cells are D1, regular, split 128, n_points 128 + H, s stored");
    CHECK(occ_bad_mu0 == 0, "OCC mu = s * sqrt(2D/255); s = 0 gives mu = 0");
    CHECK(occ_bad_sym == 0, "OCC sign symmetry: same seed, -s gives same D and exactly -mu");
    CHECK(brw_cell_lookup("OCC-s+0.00-H128", &c) == BRW_OK && brw_cell_lookup("OCC-s-3.25-H512", &c) == BRW_OK &&
          brw_cell_lookup("OCC-s+6.00-H1024", &c) == BRW_OK && brw_cell_lookup("OCC-s+0.00-H64", &c) != BRW_OK &&
          brw_cell_lookup("OCC-s-0.00-H128", &c) != BRW_OK && brw_cell_lookup("OCC-s+3.00-H128", &c) == BRW_OK, "OCC lookups");
    /* one world: mean increment over the held-out span is mu within a loose tolerance (5 sd of the endpoint noise) */
    brw_cell_lookup("OCC-s+6.00-H1024", &c);
    brw_world_seed("OCC-s+6.00-H1024", (const uint8_t *)BRW_DEV_PARENT, 15, 3, ws);
    if (brw_world_generate(&c, ws, &t, &p) == BRW_OK && t.count == 1152) {
        double span = t.t[1151] - t.t[127];
        double inc = (brw_symbol_value(t.k[1151]) - brw_symbol_value(t.k[127])) / span;
        double sd = sqrt(2.0 * p.D / span);
        CHECK(p.mu > 0.0 && fabs(inc - p.mu) < 5.0 * sd + 1e-3, "OCC world mean increment ~ mu");
        CHECK(fabs(p.mu - 6.0 * sqrt(2.0 * p.D / 255.0)) < 1e-12 * p.mu, "OCC world hidden mu formula");
        brw_traj_free(&t);
    } else CHECK(0, "OCC world generated");
}

int main(int argc, char **argv) {
    uint8_t ws[32];
    int k1, k2;
    if (argc < 6) { fprintf(stderr, "usage: %s root omega cflags cc ccversion\n", argv[0]); return 2; }
    k1 = kat1();
    k2 = kat2();
    if (!k1 || !k2) { printf("STOP: KAT mismatch: report to integrator, never edit the KAT (remaining tests still run)\n"); g_fail++; }
    test_streams();
    test_uniform_normal();
    test_transitions();
    test_symbols();
    brw_world_seed("brownian.v1|dev|B0-irregular|0", (const uint8_t *)BRW_DEV_PARENT, 15, 0, ws);
    test_qbw(ws);
    test_cells();
    test_int_cells();
    test_occ_cells();
    test_digest(argv[1], argv[2], argv[3], argv[4], argv[5]);
    printf("pass %d fail %d\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

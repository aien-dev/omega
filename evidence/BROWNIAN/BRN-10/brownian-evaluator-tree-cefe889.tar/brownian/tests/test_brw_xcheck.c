/* test_brw_xcheck: R3-31 (c). Producer/consumer cross-check of the stop-13 rejection count: `brownian_bench calibrate` (D3,
 * consumer side: reads dev qworld files, counts blocks whose block mean leaves the FROZEN interval) and `brownian_calib
 * coverage --dev` (BRN-5, regenerates the same development worlds in memory) must report identical per-cell rejects and block
 * counts on the same sample and seed. argv: <checkout root> <brownian_bench> <brownian_calib> <scratch dir>. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int g_pass, g_fail;
#define CHECK(cond, name) do { if (cond) { g_pass++; } else { g_fail++; printf("FAIL: %s (line %d)\n", name, __LINE__); } } while (0)

static int sh(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
#include <stdarg.h>
static int sh(const char *fmt, ...) {
    char cmd[4096]; va_list ap;
    va_start(ap, fmt); vsnprintf(cmd, sizeof cmd, fmt, ap); va_end(ap);
    return system(cmd);
}
/* Reads "<cell> <rej> <seen> <ppm>" for cell from calibration.txt; returns 0 on success. */
static int read_calibration(const char *path, const char *cell, unsigned *rej, unsigned *seen) {
    FILE *f = fopen(path, "r"); char line[256]; int rc = -1;
    if (!f) return -1;
    while (fgets(line, sizeof line, f)) {
        char c[64]; unsigned r, s; long p;
        if (sscanf(line, "%63s %u %u %ld", c, &r, &s, &p) == 4 && !strcmp(c, cell)) { *rej = r; *seen = s; rc = 0; }
    }
    fclose(f);
    return rc;
}
static int read_coverage(const char *path, const char *cell, unsigned *rej, unsigned *seen) {
    FILE *f = fopen(path, "r"); char line[512]; int rc = -1;
    if (!f) return -1;
    while (fgets(line, sizeof line, f)) {
        char c[64]; unsigned long long b, r;
        if (sscanf(line, "coverage %63s blocks %llu rejected %llu", c, &b, &r) == 3 && !strcmp(c, cell)) { *rej = (unsigned)r; *seen = (unsigned)b; rc = 0; }
    }
    fclose(f);
    return rc;
}

int main(int argc, char **argv) {
    if (argc != 5) { fprintf(stderr, "usage: test_brw_xcheck <root> <bench> <calib> <scratch>\n"); return 64; }
    const char *root = argv[1], *bench = argv[2], *calib = argv[3], *dir = argv[4];
    static const struct { const char *cell; unsigned blocks; } T[] = { { "B1-0", 60 }, { "B0-regular", 30 }, { "B2-weak", 40 } };
    char d[1024];
    snprintf(d, sizeof d, "%s/xcheck", dir);
    sh("rm -rf '%s' && mkdir -p '%s'", d, d);
    CHECK(sh("cd '%s' && '%s' profile --spec brownian/spec/brownian-profile-v1.md --packet brownian/spec/packet.txt "
             "--thresholds brownian/spec/brw_thr_v1.txt --out '%s/dev' >/dev/null 2>&1", root, bench, d) == 0, "profile written");
    unsigned total_rej = 0;
    for (size_t i = 0; i < sizeof T / sizeof T[0]; i++) {
        unsigned r1 = 0, s1 = 0, r2 = 0, s2 = 0, r1h = 0, s1h = 0, r2h = 0, s2h = 0;
        char p1[1100], p2[1100], p3[1100], p4[1100];
        CHECK(sh("cd '%s' && '%s' dev --cell %s --block 0-%u --out '%s/dev' >/dev/null 2>&1", root, bench, T[i].cell, T[i].blocks - 1, d) == 0, "dev blocks written");
        /* half of the blocks first, then all of them: the counts are per block prefix, so both must match */
        unsigned half = T[i].blocks / 2;
        snprintf(p1, sizeof p1, "%s/cal_%s_all", d, T[i].cell); snprintf(p2, sizeof p2, "%s/cov_%s_all.txt", d, T[i].cell);
        snprintf(p3, sizeof p3, "%s/cal_%s_half", d, T[i].cell); snprintf(p4, sizeof p4, "%s/cov_%s_half.txt", d, T[i].cell);
        sh("cd '%s' && '%s' calibrate --dev-manifest '%s/dev/devman.txt' --blocks %u --out '%s' >/dev/null 2>&1", root, bench, d, T[i].blocks, p1);
        sh("cd '%s' && '%s' calibrate --dev-manifest '%s/dev/devman.txt' --blocks %u --out '%s' >/dev/null 2>&1", root, bench, d, half, p3);
        sh("'%s' -j 2 coverage --dev %s %u > '%s' 2>/dev/null", calib, T[i].cell, T[i].blocks, p2);
        sh("'%s' -j 2 coverage --dev %s %u > '%s' 2>/dev/null", calib, T[i].cell, half, p4);
        char q1[1200], q3[1200]; snprintf(q1, sizeof q1, "%s/calibration.txt", p1); snprintf(q3, sizeof q3, "%s/calibration.txt", p3);
        CHECK(read_calibration(q1, T[i].cell, &r1, &s1) == 0 && read_coverage(p2, T[i].cell, &r2, &s2) == 0, "both tools reported the cell (all blocks)");
        CHECK(read_calibration(q3, T[i].cell, &r1h, &s1h) == 0 && read_coverage(p4, T[i].cell, &r2h, &s2h) == 0, "both tools reported the cell (half)");
        CHECK(s1 == T[i].blocks && s1 == s2 && r1 == r2, "identical block count and rejects (all blocks)");
        CHECK(s1h == half && s1h == s2h && r1h == r2h, "identical block count and rejects (first half of the blocks)");
        printf("  %s: calibrate %u/%u, coverage %u/%u; half: %u/%u vs %u/%u\n", T[i].cell, r1, s1, r2, s2, r1h, s1h, r2h, s2h);
        total_rej += r1;
    }
    CHECK(total_rej > 0, "the sample contains at least one rejected block (the comparison is not vacuous)");
    printf("brw_xcheck tests: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

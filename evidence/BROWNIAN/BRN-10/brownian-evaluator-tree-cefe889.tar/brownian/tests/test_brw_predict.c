/* Lane D1 tests: reference predictors, fit-once scorer glue, refusals, artifact digest.
 * argv: <brownian dir> (the directory holding src/ and design/)
 * Validation: (1) bit-identity with design/brw_dl, (2) B1 s=+3 fit-once gain 2.436 bits/world,
 * (3) every refusal path, (4) SHA-256 of brw_predict.c printed as the certification artifact digest. */
#include "brw_cells.h"
#include "brw_normal.h"
#include "brw_predict.h"
#include "brw_rng.h"
#include "brw_world.h"
#include "sha256.h"
#include "turing/ty_math.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* the design interpreter, compiled with renamed symbols (Makefile: -Dbrwdl_run=dsn_run ...) */
int dsn_assemble(const char *text, uint8_t *out, int *n, char *err, int errcap);
int dsn_check(const uint8_t *code, int n, BrwInfo *info, char *err, int errcap);
int dsn_run(const uint8_t *code, const BrwInfo *info, const double *t, const double *y, int N, int S,
            double *loc, double *scale, const char **why);
void dsn_sha256(const uint8_t *m, size_t n, char hex[65]);

static int g_pass, g_fail;
#define CHECK(cond, name) do { if (cond) { g_pass++; } else { g_fail++; printf("FAIL: %s (line %d)\n", name, __LINE__); } } while (0)

/* Fixed-seed pooled simulation parameters (documented in the report). */
#define SIM_LABEL   "brw.predict.test.b1s3.v1"
#define SIM_WORLDS  100000u
#define SIM_PREQ_WORLDS 3000u
#define SIM_D       0.5           /* v_rate = 2D = 1, as in brw_design.c validation rows */
#define SIM_S       3.0
#define SIM_N       256u
#define SIM_SPLIT   128u
#define EXPECT_FIT_ONCE 2.436     /* R3-15 / DESIGN_CHECK_R2, analytic (Grok R3-4) */
#define EXPECT_PREQ     2.679

static char *slurp(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long z = ftell(f); fseek(f, 0, SEEK_SET);
    char *b = malloc((size_t)z + 1);
    if (b && fread(b, 1, (size_t)z, f) != (size_t)z) { free(b); b = NULL; }
    if (b) b[z] = 0;
    fclose(f);
    return b;
}

static int assemble_text(const char *txt, brw_prog *p) {
    uint8_t code[BRW_MAXBYTES + 16]; int n = 0; char err[128];
    if (brwdl_assemble(txt, code, &n, err, (int)sizeof err)) return -1;
    return brw_prog_from_bytes(code, n, p, NULL, 0) == TYQ_OK ? 0 : -1;
}

/* ---- reference table, byte counts, k, re-assembly from the .brwdl sources ---- */
static void test_table(const char *dir) {
    static const struct { int op; int bytes, k; const char *file; } E[7] = {
        { 1, 23, 2, "iid" }, { 2, 37, 3, "linear_trend" }, { 3, 55, 5, "cubic_trend" }, { 4, 21, 1, "diffusion" },
        { 5, 37, 2, "diffusion_drift" }, { 6, 93, 2, "mean_revert_exact" }, { 7, 10, 0, "lookup_floor" } };
    for (int i = 0; i < 7; i++) {
        brw_prog p; char path[512];
        CHECK(brw_ref_program(E[i].op, &p) == TYQ_OK, "ref program checks");
        CHECK(p.n == E[i].bytes && p.info.bytes == E[i].bytes, "ref byte count");
        CHECK(p.info.k == E[i].k, "ref k");
        CHECK(brw_ref_get(E[i].op)->nbytes == E[i].bytes && brw_ref_get(E[i].op)->k == E[i].k, "ref table entry");
        snprintf(path, sizeof path, "%s/design/ref_programs/%s.brwdl", dir, E[i].file);
        char *txt = slurp(path);
        CHECK(txt != NULL, "read .brwdl source");
        if (txt) {
            uint8_t code[BRW_MAXBYTES + 16]; int n = 0; char err[128];
            CHECK(brwdl_assemble(txt, code, &n, err, (int)sizeof err) == 0, "assemble .brwdl");
            CHECK(n == p.n && memcmp(code, p.bytes, (size_t)n) == 0, "embedded bytes == assembled .brwdl");
            free(txt);
        }
    }
    CHECK(brw_ref_get(0) == NULL && brw_ref_get(8) == NULL && brw_ref_get(-1) == NULL, "ref opcode range");
    brw_prog p;
    CHECK(brw_ref_program(0, &p) == TYQ_E_ARG && brw_ref_program(8, &p) == TYQ_E_ARG, "ref program range refusal");
    /* rider per parameter at n = 127: 3.4943 bits */
    int64_t r = 0;
    CHECK(ty_qcont_rider_ub(1, 127, &r) == TYQ_OK && r == 3494342, "rider k=1 n=127");
    /* stored-pairs memorizer: generic (non-short) pairs cost 18 literal bytes each; charged 144 bits/pair */
    double T[3] = { 3.3125, 7.7, 11.9 }, Y[3] = { 0.1234567, -1.7654321, 2.5555 };
    brw_prog m;
    CHECK(brw_memorizer_build(T, Y, 3, &m) == TYQ_OK, "memorizer builds");
    CHECK(m.info.k == 0 && m.n >= 3 * 18, "memorizer k=0, at least 18 literal bytes per pair");
    CHECK(brw_memorizer_charged_bits(3) == 3u * 144u && BRW_MEMO_PAIR_BITS == 144, "memorizer 144 bits per pair");
    double t[8] = { 0, 1, 2, 3.3125, 4, 7.7, 8, 11.9 }, y[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
    tyq_pred pr[8]; const char *why = "";
    CHECK(brw_predict_fit_once(&m, t, y, 8, 3, pr, &why) == TYQ_OK, "memorizer runs");
    CHECK(pr[0].loc == Y[0] && pr[0].scale == 0x1p-10, "memorizer exact at stored time");
    CHECK(pr[1].loc == 0.0 && pr[1].scale == 1.0, "memorizer default previous value, scale 1");
    CHECK(pr[2].loc == Y[1] && pr[3].loc == 0.0 && pr[4].loc == Y[2], "memorizer other stored pairs");
    CHECK(brw_memorizer_build(NULL, Y, 3, &m) == TYQ_E_ARG && brw_memorizer_build(T, Y, 0, &m) == TYQ_E_ARG &&
          brw_memorizer_build(T, Y, 101, &m) == TYQ_E_ARG, "memorizer arg refusals");
    double bad[1] = { NAN };
    CHECK(brw_memorizer_build(bad, Y, 1, &m) == TYQ_E_ARG, "memorizer NaN refusal");
}


/* ---- spec section 13 item 9: the h = 1 DIFFUSION variant (hostile variant, not an opcode) ---- */
static void test_variant_h1(const char *dir) {
    const brw_variant *v = brw_variant_h1();
    const brw_ref *par = brw_ref_get(BRW_OP_DIFFUSION);
    brw_prog p; char path[512], err[128];
    CHECK(v && v->parent_op == BRW_OP_DIFFUSION && par != NULL, "variant table entry");
    if (!v || !par) return;
    CHECK(brw_prog_from_bytes(v->bytes, v->nbytes, &p, err, sizeof err) == TYQ_OK, "h1 variant passes the BRW-DL checker");
    CHECK(p.n == 17 && p.info.bytes == 17 && v->nbytes == 17, "h1 variant measures 17 bytes (the spec charges 22)");
    CHECK(p.info.k == 1 && v->k == 1 && v->k == par->k, "h1 variant k = 1 = parent k");
    CHECK(v->charged_bytes == par->nbytes + 1 && v->charged_bytes == 22, "h1 variant charged parent bytes + 1 = 22");
    snprintf(path, sizeof path, "%s/design/ref_programs/diffusion_h1.brwdl", dir);
    char *txt = slurp(path);
    CHECK(txt != NULL, "read diffusion_h1.brwdl");
    if (txt) {
        uint8_t code[BRW_MAXBYTES + 16]; int n = 0;
        CHECK(brwdl_assemble(txt, code, &n, err, (int)sizeof err) == 0, "assemble diffusion_h1.brwdl");
        CHECK(n == v->nbytes && memcmp(code, v->bytes, (size_t)n) == 0, "embedded h1 bytes == assembled .brwdl");
        free(txt);
    }
    /* on the unit grid (every gap 1) the variant predicts exactly what DIFFUSION predicts; on B0-irregular it does not */
    brw_prog d; CHECK(brw_ref_program(BRW_OP_DIFFUSION, &d) == TYQ_OK, "load DIFFUSION");
    static const char *const cn[2] = { "B0-regular", "B0-irregular" };
    for (int c = 0; c < 2; c++) {
        brw_cell_spec spec; char label[96]; uint8_t ws[32]; brw_traj tr;
        CHECK(brw_cell_lookup(cn[c], &spec) == BRW_OK && brw_world_label("dev", cn[c], 0, label, sizeof label) == BRW_OK, "h1 cell");
        CHECK(brw_world_seed(label, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), 0, ws) == BRW_OK &&
              brw_world_generate(&spec, ws, &tr, NULL) == BRW_OK, "h1 world");
        size_t N = (size_t)tr.count, S = spec.split; double y[BRW_MAXPOINTS]; tyq_pred a[BRW_MAXPOINTS], b[BRW_MAXPOINTS]; const char *why = "";
        for (size_t i = 0; i < N; i++) y[i] = brw_symbol_value(tr.k[i]);
        CHECK(brw_predict_fit_once(&p, tr.t, y, N, S, a, &why) == TYQ_OK && brw_predict_fit_once(&d, tr.t, y, N, S, b, &why) == TYQ_OK, "h1 and DIFFUSION run");
        size_t same = 0;
        for (size_t i = 0; i < N - S; i++) same += a[i].loc == b[i].loc && a[i].scale == b[i].scale;
        if (c == 0) CHECK(same == N - S, "h1 variant equals DIFFUSION on the unit grid");
        else CHECK(same < N - S, "h1 variant differs from DIFFUSION on the irregular grid");
        brw_traj_free(&tr);
    }
}
/* ---- (1) bit-identity with the design interpreter ---- */
static void test_bit_identical(void) {
    static const char *const cells[] = { "B0-regular", "B0-irregular", "B0-short", "B1-3", "B1-4n", "B2-clear",
                                         "B2-fast", "B2-noise", "H-missing", "H-outlier" };
    long compared = 0, both_fail = 0, mismatches = 0;
    brw_prog progs[8]; int nprog = 0;
    for (int op = 1; op <= 7; op++) { CHECK(brw_ref_program(op, &progs[nprog]) == TYQ_OK, "load ref"); nprog++; }
    double T[3] = { 3.3125, 7.7, 11.9 }, Y[3] = { 0.1234567, -1.7654321, 2.5555 };
    CHECK(brw_memorizer_build(T, Y, 3, &progs[nprog]) == TYQ_OK, "memo for identity"); nprog++;
    for (size_t ci = 0; ci < sizeof cells / sizeof cells[0]; ci++) {
        brw_cell_spec spec;
        CHECK(brw_cell_lookup(cells[ci], &spec) == BRW_OK, "cell lookup");
        for (int w = 0; w < 4; w++) {
            char label[96]; uint8_t ws[32]; brw_traj tr;
            CHECK(brw_world_label("dev", cells[ci], 0, label, sizeof label) == BRW_OK, "label");
            CHECK(brw_world_seed(label, (const uint8_t *)BRW_DEV_PARENT, strlen(BRW_DEV_PARENT), (uint64_t)w, ws) == BRW_OK, "seed");
            CHECK(brw_world_generate(&spec, ws, &tr, NULL) == BRW_OK, "generate");
            size_t N = (size_t)tr.count; double y[BRW_MAXPOINTS];
            for (size_t i = 0; i < N; i++) y[i] = brw_symbol_value(tr.k[i]);
            for (int pi = 0; pi < nprog; pi++) {
                double l1[BRW_MAXPOINTS], s1[BRW_MAXPOINTS], l2[BRW_MAXPOINTS], s2[BRW_MAXPOINTS];
                const char *w1 = "", *w2 = "";
                int r1 = brwdl_run(progs[pi].bytes, &progs[pi].info, tr.t, y, (int)N, (int)spec.split, l1, s1, &w1);
                int r2 = dsn_run(progs[pi].bytes, &progs[pi].info, tr.t, y, (int)N, (int)spec.split, l2, s2, &w2);
                compared++;
                if (r1 != r2) { mismatches++; continue; }
                if (r1) { both_fail++; continue; }
                size_t H = N - spec.split;
                if (memcmp(l1, l2, H * sizeof(double)) || memcmp(s1, s2, H * sizeof(double))) mismatches++;
            }
            brw_traj_free(&tr);
        }
    }
    printf("bit-identity: %ld (program, world) runs compared, %ld both-refused, %ld mismatches\n", compared, both_fail, mismatches);
    CHECK(compared > 200 && mismatches == 0, "src interpreter bit-identical to design/brw_dl");
    /* checker and assembler agree too, and the digests of the program bytes */
    for (int op = 1; op <= 7; op++) {
        BrwInfo a, b; char e[64], h1[65], h2[65];
        CHECK(brwdl_check(progs[op - 1].bytes, progs[op - 1].n, &a, e, sizeof e) == 0 &&
              dsn_check(progs[op - 1].bytes, progs[op - 1].n, &b, e, sizeof e) == 0 && memcmp(&a, &b, sizeof a) == 0, "check identical");
        brwdl_sha256(progs[op - 1].bytes, (size_t)progs[op - 1].n, h1); dsn_sha256(progs[op - 1].bytes, (size_t)progs[op - 1].n, h2);
        CHECK(strcmp(h1, h2) == 0, "program sha identical");
    }
}

/* ---- (2) B1 s=+3 pooled simulation ---- */
typedef struct { double mean, sd, se; long n; } stat;
static stat gain_sim(brw_mode mode, unsigned worlds, int64_t *T_net_out) {
    brw_prog diff, drift;
    CHECK(brw_ref_program(BRW_OP_DIFFUSION, &diff) == TYQ_OK && brw_ref_program(BRW_OP_DIFF_DRIFT, &drift) == TYQ_OK, "load B and M");
    uint8_t dg[32]; ClRng rng;
    brw_stream_digest((const uint8_t *)SIM_LABEL, strlen(SIM_LABEL), "world", dg);
    brw_rng_from_digest(&rng, dg);
    double t[SIM_N]; int64_t k[SIM_N];
    for (unsigned j = 0; j < SIM_N; j++) t[j] = (double)j;
    brw_traj tr = { SIM_N, t, k };
    double mu = SIM_S * sqrt(2.0 * SIM_D / BRW_B1_TFULL), sdv = sqrt(2.0 * SIM_D);
    brw_cell_dl cb, cm;
    CHECK(brw_cell_dl_init(&cb, &diff) == TYQ_OK && brw_cell_dl_init(&cm, &drift) == TYQ_OK, "cell init");
    double sum = 0, sumsq = 0; long n = 0;
    for (unsigned w = 0; w < worlds; w++) {
        double x = 0;
        for (unsigned j = 0; j < SIM_N; j++) {
            if (j) x += mu + sdv * brw_normal(&rng);
            if (brw_quantize(x, &k[j]) != BRW_OK) { CHECK(0, "quantize"); return (stat){0, 0, 0, 0}; }
        }
        brw_world_score sb, sm;
        int a = brw_score_world(&diff, &tr, SIM_SPLIT, mode, &sb), b = brw_score_world(&drift, &tr, SIM_SPLIT, mode, &sm);
        if (a != TYQ_OK || b != TYQ_OK) { CHECK(0, "score world"); return (stat){0, 0, 0, 0}; }
        brw_cell_dl_add(&cb, &sb); brw_cell_dl_add(&cm, &sm);
        double g = (double)(sb.data_ub - sm.data_ub) / (double)TY_UB_PER_BIT;   /* bits per world, positive = DRIFT better */
        sum += g; sumsq += g * g; n++;
    }
    stat s; s.n = n; s.mean = sum / (double)n;
    double var = (sumsq - (double)n * s.mean * s.mean) / (double)(n - 1);
    s.sd = sqrt(var); s.se = s.sd / sqrt((double)n);
    /* integer identity of the cell T: -8e6*(37-21) + worlds*(rider_B - rider_M) + sum(dataB - dataM) */
    int64_t T;
    CHECK(brw_cell_gain(&cb, &cm, &T) == TYQ_OK, "cell gain");
    int64_t rb = 0, rm = 0;
    if (mode == BRW_MODE_FIT_ONCE) { ty_qcont_rider_ub(1, SIM_SPLIT - 1, &rb); ty_qcont_rider_ub(2, SIM_SPLIT - 1, &rm); }
    int64_t want = -8000000LL * (37 - 21) + (int64_t)worlds * (rb - rm) + (cb.data_ub - cm.data_ub);
    CHECK(T == want, "cell T identity: byte term once, riders per world");
    CHECK(cb.bytes_ub == 21 * 8000000LL && cm.bytes_ub == 37 * 8000000LL, "bytes charged once per cell");
    CHECK(cb.worlds == worlds && cm.worlds == worlds, "world count");
    if (T_net_out) *T_net_out = T;
    return s;
}

static void test_sim(void) {
    int64_t T;
    stat s = gain_sim(BRW_MODE_FIT_ONCE, SIM_WORLDS, &T);
    double dz = (s.mean - EXPECT_FIT_ONCE) / s.se;
    printf("B1 s=+3 fit-once gain (DRIFT vs DIFF): %.4f bits/world, se %.4f, worlds %ld, seed label \"%s\" name \"world\", "
           "D=%.2f N=%u split=%u; expected %.3f; (mean-expected)/se = %+.2f\n",
           s.mean, s.se, s.n, SIM_LABEL, SIM_D, SIM_N, SIM_SPLIT, EXPECT_FIT_ONCE, dz);
    printf("  net T per world with bytes and riders: %.4f bits (Grok: 2.436 - 3.494 - bytes term)\n",
           (double)T / (double)TY_UB_PER_BIT / (double)SIM_WORLDS);
    CHECK(fabs(s.mean - EXPECT_FIT_ONCE) <= s.se, "fit-once gain reproduces 2.436 within one standard error");
    /* R3-22a check: fit-once versus prequential agree in sign */
    stat q = gain_sim(BRW_MODE_PREQUENTIAL, SIM_PREQ_WORLDS, NULL);
    stat f = gain_sim(BRW_MODE_FIT_ONCE, SIM_PREQ_WORLDS, NULL);
    printf("R3-22a sign check on %u worlds: fit-once gain %.4f (se %.4f), prequential gain %.4f (se %.4f); expected 2.436 / 2.679\n",
           SIM_PREQ_WORLDS, f.mean, f.se, q.mean, q.se);
    CHECK((f.mean > 0) == (q.mean > 0), "fit-once and prequential agree in sign");
    CHECK(fabs(q.mean - EXPECT_PREQ) <= 3 * q.se, "prequential gain near 2.679");
    CHECK(q.mean > f.mean - 3 * q.se, "prequential gain at least fit-once gain (within noise)");
}

/* ---- prequential mechanics ---- */
static void test_prequential(void) {
    brw_prog iid, ddr;
    CHECK(brw_ref_program(BRW_OP_IID, &iid) == TYQ_OK && brw_ref_program(BRW_OP_DIFF_DRIFT, &ddr) == TYQ_OK, "load");
    enum { N = 40, S = 20 };
    double t[N], y[N]; tyq_pred a[N - S], b[N - S]; const char *why;
    for (int i = 0; i < N; i++) { t[i] = i; y[i] = sin(i * 0.7) + 0.05 * i; }
    for (int pass = 0; pass < 2; pass++) {
        const brw_prog *p = pass ? &ddr : &iid;
        CHECK(brw_predict_fit_once(p, t, y, N, S, a, &why) == TYQ_OK && brw_predict_prequential(p, t, y, N, S, b, &why) == TYQ_OK, "both modes run");
        CHECK(a[0].loc == b[0].loc && a[0].scale == b[0].scale, "first held-out prediction identical (same prefix)");
        CHECK(a[N - S - 1].loc != b[N - S - 1].loc || a[N - S - 1].scale != b[N - S - 1].scale, "later prediction refit");
        CHECK(a[3].index == S + 3 && b[3].index == S + 3 && a[3].family == TYQ_FAM_GAUSS, "index and family");
    }
    /* fit-once never sees held-out values: change y past the split (except revealed y_{i-1}) leaves fit alone;
       a change to a later held-out y changes only later predictions */
    double y2[N]; memcpy(y2, y, sizeof y);
    y2[N - 1] += 100.0;
    tyq_pred c[N - S];
    CHECK(brw_predict_fit_once(&iid, t, y2, N, S, c, &why) == TYQ_OK, "run modified");
    tyq_pred a2[N - S];
    brw_predict_fit_once(&iid, t, y, N, S, a2, &why);
    CHECK(memcmp(a2, c, sizeof(tyq_pred) * (N - S)) == 0, "the last held-out value affects no prediction (only y_{i-1} is revealed)");
}

/* ---- (3) refusal paths ---- */
static void test_refusals(void) {
    brw_prog iid, diff;
    CHECK(brw_ref_program(BRW_OP_IID, &iid) == TYQ_OK && brw_ref_program(BRW_OP_DIFFUSION, &diff) == TYQ_OK, "load");
    enum { N = 12, S = 6 };
    double t[N], y[N]; tyq_pred out[N]; const char *why = "";
    for (int i = 0; i < N; i++) { t[i] = i; y[i] = 0.1 * i * i; }
    CHECK(brw_predict_fit_once(&iid, t, y, N, S, out, &why) == TYQ_OK, "baseline run ok");
    /* empty prefix, no held-out points, too many points, NULLs */
    CHECK(brw_predict_fit_once(&iid, t, y, N, 0, out, &why) == TYQ_E_ARG, "empty prefix refused");
    CHECK(brw_predict_fit_once(&iid, t, y, N, N, out, &why) == TYQ_E_ARG, "no held-out refused");
    CHECK(brw_predict_fit_once(&iid, t, y, N, N + 1, out, &why) == TYQ_E_ARG, "split past end refused");
    CHECK(brw_predict_fit_once(&iid, t, y, BRW_MAXPOINTS + 1, S, out, &why) == TYQ_E_ARG, "N over limit refused");
    CHECK(brw_predict_fit_once(NULL, t, y, N, S, out, &why) == TYQ_E_ARG, "NULL program");
    CHECK(brw_predict_fit_once(&iid, NULL, y, N, S, out, &why) == TYQ_E_ARG, "NULL t");
    CHECK(brw_predict_fit_once(&iid, t, NULL, N, S, out, &why) == TYQ_E_ARG, "NULL y");
    CHECK(brw_predict_fit_once(&iid, t, y, N, S, NULL, &why) == TYQ_E_ARG, "NULL out");
    CHECK(brw_predict_prequential(&iid, t, y, N, 0, out, &why) == TYQ_E_ARG, "prequential empty prefix refused");
    /* non-finite and non-monotone inputs */
    double save = y[2]; y[2] = NAN; CHECK(brw_predict_fit_once(&iid, t, y, N, S, out, &why) == TYQ_E_ARG, "NaN y in prefix"); y[2] = save;
    save = y[9]; y[9] = INFINITY; CHECK(brw_predict_fit_once(&iid, t, y, N, S, out, &why) == TYQ_E_ARG, "Inf y in held-out"); y[9] = save;
    save = t[3]; t[3] = NAN; CHECK(brw_predict_fit_once(&iid, t, y, N, S, out, &why) == TYQ_E_ARG, "NaN t"); t[3] = save;
    save = t[7]; t[7] = -INFINITY; CHECK(brw_predict_fit_once(&iid, t, y, N, S, out, &why) == TYQ_E_ARG, "-Inf t"); t[7] = save;
    save = t[4]; t[4] = t[3]; CHECK(brw_predict_fit_once(&iid, t, y, N, S, out, &why) == TYQ_E_ARG, "zero gap refused"); t[4] = save;
    save = t[8]; t[8] = t[7] - 1; CHECK(brw_predict_fit_once(&iid, t, y, N, S, out, &why) == TYQ_E_ARG, "negative gap refused"); t[8] = save;
    /* program-level failures become FAIL_PROTOCOL */
    brw_prog p;
    CHECK(assemble_text("fit { } predict { prevobs -1 emit_normal }", &p) == 0, "assemble negative-scale program");
    CHECK(brw_predict_fit_once(&p, t, y, N, S, out, &why) == TYQ_FAIL_PROTOCOL, "negative sd rejected");
    CHECK(assemble_text("fit { } predict { prevobs 0 emit_normal }", &p) == 0 &&
          brw_predict_fit_once(&p, t, y, N, S, out, &why) == TYQ_FAIL_PROTOCOL, "zero sd rejected");
    CHECK(assemble_text("fit { } predict { prevobs 0 0 div emit_normal }", &p) == 0 &&
          brw_predict_fit_once(&p, t, y, N, S, out, &why) == TYQ_FAIL_PROTOCOL, "division by zero (NaN/Inf) rejected");
    CHECK(assemble_text("fit { } predict { prevobs 0 log emit_normal }", &p) == 0 &&
          brw_predict_fit_once(&p, t, y, N, S, out, &why) == TYQ_FAIL_PROTOCOL, "log of zero rejected");
    CHECK(assemble_text("fit { } predict { prevobs -1 sqrt emit_normal }", &p) == 0 &&
          brw_predict_fit_once(&p, t, y, N, S, out, &why) == TYQ_FAIL_PROTOCOL, "sqrt of negative rejected");
    CHECK(assemble_text("fit { } predict { 1e300 dup mul 1 emit_normal }", &p) == 0 &&
          brw_predict_fit_once(&p, t, y, N, S, out, &why) == TYQ_FAIL_PROTOCOL, "overflow to Inf rejected");
    CHECK(brw_predict_fit_once(&diff, t, y, 1 + 1, 1, out, &why) == TYQ_FAIL_PROTOCOL, "sum_inc with one prefix point is a protocol failure");
    CHECK(brw_predict_prequential(&p, t, y, N, S, out, &why) == TYQ_FAIL_PROTOCOL, "prequential shares the program refusals");
    /* a program whose fit divides by zero on a constant prefix (DIFFUSION: zero increments -> scale 0) */
    double yc[N]; for (int i = 0; i < N; i++) yc[i] = 1.5;
    CHECK(brw_predict_fit_once(&diff, t, yc, N, S, out, &why) == TYQ_FAIL_PROTOCOL, "zero fitted variance refused");
    /* checker refusals: bad bytes */
    brw_prog q; char err[64];
    const brw_ref *r = brw_ref_get(BRW_OP_IID);
    uint8_t buf[BRW_MAXBYTES + 4];
    CHECK(brw_prog_from_bytes(r->bytes, r->nbytes - 1, &q, err, sizeof err) == TYQ_FAIL_PROTOCOL, "truncated program");
    memcpy(buf, r->bytes, (size_t)r->nbytes); buf[r->nbytes] = 0;
    CHECK(brw_prog_from_bytes(buf, r->nbytes + 1, &q, err, sizeof err) == TYQ_FAIL_PROTOCOL, "trailing byte");
    uint8_t junk[8] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
    CHECK(brw_prog_from_bytes(junk, 8, &q, err, sizeof err) == TYQ_FAIL_PROTOCOL, "junk bytes");
    CHECK(brw_prog_from_bytes(NULL, 8, &q, err, sizeof err) == TYQ_E_ARG && brw_prog_from_bytes(junk, 0, &q, err, sizeof err) == TYQ_E_ARG &&
          brw_prog_from_bytes(junk, BRW_MAXBYTES + 1, &q, err, sizeof err) == TYQ_E_ARG && brw_prog_from_bytes(junk, 8, NULL, err, sizeof err) == TYQ_E_ARG, "from_bytes args");
    /* qint.v1 scorer refusals: NaN/Inf/negative/zero sd, NaN loc */
    tyq_pred pr; int64_t ub; int fh;
    memset(&pr, 0, sizeof pr); pr.family = TYQ_FAM_GAUSS; pr.loc = 0.0;
    double sds[5] = { NAN, INFINITY, -1.0, 0.0, -INFINITY };
    for (int i = 0; i < 5; i++) { pr.scale = sds[i]; CHECK(ty_qcont_point_ub(&pr, 0, &ub, &fh) == TYQ_FAIL_PROTOCOL, "scorer rejects bad sd"); }
    pr.scale = 1.0; pr.loc = NAN; CHECK(ty_qcont_point_ub(&pr, 0, &ub, &fh) == TYQ_FAIL_PROTOCOL, "scorer rejects NaN loc");
    pr.loc = INFINITY; CHECK(ty_qcont_point_ub(&pr, 0, &ub, &fh) == TYQ_FAIL_PROTOCOL, "scorer rejects Inf loc");
    pr.loc = 0.0; pr.scale = 1e-9; fh = 0; CHECK(ty_qcont_point_ub(&pr, 0, &ub, &fh) == TYQ_OK && fh == 1, "tiny sd raised to sd_min and counted");
    /* score_world and cell refusals */
    double tt[8] = { 0, 1, 2, 3, 4, 5, 6, 7 }; int64_t kk[8] = { 0, 1, 2, 3, 4, 5, 6, 7 };
    brw_traj tr = { 8, tt, kk }; brw_world_score ws;
    CHECK(brw_score_world(&iid, &tr, 4, BRW_MODE_FIT_ONCE, &ws) == TYQ_OK && ws.scored == 4, "score_world ok");
    CHECK(brw_score_world(&iid, &tr, 0, BRW_MODE_FIT_ONCE, &ws) == TYQ_E_ARG, "score_world empty prefix");
    CHECK(brw_score_world(&iid, &tr, 8, BRW_MODE_FIT_ONCE, &ws) == TYQ_E_ARG, "score_world no held-out");
    CHECK(brw_score_world(NULL, &tr, 4, BRW_MODE_FIT_ONCE, &ws) == TYQ_E_ARG && brw_score_world(&iid, NULL, 4, BRW_MODE_FIT_ONCE, &ws) == TYQ_E_ARG &&
          brw_score_world(&iid, &tr, 4, BRW_MODE_FIT_ONCE, NULL) == TYQ_E_ARG && brw_score_world(&iid, &tr, 4, (brw_mode)7, &ws) == TYQ_E_ARG, "score_world args");
    kk[6] = INT64_C(1) << 52;
    CHECK(brw_score_world(&iid, &tr, 4, BRW_MODE_FIT_ONCE, &ws) != TYQ_OK, "score_world out-of-range symbol refused");
    kk[6] = 6;
    tt[5] = tt[4];
    CHECK(brw_score_world(&iid, &tr, 4, BRW_MODE_FIT_ONCE, &ws) == TYQ_E_ARG, "score_world non-increasing time");
    brw_cell_dl c; int64_t tot;
    CHECK(brw_cell_dl_init(NULL, &iid) == TYQ_E_ARG && brw_cell_dl_init(&c, NULL) == TYQ_E_ARG, "cell init args");
    CHECK(brw_cell_dl_add(NULL, &ws) == TYQ_E_ARG && brw_cell_dl_add(&c, NULL) == TYQ_E_ARG, "cell add args");
    CHECK(brw_cell_dl_total(NULL, &tot) == TYQ_E_ARG && brw_cell_gain(NULL, &c, &tot) == TYQ_E_ARG, "cell total args");
    brw_cell_dl_init(&c, &iid);
    brw_world_score big = { INT64_MAX, 0, 0, 1 };
    CHECK(brw_cell_dl_add(&c, &big) == TYQ_OK && brw_cell_dl_add(&c, &big) == TYQ_FAIL_PROTOCOL, "cell add overflow refused");
    CHECK(brw_cell_dl_init_bits(&c, UINT64_MAX, 0) == TYQ_FAIL_PROTOCOL, "model bits overflow refused");
    CHECK(brw_predict_artifact_digest("/nonexistent/brw_predict.c", (char[65]){0}) == TYQ_E_IO, "digest of missing file refused");
    CHECK(brw_predict_artifact_digest(NULL, (char[65]){0}) == TYQ_E_ARG, "digest NULL path");
}

/* ---- (4) artifact digest ---- */
static void test_digest(const char *dir) {
    char path[512], hex[65], ref[65];
    snprintf(path, sizeof path, "%s/src/brw_predict.c", dir);
    CHECK(brw_predict_artifact_digest(path, hex) == TYQ_OK, "artifact digest");
    char *txt = slurp(path);
    CHECK(txt != NULL, "read artifact");
    if (txt) {
        uint8_t d[32]; sha256_hash((const uint8_t *)txt, strlen(txt), d);
        for (int i = 0; i < 32; i++) sprintf(ref + 2 * i, "%02x", d[i]);
        CHECK(strcmp(hex, ref) == 0, "digest equals omega sha256 of the same bytes");
        free(txt);
    }
    char kat[65];
    brwdl_sha256((const uint8_t *)"abc", 3, kat);
    CHECK(strcmp(kat, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") == 0, "sha256 KAT abc");
    printf("CERTIFICATION_ARTIFACT_SHA256 brownian/src/brw_predict.c %s\n", hex);
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: test_brw_predict <brownian dir>\n"); return 2; }
    test_table(argv[1]);
    test_variant_h1(argv[1]);
    test_bit_identical();
    test_refusals();
    test_prequential();
    test_sim();
    test_digest(argv[1]);
    printf("brw_predict: %d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
